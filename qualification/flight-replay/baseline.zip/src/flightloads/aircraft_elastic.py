"""Flight-driven illustrative wing bending, with a prescribed moving root."""
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import numpy as np
from .aircraft_workspace import stable_example_definition
from .aircraft_transient import run_transient
from .aircraft_structure import (from_aircraft, transfer_wing_load, generalized_imperial,
    IN_M, LBF_N, MOMENT_NM, PSI_PA, number)
from .beam import Excitation, integrate_modal

SCREEN_LIMITS = dict(deflection_over_span=.02, slope_rad=.05, pitch_rate_over_omega1=.05)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def source_history(definition=None, *, rigid_dt_s=.00025):
    """Generate a rigid history here; arbitrary saved histories are not accepted."""
    d = stable_example_definition() if definition is None else deepcopy(definition)
    rigid_dt_s = number(rigid_dt_s, 'rigid_dt_s', positive=True)
    from_aircraft(d)  # mass/geometry compatibility before propagation
    if not isinstance(d.get('transient_case'), dict):
        raise ValueError('complete flight/transient settings are required')
    d['transient_case']['dt_s'] = rigid_dt_s
    run = run_transient(d)
    return run


def _solve(source, *, young_psi=2e6, elements=32, dt_s=.0005, retained_modes=None):
    """Private coupling for internally generated source_history results."""
    dt_s = number(dt_s, 'dt_s', positive=True)
    d = source['definition']; g = d['geometry']
    wing = from_aircraft(d, young_psi=young_psi, elements=elements)
    b = wing.beam; snapshots = source['snapshots']
    ts = np.array([s['time_s'] for s in snapshots])
    if len(ts)<2:
        raise ValueError('structural response needs two accepted rigid snapshots')
    source_dt = source['settings']['dt_s']
    if dt_s < source_dt or abs(dt_s/source_dt-round(dt_s/source_dt))>1e-9:
        raise ValueError('elastic dt must be an integer multiple of rigid dt')
    duration = float(ts[-1])
    cg = np.asarray(source['mass_properties']['cg_B_in'])
    root = np.array([-(g['wing_le_station_in']+g['wing_chord_in']/2),
        g['wing_root_spacing_in']/2, g['wing_z_in']])
    rho = root-cg
    aero, gravity, acceleration, transfers, rates = [], [], [], [], []
    for s in snapshots:
        omega = np.radians(s['angular_velocity_B_deg_s'])
        alpha = np.radians(s['angular_acceleration_B_deg_s2'])
        if max(abs(omega[[0,2]]).max(), abs(alpha[[0,2]]).max())>1e-8:
            raise ValueError('wing pilot requires longitudinal rigid motion')
        tr = transfer_wing_load(s['aerodynamic']['ledger'][0], panel_span_in=wing.length_in,
            root_spacing_in=g['wing_root_spacing_in'], beam_station_in=-root[0],
            beam_z_in=root[2], cg_B_in=cg)
        transfers.append(tr)
        aero.append(tr['right_uniform_Fz_lbf_per_in'])
        gravity.append(s['gravity_B_in_s2'][2])
        acceleration.append((np.asarray(s['acceleration_CG_B_in_s2'])+
            np.cross(alpha,rho)+np.cross(omega,np.cross(omega,rho)))[2])
        rates.append(float(omega[1]))
    def forcing(t):
        if t < ts[0]-1e-12 or t > ts[-1]+1e-12:
            raise ValueError('cannot extrapolate beyond accepted rigid history')
        p = float(np.interp(t,ts,aero))*LBF_N/IN_M
        gz = float(np.interp(t,ts,gravity))*IN_M
        az = float(np.interp(t,ts,acceleration))*IN_M
        return Excitation(b,b.uniform_load(p+b.mass_per_length_kgpm*gz),base_accel=[az,0.])
    count = len(b.omega_radps) if retained_modes is None else retained_modes
    b.residual_flexibility(count)  # count validation; correction is deliberately OFF
    count = int(count)
    static = b.static_displacement(forcing(0).effective_free)
    q0 = b.modes[:,:count].T@b.mass_free@static
    h = integrate_modal(b,forcing,t_final_s=duration,dt_s=dt_s,retained_modes=count,
        initial_q=q0,residual_correction=False)
    indices = np.searchsorted(ts,h.times_s)
    indices = np.clip(indices,0,len(ts)-1)
    for i,t in enumerate(h.times_s):
        if indices[i]>0 and abs(ts[indices[i]-1]-t)<abs(ts[indices[i]]-t):
            indices[i]-=1
    if np.max(abs(ts[indices]-h.times_s))>1e-10:
        raise ValueError('structural snapshots must have concurrent accepted rigid states')
    return wing,h,dict(root_B_in=root.tolist(),source_indices=indices.tolist(),
        aero_lbf_per_in=np.asarray(aero)[indices].tolist(),gravity_z_in_s2=np.asarray(gravity)[indices].tolist(),
        root_accel_z_in_s2=np.asarray(acceleration)[indices].tolist(),
        pitch_rate_rad_s=np.asarray(rates)[indices].tolist(),transfers=[transfers[i] for i in indices])


def serialize_response(source, wing, history, inputs):
    """Imperial archive; alternating nodal forces/couples retain distinct units."""
    b = wing.beam; a = history.arrays
    u,v,acc = (a[k] for k in ('displacement_free','velocity_free','acceleration_free'))
    full_acc = np.pad(acc,((0,0),(2,0)))
    rigid_acc = a['base_accel']@b.rigid_map.T
    damping = v@b.damping_free.T@b.elastic_extractor
    fields = {}
    for label,value in (('applied_full',a['applied_full']),('negative_rigid_inertia_full',-rigid_acc@b.mass_full.T),
        ('negative_elastic_inertia_full',-full_acc@b.mass_full.T),('negative_damping_full',-damping),
        ('dynamic_residual_free',a['dynamic_residual_free'])):
        fields[label] = generalized_imperial(value)
    fields['aero_full'] = generalized_imperial(np.array([b.uniform_load(p*LBF_N/IN_M) for p in inputs['aero_lbf_per_in']]))
    fields['gravity_full'] = generalized_imperial(np.array([b.uniform_load(b.mass_per_length_kgpm*g*IN_M) for g in inputs['gravity_z_in_s2']]))
    state = {}
    for label,value in (('displacement',u),('velocity',v),('acceleration',acc)):
        state[label+'_transverse']=(value[:,::2]/IN_M).tolist()
        state[label+'_slope']=np.degrees(value[:,1::2]).tolist()
    r = dict(tip_w_in=(u[:,-2]/IN_M).tolist(),
        root_Fz_lbf=(a['root_reaction_z_N']/LBF_N).tolist(),
        root_Mx_in_lbf=(-a['root_reaction_y_Nm']/MOMENT_NM).tolist(),
        root_stress_positive_z_psi=(a['stress_positive_z_Pa'][:,0]/PSI_PA).tolist(),
        mid_stress_positive_z_psi=np.array([wing.recover(row,[wing.length_in/2])['stress_positive_z_psi'][0]
            for row in u]).tolist())
    metrics = dict(deflection_over_span=float(abs(u[:,::2]).max()/(IN_M*wing.length_in)),
        slope_rad=float(abs(u[:,1::2]).max()),
        pitch_rate_over_omega1=float(max(abs(np.asarray(inputs['pitch_rate_rad_s'])))/b.omega_radps[0]))
    within = all(metrics[k]<=limit for k,limit in SCREEN_LIMITS.items())
    source_complete = source['status']=='completed'
    residual = np.asarray(fields['dynamic_residual_free'])
    force_error=float(abs(residual[:,::2]).max());moment_error=float(abs(residual[:,1::2]).max())
    full_modes = history.retained_modes==len(b.omega_radps)
    equation_verified = full_modes and force_error<=1e-7 and moment_error<=1e-6
    result=dict(schema='aircraft-wing-history-v1',definition=source['definition'],
        source_input_sha256=source['input_sha256'],source_history_sha256=digest(source),
        structural_model_id=wing.model_id,structural_config=asdict(wing),
        retained_modes=history.retained_modes,residual_correction=False,
        times_s=history.times_s.tolist(),dt_s=history.requested_dt_s,nodes_in=(b.nodes_m/IN_M).tolist(),
        source_status=source['status'],source_event=source['event'],
        scope_status='within-illustrative-pilot' if within and source_complete else 'outside-pilot-or-incomplete-event',
        screening_metrics=metrics,screening_limits=SCREEN_LIMITS,
        equation_verified=equation_verified,equation_residual_lbf=force_error,equation_residual_in_lbf=moment_error,
        state=state,fields=fields,response=r,response_increment={k:(np.asarray(v)-v[0]).tolist() for k,v in r.items()},
        inputs=inputs,concurrent_rigid_snapshots=[source['snapshots'][i] for i in inputs['source_indices']],
        units=dict(transverse='in; derivatives in/s and in/s^2',slope='deg; derivatives deg/s and deg/s^2',
            fields='alternating lbf and in-lbf; positive couples conjugate to right-wing slope about +x',
            screening_slope='rad, internal approximation metric'),
        limitations='One-way prescribed-root symmetric vertical wing bending; no torsion, fuselage flexibility, local strength, aeroelastic validation or design acceptance.')
    result['history_sha256']=digest(result)
    return result


def run_response(definition=None, **settings):
    source = source_history(definition,rigid_dt_s=settings.pop('rigid_dt_s',.00025))
    return serialize_response(source,*_solve(source,**settings))
