"""Deterministic bounded equilibrium search; see mechanics/CONTROLLER_TRIM.md."""
from copy import deepcopy
import hashlib
import math
from pathlib import Path
import platform
import numpy as np
from .propulsion import available_thrust_lbf
from .aircraft_controller_plant import ControllerPlant
from .aircraft_elastic import digest
from .aircraft_full_angle_field import LIMITATIONS
from .aircraft_transient import G_N
from .conventions import rotation_matrix, attitude_error
from .integration import integrate
from .state import RigidState

MODEL_ID = 'aircraft-controller-trim-v1'
CONTROL_NAMES = ('left_tail_deg', 'right_tail_deg', 'aileron_deg', 'thrust_lbf')
UNKNOWN_NAMES = ('alpha_deg', 'roll_deg') + CONTROL_NAMES
SETTINGS = dict(starts_alpha_deg=[3., 0., 10., -3.], max_iterations=40,
    max_evaluations=2000, internal_goal=1e-9, acceptance=1e-5, fd_step=1e-4,
    residual_units=['m/s^2']*3+['rad/s^2']*3, residual_scales=[1.]*6,
    lstsq_rcond=1e-10, line_factors=[2.**-i for i in range(8)],
    minimum_improvement=1e-14, effectiveness_step_deg=.05, rank_relative_tol=1e-8,
    hold_duration_s=2., max_hold_intervals=24000, max_ledger_intervals=8000000,
    hold_tolerances=[.005, .005, 1e-4, 1e-4],
    hold_error_units=['m', 'm/s', 'rad', 'rad/s'], quaternion_tolerance=1e-12)


def _identity():
    # Hash every Python source in this package: includes all transitive plant,
    # geometry, coefficient, integration and load-recovery dependencies.
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(Path(__file__).parent.glob('*.py'))}
    root = Path(__file__).parent
    hashes.update({str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in sorted(root.rglob('*.json'))})
    return hashes, dict(system=platform.system(), release=platform.release(),
        machine=platform.machine(), python=platform.python_version(), numpy=np.__version__)


def _residual(derivative):
    return np.r_[derivative.vdot_B_mps2, derivative.omegadot_B_radps2]


def _bounds(bench):
    limits = [(-30., 30.), (-45., 45.)]
    limits += [(bench['actuators'][n]['min_deg'], bench['actuators'][n]['max_deg'])
               for n in ('left_tail', 'right_tail', 'aileron')]
    if bench['target']['thrust_mode'] == 'trim':
        limits.append((bench['target']['trim_thrust_min_lbf'], bench['target']['trim_thrust_max_lbf']))
    return np.array(limits, dtype=float).T


class _Search:
    def __init__(self, plant):
        self.plant = plant
        self.bench = plant.inputs['bench']
        self.lo, self.hi = _bounds(self.bench)
        propulsion = plant.propulsion
        if propulsion is not None and self.bench['target']['thrust_mode'] == 'trim':
            # Search only where the propeller map does not clip the command (#209): available
            # thrust falls with speed and axial speed V*cos(alpha) <= V, so this cap is conservative.
            self.hi[-1] = min(self.hi[-1], available_thrust_lbf(self.bench['target']['airspeed_ft_s'], propulsion))
            self.lo[-1] = min(self.lo[-1], self.hi[-1])
        self.evaluations, self.best = 0, None
        self.invalid = {}

    def evaluate(self, x):
        if self.evaluations >= SETTINGS['max_evaluations']:
            return None
        self.evaluations += 1
        controls = dict(zip(CONTROL_NAMES, [float(v) for v in x[2:]]))
        controls.setdefault('thrust_lbf', self.bench['target']['fixed_thrust_lbf'])
        try:
            state = self.plant.initial_state(float(x[0]), float(x[1]))
            field, _, derivative = self.plant.evaluate(state, controls)
            residual = _residual(derivative)
            if not np.all(np.isfinite(residual)):
                raise ValueError('Nonfinite equilibrium accelerations')
        except (ValueError, FloatingPointError, OverflowError) as error:
            reason = str(error)
            self.invalid[reason] = self.invalid.get(reason, 0) + 1
            return None
        result = dict(x=x.copy(), state=state, field=field, derivative=derivative,
                      controls=controls, residual=residual, norm=float(np.linalg.norm(residual)))
        if self.best is None or result['norm'] < self.best['norm']:
            self.best = result
        return result

    def solve(self):
        starts = []
        for alpha in SETTINGS['starts_alpha_deg']:
            x = np.array([alpha, 0., 0., 0., 0., self.bench['target']['fixed_thrust_lbf']][:len(self.lo)])
            x = np.clip(x, self.lo, self.hi)
            current = self.evaluate(x)
            reason, iterations = 'invalid-start', 0
            while current is not None and iterations < SETTINGS['max_iterations']:
                if max(abs(current['residual'])) <= SETTINGS['internal_goal']:
                    reason = 'internal-residual-goal'
                    break
                if self.evaluations >= SETTINGS['max_evaluations']:
                    reason = 'global-evaluation-budget'
                    break
                iterations += 1
                columns = []
                for j in range(len(x)):
                    lower, upper = x.copy(), x.copy()
                    lower[j] = max(self.lo[j], x[j]-SETTINGS['fd_step'])
                    upper[j] = min(self.hi[j], x[j]+SETTINGS['fd_step'])
                    a = self.evaluate(lower) if lower[j] < x[j] else current
                    b = self.evaluate(upper) if upper[j] > x[j] else current
                    if a is None: a, lower = current, x
                    if b is None: b, upper = current, x
                    width = upper[j]-lower[j]
                    if width <= 0:
                        reason = 'unavailable-finite-difference'
                        break
                    columns.append((b['residual']-a['residual'])/width)
                if len(columns) != len(x):
                    break
                jacobian = np.array(columns).T
                step = np.linalg.lstsq(jacobian, -current['residual'], rcond=SETTINGS['lstsq_rcond'])[0]
                blocked = ((x <= self.lo) & (step < 0)) | ((x >= self.hi) & (step > 0))
                if np.any(blocked) and np.any(~blocked):
                    step[blocked] = 0
                    step[~blocked] = np.linalg.lstsq(jacobian[:, ~blocked], -current['residual'],
                                                   rcond=SETTINGS['lstsq_rcond'])[0]
                accepted = None
                for factor in SETTINGS['line_factors']:
                    trial = self.evaluate(np.clip(x+factor*step, self.lo, self.hi))
                    if trial is not None and current['norm']-trial['norm'] > SETTINGS['minimum_improvement']:
                        accepted = trial
                        break
                if accepted is None:
                    reason = 'bounded-line-search-stall'
                    break
                current, x = accepted, accepted['x']
            else:
                if current is not None: reason = 'iteration-budget'
            starts.append(dict(alpha_deg=alpha, iterations=iterations, reason=reason))
            if self.best is not None and max(abs(self.best['residual'])) <= SETTINGS['internal_goal']:
                break
            if self.evaluations >= SETTINGS['max_evaluations']:
                break
        return dict(evaluations=self.evaluations, starts=starts, invalid_trials=self.invalid)


def _effectiveness(plant, best):
    state, controls = best['state'], best['controls']
    bench = plant.inputs['bench']
    columns, methods = [], []
    try:
        for name in CONTROL_NAMES[:3]:
            bounds = bench['actuators'][name.removesuffix('_deg')]
            v = controls[name]
            below, above = v-bounds['min_deg'], bounds['max_deg']-v
            if below > 0 and above > 0:
                h = min(SETTINGS['effectiveness_step_deg'], below, above)
                low, high, method = v-h, v+h, 'central'
            elif above > 0:
                low, high, method = v, v+min(SETTINGS['effectiveness_step_deg'], above), 'forward'
            elif below > 0:
                low, high, method = v-min(SETTINGS['effectiveness_step_deg'], below), v, 'backward'
            else:
                return dict(status='unavailable', reason='No admissible perturbation for '+name)
            a = plant.evaluate(state, dict(controls, **{name: low}))[2].omegadot_B_radps2
            b = plant.evaluate(state, dict(controls, **{name: high}))[2].omegadot_B_radps2
            columns.append(np.degrees(b-a)/(high-low))
            methods.append(dict(control=name, method=method, lower_deg=low, upper_deg=high))
        matrix = np.array(columns).T
        u, s, _ = np.linalg.svd(matrix)
        rank = int(np.sum(s > s[0]*SETTINGS['rank_relative_tol']))
        condition = float(s[0]/s[-1]) if rank == 3 else None
        if condition is not None and not math.isfinite(condition): condition = None
        return dict(status='available', columns=list(CONTROL_NAMES[:3]),
            units='deg/s^2 per deg', matrix=matrix.tolist(), perturbations=methods,
            singular_values=s.tolist(), rank=rank, rank_threshold=float(s[0]*SETTINGS['rank_relative_tol']),
            condition=condition, condition_reason=None if condition is not None else 'Rank deficient',
            unavailable_moment_directions_B=u[:, rank:].T.tolist())
    except (ValueError, np.linalg.LinAlgError, FloatingPointError) as error:
        return dict(status='unavailable', reason=str(error))


def _state_errors(state, reference):
    return [float(max(abs(state.r_CG_N_m-reference.r_CG_N_m))),
        float(max(abs(rotation_matrix(state.q_NB)@state.v_CG_B_mps-
                      rotation_matrix(reference.q_NB)@reference.v_CG_B_mps))),
        float(attitude_error(state.q_NB, reference.q_NB)),
        float(max(abs(state.omega_B_radps-reference.omega_B_radps)))]


def _hold_run(plant, best, times):
    initial, controls = best['state'], best['controls']
    velocity = rotation_matrix(initial.q_NB)@initial.v_CG_B_mps
    history, stage_norm = [], 0.
    reason = None

    def checked(state):
        nonlocal stage_norm
        stage_norm = max(stage_norm, abs(float(np.linalg.norm(state.q_NB))-1))
        if state.r_CG_N_m[2] >= 0:
            raise ValueError('Ground-plane crossing; CG proxy only')
        return plant.evaluate(state, controls)

    def record(t, state):
        field, _, derivative = checked(state)
        loads = plant.recover(state, field, derivative, float(t))
        reference = RigidState(initial.r_CG_N_m+velocity*t, initial.v_CG_B_mps,
                               initial.q_NB, initial.omega_B_radps)
        history.append(dict(time_s=float(t), state_SI=state.to_vector().tolist(),
            residuals=_residual(derivative).tolist(), errors=_state_errors(state, reference),
            quaternion_norm_error=abs(float(np.linalg.norm(state.q_NB))-1),
            loads={k: v for k, v in loads.items() if k not in ('ledger', 'retained_ledger')}))

    state = initial
    try:
        record(0., state)
        for t0, t1 in zip(times[:-1], times[1:]):
            result = integrate(state, plant.mass, float(t1), float(t1-t0),
                lambda t, s, ctx: checked(s)[1], lambda *args: G_N,
                t0=float(t0), max_steps=1)
            state = result.state_at(-1)
            record(t1, state)
    except (ValueError, FloatingPointError, OverflowError, np.linalg.LinAlgError) as error:
        reason = str(error)
    maximum = np.max([r['errors'] for r in history], axis=0).tolist() if history else None
    passed = reason is None and maximum is not None and all(np.array(maximum) <= SETTINGS['hold_tolerances'])
    passed = passed and all(r['loads']['balanced'] and
        r['quaternion_norm_error'] <= SETTINGS['quaternion_tolerance'] for r in history)
    return dict(status='passed' if passed else 'failed',
        reason=reason if reason is not None or passed else 'State-error, quaternion or load-balance tolerance exceeded',
        max_errors=maximum, max_raw_stage_quaternion_norm_error=stage_norm, history=history)


def _hold(plant, best):
    dt = plant.inputs['bench']['timing']['plant_dt_s']
    horizon = SETTINGS['hold_duration_s']
    # Nest the half steps exactly, including any shortened final interval.
    coarse = np.minimum(np.arange(math.ceil(horizon/dt)+1)*dt, horizon)
    fine = np.sort(np.r_[coarse, (coarse[:-1]+coarse[1:])/2])
    intervals = len(coarse)+len(fine)-2
    elements = len(best['field']['ledger'])
    if intervals > SETTINGS['max_hold_intervals'] or elements*intervals > SETTINGS['max_ledger_intervals']:
        return dict(status='not-run-budget', reason='Combined interval or ledger budget exceeded',
                    intervals=intervals, ledger_element_intervals=elements*intervals)
    a, b = _hold_run(plant, best, coarse), _hold_run(plant, best, fine)
    comparisons = [_state_errors(RigidState.from_vector(x['state_SI']), RigidState.from_vector(y['state_SI']))
                   for x, y in zip(a['history'], b['history'][::2])]
    maximum = np.max(comparisons, axis=0).tolist() if comparisons else None
    passed = a['status'] == b['status'] == 'passed' and maximum is not None
    passed = passed and all(np.array(maximum) <= SETTINGS['hold_tolerances'])
    return dict(status='passed' if passed else 'failed', duration_s=horizon, dt_s=dt,
        actual_controls=best['controls'], intervals=intervals, ledger_element_intervals=elements*intervals,
        coarse=a, fine=b, refinement_max_errors=maximum)


def trim_bench(inputs, *, verify_hold=True):
    """Return an immutable-input JSON report. Local failure is not infeasibility proof."""
    if type(verify_hold) is not bool:
        raise ValueError('verify_hold must be bool')
    plant = ControllerPlant(inputs)
    search = _Search(plant)
    diagnostics = search.solve()
    best = search.best
    feasible = best is not None and max(abs(best['residual'])) <= SETTINGS['acceptance']
    candidate = None
    if best is not None:
        state, x, field = best['state'], best['x'], best['field']
        R = rotation_matrix(state.q_NB)
        candidate = dict(unknown_names=list(UNKNOWN_NAMES[:len(x)]), unknown_values=x.tolist(),
            state_SI=state.to_vector().tolist(),
            state_order=['r_CG_N_m[3]', 'v_CG_B_mps[3]', 'q_NB[4]', 'omega_B_radps[3]'],
            alpha_deg=float(x[0]), beta_deg=0., roll_deg=float(x[1]),
            pitch_deg=math.degrees(math.asin(float(np.clip(-R[2, 0], -1, 1)))),
            body_heading_deg=plant.inputs['bench']['target']['heading_deg'],
            air_velocity_B_ft_s=field['velocity_air_B_ft_s'],
            ground_velocity_N_m_s=(R@state.v_CG_B_mps).tolist(), controls=best['controls'],
            residuals=best['residual'].tolist(), residual_units=SETTINGS['residual_units'],
            margins={name: dict(lower=float(v-lo), upper=float(hi-v))
                     for name, v, lo, hi in zip(UNKNOWN_NAMES, x, search.lo, search.hi)},
            within_assumed_domain=field['within_assumed_domain'],
            reference_coverage_gaps=field['reference_coverage_gaps'],
            model_limitations=list(field['limitations'] if plant.aero_dataset.get('load_resolution') == 'component-resultant' else LIMITATIONS),
            thrust_margins_lbf=dict(lower=best['controls']['thrust_lbf']-plant.inputs['bench']['target']['trim_thrust_min_lbf'],
                upper=plant.inputs['bench']['target']['trim_thrust_max_lbf']-best['controls']['thrust_lbf']),
            loads=plant.recover(state, field, best['derivative']))
    hashes, environment = _identity()
    reason = ('All six accelerations meet declared tolerances' if feasible else
              'Local bounded search did not establish equilibrium; not proof of global infeasibility')
    report = dict(schema=MODEL_ID, model_id=MODEL_ID, inputs=plant.inputs,
        inputs_sha256=inputs['inputs_sha256'], implementation_hashes=hashes,
        platform=environment, solver_settings=deepcopy(SETTINGS), verify_hold=verify_hold,
        status='feasible' if feasible else ('model-limit' if best is None else 'not-converged'),
        reason=reason, diagnostics=diagnostics, candidate=candidate,
        effectiveness=_effectiveness(plant, best) if feasible else dict(status='unavailable', reason='No feasible trim'),
        hold=(_hold(plant, best) if verify_hold and feasible else
              dict(status='not-requested' if not verify_hold else 'unavailable', reason='No hold requested' if not verify_hold else 'No feasible trim')))
    report['report_sha256'] = digest(report)
    return report


def replay_trim(report):
    """Recompute exact options; reject stale implementation, platform or result."""
    saved = deepcopy(report)
    expected = saved.pop('report_sha256', None)
    if digest(saved) != expected:
        raise ValueError('Report checksum mismatch')
    hashes, environment = _identity()
    if saved['implementation_hashes'] != hashes or saved['platform'] != environment:
        raise ValueError('Replay requires identical implementation and platform')
    replayed = trim_bench(saved['inputs'], verify_hold=saved['verify_hold'])
    if replayed['report_sha256'] != expected:
        raise ValueError('Replayed report differs')
    return replayed
