"""Bounded physical component-placement screening, not an operating envelope.

Station is aft of the nose in inches. All samples recompute the component CG
and inertia and retrim independently at the Cartesian speed/load-factor grid.
Accepted nodes do not establish acceptance between nodes or outside the search.
"""
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path

from .aircraft_workspace import evaluate_aircraft, resolve_components, validate_definition
from .aircraft_input_limits import FLIGHT_BOUNDS, POSITION_BOUNDS, ACCELERATION_BOUNDS

MODEL_ID = 'symmetric-longitudinal-cg-screen-v1'
MAX_EVALUATIONS = 512
INTEGER_BOUNDS = {'sample_count': (2, 51), 'refinement_steps': (0, 6)}
MARGIN_BOUNDS = (0, 100)
LIST_BOUNDS = {'speeds_ft_s': (5, *FLIGHT_BOUNDS['speed_ft_s']),
               'load_factors': (3, 0.000001, 1+ACCELERATION_BOUNDS[1])}
SETTING_KEYS = {'component_id', 'station_min_in', 'station_max_in', 'sample_count',
                'speeds_ft_s', 'load_factors', 'minimum_static_margin_percent', 'refinement_steps'}
SCOPE = ('Estimated sampled CG screen using unvalidated symmetric longitudinal coefficients. '
         'Numerical trim and a restoring static tendency do not establish dynamic stability, '
         'packaging feasibility, structural acceptance, or an approved flight envelope. '
         'Unsampled intervals and disconnected feasible islands remain unresolved.')



def input_limits():
    fields = {key: dict(type='number', minimum=lo, maximum=hi, unit='count', integer=True, nullable=False)
              for key, (lo, hi) in INTEGER_BOUNDS.items()}
    fields.update({key: dict(type='number', minimum=POSITION_BOUNDS[0], maximum=POSITION_BOUNDS[1], unit='in', nullable=False)
                   for key in ('station_min_in', 'station_max_in')})
    fields['minimum_static_margin_percent'] = dict(type='number', minimum=MARGIN_BOUNDS[0], maximum=MARGIN_BOUNDS[1], unit='%', nullable=False)
    fields['component_id'] = dict(type='string', nonblank=True, description='Select an existing component with a known resolved station')
    for key, (count, lo, hi) in LIST_BOUNDS.items():
        fields[key] = dict(type='array', min_items=1, max_items=count, unique=True,
                           minimum=lo, maximum=hi, unit='ft/s' if key=='speeds_ft_s' else 'load factor n')
    return dict(fields=fields, max_evaluations=MAX_EVALUATIONS, constraints=[
        'Minimum component station must be below maximum. Geometry-derived placement must also remain within numerical coordinate bounds.',
        '(samples + (samples - 1) * refinement steps) * speeds * load factors must not exceed 512 condition evaluations.',
        'The static-margin threshold is an explicit user-selected criterion. Near-neutral and unavailable derivatives do not pass.',
        'Sampled spans and refined transition brackets do not establish acceptance between nodes or an approved CG envelope.'])


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def _number(value, name, lo, hi):
    if type(value) not in (int, float) or not math.isfinite(value) or not lo <= value <= hi:
        raise ValueError(f'{name} must be finite in [{lo}, {hi}]')


def validate_settings(settings):
    if not isinstance(settings, dict) or set(settings) != SETTING_KEYS:
        raise ValueError('CG study settings require exactly the documented fields')
    s = deepcopy(settings)
    if not isinstance(s['component_id'], str) or not s['component_id']:
        raise ValueError('Select a component_id')
    for key in ('station_min_in', 'station_max_in'):
        _number(s[key], key, *POSITION_BOUNDS)
    if s['station_min_in'] >= s['station_max_in']:
        raise ValueError('Minimum component station must be below maximum station')
    for key, (lo, hi) in INTEGER_BOUNDS.items():
        if type(s[key]) is not int or not lo <= s[key] <= hi:
            raise ValueError(f'{key} must be an integer in [{lo}, {hi}]')
    _number(s['minimum_static_margin_percent'], 'minimum_static_margin_percent', *MARGIN_BOUNDS)
    for key, (count, lo, hi) in LIST_BOUNDS.items():
        values = s[key]
        if not isinstance(values, list) or not 1 <= len(values) <= count:
            raise ValueError(f'{key} requires 1 to {count} distinct values')
        for value in values:
            _number(value, key, lo, hi)
        if len(set(values)) != len(values):
            raise ValueError(f'{key} must contain distinct values')
    budget = (s['sample_count']+(s['sample_count']-1)*s['refinement_steps']) * len(s['speeds_ft_s']) * len(s['load_factors'])
    if budget > MAX_EVALUATIONS:
        raise ValueError(f'CG study worst-case condition evaluations {budget} exceed {MAX_EVALUATIONS}; reduce samples, conditions or refinement')
    return s, budget


def relocate_component(definition, component_id, station_in):
    """Return a physical realization, preserving shape, mass and manual records."""
    d = deepcopy(definition)
    raw = next((c for c in d['components'] if c['id'] == component_id), None)
    resolved = next((c for c in resolve_components(d) if c['id'] == component_id), None)
    if raw is None or resolved['station_in'] is None:
        raise ValueError('Selected component must exist with a known resolved station')
    if raw.get('cg_source', 'manual') == 'geometry':
        raw['placement']['forward_station_in'] += station_in-resolved['station_in']
    else:
        raw['station_in'] = station_in
    validate_definition(d)
    return d


def constraint_outcome(flight, minimum_margin):
    """Keep failed-search and unavailable-derivative reasons distinct."""
    trim = (flight or {}).get('trim')
    static = (flight or {}).get('static_stability', {}).get('trim')
    reasons = []
    if not trim:
        reasons.append('Trim unavailable: '+str((flight or {}).get('status', 'missing flight inputs')))
    elif not trim['feasible']:
        reasons.append('No feasible trim found within the assumed model')
        if not trim['converged']:
            reasons.append('Trim force/moment residual tolerance not met')
        if trim['control_at_limit']:
            reasons.append('Trim ruddervator at travel limit')
        reasons.extend(trim['domain_violations'])
    if not static or static.get('status') != 'valid':
        reasons.append('Static derivative unavailable: '+str((static or {}).get('status', 'unavailable')))
    else:
        if static['classification'] != 'stable':
            reasons.append('Static tendency is '+static['classification'])
        if static['static_margin_percent'] < minimum_margin:
            reasons.append(f"Static margin {static['static_margin_percent']:.6g}% is below selected {minimum_margin:.6g}% criterion")
    compact_trim = None if trim is None else {key: deepcopy(value) for key, value in trim.items() if key != 'predicted'}
    return dict(accepted=not reasons, reasons=reasons, trim=compact_trim, static=deepcopy(static))


def sampled_spans(samples):
    """Contiguous accepted *nodes*. Never infer acceptance through rejected nodes."""
    spans = []
    start = None
    for i in range(len(samples)+1):
        accepted = i < len(samples) and samples[i]['accepted_all_conditions']
        if accepted and start is None:
            start = i
        if not accepted and start is not None:
            nodes = samples[start:i]
            spans.append(dict(sample_ids=[p['sample_id'] for p in nodes],
                forward_sampled_cg_in=nodes[0]['cg_station_in'], aft_sampled_cg_in=nodes[-1]['cg_station_in'],
                forward_boundary='search-edge-unresolved' if start == 0 else 'sampled-transition-bracket',
                aft_boundary='search-edge-unresolved' if i == len(samples) else 'sampled-transition-bracket'))
            start = None
    return spans


def run_cg_study(definition, settings):
    s, budget = validate_settings(settings)
    original = deepcopy(definition)
    baseline = evaluate_aircraft(original)
    if baseline['mass_properties'] is None or not original.get('flight_condition'):
        raise ValueError('CG study requires complete baseline mass and flight inputs')
    # Validate physical endpoint realizations before spending the evaluation budget.
    for station in (s['station_min_in'], s['station_max_in']):
        relocate_component(original, s['component_id'], station)
    conditions = [dict(condition_id=f'c{i}', speed_ft_s=speed, load_factor=n)
                  for i, (speed, n) in enumerate((v, n) for v in s['speeds_ft_s'] for n in s['load_factors'])]
    cache = {}
    evaluations = 0

    def sample(station, stage):
        nonlocal evaluations
        if station in cache:
            return cache[station]
        physical = relocate_component(original, s['component_id'], station)
        outcomes = []
        mp = None
        for condition in conditions:
            d = deepcopy(physical)
            d['flight_condition']['speed_ft_s'] = condition['speed_ft_s']
            d['load_case'] = dict(kind='vertical-translation', a_up_g=condition['load_factor']-1)
            evaluated = evaluate_aircraft(d)
            evaluations += 1
            if evaluations > budget:
                raise RuntimeError('Internal CG study evaluation budget exceeded')
            mp = evaluated['mass_properties']
            outcomes.append(dict(condition_id=condition['condition_id'],
                                 **constraint_outcome(evaluated['flight_condition'], s['minimum_static_margin_percent'])))
        item = dict(sample_id=f's{len(cache)}', component_station_in=station, stage=stage,
                    cg_station_in=mp['cg_station_in'], cg_B_in=mp['cg_B_in'],
                    inertia_CG=mp['inertia_CG'], weight_lbf=mp['weight_lbf'],
                    accepted_all_conditions=all(c['accepted'] for c in outcomes), conditions=outcomes)
        cache[station] = item
        return item

    lo, hi = s['station_min_in'], s['station_max_in']
    coarse = [sample(lo+(hi-lo)*i/(s['sample_count']-1), 'coarse') for i in range(s['sample_count'])]
    brackets = []
    for left, right in zip(coarse, coarse[1:]):
        if left['accepted_all_conditions'] == right['accepted_all_conditions']:
            continue
        original_width = right['component_station_in']-left['component_station_in']
        for _ in range(s['refinement_steps']):
            mid = sample((left['component_station_in']+right['component_station_in'])/2, 'refinement')
            if mid['accepted_all_conditions'] == left['accepted_all_conditions']:
                left = mid
            else:
                right = mid
        brackets.append(dict(left_sample_id=left['sample_id'], right_sample_id=right['sample_id'],
            component_station_width_in=right['component_station_in']-left['component_station_in'],
            cg_width_in=right['cg_station_in']-left['cg_station_in'],
            coarse_component_station_width_in=original_width,
            scope='Bracket around a sampled acceptance transition; additional unsampled crossings are not excluded'))
    samples = sorted(cache.values(), key=lambda p: p['component_station_in'])
    source = Path(__file__).parent
    output = dict(schema='aircraft-cg-study-v1', model_id=MODEL_ID, scope=SCOPE,
        implementation_sha256={name: hashlib.sha256((source/name).read_bytes()).hexdigest()
                               for name in ('aircraft_cg_study.py', 'aircraft_flight.py', 'aircraft_workspace.py', 'aircraft_input_limits.py')},
        baseline_definition=original, baseline_sha256=digest(original), settings=s, settings_sha256=digest(s),
        baseline_mass_properties=baseline['mass_properties'], conditions=conditions, samples=samples,
        sampled_spans=sampled_spans(samples), transition_brackets=brackets,
        accounting=dict(baseline_evaluations=1, condition_evaluations=evaluations,
                        worst_case_condition_budget=budget, maximum_condition_evaluations=MAX_EVALUATIONS),
        criteria=dict(minimum_static_margin_percent=s['minimum_static_margin_percent'],
                      margin_basis='Explicit user-selected screening criterion, not design guidance',
                      require_feasible_trim=True, require_valid_restoring_static_derivative=True),
        units=dict(station='in aft of nose', speed='ft/s', load_factor='n = 1 + upward acceleration/g',
                   inertia_CG='lbf*s^2*in', static_margin='percent wing reference chord'))
    output['study_sha256'] = digest(output)
    return output
