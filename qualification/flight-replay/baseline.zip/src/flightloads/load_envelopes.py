"""Per-station correlated load envelopes, governing cases and load-table export (issue #227).

Input: Monte Carlo sample summaries (monte_carlo.summarize). Each summary keeps,
for every station, the concurrent field of ALL stations at that station's peak
force and peak moment instants. An envelope point is one concurrent field at one
stored instant, so envelopes never combine peaks from different instants.

For each station and component pair, the envelope is the 2D convex hull of the
points (Andrew's monotone chain). Every hull vertex traces to its sample index,
time and the full concurrent field at that instant (the governing case).

Component definitions (reactions on the retained part; body frame x fwd, y right,
z down; lbf and in-lbf):
    plane (fuselage):  shear = Fz, lateral shear = Fy, bending = My, torsion = Mx
    wing root:         shear = Fz, bending = Mx, torsion = My
    tail root:         panel axes (shear normal, bending about chord, torsion about span)
    mounts:            the six body components (Fx, Fy, Fz, Mx, My, Mz)
See docs/mechanics/LOAD_ENVELOPES.md (Station 11).
"""
from __future__ import annotations

import csv
import io
import json
import math
from itertools import combinations

import numpy as np

SCHEMA = 'station-load-envelopes-v2'
EVIDENCE_ORDER = ('estimate', 'cfd', 'cfd-validated')


FLIGHT_AXES = {
    'airspeed_ft_s': dict(label='True airspeed', unit='ft/s', definition='Magnitude of local air-relative CG velocity'),
    'height_agl_ft': dict(label='Height AGL', unit='ft', definition='CG height above the local ground plane'),
    'altitude_msl_ft': dict(label='Altitude MSL', unit='ft', definition='Recorded field elevation plus CG height AGL; unavailable without a datum'),
    'normal_load_factor': dict(label='Signed normal load factor', unit='g', definition='n_z = -F_non_gravity_Bz / W; positive body-up; distinct from inertial acceleration'),
}


def governing_field(envelopes, vertex):
    """Resolve compact v3 vertices; historical vertices carry their field inline."""
    if 'concurrent_field' in vertex:
        return vertex['concurrent_field']
    return envelopes['concurrent_fields'][vertex['concurrent_field_key']]


def component_definitions():
    """Return a plain dict mapping component keys to their body force/moment names.

    Mirrors the _components function logic. The convention:
    reactions on the retained part; body frame x forward, y right, z down;
    lbf and in-lbf.
    """
    return {
        'fuselage': {'shear_lbf': 'Fz', 'lateral_shear_lbf': 'Fy', 'bending_in_lbf': 'My', 'torsion_in_lbf': 'Mx'},
        'wing-root': {'shear_lbf': 'Fz', 'bending_in_lbf': 'Mx', 'torsion_in_lbf': 'My'},
        'tail-root': {'shear_lbf': 'force along the panel normal axis',
                      'bending_in_lbf': 'moment about the panel chord axis',
                      'torsion_in_lbf': 'moment about the panel span axis'},
        'mount': {'fx_lbf': 'Fx', 'fy_lbf': 'Fy', 'fz_lbf': 'Fz', 'mx_in_lbf': 'Mx', 'my_in_lbf': 'My', 'mz_in_lbf': 'Mz'},
        'convention': 'reactions on the retained part; body frame x forward, y right, z down; lbf and in-lbf'
    }


def component_kind(station_id):
    """Return the component kind prefix for a station: 'fuselage', 'wing-root', 'tail-root', or 'mount'."""
    if station_id.startswith('fuselage'):
        return 'fuselage'
    if station_id.startswith('wing-root'):
        return 'wing-root'
    if station_id.startswith('tail-root'):
        return 'tail-root'
    return 'mount'


def _components(station_id, force, moment, panel_axes=None):
    fx, fy, fz = force
    mx, my, mz = moment
    if station_id.startswith('fuselage'):
        return dict(shear_lbf=fz, lateral_shear_lbf=fy, bending_in_lbf=my, torsion_in_lbf=mx)
    if station_id.startswith('wing-root'):
        return dict(shear_lbf=fz, bending_in_lbf=mx, torsion_in_lbf=my)
    if station_id.startswith('tail-root') and panel_axes is not None:
        return dict(shear_lbf=float(np.dot(force, panel_axes['normal'])),
                    bending_in_lbf=float(np.dot(moment, panel_axes['chord'])),
                    torsion_in_lbf=float(np.dot(moment, panel_axes['span'])))
    if station_id.startswith('tail-root'):
        raise ValueError('tail-root loads require sample-specific panel axes or panel components')
    return dict(fx_lbf=fx, fy_lbf=fy, fz_lbf=fz, mx_in_lbf=mx, my_in_lbf=my, mz_in_lbf=mz)


def _pairs(station_id):
    if station_id.startswith(('fuselage', 'wing-root', 'tail-root')):
        return [('shear_lbf', 'bending_in_lbf'), ('bending_in_lbf', 'torsion_in_lbf')]
    return [('fz_lbf', 'my_in_lbf'), ('fx_lbf', 'fz_lbf')]


def convex_hull(points):
    """Indices of the 2D convex hull, counter-clockwise, collinear points dropped."""
    unique = {}
    for i, point in enumerate(points):
        unique.setdefault(tuple(point), i)
    order = sorted(unique.values(), key=lambda i: (points[i][0], points[i][1]))
    if len(order) <= 2:
        return order

    def cross(o, a, b):
        return (points[a][0] - points[o][0])*(points[b][1] - points[o][1]) - (points[a][1] - points[o][1])*(points[b][0] - points[o][0])
    lower, upper = [], []
    for i in order:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], i) <= 0:
            lower.pop()
        lower.append(i)
    for i in reversed(order):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], i) <= 0:
            upper.pop()
        upper.append(i)
    return lower[:-1] + upper[:-1]


def envelope_points(summaries):
    """Unique concurrent fields (sample index, time) from all stored peak instants."""
    seen, points = set(), []
    for s in summaries:
        for station_peaks in s.get('station_peaks', {}).values():
            for quantity in ('force', 'moment'):
                peak = station_peaks.get(quantity)
                if not peak:
                    continue
                key = (s['index'], peak['tick'])
                if key in seen:
                    continue
                seen.add(key)
                points.append(dict(sample=s['index'], time_s=peak['time_s'], tick=peak['tick'],
                                   evidence_level=(s.get('aero_dataset') or {}).get('evidence_level', 'estimate'),
                                   field=peak['concurrent']))
    return points


def build_envelopes(summaries, panel_frames=None):
    """Envelopes for every station found in the summaries.

    panel_frames: optional {station_id: {'span','chord','normal'}} for tail roots
    (from station_loads.default_stations)."""
    points = envelope_points(summaries)
    return _build(points, len(summaries), panel_frames, 'incomplete-stored-norm-peaks-only')


def _point_components(sid, entry, panel_frames):
    if sid.startswith('tail-root') and 'panel_components' in entry:
        p = entry['panel_components']
        return dict(shear_lbf=p['shear_normal_lbf'], bending_in_lbf=p['bending_about_chord_in_lbf'],
                    torsion_in_lbf=p['torsion_about_span_in_lbf'])
    return _components(sid, entry['force_B_lbf'], entry['moment_B_in_lbf'], panel_frames.get(sid))


def _governing(row, inline=True):
    result = dict(sample=row['sample'], time_s=row['time_s'], tick=row['tick'],
                evidence_level=row['evidence_level'], report_sha256=row.get('report_sha256'),
                status=row.get('status'), stop_reason=row.get('stop_reason'),
                concurrent_field_key=f"{row['sample']}:{row['tick']}")
    if inline:
        result['concurrent_field'] = row['field']
    for key in ('flight_condition','aircraft_sha256','inputs_sha256','aircraft_name'):
        if key in row:
            result[key] = row[key]
    if 'aero_dataset' in row:
        result['aero_dataset'] = dict(row['aero_dataset'])
    return result


def _build(points, sample_count, panel_frames=None, coverage='complete-recorded-ticks', condition_axes=()):
    panel_frames = panel_frames or {}
    stations = sorted({sid for p in points for sid in p['field']})
    envelopes = {}
    for sid in stations:
        rows = [dict(p, components=_point_components(sid, p['field'][sid], panel_frames))
                for p in points if sid in p['field']]
        if any(not math.isfinite(v) for r in rows for v in r['components'].values()):
            raise ValueError('nonfinite load component')
        if condition_axes:
            for row in rows:
                row['components'].update({key:row['flight_condition'][key] for key in condition_axes})
        station = dict(points=len(rows), pairs=[], extremes={})
        keys = list(rows[0]['components']) if rows else []
        station['axes'] = {key:dict(FLIGHT_AXES[key]) if key in FLIGHT_AXES else
            dict(label=key.replace('_',' '),unit='in-lbf' if key.endswith('in_lbf') else 'lbf',
                 definition=component_definitions()[component_kind(sid)].get(key,key)) for key in keys}
        pairs = list(_pairs(sid))
        if condition_axes:
            existing = {frozenset(pair) for pair in pairs}
            pairs.extend(pair for pair in combinations(keys,2) if frozenset(pair) not in existing)
        for x_key, y_key in pairs:
            xy = [(r['components'][x_key], r['components'][y_key]) for r in rows]
            hull = convex_hull(xy)
            station['pairs'].append(dict(x=x_key, y=y_key, vertices=[
                dict(_governing(rows[i], (x_key,y_key) in _pairs(sid)), x=xy[i][0], y=xy[i][1]) for i in hull]))
        for key in rows[0]['components'] if rows else []:
            values = [r['components'][key] for r in rows]
            for label, pick in (('max', max), ('min', min)):
                i = values.index(pick(values))
                station['extremes'][f'{key}:{label}'] = dict(_governing(rows[i]), value=values[i])
        station['weakest_evidence'] = min((r['evidence_level'] for r in rows), key=EVIDENCE_ORDER.index, default=None)
        envelopes[sid] = station
    result = dict(schema='station-load-envelopes-v3' if condition_axes else SCHEMA, samples=sample_count, points=len(points), stations=envelopes, coverage=coverage,
                convention='Reactions on the retained part; body frame x fwd, y right, z down; lbf, in-lbf. '
                           'Moments about each station reference_B_in; tail components in each sampled panel frame. '
                           'Concurrent recorded instants only, never independently combined peaks. '
                           'Numerical coverage is not continuous-time verification or validated design acceptance.')
    if condition_axes:
        refs = {v['concurrent_field_key'] for st in envelopes.values() for pair in st['pairs'] for v in pair['vertices']}
        result['concurrent_fields'] = {f"{p['sample']}:{p['tick']}":p['field'] for p in points
                                       if f"{p['sample']}:{p['tick']}" in refs}
        result['flight_axes'] = {key:dict(FLIGHT_AXES[key]) for key in condition_axes}
    return result


def build_complete_envelopes(study, summaries):
    """Replay all samples, verify archive hashes, and reduce every recorded load tick.

    Retains hull vertices and signed extrema, not full histories of all samples.
    The compact Monte Carlo archive is never modified. Rejected/unreproducible
    samples fail closed; no complete load table can be claimed for them.
    """
    from .monte_carlo import replay_sample, sample_inputs, validate_study
    from .station_loads import default_stations
    from .aircraft_elastic import digest
    study = validate_study(study)
    indexes = [s['index'] for s in summaries]
    if len(indexes) != study['count'] or set(indexes) != set(range(study['count'])):
        raise ValueError('complete envelope requires every study sample exactly once')
    candidates, total, counts, weakest = [], 0, {}, {}
    msl_known, statuses = True, {}
    for summary in sorted(summaries, key=lambda s: s['index']):
        index = summary['index']
        if not summary.get('report_sha256'):
            raise ValueError(f'sample {index}: missing replay hash (possibly input-rejected)')
        report = replay_sample(study, index)
        if report.get('report_sha256') != summary['report_sha256']:
            raise ValueError(f'sample {index}: replay hash mismatch; reproduce with original inputs/code')
        inputs, values = sample_inputs(study, index)
        if values != summary['values']:
            raise ValueError(f'sample {index}: archived draws disagree with study')
        frames = {s['id']: s['panel_frame'] for s in default_stations(inputs['definition']) if s.get('panel_frame')}
        evidence = (report.get('aero_dataset') or {}).get('evidence_level', 'estimate')
        if evidence not in EVIDENCE_ORDER:
            raise ValueError(f'sample {index}: unknown evidence level')
        history = report.get('station_loads') or []
        if not history:
            raise ValueError(f'sample {index}: no load history')
        truth = report.get('truth') or []
        by_tick = {}
        for row in truth:
            if type(row.get('tick')) is not int or row['tick'] in by_tick:
                raise ValueError(f'sample {index}: duplicate or invalid truth tick')
            by_tick[row['tick']] = row
        load_ticks = set()
        status = report.get('status') or 'unknown'
        statuses[status] = statuses.get(status,0)+1
        aircraft_sha256 = digest(inputs['definition'])
        for row in history:
            tick = row.get('tick')
            if type(tick) is not int or tick in load_ticks:
                raise ValueError(f'sample {index}: duplicate or invalid load tick')
            load_ticks.add(tick)
            state = by_tick.get(tick)
            if state is None or state.get('time_s') != row['time_s']:
                raise ValueError(f'sample {index}: flight conditions/load tick or time mismatch')
            condition = state.get('flight_condition')
            if type(condition) is not dict:
                raise ValueError(f'sample {index}: missing concurrent flight conditions')
            for key in FLIGHT_AXES:
                value = condition.get(key)
                if key == 'altitude_msl_ft' and value is None:
                    msl_known = False
                elif type(value) not in (int,float) or not math.isfinite(value):
                    raise ValueError(f'sample {index}: missing/nonfinite flight condition {key}')
            field = {s['id']: dict(s) for s in row['stations']}
            for sid, entry in field.items():
                if sid in frames:
                    entry['panel_frame'] = frames[sid]
                counts[sid] = counts.get(sid, 0) + 1
                weakest[sid] = min(weakest.get(sid, evidence), evidence, key=EVIDENCE_ORDER.index)
            candidates.append(dict(sample=index, tick=row['tick'], time_s=row['time_s'], field=field,
                                   report_sha256=report['report_sha256'], evidence_level=evidence,
                                   status=report.get('status'), stop_reason=report.get('stop_reason'),
                                   flight_condition=dict(condition), aircraft_sha256=aircraft_sha256,
                                   aircraft_name=inputs['definition'].get('name'), inputs_sha256=report.get('inputs_sha256')))
            if (report.get('aero_dataset') or {}).get('load_resolution') == 'component-resultant':
                candidates[-1]['aero_dataset'] = dict(report['aero_dataset'])
        total += len(history)
        axes = tuple(k for k in FLIGHT_AXES if k!='altitude_msl_ft' or msl_known)
        reduced = _build(candidates, study['count'], condition_axes=axes)
        keep = set()
        for station in reduced['stations'].values():
            governing = list(station['extremes'].values())
            governing.extend(v for pair in station['pairs'] for v in pair['vertices'])
            keep.update((v['sample'], v['tick']) for v in governing)
        candidates = [p for p in candidates if (p['sample'], p['tick']) in keep]
    axes = tuple(k for k in FLIGHT_AXES if k!='altitude_msl_ft' or msl_known)
    result = _build(candidates, study['count'], condition_axes=axes)
    result.update(study_sha256=digest(study), sample_status_counts=statuses,
                  altitude_msl_available=msl_known,
                  coverage_note='Sampled recorded trajectory hulls, including stopped trajectories; not validated operating boundaries.')
    result['points'] = total
    result['retained_points'] = len(candidates)
    for sid, station in result['stations'].items():
        station['points'] = counts[sid]
        station['weakest_evidence'] = weakest[sid]
    return result


def projection_pair(station, x, y):
    """Return one exact hull in the requested axis order; never interpolate."""
    if x == y:
        raise ValueError('choose two different envelope axes')
    for pair in station['pairs']:
        if (pair['x'],pair['y']) == (x,y):
            return pair
        if (pair['x'],pair['y']) == (y,x):
            return dict(pair,x=x,y=y,vertices=[dict(v,x=v['y'],y=v['x']) for v in pair['vertices']])
    raise ValueError('requested envelope projection is unavailable')


def export_csv(envelopes, station_id=None, x=None, y=None):
    """Default: historical load-pair table. Optional: one selected projection."""
    selected = any(v is not None for v in (station_id,x,y))
    if selected and (station_id not in envelopes['stations'] or x is None or y is None):
        raise ValueError('selected CSV requires station, x and y')
    out = io.StringIO()
    writer = csv.writer(out)
    dataset_column = any('aero_dataset' in v for s in envelopes['stations'].values() for p in s['pairs'] for v in p['vertices'])
    extra = ['flight_condition','aircraft_sha256','aircraft_name','inputs_sha256','study_sha256','status','stop_reason','x_unit','y_unit']
    writer.writerow(['station', 'x_component', 'y_component', 'vertex', 'x_value', 'y_value', 'sample', 'time_s', 'evidence_level',
                     'tick', 'report_sha256', 'coverage', 'convention', 'concurrent_field'] + (['aero_dataset'] if dataset_column else []) + extra)
    for sid, station in envelopes['stations'].items():
        if selected and sid != station_id:
            continue
        pairs = [projection_pair(station,x,y)] if selected else [p for p in station['pairs'] if (p['x'],p['y']) in _pairs(sid)]
        for pair in pairs:
            for k, v in enumerate(pair['vertices']):
                writer.writerow([sid, pair['x'], pair['y'], k, repr(float(v['x'])), repr(float(v['y'])),
                                 v['sample'], repr(float(v['time_s'])), v['evidence_level'], v['tick'],
                                 v.get('report_sha256'), envelopes['coverage'], envelopes['convention'],
                                 json.dumps(governing_field(envelopes,v), sort_keys=True, allow_nan=False)] +
                                ([json.dumps(v.get('aero_dataset'), sort_keys=True)] if dataset_column else []) +
                                [json.dumps(v.get('flight_condition'),sort_keys=True,allow_nan=False),v.get('aircraft_sha256'),
                                 v.get('aircraft_name'),v.get('inputs_sha256'),envelopes.get('study_sha256'),v.get('status'),v.get('stop_reason'),
                                 station.get('axes',{}).get(pair['x'],{}).get('unit'),station.get('axes',{}).get(pair['y'],{}).get('unit')])
    return out.getvalue()


def read_csv(text):
    rows = list(csv.DictReader(io.StringIO(text)))
    for r in rows:
        for key in ('x_value', 'y_value', 'time_s'):
            r[key] = float(r[key])
        r['vertex'], r['sample'] = int(r['vertex']), int(r['sample'])
        r['tick'] = int(r['tick'])
        r['concurrent_field'] = json.loads(r['concurrent_field'])
        if 'flight_condition' in r:
            r['flight_condition'] = json.loads(r['flight_condition'])
        if 'aero_dataset' in r:
            r['aero_dataset'] = json.loads(r['aero_dataset'])
    return rows


def export_json(envelopes):
    return json.dumps(envelopes, sort_keys=True, allow_nan=False)
