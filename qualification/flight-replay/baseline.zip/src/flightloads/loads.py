"""Distributed body-frame non-gravity loads."""

from __future__ import annotations
from dataclasses import dataclass
from typing import ClassVar, Tuple
import numpy as np
from ._arrays import readonly_copy

@dataclass(frozen=True)
class AppliedLoads:
    locations_CG_B_m: np.ndarray
    forces_non_gravity_B_N: np.ndarray
    couples_B_Nm: np.ndarray
    source_ids: Tuple[str, ...]
    frame: ClassVar[str] = 'B'

    def __init__(self, locations_CG_B_m: np.ndarray, forces_non_gravity_B_N: np.ndarray, couples_B_Nm: np.ndarray, source_ids: Tuple[str, ...]) -> None:
        locations = np.asarray(locations_CG_B_m, dtype=np.float64)
        forces = np.asarray(forces_non_gravity_B_N, dtype=np.float64)
        couples = np.asarray(couples_B_Nm, dtype=np.float64)
        for name, array in (('locations', locations), ('forces', forces), ('couples', couples)):
            if array.ndim != 2 or array.shape[1] != 3:
                raise ValueError(f'{name} must have shape (k, 3), got {array.shape}')
        k_locs = locations.shape[0] if locations.shape[0] > 0 else 0
        k_f = forces.shape[0] if forces.shape[0] > 0 else 0
        k_c = couples.shape[0] if couples.shape[0] > 0 else 0
        k = k_locs
        if k_f != k:
            raise ValueError(f'forces shape[0]={k_f} must equal locations shape[0]={k}')
        if k_c != k:
            raise ValueError(f'couples shape[0]={k_c} must equal locations shape[0]={k}')
        if locations.shape != (k, 3):
            raise ValueError(f'locations_CG_B_m must have shape ({k}, 3), got {locations.shape}')
        if forces.shape != (k, 3):
            raise ValueError(f'forces_non_gravity_B_N must have shape ({k}, 3), got {forces.shape}')
        if couples.shape != (k, 3):
            raise ValueError(f'couples_B_Nm must have shape ({k}, 3), got {couples.shape}')
        if not isinstance(source_ids, tuple):
            raise ValueError('source_ids must be a tuple')
        if len(source_ids) != k:
            raise ValueError(f'source_ids length {len(source_ids)} must equal k={k}')
        for i, sid in enumerate(source_ids):
            if not isinstance(sid, str) or not sid:
                raise ValueError(f'source_ids[{i}] must be nonempty string')
        if not np.all(np.isfinite(locations)):
            raise ValueError('locations_CG_B_m must be finite')
        if not np.all(np.isfinite(forces)):
            raise ValueError('forces_non_gravity_B_N must be finite')
        if not np.all(np.isfinite(couples)):
            raise ValueError('couples_B_Nm must be finite')
        object.__setattr__(self, 'locations_CG_B_m', readonly_copy(locations))
        object.__setattr__(self, 'forces_non_gravity_B_N', readonly_copy(forces))
        object.__setattr__(self, 'couples_B_Nm', readonly_copy(couples))
        object.__setattr__(self, 'source_ids', source_ids)

    @classmethod
    def empty(cls) -> 'AppliedLoads':
        empty_array = np.zeros((0, 3), dtype=np.float64)
        return cls(locations_CG_B_m=empty_array, forces_non_gravity_B_N=empty_array, couples_B_Nm=empty_array, source_ids=())

@dataclass(frozen=True)
class LoadResultant:
    force_B_N: np.ndarray
    moment_B_Nm: np.ndarray
    reference_CG_B_m: np.ndarray
    frame: str

    def __init__(self, force_B_N: np.ndarray, moment_B_Nm: np.ndarray, reference_CG_B_m: np.ndarray, frame: str='B') -> None:
        force = np.asarray(force_B_N, dtype=np.float64)
        moment = np.asarray(moment_B_Nm, dtype=np.float64)
        reference = np.asarray(reference_CG_B_m, dtype=np.float64)
        if force.shape != (3,):
            raise ValueError(f'force_B_N must have shape (3,), got {force.shape}')
        if moment.shape != (3,):
            raise ValueError(f'moment_B_Nm must have shape (3,), got {moment.shape}')
        if reference.shape != (3,):
            raise ValueError(f'reference_CG_B_m must have shape (3,), got {reference.shape}')
        if not np.all(np.isfinite(force)):
            raise ValueError('force_B_N must be finite')
        if not np.all(np.isfinite(moment)):
            raise ValueError('moment_B_Nm must be finite')
        if not np.all(np.isfinite(reference)):
            raise ValueError('reference_CG_B_m must be finite')
        if frame != 'B':
            raise ValueError(f"frame must be 'B', got '{frame}'")
        object.__setattr__(self, 'force_B_N', readonly_copy(force))
        object.__setattr__(self, 'moment_B_Nm', readonly_copy(moment))
        object.__setattr__(self, 'reference_CG_B_m', readonly_copy(reference))
        object.__setattr__(self, 'frame', frame)

def integrate_loads(loads: AppliedLoads, reference_CG_B_m: np.ndarray | None=None) -> LoadResultant:
    if reference_CG_B_m is None:
        reference_CG_B_m = np.zeros(3, dtype=np.float64)
    reference = np.asarray(reference_CG_B_m, dtype=np.float64)
    if reference.shape != (3,):
        raise ValueError(f'reference_CG_B_m must have shape (3,), got {reference.shape}')
    if not np.all(np.isfinite(reference)):
        raise ValueError('reference_CG_B_m must be finite')
    locations = loads.locations_CG_B_m
    forces = loads.forces_non_gravity_B_N
    couples = loads.couples_B_Nm
    k = locations.shape[0]
    if k == 0:
        force_B_N = np.zeros(3, dtype=np.float64)
        moment_B_Nm = np.zeros(3, dtype=np.float64)
    else:
        force_B_N = np.sum(forces, axis=0)
        moment_B_Nm = np.sum(np.cross(locations - reference, forces) + couples, axis=0)
    if not np.all(np.isfinite(force_B_N)):
        raise RuntimeError('Computed force is nonfinite')
    if not np.all(np.isfinite(moment_B_Nm)):
        raise RuntimeError('Computed moment is nonfinite')
    return LoadResultant(force_B_N=force_B_N, moment_B_Nm=moment_B_Nm, reference_CG_B_m=reference, frame='B')
