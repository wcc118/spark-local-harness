"""Manufactured aerodynamic reference, not a validated aircraft dataset."""
from dataclasses import dataclass
import math
from numbers import Real
from types import MappingProxyType
import numpy as np
from ._arrays import readonly_copy
from .conventions import rotation_matrix
from .dynamics import rigid_derivative
from .loads import AppliedLoads, integrate_loads
from .mass import MassModel
from .state import RigidState

COEFFICIENTS = MappingProxyType(dict(CL0=.1635, CLalpha=4., CD0=.02, CYbeta=-.5,
    Clbeta=-.1, Clp=-.5, Clr=.1, Cnbeta=.1, Cnp=-.02, Cnr=-.2,
    Cmalpha=-.5, Cmq=-8., Cmde=-1.))
AREA_M2, SPAN_M, CHORD_M = 1., 2., .5
GRAVITY_MPS2 = 9.81


def _scalar(value, name, low, high):
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
        raise ValueError(f'{name} must be finite real')
    if not low <= value <= high:
        raise ValueError(f'{name} outside manufactured-model domain [{low}, {high}]')
    return float(value)


def reference_mass():
    return MassModel(np.ones(4), np.array([(1,1,0),(1,-1,0),(-1,1,0),(-1,-1,0)]),
                     'manufactured-reference-CG')


@dataclass(frozen=True)
class AeroEvaluation:
    relative_velocity_B_mps: np.ndarray
    airspeed_mps: float
    alpha_rad: float
    beta_rad: float
    dynamic_pressure_Pa: float
    coefficients: object
    applied_loads: AppliedLoads


def evaluate_aerodynamics(state, *, density_kgpm3, wind_N_mps, elevator_rad, thrust_N):
    """Return one explicit distributed field; gravity is excluded.

    Domain bounds are implementation scope, not measured aerodynamic validity.
    Coefficients are fixed and synthetic; reverse flow/stall extrapolation rejected.
    """
    density = _scalar(density_kgpm3, 'density_kgpm3', .8, 1.4)
    elevator = _scalar(elevator_rad, 'elevator_rad', -.1, .1)
    thrust = _scalar(thrust_N, 'thrust_N', 0., 20.)
    wind = np.asarray(wind_N_mps, dtype=float)
    if wind.shape != (3,) or not np.all(np.isfinite(wind)):
        raise ValueError('wind_N_mps must be a finite 3-vector')
    with np.errstate(over='raise', invalid='raise'):
        try:
            velocity = state.v_CG_B_mps-rotation_matrix(state.q_NB).T@wind
            speed = _scalar(float(np.linalg.norm(velocity)), 'airspeed_mps', 10., 30.)
        except FloatingPointError as exc:
            raise ValueError('relative airflow arithmetic overflow') from exc
    u,v,w = velocity
    alpha = _scalar(math.atan2(w,u), 'alpha_rad', -.15, .15)
    beta = _scalar(math.atan2(v,math.hypot(u,w)), 'beta_rad', -.1, .1)
    p_hat,q_hat,r_hat = (state.omega_B_radps/(2*speed))*np.array([SPAN_M,CHORD_M,SPAN_M])
    for name, value in zip(('p_hat','q_hat','r_hat'),(p_hat,q_hat,r_hat)):
        _scalar(value,name,-.1,.1)
    c = COEFFICIENTS
    coefficients = dict(CL=c['CL0']+c['CLalpha']*alpha, CD=c['CD0'], CY=c['CYbeta']*beta,
        Cl=c['Clbeta']*beta+c['Clp']*p_hat+c['Clr']*r_hat,
        Cm=c['Cmalpha']*alpha+c['Cmq']*q_hat+c['Cmde']*elevator,
        Cn=c['Cnbeta']*beta+c['Cnp']*p_hat+c['Cnr']*r_hat)
    ca,sa,cb,sb = math.cos(alpha),math.sin(alpha),math.cos(beta),math.sin(beta)
    # Columns are wind-axis unit vectors expressed in B, x along relative velocity.
    wind_to_body = np.array([(ca*cb,-ca*sb,-sa),(sb,cb,0),(sa*cb,-sa*sb,ca)])
    pressure = .5*density*speed**2
    force = pressure*AREA_M2*(wind_to_body@np.array([-coefficients['CD'],coefficients['CY'],-coefficients['CL']]))
    moment = pressure*AREA_M2*np.array([SPAN_M*coefficients['Cl'],CHORD_M*coefficients['Cm'],SPAN_M*coefficients['Cn']])
    # Prescribed equal halves at symmetric points; not a unique recovery from resultants.
    loads = AppliedLoads(np.array([(0,SPAN_M/4,0),(0,-SPAN_M/4,0),(0,0,0),(0,0,0)]),
        np.array([force/2,force/2,np.zeros(3),(thrust,0,0)]),
        np.array([np.zeros(3),np.zeros(3),moment,np.zeros(3)]),
        ('aero-right','aero-left','aero-couple','CG-thrust'))
    return AeroEvaluation(readonly_copy(velocity),speed,alpha,beta,pressure,
                          MappingProxyType(coefficients),loads)


@dataclass(frozen=True)
class TrimResult:
    state: RigidState
    mass_model: MassModel
    density_kgpm3: float
    elevator_rad: float
    thrust_N: float
    alpha_rad: float
    force_residual_B_N: np.ndarray
    moment_residual_B_Nm: np.ndarray
    velocity_derivative_B_mps2: np.ndarray
    angular_acceleration_B_radps2: np.ndarray
    vertical_velocity_N_mps: float


def trim_level(*, airspeed_mps=20., density_kgpm3=1.2):
    """Constrained zero-wind straight-level trim of the fixed 4 kg reference.

    beta=roll=yaw=omega=0; theta=alpha; solve alpha/elevator/thrust only.
    The scalar root is CL(alpha)+CD*tan(alpha)-mg/(qbar*S)=0.
    """
    speed = _scalar(airspeed_mps,'airspeed_mps',10.,30.)
    density = _scalar(density_kgpm3,'density_kgpm3',.8,1.4)
    mass = reference_mass()
    pressure = .5*density*speed**2
    c = COEFFICIENTS
    def residual(alpha):
        return c['CL0']+c['CLalpha']*alpha+c['CD0']*math.tan(alpha)-mass.mass_kg*GRAVITY_MPS2/(pressure*AREA_M2)
    lo,hi = -.15,.15
    if residual(lo)>0 or residual(hi)<0:
        raise ValueError('no level trim inside alpha domain')
    for _ in range(64):
        alpha=(lo+hi)/2
        value=residual(alpha)
        if abs(value)<1e-15: break
        if value>0: hi=alpha
        else: lo=alpha
    elevator = -c['Cmalpha']*alpha/c['Cmde']
    thrust = pressure*AREA_M2*c['CD0']/math.cos(alpha)
    state = RigidState(np.zeros(3),np.array([speed*math.cos(alpha),0,speed*math.sin(alpha)]),
                       np.array([math.cos(alpha/2),0,math.sin(alpha/2),0]),np.zeros(3))
    evaluation = evaluate_aerodynamics(state,density_kgpm3=density,wind_N_mps=np.zeros(3),
                                       elevator_rad=elevator,thrust_N=thrust)
    gravity = np.array([0,0,GRAVITY_MPS2])
    resultants = integrate_loads(evaluation.applied_loads)
    force = resultants.force_B_N+mass.mass_kg*(rotation_matrix(state.q_NB).T@gravity)
    derivative = rigid_derivative(state,mass,evaluation.applied_loads,gravity)
    acceleration = np.concatenate([derivative.vdot_B_mps2,derivative.omegadot_B_radps2])
    vertical = float((rotation_matrix(state.q_NB)@state.v_CG_B_mps)[2])
    if max(np.max(np.abs(force)),np.max(np.abs(resultants.moment_B_Nm)),
           np.max(np.abs(acceleration)),abs(vertical))>1e-10:
        raise RuntimeError('trim failed independent rigid-equilibrium residual check')
    return TrimResult(state,mass,density,elevator,thrust,alpha,readonly_copy(force),
                      readonly_copy(resultants.moment_B_Nm),derivative.vdot_B_mps2,
                      derivative.omegadot_B_radps2,vertical)


def longitudinal_reference_matrix():
    """Independently derived A for [du,dw,dq,dtheta] at V20/rho1.2/alpha0."""
    return readonly_copy([[-.12,.4905,0,-9.81],[-.981,-12.06,20,0],
                          [0,-.75,-3,0],[0,0,1,0]])


def linear_reference(times_s, initial_perturbation):
    """Closed-form matrix exponential through the diagonalizable reference A."""
    times=np.asarray(times_s,dtype=float); initial=np.asarray(initial_perturbation,dtype=float)
    if times.ndim!=1 or not len(times) or not np.all(np.isfinite(times)) or np.any(times<0):
        raise ValueError('times must be a nonempty finite nonnegative vector')
    if initial.shape!=(4,) or not np.all(np.isfinite(initial)):
        raise ValueError('initial perturbation must be a finite 4-vector')
    eigenvalues,vectors=np.linalg.eig(longitudinal_reference_matrix())
    weights=np.linalg.solve(vectors,initial)
    result=((np.exp(times[:,None]*eigenvalues)*weights)@vectors.T)
    if np.max(np.abs(result.imag))>1e-10 or not np.all(np.isfinite(result)):
        raise RuntimeError('invalid linear reference evaluation')
    return readonly_copy(result.real)
