"""Streaming, replayable archive for the declared aircraft sensitivity pilot."""
from copy import deepcopy
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import numpy as np
from .aircraft_sampling import SPEC,SPEC_ID,sample,mandatory
from .aircraft_workspace import evaluate_aircraft
from .aircraft_elastic import digest,source_history,_solve
from .aircraft_ensemble import run_event,summary,governors,paired_statistics
from .aircraft_equivalent import candidate_cases,response_histories,RESPONSES
from .aircraft_structural_study import compare

MAX_BYTES=64*1024*1024


def plan(seed,n_train=16,n_heldout=8):
    for n,limit in ((n_train,64),(n_heldout,32)):
        if type(n) is not int or not 1<=n<=limit:raise ValueError('bounded positive sample counts required')
    sample(seed,0)  # validate master seed before any output is created
    realizations=[]
    for i,r in enumerate(mandatory()):realizations.append(dict(partition='mandatory',index=i,**r))
    for partition,count in [('train',n_train),('heldout',n_heldout)]:
        for i in range(count):realizations.append(sample(seed,i,partition))
    records=[]
    for r in realizations:
        name=f"{r['partition']}-{r['index']:03d}"
        events=[('positive',.25),('negative',-.25)]
        if r['partition']=='mandatory' and r['index']==0:events.insert(0,('zero',0.))
        for event,pulse in events:
            d=deepcopy(r['definition']);d['transient_case']['ruddervator_pulse_deg']=pulse
            records.append(dict(id=name+'-'+event,realization_id=name,partition=r['partition'],index=r['index'],
                latents=r['latents'],sample_input_id=r.get('input_id'),event_name=event,pulse_deg=pulse,
                requested_definition=d,young_psi=2e6,status='queued'))
    nominal=deepcopy(records[1]);nominal.update(id='alternate-stiffness-positive',realization_id='alternate-stiffness',
        partition='alternate-model',young_psi=1e6,status='queued')
    records.append(nominal)
    return records


def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def write_artifact(root,name,value,artifacts):
    raw=encoded(value);raw=gzip.compress(raw,compresslevel=3,mtime=0) if name.endswith('.gz') else raw
    with (root/name).open('xb') as file:file.write(raw)
    artifacts[name]=dict(sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))


def read_artifact(root,name,artifacts):
    if name not in artifacts or Path(name).name!=name:raise ValueError('unlisted artifact')
    path=root/name
    if path.is_symlink() or path.stat().st_size>MAX_BYTES:raise ValueError('invalid artifact path or size')
    raw=path.read_bytes()
    if len(raw)!=artifacts[name]['bytes'] or hashlib.sha256(raw).hexdigest()!=artifacts[name]['sha256']:
        raise ValueError('artifact hash mismatch')
    if name.endswith('.gz'):
        with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:raw=stream.read(MAX_BYTES+1)
        if len(raw)>MAX_BYTES:raise ValueError('expanded artifact too large')
    return json.loads(raw,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite artifact')))


def record_event(root,entry,artifacts):
    result,source,pilot,candidates=run_event(entry['requested_definition'],young_psi=entry['young_psi'])
    entry.update(result);entry['candidates']=[]
    for key,value in [('rigid',source),('pilot',pilot)]:
        if value is not None:
            name=entry['id']+'-'+key+'.json.gz';write_artifact(root,name,value,artifacts);entry[key+'_artifact']=name
    for item in candidates:
        case=item['case'];identifier=entry['id']+f"-t{case['selected_index']:04d}"
        name=identifier+'.json';write_artifact(root,name,case,artifacts)
        entry['candidates'].append(dict(id=identifier,artifact=name,index=case['selected_index'],time_s=case['selected_time'],
            criteria=item['criteria'],case_sha256=case['canonical_case_sha256']))
    if pilot is not None:
        # A compact viewer payload; full replay fields remain in the pilot archive.
        review=review_payload(pilot)
        name=entry['id']+'-review.json';write_artifact(root,name,review,artifacts);entry['review_artifact']=name


def review_payload(pilot):
    return dict(times_s=pilot['times_s'],nodes_in=pilot['nodes_in'],response=pilot['response'],
        geometry=pilot['definition']['geometry'],cut=pilot['definition']['cut'],scope_status=pilot['scope_status'])


def refinement_ids(records):
    return {v['event_id'] for partition in ('mandatory','train')
        for v in governors([r for r in records if r['partition']==partition]).values()}


def refinement(source):
    fine=_solve(source)
    return dict(spatial=compare(_solve(source,elements=16),fine),modal=compare(_solve(source,retained_modes=32),fine),
        time=compare(_solve(source,dt_s=.001),fine),
        forcing=compare(_solve(source_history(source['definition'],rigid_dt_s=.0005)),fine))


def code_provenance():
    package=Path(__file__).parent;root=package.parent.parent
    try:
        commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
        dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip())
    except (subprocess.CalledProcessError,FileNotFoundError):commit='unavailable';dirty=None
    return dict(commit=commit,dirty=dirty,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob('*.py')})


def complete_summary(records,numerical):
    result=summary(records)
    passed=bool(numerical) and all(c['passed'] for row in numerical.values() for c in row.values())
    if not passed:
        unqualified=deepcopy(records)
        for row in unqualified:
            if row['partition']=='train':row['status']='ensemble-refinement-failed'
        result['conditional_statistics']=paired_statistics(unqualified)
    result['numerical_verification_passed']=passed
    result['qualified_finite_pilot_coverage']=passed and result['finite_pilot_coverage_passed']
    return result


def save_ensemble(output,*,seed=570058,n_train=16,n_heldout=8):
    records=plan(seed,n_train,n_heldout);root=Path(output);root.mkdir(parents=True,exist_ok=False)
    manifest=dict(schema='aircraft-ensemble-v1',spec=deepcopy(SPEC),spec_identity=SPEC_ID,seed=seed,
        training_realizations=n_train,heldout_realizations=n_heldout,declared_pilot_counts=(n_train,n_heldout)==(16,8),
        provenance=code_provenance(),records=records,artifacts={},state='running',
        limitations='Conditional illustrative sensitivity study, no calibrated aircraft probability, strength acceptance or operational flight envelope.')
    checkpoint=root/'progress.json'
    for i,entry in enumerate(records):
        record_event(root,entry,manifest['artifacts'])
        checkpoint.write_bytes(encoded(manifest))
        print(f"event {i+1}/{len(records)} {entry['id']}: {entry['status']}",flush=True)
    selected=refinement_ids(records)
    numerical={};lookup={r['id']:r for r in records}
    for identifier in sorted(selected):
        source=read_artifact(root,lookup[identifier]['rigid_artifact'],manifest['artifacts'])
        numerical[identifier]=refinement(source)
        print('refinement '+identifier+': '+str(all(c['passed'] for c in numerical[identifier].values())),flush=True)
    manifest.update(state='completed',numerical_checks=numerical,summary=complete_summary(records,numerical))
    manifest['study_sha256']=digest(manifest)
    with (root/'manifest.json').open('xb') as file:file.write(encoded(manifest))
    return manifest


def replay_ensemble(directory,*,repeat_refinement=True):
    root=Path(directory);path=root/'manifest.json'
    if path.is_symlink() or path.stat().st_size>MAX_BYTES:raise ValueError('invalid manifest')
    m=json.loads(path.read_bytes());body=dict(m);identity=body.pop('study_sha256')
    if m['schema']!='aircraft-ensemble-v1' or m['state']!='completed' or digest(body)!=identity:raise ValueError('manifest identity mismatch')
    if m['spec_identity']!=SPEC_ID or m['spec']!=SPEC:raise ValueError('unsupported uncertainty specification')
    if m['declared_pilot_counts']!=((m['training_realizations'],m['heldout_realizations'])==(16,8)):raise ValueError('pilot count qualification mismatch')
    expected_plan=plan(m['seed'],m['training_realizations'],m['heldout_realizations'])
    if len(expected_plan)!=len(m['records']):raise ValueError('event accounting mismatch')
    for expected,row in zip(expected_plan,m['records']):
        for key in ('id','realization_id','partition','index','latents','sample_input_id','event_name','pulse_deg','requested_definition','young_psi'):
            if row[key]!=expected[key]:raise ValueError('sample/input replay mismatch')
        source=read_artifact(root,row['rigid_artifact'],m['artifacts']) if 'rigid_artifact' in row else None
        pilot=read_artifact(root,row['pilot_artifact'],m['artifacts']) if 'pilot_artifact' in row else None
        if source is not None:
            if digest(source)!=row['source_history_sha256']:raise ValueError('rigid history identity mismatch')
            definition=deepcopy(expected['requested_definition']);definition['transient_case']['dt_s']=.00025
            if source['definition']!=definition or row['definition']!=definition:raise ValueError('realized flight definition mismatch')
            if row['source_input_sha256']!=digest(definition) or source['input_sha256']!=digest(definition):raise ValueError('realized input identity mismatch')
            if row['mass_properties']!=source['mass_properties'] or row['initial_trim']!=source['initial_trim']:raise ValueError('mass/trim provenance mismatch')
        if pilot is not None:
            pbody=dict(pilot);pid=pbody.pop('history_sha256')
            if digest(pbody)!=pid or row['pilot_sha256']!=pid:raise ValueError('pilot identity mismatch')
            if source is None or pilot['definition']!=source['definition'] or pilot['source_status']!=source['status']:
                raise ValueError('pilot flight provenance mismatch')
            indices=pilot['inputs']['source_indices'];snapshots=pilot['concurrent_rigid_snapshots']
            if len(indices)!=len(snapshots):raise ValueError('concurrent source count mismatch')
            for index,snapshot in zip(indices,snapshots):
                if type(index) is not int or not 0<=index<len(source['snapshots']) or snapshot!=source['snapshots'][index]:
                    raise ValueError('concurrent source snapshot mismatch')
            if read_artifact(root,row['review_artifact'],m['artifacts'])!=review_payload(pilot):raise ValueError('viewer data mismatch')
        if row['status']=='completed':
            if pilot['source_history_sha256']!=digest(source):raise ValueError('pilot/source mismatch')
            regenerated=candidate_cases(pilot)
            if len(regenerated)!=len(row['candidates']):raise ValueError('candidate count mismatch')
            for item,saved in zip(regenerated,row['candidates']):
                case=read_artifact(root,saved['artifact'],m['artifacts'])
                if item['case']!=case or item['criteria']!=saved['criteria']:raise ValueError('static candidate replay mismatch')
                identifier=row['id']+f"-t{case['selected_index']:04d}"
                if (saved['id']!=identifier or saved['artifact']!=identifier+'.json' or saved['index']!=case['selected_index'] or
                    saved['time_s']!=case['selected_time'] or saved['case_sha256']!=case['canonical_case_sha256']):
                    raise ValueError('candidate metadata mismatch')
            for key,values in response_histories(pilot).items():
                ext=row['extrema'][key]
                if ext['min']!=float(min(values)) or ext['max']!=float(max(values)) or ext['min_index']!=int(np.argmin(values)) or ext['max_index']!=int(np.argmax(values)):
                    raise ValueError('event extrema mismatch')
                demand=float(np.max(abs(values))) if key in RESPONSES else float(np.max(values))
                if row['demands'][key]!=demand:raise ValueError('paired demand mismatch')
        else:
            replayed,_,_,_=run_event(row['requested_definition'],young_psi=row['young_psi'])
            if replayed['status']!=row['status']:raise ValueError('failure status did not reproduce')
        workspace=evaluate_aircraft(row['requested_definition'])
        if row.get('mass_properties')!=workspace['mass_properties']:raise ValueError('realized mass mismatch')
        print('replayed '+row['id'],flush=True)
    if set(m['numerical_checks'])!=refinement_ids(m['records']):raise ValueError('governor refinement coverage mismatch')
    numerical=m['numerical_checks']
    if repeat_refinement:
        numerical={}
        lookup={r['id']:r for r in m['records']}
        for identifier in m['numerical_checks']:
            source=read_artifact(root,lookup[identifier]['rigid_artifact'],m['artifacts'])
            numerical[identifier]=refinement(source)
        if numerical!=m['numerical_checks']:raise ValueError('numerical refinement replay mismatch')
    if complete_summary(m['records'],numerical)!=m['summary']:raise ValueError('ensemble summary replay mismatch')
    return m


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path);parser.add_argument('--replay',action='store_true')
    parser.add_argument('--seed',type=int,default=570058);parser.add_argument('--train',type=int,default=16);parser.add_argument('--heldout',type=int,default=8)
    args=parser.parse_args(argv)
    try:
        m=replay_ensemble(args.directory) if args.replay else save_ensemble(args.directory,seed=args.seed,n_train=args.train,n_heldout=args.heldout)
        print('Study '+m['study_sha256']+'; finite pilot coverage qualified='+str(m['summary']['qualified_finite_pilot_coverage']))
    except (ValueError,TypeError,KeyError,OSError) as error:parser.exit(2,f'ensemble failed: {error}\n')


if __name__=='__main__':main()
