"""Shared analysis input limits, not a flight or design envelope.

Validators consume these same bounds. The read-only UI metadata is a fresh copy;
schema-v1 flight inputs allow optional explicit longitudinal ruddervator travel.
"""

FLIGHT_BOUNDS = dict(
    speed_ft_s=(30,300), altitude_ft=(0,30000), density_override_slug_ft3=(.0001,.004),
    viscosity_slug_ft_s=(1e-7,1e-6), alpha_deg=(-20,20), wing_incidence_deg=(-10,10),
    tail_incidence_deg=(-10,10), ruddervator_deg=(-45,45), ruddervator_limit_deg=(0,45), thrust_lbf=(0,100), max_thrust_lbf=(0,100),
    wing_cl0=(-1,1), wing_cl_alpha_per_rad=(.1,10), wing_cd0=(0,1), wing_cm0=(-1,1),
    wing_efficiency=(.1,1), wing_cl_limit=(.1,3), wing_alpha_limit_deg=(1,20),
    tail_cl_alpha_per_rad=(.1,10), tail_cd0=(0,1), tail_efficiency=(.1,1),
    tail_cl_limit=(.1,3), tail_alpha_limit_deg=(1,25), downwash_gradient=(0,.9),
    reynolds_min=(1,1e7), reynolds_max=(1,1e8))
TRANSIENT_BOUNDS = dict(duration_s=(.001,2), dt_s=(.0001,.05), pulse_start_s=(0,2), pulse_end_s=(0,2),
    ruddervator_pulse_deg=(-2,2), initial_height_agl_ft=(.000001,10000))
RELEASE_BOUNDS = dict(duration_s=(.001,2), dt_s=(.0001,.02), height_agl_ft=(1e-6,10000),
    phi_deg=(-180,180), theta_offset_deg=(-45,45), psi_deg=(-180,180), beta_deg=(-10,10),
    p_deg_s=(-60,60), q_deg_s=(-60,60), r_deg_s=(-60,60), aileron_deg=(-10,10),
    tail_differential_deg=(-10,10), prop_torque_in_lbf=(-100,100))
TRANSIENT_MAX_INTERVALS = 996
RELEASE_MAX_INTERVALS = 4000
POSITION_BOUNDS = (-10000,10000)
WEIGHT_BOUNDS = (.000001,100000)
DIMENSION_BOUNDS = (0,1000)
ACCELERATION_BOUNDS = (-10,10)
GEOMETRY_POSITIVE = ('fuselage_length_in','forward_diameter_in','aft_diameter_in',
    'wing_exposed_span_in','wing_chord_in','tail_panel_length_in','tail_chord_in',
    'aileron_span_in','aileron_chord_in','prop_diameter_in')
GEOMETRY_NONNEGATIVE = ('wing_root_spacing_in','tail_root_spacing_in','aileron_inboard_from_root_in')
GEOMETRY_POSITIVE_BOUNDS = (.001,1000)
GEOMETRY_NONNEGATIVE_BOUNDS = (0,1000)
CANT_BOUNDS = (0,90)
MIN_LOAD_STATION_SEPARATION_IN = .001


def _unit(key):
    for suffix, unit in [('_kts','kt'),('_slug_ft3','slug/ft^3'),('_slug_ft_s','slug/(ft*s)'),
                         ('_deg_s','deg/s'),('_ft_s','ft/s'),('_in_lbf','in-lbf'),
                         ('_per_rad','1/rad'),('_lbf','lbf'),('_deg','deg'),
                         ('_in','in'),('_ft','ft'),('_s','s')]:
        if key.endswith(suffix):
            return unit
    return 'dimensionless'


def _fields(bounds, nullable=()):
    return {key:dict(type='number',minimum=lo,maximum=hi,unit=_unit(key),nullable=key in nullable)
            for key,(lo,hi) in bounds.items()}


def input_limits():
    """Standalone GET metadata remains available when an aircraft is invalid."""
    from .aircraft_workspace import default_definition
    geometry={key:POSITION_BOUNDS for key in default_definition()['geometry']}
    geometry.update({key:GEOMETRY_POSITIVE_BOUNDS for key in GEOMETRY_POSITIVE})
    geometry.update({key:GEOMETRY_NONNEGATIVE_BOUNDS for key in GEOMETRY_NONNEGATIVE})
    geometry['tail_down_cant_deg']=CANT_BOUNDS
    geom_fields=_fields(geometry)
    for key in ('wing_le_station_in','tail_le_station_in'):
        geom_fields[key].update(minimum=0,maximum=GEOMETRY_POSITIVE_BOUNDS[1],
                                maximum_field='geometry.fuselage_length_in')
    component_bounds=dict(weight_lbf=WEIGHT_BOUNDS,station_in=POSITION_BOUNDS,y_in=POSITION_BOUNDS,
                          z_in=POSITION_BOUNDS,length_in=DIMENSION_BOUNDS,width_in=DIMENSION_BOUNDS,
                          height_in=DIMENSION_BOUNDS)
    components=_fields(component_bounds,component_bounds)
    for key in ('length_in','width_in','height_in'):
        components[key]['positive_for_models']=['line','box'] if key=='length_in' else ['box']
    flight=_fields(FLIGHT_BOUNDS,('density_override_slug_ft3',))
    text_source=dict(type='string',min_length=1,max_length=1000,nonblank=True)
    flight['coefficient_source']=dict(text_source)
    release=_fields(RELEASE_BOUNDS)
    release['prop_torque_source']=dict(text_source)
    groups=dict(
        flight_condition=dict(fields=flight,constraints=[
            'Minimum Reynolds number must be less than maximum Reynolds number.',
            'Allowed field ranges are numerical input bounds. Assumed incidence, lift coefficient, Reynolds and available-thrust limits additionally constrain trim and the evolving trajectory.',
            'Steady 1-g trim requires upward acceleration/g = 0. Editable assumed symmetric ruddervator travel bounds the required trim search result (default 10 deg for legacy files). Numerical balance is searched independently within search bounds of +/-20 deg alpha and +/-45 deg ruddervator; these are not aircraft capability limits.']),
        transient_case=dict(fields=_fields(TRANSIENT_BOUNDS),max_intervals=TRANSIENT_MAX_INTERVALS,constraints=[
            'Pulse start must be before pulse end; pulse end must not exceed duration.',
            f'Duration / integration step must be at most {TRANSIENT_MAX_INTERVALS}, reserving steps for pulse breakpoints.',
            'Trim ruddervator plus pulse increment must stay within the configured longitudinal ruddervator travel.',
            'Run requires complete mass, flight inputs, maneuver settings and feasible longitudinal steady 1-g trim.']),
        release=dict(fields=release,max_intervals=RELEASE_MAX_INTERVALS,constraints=[
            f'Duration / integration step must be at most {RELEASE_MAX_INTERVALS}.',
            'Each actual tail command (symmetric trim +/- differential) must stay within -10 to +10 deg.',
            'This action computes its own four-panel symmetric trim; the longitudinal trim result is a different model.',
            'Existing free-flight model: CG and local panel speeds 30 to 300 ft/s, sideslip within +/-10 deg, plus declared incidence/Reynolds/coefficient limits. Broadside 200-knot release is outside this model.']),
        geometry=dict(fields=geom_fields,constraints=[
            'Wing and tail leading-edge stations must lie within the fuselage length.',
            'Aileron inboard distance plus span must fit within half the exposed wing span.',
            'Wing and tail load stations must differ by at least 0.001 in. Geometry edits do not automatically move component mass locations.']),
        components=dict(fields=components,constraints=[
            'Blank mass inputs are unknown. Point masses require manual placement; line length and box length/width/height must be positive.',
            'At most 100 components; entered weights are lbf, not lbm. Numerical coordinate bounds do not establish packaging feasibility.']),
        placement=dict(fields=_fields({key:POSITION_BOUNDS for key in ('forward_station_in','left_y_in','top_z_in')},
                                      ('forward_station_in','left_y_in','top_z_in')),constraints=[]),
        load_case=dict(fields={'a_up_g':dict(type='number',minimum=ACCELERATION_BOUNDS[0],maximum=ACCELERATION_BOUNDS[1],unit='g',nullable=False)},
                       constraints=['Load factor n = 1 + upward acceleration/g; 0 means steady 1-g support.']),
        cut=dict(fields={'station_in':dict(type='number',minimum=0,maximum=1000,maximum_field='geometry.fuselage_length_in',unit='in',nullable=False)},constraints=[]),
        aircraft=dict(fields=_fields({'target_weight_lbf':WEIGHT_BOUNDS}),constraints=[]))
    from .aircraft_cg_study import input_limits as cg_study_limits
    groups['cg_study']=cg_study_limits()
    return dict(schema='aircraft-input-limits-v1',scope='Numerical input bounds and additional model assumptions; not an approved flight or design envelope.',groups=groups)
