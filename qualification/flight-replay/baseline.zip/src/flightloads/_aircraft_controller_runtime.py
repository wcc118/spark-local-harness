"""Same-plant sampled trace engine; public summaries are a separate C2 layer."""
from copy import deepcopy
import json
import math
import numpy as np
from .aircraft_controller import SampledController, ideal_measurement, CONTROL_KEYS
from .aircraft_actuators import ActuatorBank
from .station_loads import StationModel
from .aircraft_controller import attitude_error_body_deg
from .aircraft_controller_plant import ControllerPlant, PlantDomainError
from .aircraft_controller_trim import trim_bench
from .aircraft_elastic import digest
from .aircraft_release import quaternion_321
from .aircraft_transient import G_N, FT_M
from .conventions import rotation_matrix, quaternion_multiply, attitude_error
from .integration import integrate
from .state import RigidState
from .flight_conditions import flight_condition


class _GroundStop(ValueError):
    pass


_NUMERICAL = (ValueError, FloatingPointError, OverflowError, np.linalg.LinAlgError)


def _plain(value):
    # Existing imperial recovery includes NumPy scalar floats. JSON round trip
    # both copies that data and rejects nonfinite values without changing numbers.
    return json.loads(json.dumps(value, allow_nan=False))


def _truth(tick, time, state, controls, field, reference):
    R = rotation_matrix(state.q_NB)
    air = np.array(field['velocity_air_B_ft_s'])
    speed = math.hypot(*air)
    air_N = R@air
    zero = speed <= 1e-12
    vertical = math.hypot(R[0,0],R[1,0]) <= 1e-12
    norm_error = abs(float(np.linalg.norm(state.q_NB))-1)
    if norm_error > 1e-12: raise ValueError('Accepted quaternion norm exceeds tolerance')
    return dict(tick=tick,time_s=time,state_SI=state.to_vector().tolist(),actual_controls=deepcopy(controls),
        attitude_error_deg=math.degrees(attitude_error(state.q_NB,reference.q_NB)),
        rate_max_deg_s=float(max(abs(np.degrees(state.omega_B_radps)))),airspeed_ft_s=speed,
        height_ft=float(-state.r_CG_N_m[2]/FT_M),
        alpha_deg=None if zero else math.degrees(math.atan2(air[2],air[0])),
        beta_deg=None if zero else math.degrees(math.asin(float(np.clip(air[1]/speed,-1,1)))),
        flight_path_deg=None if zero else math.degrees(math.atan2(-air_N[2],math.hypot(*air_N[:2]))),
        heading_deg=None if vertical else math.degrees(math.atan2(R[1,0],R[0,0])),
        air_angles_reason='Zero airspeed' if zero else None,
        heading_reason='Body-forward axis vertical' if vertical else None,quaternion_norm_error=norm_error)


def _governing(governing, tick, time, controls, field, loads):
    if not loads['balanced']: return
    extrema, snapshots = governing['extrema'], governing['snapshots']
    changed = False
    for quantity in ('cut_force_B_lbf','cut_moment_B_in_lbf'):
        for axis,value in zip('xyz',loads[quantity]):
            for side in ('min','max'):
                key = quantity+'/'+axis+'/'+side
                previous = extrema.get(key)
                if previous is None or (value < previous['value'] if side=='min' else value > previous['value']):
                    extrema[key] = dict(value=value,tick=tick,time_s=time,snapshot_key=str(tick))
                    changed = True
    if changed:
        snapshots[str(tick)] = _plain(dict(tick=tick,time_s=time,actual_controls=controls,field=field,recovery=loads))
        referenced = {entry['snapshot_key'] for entry in extrema.values()}
        for key in list(snapshots):
            if key not in referenced: del snapshots[key]


def simulate_bench(inputs, *, progress=None, cancelled=None):
    for name,callback in (('progress',progress),('cancelled',cancelled)):
        if callback is not None and not callable(callback): raise ValueError(name+' must be callable or None')
    trim = trim_bench(inputs,verify_hold=False)
    saved = deepcopy(trim['inputs'])
    bench = saved['bench']; timing = bench['timing']; dt = timing['plant_dt_s']
    capture_version=bench['schema_version']==2
    total = round(timing['duration_s']/dt)
    trace = dict(schema='aircraft-controller-trace-v1',inputs=saved,inputs_sha256=saved['inputs_sha256'],
        trim=trim,initial_state_SI=None,status='running',stop_reason=None,stop_tick=None,stop_time_s=None,
        cancel_tick=None,truth=[],measurements=[],commands=[],segments=[],events=[],located_loads=[],station_loads=[],
        governing_loads=dict(extrema={},snapshots={}),coverage_gaps=[],max_raw_stage_quaternion_norm_error=None,
        settings=dict(state_order=['r_CG_N_m[3]','v_CG_B_mps[3]','q_NB[4]','omega_B_radps[3]'],
            quaternion_convention='Hamilton scalar-first body-to-NED',body_axes='x forward, y right, z down',
            load_scope='selected-cut rigid free-flight',plant_dt_s=dt,sensor_period_s=timing['sensor_period_s'],
            controller_period_s=timing['controller_period_s'],total_ticks=total,quaternion_tolerance=1e-12,
            time_roundoff_factor=64,zero_airspeed_ft_s=1e-12))

    if capture_version:
        trace['thrust_segments']=[]

    def notification(status):
        last = trace['truth'][-1] if trace['truth'] else None
        return dict(accepted_tick=None if last is None else last['tick'],total_ticks=total,
                    time_s=None if last is None else last['time_s'],status=status)

    def finish(status, reason, tick=None, time=None):
        trace.update(status=status,stop_reason=reason,stop_tick=tick,stop_time_s=time)
        if status=='cancelled': trace['cancel_tick'] = tick
        trace['events'].append(dict(tick=tick,time_s=time,kind='completed' if status=='completed' else 'stop',reason=reason))
        if progress is not None: progress(notification(status))
        return _plain(trace)

    def failed(error, tick, time):
        status = 'ground' if isinstance(error,_GroundStop) else ('model-domain' if isinstance(error,PlantDomainError) else 'numerical-error')
        return finish(status,str(error),tick,time)

    if trim['status'] != 'feasible': return finish('not-run-trim',trim['reason'])
    reference = RigidState.from_vector(trim['candidate']['state_SI'])
    delta = quaternion_321(*np.radians(bench['disturbance']['attitude_body_deg']))
    q = quaternion_multiply(reference.q_NB,delta)
    velocity_N = rotation_matrix(reference.q_NB)@reference.v_CG_B_mps
    if capture_version:
        wind=np.array(saved['field_case']['wind_N_ft_s'])*FT_M
        air=velocity_N-wind
        speed=math.hypot(*air)+bench['disturbance']['airspeed_delta_ft_s']*FT_M
        gamma=math.atan2(-air[2],math.hypot(*air[:2]))+math.radians(bench['disturbance']['flight_path_delta_deg'])
        azimuth=math.atan2(air[1],air[0])
        velocity_N=np.array([speed*math.cos(gamma)*math.cos(azimuth),speed*math.cos(gamma)*math.sin(azimuth),-speed*math.sin(gamma)])+wind
    state = RigidState(reference.r_CG_N_m,rotation_matrix(q).T@velocity_N,q,
                       reference.omega_B_radps+np.radians(bench['disturbance']['rate_body_deg_s']))
    launch = bench.get('launch') if capture_version else None
    if launch is not None:
        from .launch import exit_state
        state = exit_state(launch['scenario'])
        trace['events'].append(dict(tick=0,time_s=0.,kind='launch-exit',reason='Initial state from tube exit scenario' if launch['scenario']['schema_version']==1 else 'Initial state from fully separated platform release scenario'))
    trace['initial_state_SI'] = state.to_vector().tolist()
    controls = deepcopy(trim['candidate']['controls'])
    authority = trim['effectiveness']
    if authority['status'] != 'available' and bench['controller']['mode'] != 'off':
        return finish('not-run-authority',authority['reason'])
    matrix = authority['matrix'] if authority['status']=='available' else np.zeros((3,3)).tolist()
    if authority['status'] != 'available':
        trace['events'].append(dict(tick=0,time_s=0.,kind='authority-unused',reason='Off mode holds trim; zero allocation matrix unused'))
    phase = dict(name='rate-damp',start_s=0.,dwell_since=None)
    plant = ControllerPlant(saved)
    station_model = StationModel(plant)
    controller = SampledController(bench,controls,matrix,reference.q_NB.tolist())
    bank = ActuatorBank(bench,controls)
    if capture_version:
        from .aircraft_controller_capture import CaptureController, ThrustActuator
        if not bench['outer_loop']['pitch_min_deg']<=trim['candidate']['pitch_deg']<=bench['outer_loop']['pitch_max_deg']:
            return finish('not-run-authority','Trim pitch outside declared outer-loop limits')
        outer=CaptureController(bench,reference.to_vector().tolist(),controls['thrust_lbf'],saved['field_case']['wind_N_ft_s'])
        thrust_bank=ThrustActuator(bench,controls['thrust_lbf'])
    schedule = bench.get('schedule') if capture_version else None
    if schedule is not None:
        wind_N = np.array(saved['field_case']['wind_N_ft_s'], dtype=float)
        q_trim = _dynamic_pressure(plant, reference.r_CG_N_m, rotation_matrix(reference.q_NB)@reference.v_CG_B_mps/FT_M, wind_N)
    sensor_stride = round(timing['sensor_period_s']/dt)
    controller_stride = round(timing['controller_period_s']/dt)
    measurement = None
    gaps = set()
    trace['events'].append(dict(tick=0,time_s=0.,kind='controller-mode',reason=bench['controller']['mode']))

    def evaluate(candidate, actual, time_s):
        if candidate.r_CG_N_m[2] >= 0: raise _GroundStop('CG ground-plane crossing; not resolved contact')
        return plant.evaluate(candidate,actual,float(time_s))

    for tick in range(total+1):
        time = tick*dt
        actual = dict(zip(CONTROL_KEYS[:3],bank.snapshot()['next_actual_deg']))
        actual['thrust_lbf'] = thrust_bank.snapshot()['next_actual_lbf'] if capture_version else controls['thrust_lbf']
        try:
            field,_,derivative = evaluate(state,actual,time)
            loads = _plain(plant.recover(state,field,derivative,float(time)))
            row = _plain(_truth(tick,time,state,actual,field,reference))
            row['flight_condition'] = flight_condition(plant,state,field,derivative)
            load_row = dict(tick=tick,time_s=time,field_sha256=digest(field),
                recovery={k:v for k,v in loads.items() if k not in ('ledger','retained_ledger')},
                coverage_gap_count=len(field['reference_coverage_gaps']))
            stations = station_model.evaluate(state,field,derivative,float(time))['stations']
            trace['truth'].append(row); trace['located_loads'].append(load_row)
            trace['station_loads'].append(_plain(dict(tick=tick,time_s=time,stations=stations)))
            if trace['segments']: trace['segments'][-1]['completed'] = True
            if capture_version and trace['thrust_segments']: trace['thrust_segments'][-1]['completed']=True
            gaps.update(field['reference_coverage_gaps']); trace['coverage_gaps'] = sorted(gaps)
            _governing(trace['governing_loads'],tick,time,actual,field,loads)
        except _NUMERICAL as error:
            return failed(error,tick,time)
        if not loads['balanced']: return finish('numerical-error','Whole-body load recovery imbalance',tick,time)
        if tick==total: return finish('completed',None,tick,time)
        # Deliberately outside physics exception handling. Each callback gets its
        # own flat data copy and cannot mutate the trace or the other callback.
        if progress is not None: progress(notification('running'))
        if cancelled is not None:
            cancel = cancelled(notification('running'))
            if type(cancel) is not bool: raise ValueError('cancelled callback must return bool')
            if cancel: return finish('cancelled','Cancelled at accepted tick',tick,time)
        attempted_time = time
        try:
            if tick%sensor_stride==0:
                measurement = ideal_measurement(state,float(time))
                trace['measurements'].append(dict(tick=tick,**deepcopy(measurement)))
            command = None; thrust_command=None
            if tick%controller_stride==0:
                scale = None
                if schedule is not None:
                    ratio = _dynamic_pressure(plant, measurement['position_N_m'], np.array(measurement['velocity_N_m_s'])/FT_M, wind_N)/q_trim
                    scale = float(np.clip(ratio**schedule['exponent'], schedule['min_scale'], schedule['max_scale']))
                if launch is not None and phase['name']!='capture':
                    _advance_launch_phase(phase,launch,measurement,tick,time,outer,controller,actual,trace)
                if launch is None or phase['name']=='capture':
                    outer_output=outer.step(tick,measurement,actual['thrust_lbf']) if capture_version else None
                    output = controller.step(tick,measurement,[actual[k] for k in CONTROL_KEYS[:3]],
                        target_q_NB=outer_output['desired_q_NB'] if capture_version else None, effectiveness_scale=scale)
                    if capture_version:
                        output.update(outer_output)
                        if outer_output.get('outer_diagnostics',{}).get('autopilot_engagement_time_s')==float(time):
                            trace['events'].append(dict(tick=tick,time_s=float(time),kind='autopilot-engaged',
                                stabilization_start_s=outer_output['outer_diagnostics']['stabilization_start_s'],
                                reason='Stable-flight criteria held; capture -> altitude-hold',trigger='criteria-dwell'))
                        thrust_command=outer_output['thrust_lbf']
                    if launch is not None: output['launch_phase']='capture'
                else:
                    # Rate damping targets the measured attitude (zero attitude error: rates only);
                    # attitude recovery targets the level trim attitude. Thrust at its maximum.
                    # Speed recovery (#221) holds a nose-down attitude at the trim heading and roll.
                    target = (measurement['q_NB'] if phase['name']=='rate-damp' else
                              outer.trim_q if phase['name']=='attitude' else _recovery_attitude(outer, launch['speed_recovery']))
                    output = controller.step(tick,measurement,[actual[k] for k in CONTROL_KEYS[:3]],target_q_NB=target,effectiveness_scale=scale)
                    thrust_command=bench['target']['trim_thrust_max_lbf']
                    output.update(launch_phase=phase['name'],thrust_lbf=thrust_command)
                trace['commands'].append(dict(**output,controller_state=controller.snapshot()))
                command = output['command_surface_deg']
            segment = bank.plan_interval(tick,command)
            trace['segments'].append(dict(**segment.as_dict(),completed=False))
            if capture_version:
                thrust_segment=thrust_bank.plan_interval(tick,thrust_command)
                trace['thrust_segments'].append(dict(**thrust_segment.as_dict(),completed=False))
            end = (tick+1)*dt
            tolerance = 64*np.finfo(float).eps*max(1.,abs(time),abs(end))

            def load_provider(stage_time, candidate, context):
                nonlocal attempted_time
                attempted_time = float(stage_time)
                elapsed = stage_time-time
                if elapsed < -tolerance or elapsed > dt+tolerance:
                    raise ValueError('RK stage outside actuator segment')
                error = abs(float(np.linalg.norm(candidate.q_NB))-1)
                previous = trace['max_raw_stage_quaternion_norm_error']
                trace['max_raw_stage_quaternion_norm_error'] = error if previous is None else max(previous,error)
                stage_controls = dict(zip(CONTROL_KEYS[:3],segment.at(float(np.clip(elapsed,0,dt)))))
                stage_controls['thrust_lbf'] = thrust_segment.at(float(np.clip(elapsed,0,dt))) if capture_version else controls['thrust_lbf']
                return evaluate(candidate,stage_controls,stage_time)[1]

            integrated = integrate(state,plant.mass,end,end-time,load_provider,lambda *args:G_N,t0=time,max_steps=1)
            state = integrated.state_at(-1)
        except _NUMERICAL as error:
            return failed(error,tick,attempted_time)


def _recovery_attitude(outer, recovery):
    R = rotation_matrix(outer.trim_q)
    heading = math.atan2(R[1, 0], R[0, 0])
    return quaternion_321(outer.trim_roll, math.radians(recovery['pitch_deg']), heading).tolist()


def _dynamic_pressure(plant, position_N_m, velocity_N_ft_s, wind_N_ft_s):
    """q = rho |v_air|^2 / 2 (lbf/ft^2) with the plant's environment at the CG height and the
    steady wind (ideal sensing; gusts are not measured)."""
    from types import SimpleNamespace
    rho = plant.environment_at(SimpleNamespace(r_CG_N_m=np.asarray(position_N_m, dtype=float)))['density_slug_ft3']
    air = np.asarray(velocity_N_ft_s, dtype=float) - np.asarray(wind_N_ft_s, dtype=float)
    return 0.5*rho*float(air@air)


def _advance_launch_phase(phase, launch, measurement, tick, time, outer, controller, actual, trace):
    """Launch mode logic (#220): rate-damp -> attitude -> [speed-recovery, #221] -> capture on
    criteria held for a dwell, or on the phase time limit. Speed recovery is entered only when
    configured and the airspeed at the end of attitude recovery is below its floor. Integrators reset at every transition; the outer loop begins
    at the capture tick from the measured pitch and actual thrust (bumpless)."""
    omega_deg = np.degrees(np.asarray(measurement['omega_B_rad_s'], dtype=float))
    rate_max = float(np.max(np.abs(omega_deg)))
    attitude_error = float(np.linalg.norm(attitude_error_body_deg(measurement['q_NB'], outer.trim_q)))
    rates_ok = rate_max <= launch['rate_damp']['threshold_deg_s']
    recovery = launch.get('speed_recovery')
    airspeed = float(np.linalg.norm(np.asarray(measurement['velocity_N_m_s']) - outer.wind))/0.3048
    if phase['name'] == 'rate-damp':
        settings, ok, following = launch['rate_damp'], rates_ok, 'attitude'
    elif phase['name'] == 'attitude':
        settings = launch['attitude']
        following = 'speed-recovery' if recovery is not None and airspeed < recovery['min_airspeed_ft_s'] else 'capture'
        ok = rates_ok and attitude_error <= launch['attitude']['threshold_deg']
    else:  # speed-recovery (#221): hold the dive attitude until the capture floor speed is regained
        settings, following = recovery, 'capture'
        ok = airspeed >= recovery['min_airspeed_ft_s']
    phase['dwell_since'] = (phase['dwell_since'] if phase['dwell_since'] is not None else time) if ok else None
    met = ok and time - phase['dwell_since'] >= settings['dwell_s'] - 1e-12
    timed_out = time - phase['start_s'] >= settings['max_s'] - 1e-12
    if not (met or timed_out):
        return
    trace['events'].append(dict(tick=tick, time_s=float(time), kind='launch-phase', reason=f"{phase['name']} -> {following}",
                                trigger='criteria' if met else 'timeout', max_rate_deg_s=rate_max,
                                attitude_error_deg=attitude_error, airspeed_ft_s=airspeed))
    controller.reset_integral()
    if following == 'capture':
        R = rotation_matrix(measurement['q_NB'])
        pitch = math.degrees(math.asin(float(np.clip(-R[2, 0], -1, 1))))
        outer.begin(tick, pitch, actual['thrust_lbf'])
    phase.update(name=following, start_s=float(time), dwell_since=None)
