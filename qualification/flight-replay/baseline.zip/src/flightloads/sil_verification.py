"""Independent clock, held-torque motion, cut-load and SIL parity evidence."""
from dataclasses import replace
import numpy as np
from .sil import CASES, SILConfig, UNITS, run_sil
from .sil_controller import MathematicalController, CompiledController, Command, Measurement, ControllerState

# Component-wise SI comparison, never a mixed-unit state norm.
ATOL = {'tick': 0., 'boolean': 0., 's': 1e-12, 'm': 1e-11, 'm/s': 1e-11,
        '1': 1e-11, 'rad': 1e-11, 'rad/s': 1e-11, 'rad s': 1e-11,
        'N': 1e-10, 'N m': 1e-10}
RTOL = 1e-10


def compare(name, observed, reference, unit, *, atol=None, rtol=None):
    x, y = np.asarray(observed), np.asarray(reference)
    if x.shape != y.shape or not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError(f'{name}: comparison requires matching finite arrays')
    absolute = ATOL[unit] if atol is None else atol
    relative = (0. if unit in ('tick', 'boolean') else RTOL) if rtol is None else rtol
    error = abs(x-y)
    limit = absolute + relative*abs(y)
    return dict(name=name, unit=unit, max_abs_error=float(np.max(error)),
                atol=absolute, rtol=relative, passed=bool(np.all(error <= limit)))


def verify_history(history):
    a, c = history.arrays, history.config
    checks = []
    def test(key, reference, unit=None):
        checks.append(compare(key, a[key], reference, unit or UNITS[key]))
    k = np.arange(c.steps+1)
    times = k*c.dt_s
    test('tick', k); test('time_s', times)
    capture = k % c.sensor_ticks == 0
    released = (k >= c.delay_ticks) & ((k-c.delay_ticks) % c.sensor_ticks == 0)
    available = k >= c.delay_ticks
    capture_tick = np.where(available, ((k-c.delay_ticks)//c.sensor_ticks)*c.sensor_ticks, -c.delay_ticks)
    release_tick = np.where(available, capture_tick+c.delay_ticks, 0)
    test('capture_event', capture.astype(int))
    test('release_event', released.astype(int))
    test('scheduled_release_tick', np.where(capture, k+c.delay_ticks, 0))
    test('measurement_capture_tick', capture_tick)
    test('measurement_release_tick', release_tick)
    test('measurement_age_s', (k-capture_tick)*c.dt_s)
    test('captured_yaw_rad', np.where(capture, a['yaw_rad'], 0.))
    test('captured_rate_radps', np.where(capture, a['omega_B_radps'][:, 2], 0.))
    indices = np.maximum(capture_tick, 0)
    test('measured_yaw_rad', np.where(available, a['yaw_rad'][indices], 0.))
    test('measured_rate_radps', np.where(available, a['omega_B_radps'][indices, 2], 0.))
    updates = k % c.controller_ticks == 0
    test('controller_event', updates.astype(int))
    test('controller_elapsed_s', np.where(updates & (k > 0), c.controller_ticks*c.dt_s, 0.))
    command = np.where(k >= c.command_tick, c.command_rad, 0.)
    test('command_rad', command)
    # Offline recurrence, using expected update clocks, not controller adapters.
    integral = error = unlimited = 0.
    integral_history, error_history, command_history = [], [], []
    for j in k:
        if updates[j]:
            integral = np.clip(integral + error*(c.controller_ticks*c.dt_s if j else 0), -.2, .2)
            error = command[j] - a['measured_yaw_rad'][j]
            unlimited = 24*error + 8*integral - 24*a['measured_rate_radps'][j]
        integral_history.append(integral); error_history.append(error); command_history.append(unlimited)
    test('integral_rad_s', np.array(integral_history))
    test('previous_error_rad', np.array(error_history))
    test('unlimited_torque_Nm', np.array(command_history))
    clipped = np.clip(a['unlimited_torque_Nm'], -c.torque_limit_Nm, c.torque_limit_Nm)
    actuator = np.zeros(len(k))
    for j in k:
        previous = actuator[j-1] if j else 0.
        actuator[j] = np.clip(clipped[j], previous-c.slew_Nmps*c.dt_s, previous+c.slew_Nmps*c.dt_s)
    test('actuator_torque_Nm', actuator)
    test('saturation_event', (clipped != a['unlimited_torque_Nm']).astype(int))
    test('slew_event', (actuator != clipped).astype(int))
    # Independently integrate scalar mechanics with the recorded held input.
    alpha = a['actuator_torque_Nm']/8.
    theta = np.zeros(len(k)); rate = np.zeros(len(k))
    for j, h in enumerate(np.diff(times)):
        theta[j+1] = theta[j] + h*rate[j] + .5*h*h*alpha[j]
        rate[j+1] = rate[j] + h*alpha[j]
    test('yaw_rad', theta)
    test('omega_B_radps', np.column_stack((np.zeros(len(k)), np.zeros(len(k)), rate)))
    test('quaternion_NB', np.column_stack((np.cos(theta/2), np.zeros(len(k)), np.zeros(len(k)), np.sin(theta/2))))
    test('position_N_m', np.zeros((len(k), 3))); test('velocity_B_mps', np.zeros((len(k), 3)))
    test('section_force_B_N', np.column_stack((-2*rate**2, 2*alpha, np.zeros(len(k)))))
    test('section_moment_B_Nm', np.column_stack((np.zeros(len(k)), np.zeros(len(k)), 3*alpha)))
    test('force_residual_B_N', np.zeros((len(k), 3)))
    test('moment_residual_B_Nm', np.zeros((len(k), 3)))
    checks.append(dict(name='pure_yaw_branch', unit='rad', maximum=float(max(abs(a['yaw_rad']))),
                       upper_exclusive=1., passed=bool(np.all(abs(a['yaw_rad']) < 1.))))
    if c in CASES:
        for field in ('saturation_event', 'slew_event'):
            expected = c.case == 'limited'
            checks.append(dict(name=field+'_activation', observed=bool(np.any(a[field])),
                               expected=expected, passed=bool(np.any(a[field])) == expected))
        if c.case == 'nominal':
            checks.append(dict(name='nominal_integral_clamp_inactive',
                maximum=float(max(abs(a['integral_rad_s']))), upper_exclusive=.2,
                passed=bool(np.all(abs(a['integral_rad_s']) < .2))))
    return checks


def compare_histories(left, right):
    if left.config != right.config:
        raise ValueError('parity requires identical case definitions')
    return [compare(key, left.arrays[key], right.arrays[key], unit) for key, unit in UNITS.items()]


def direct_checks(controller):
    # Independent expected transitions, including both clamp signs.
    cases = [(.1, 0., 0., 0., 0., 0., 0., .1, 2.4),
             (.1, .01, .02, 0., .1, .02, .002, .09, 1.696),
             (-.1, .1, -.1, .19, 2., .02, .2, -.2, -.8),
             (.1, -.1, .1, -.19, -2., .02, -.2, .2, .8)]
    checks = []
    for i, (cmd, yaw, rate, integral, previous, elapsed, ei, ee, eu) in enumerate(cases):
        out = controller.step(Measurement(yaw, rate), Command(cmd), ControllerState(integral, previous), elapsed)
        for name, value, reference, unit in (('integral',out.state.integral_rad_s,ei,'rad s'),
                ('error',out.state.previous_error_rad,ee,'rad'), ('torque',out.torque_Nm,eu,'N m')):
            checks.append(compare(f'direct_{i}_{name}', value, reference, unit))
    return checks


def continuous_yaw(times, step_s=.2, amplitude=.1):
    u = np.maximum(np.asarray(times)-step_s, 0.)
    return amplitude*(1+(u*u-u-1)*np.exp(-u))


def convergence_study():
    """Separate sample refinement from plant refinement with fixed physical clocks."""
    histories, checks, sample_errors = {}, [], []
    base = SILConfig(case='verification', steps=2000)
    for factor in (1, 2, 4):
        config = replace(base, dt_s=base.dt_s/factor, steps=base.steps*factor,
                         command_tick=base.command_tick*factor)
        run = run_sil(config, MathematicalController())
        name = f'sampling_{factor}'
        histories[name] = run
        checks.extend(dict(item, name=name+'/'+item['name']) for item in verify_history(run))
        error = float(max(abs(run.arrays['yaw_rad'] - continuous_yaw(run.arrays['time_s']))))
        sample_errors.append(error)
        checks.append(dict(name=name+'/ideal_error', unit='rad', maximum=error,
                           upper=.004/factor, passed=error <= .004/factor))
        checks.append(dict(name=name+'/limits_inactive', passed=bool(
            not np.any(run.arrays['saturation_event']) and not np.any(run.arrays['slew_event'])
            and np.all(abs(run.arrays['integral_rad_s']) < .2))))
    for i in (0, 1):
        ratio = sample_errors[i]/sample_errors[i+1]
        checks.append(dict(name=f'sampling_ratio_{i}', value=ratio, lower=1.7, upper=2.3,
                           passed=1.7 <= ratio <= 2.3))
    # Preserve .01 s sensing, .02 s control, .2 s command, physical actuator limits.
    refined = replace(base, dt_s=.001, steps=4000, sensor_ticks=10,
                      controller_ticks=20, command_tick=200)
    run = run_sil(refined, MathematicalController()); histories['plant_2'] = run
    checks.extend(dict(item, name='plant_2/'+item['name']) for item in verify_history(run))
    for key in ('yaw_rad', 'omega_B_radps', 'section_force_B_N', 'section_moment_B_Nm'):
        checks.append(compare('fixed_sampling_plant_refinement/'+key,
            histories['sampling_1'].arrays[key], run.arrays[key][::2], UNITS[key]))
    return histories, checks


def compute_study():
    histories, checks = {}, {}
    mathematical = MathematicalController()
    with CompiledController() as compiled:
        provenance = dict(compiled.provenance)
        checks['direct_mathematical'] = direct_checks(mathematical)
        checks['direct_compiled'] = direct_checks(compiled)
        for config in CASES:
            for name, controller in (('mathematical', mathematical), ('compiled', compiled)):
                key = config.case+'_'+name
                histories[key] = run_sil(config, controller)
                checks[key] = verify_history(histories[key])
            checks[config.case+'_parity'] = compare_histories(histories[config.case+'_mathematical'],
                                                             histories[config.case+'_compiled'])
    convergence, evidence = convergence_study()
    histories.update(convergence); checks['convergence'] = evidence
    return histories, checks, provenance
