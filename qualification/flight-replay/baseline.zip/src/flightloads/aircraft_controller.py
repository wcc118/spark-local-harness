"""Sampled ideal-state control primitives; see mechanics/SAMPLED_CONTROLLER.md."""
from copy import deepcopy
from itertools import product
import math
import numpy as np
from .aircraft_controller_contract import validate_bench, _number, _object, _json_values
from .conventions import unit_quaternion, quaternion_multiply, rotation_matrix
from .state import RigidState

SURFACES = ('left_tail', 'right_tail', 'aileron')
CONTROL_KEYS = tuple(n+'_deg' for n in SURFACES)+('thrust_lbf',)
MEASUREMENT_KEYS = ('adapter','acquisition_time_s','available_time_s','q_NB',
                    'omega_B_rad_s','position_N_m','velocity_N_m_s')


def _vector(value, size, name):
    if type(value) is not list or len(value) != size:
        raise ValueError(name+' requires a JSON list of length '+str(size))
    for v in value: _number(v, -float('inf'), float('inf'), name)
    return np.array(value, dtype=float)


def _matrix(value):
    if type(value) is not list or len(value) != 3:
        raise ValueError('effectiveness requires three rows')
    return np.array([_vector(r, 3, 'effectiveness row') for r in value])


def _setup(bench, controls):
    bench = validate_bench(bench)
    _object(controls, CONTROL_KEYS, 'trim_controls')
    low = np.array([bench['actuators'][n]['min_deg'] for n in SURFACES], dtype=float)
    high = np.array([bench['actuators'][n]['max_deg'] for n in SURFACES], dtype=float)
    for name, lo, hi in zip(CONTROL_KEYS, low, high):
        _number(controls[name], float(lo), float(hi), name)
    target = bench['target']
    _number(controls['thrust_lbf'], target['trim_thrust_min_lbf'], target['trim_thrust_max_lbf'], 'thrust_lbf')
    if target['thrust_mode']=='fixed' and controls['thrust_lbf'] != target['fixed_thrust_lbf']:
        raise ValueError('Trim thrust must match declared fixed thrust')
    return bench, deepcopy(controls), low, high


def ideal_measurement(state, time_s):
    _number(time_s, 0, float('inf'), 'time_s')
    if not isinstance(state, RigidState): raise ValueError('state must be RigidState')
    result = dict(adapter='ideal-state', acquisition_time_s=float(time_s), available_time_s=float(time_s),
        q_NB=unit_quaternion(state.q_NB).tolist(), omega_B_rad_s=state.omega_B_radps.tolist(),
        position_N_m=state.r_CG_N_m.tolist(), velocity_N_m_s=(rotation_matrix(state.q_NB)@state.v_CG_B_mps).tolist())
    _json_values(result, 'measurement')
    return result


def attitude_error_body_deg(measured_q, target_q):
    measured = unit_quaternion(_vector(measured_q, 4, 'measured quaternion'))
    target = unit_quaternion(_vector(target_q, 4, 'target quaternion'))
    q = quaternion_multiply(measured*[1,-1,-1,-1], target)
    if q[0] < 0 or (q[0] == 0 and next((v for v in q[1:] if v != 0), 0) < 0): q = -q
    norm = float(np.linalg.norm(q[1:]))
    return (np.degrees(q[1:]*(2*math.atan2(norm, float(q[0]))/norm)).tolist()
            if norm else [0.,0.,0.])


def _allocate(B, request, trim, lower, upper):
    delta = np.linalg.lstsq(B, request, rcond=1e-8)[0]
    unbounded = trim+delta
    command = np.clip(unbounded, lower, upper)
    if np.any(command != unbounded):
        best_norm = math.hypot(*(B@(command-trim)-request))
        best_distance = math.hypot(*(command-trim))
        for face in product((0,-1,1), repeat=3):
            free = np.array(face)==0
            trial = np.where(np.array(face)<0, lower-trim, upper-trim)
            trial[free] = 0
            if np.any(free):
                trial[free] = np.linalg.lstsq(B[:,free], request-B@trial, rcond=1e-8)[0]
            surface = trim+trial
            if np.any(surface < lower-1e-12) or np.any(surface > upper+1e-12): continue
            surface = np.clip(surface, lower, upper)
            residual = math.hypot(*(B@(surface-trim)-request))
            distance = math.hypot(*(surface-trim))
            if residual < best_norm-1e-12 or (abs(residual-best_norm)<=1e-12 and distance<best_distance):
                command, best_norm, best_distance = surface, residual, distance
    allocated = B@(command-trim)
    unmet = request-allocated
    singular = np.linalg.svd(B, compute_uv=False)
    if not all(np.all(np.isfinite(a)) for a in (unbounded, command, allocated, unmet, singular)):
        raise ValueError('Nonfinite allocation result')
    return dict(unbounded_surface_deg=unbounded.tolist(), command_surface_deg=command.tolist(),
        allocated_accel_deg_s2=allocated.tolist(), unmet_accel_deg_s2=unmet.tolist(),
        travel_limited=((abs(command-lower)<=1e-12)|(abs(command-upper)<=1e-12)).tolist(),
        rank=int(np.sum(singular > singular[0]*1e-8)))


def allocate_acceleration(matrix, request, trim, lower, upper):
    B = _matrix(matrix)
    request, trim, lower, upper = [_vector(v,3,n) for v,n in
        zip((request,trim,lower,upper),('request','trim','lower','upper'))]
    if np.any(lower>=upper) or np.any(trim<lower) or np.any(trim>upper):
        raise ValueError('Allocation bounds require lower<=trim<=upper and lower<upper')
    return _allocate(B, request, trim, lower, upper)


class SampledController:
    def __init__(self, bench, trim_controls, effectiveness_matrix, target_q_NB):
        self._bench, self._controls, self._low, self._high = _setup(bench, trim_controls)
        self._trim = np.array([self._controls[k] for k in CONTROL_KEYS[:3]], dtype=float)
        self._B = _matrix(effectiveness_matrix)
        self._target = unit_quaternion(_vector(target_q_NB,4,'target_q_NB')).tolist()
        self._settings = self._bench['controller']
        self._dt = self._bench['timing']['plant_dt_s']
        self._period = self._bench['timing']['controller_period_s']
        self._stride = round(self._period/self._dt)
        self.reset()

    def reset(self):
        self._last_tick, self._integral, self._last_command = None, np.zeros(3), self._trim.copy()

    def reset_integral(self):
        """Zero the rate integrators at a mode transition (bumpless launch phases, #220)."""
        self._integral = np.zeros(3)

    def snapshot(self):
        return dict(last_tick=self._last_tick, integral_error_deg=self._integral.tolist(),
                    last_command_surface_deg=self._last_command.tolist())

    def step(self, tick, measurement, actual_surface_deg, *, target_q_NB=None, effectiveness_scale=None):
        """effectiveness_scale (#221): scheduled multiplier on the frozen trim effectiveness,
        B = B_trim * scale; None keeps the unscheduled controller exactly."""
        expected = 0 if self._last_tick is None else self._last_tick+self._stride
        if type(tick) is not int or tick != expected:
            raise ValueError('Expected controller plant tick '+str(expected))
        time = tick*self._dt
        _object(measurement, MEASUREMENT_KEYS, 'measurement')
        if measurement['adapter'] != 'ideal-state': raise ValueError('Expected ideal-state adapter')
        available, acquisition = measurement['available_time_s'], measurement['acquisition_time_s']
        _number(available,0,time,'available_time_s')
        _number(acquisition,0,available,'acquisition_time_s')
        q = _vector(measurement['q_NB'],4,'q_NB')
        omega = _vector(measurement['omega_B_rad_s'],3,'omega_B_rad_s')
        for key in ('position_N_m','velocity_N_m_s'): _vector(measurement[key],3,key)
        actual = _vector(actual_surface_deg,3,'actual_surface_deg')
        if np.any(actual<self._low) or np.any(actual>self._high): raise ValueError('Actual surface outside bounds')
        target=self._target if target_q_NB is None else unit_quaternion(_vector(target_q_NB,4,'target_q_NB')).tolist()
        error = np.array(attitude_error_body_deg(q.tolist(), target))
        c = self._settings; mode = c['mode']
        rate_raw = np.array(c['attitude_gain_per_s'])*error if mode=='rate-attitude' else np.zeros(3)
        rate = np.clip(rate_raw,-np.array(c['rate_limit_deg_s']),c['rate_limit_deg_s'])
        rate_error = rate-np.degrees(omega)
        Ki = np.array(c['rate_integral_gain_per_s2'])
        elapsed = 0. if self._last_tick is None else self._period
        trial = np.clip(self._integral+elapsed*rate_error,-np.array(c['integral_limit_deg']),c['integral_limit_deg'])
        trial[Ki==0] = 0
        if mode=='off': trial[:] = 0
        if effectiveness_scale is not None:
            _number(effectiveness_scale, 0, float('inf'), 'effectiveness_scale', True)
        B = self._B if effectiveness_scale is None else self._B*float(effectiveness_scale)
        tracking = B@(self._last_command-actual)

        def command(integral):
            raw = np.array(c['rate_gain_per_s'])*rate_error+Ki*integral if mode!='off' else np.zeros(3)
            requested = np.clip(raw,-np.array(c['accel_limit_deg_s2']),c['accel_limit_deg_s2'])
            return raw, requested, _allocate(B, requested, self._trim, self._low, self._high)

        raw, requested, allocation = command(trial)
        blocked = raw-np.array(allocation['allocated_accel_deg_s2'])+tracking
        frozen = Ki*(trial-self._integral)*blocked > 1e-12 if mode!='off' else np.zeros(3,dtype=bool)
        accepted = np.where(frozen,self._integral,trial)
        raw, requested, allocation = command(accepted)
        result = dict(tick=tick,time_s=float(time),mode=mode,measurement_time_s=float(acquisition),
            attitude_error_body_deg=error.tolist(),requested_rate_deg_s=rate.tolist(),
            rate_error_deg_s=rate_error.tolist(),unlimited_accel_deg_s2=raw.tolist(),
            requested_accel_deg_s2=requested.tolist(),**allocation,
            tracking_residual_deg_s2=tracking.tolist(),integral_error_deg=accepted.tolist(),
            integral_frozen=frozen.tolist(),rate_limited=(rate_raw!=rate).tolist(),
            accel_limited=(raw!=requested).tolist(),thrust_lbf=self._controls['thrust_lbf'],
            allocation_model='frozen-trim-effectiveness')
        if effectiveness_scale is not None:
            result.update(allocation_model='dynamic-pressure-scheduled', effectiveness_scale=float(effectiveness_scale))
        _json_values(result, 'controller response')
        self._last_tick, self._integral = tick, accepted.copy()
        self._last_command = np.array(allocation['command_surface_deg'])
        return result
