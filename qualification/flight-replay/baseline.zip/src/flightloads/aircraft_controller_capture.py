"""Sampled E2 outer control and pure continuous delayed-thrust segments."""
from copy import deepcopy
from dataclasses import dataclass
import math
import numpy as np
from .aircraft_controller import _vector, MEASUREMENT_KEYS
from .aircraft_controller_contract import validate_bench, _number, _object, _json_values
from .aircraft_release import quaternion_321
from .conventions import rotation_matrix, unit_quaternion
from .state import RigidState


def _clip(value,low,high):
    return float(min(high,max(low,value)))


def _bench(value):
    b=validate_bench(value)
    if b['schema_version']!=2:raise ValueError('Capture requires version2 bench')
    return b


def altitude_command(height_ft,airspeed_ft_s,wind_down_ft_s,target_ft,config):
    """NED steady wind: ground_up = air_up - wind_down; positive height is AGL."""
    error=target_ft-height_ft
    raw=config['altitude_kp_per_s']*error
    ground_up=_clip(raw,-config['max_descent_ft_s'],config['max_climb_ft_s'])
    ratio=(ground_up+wind_down_ft_s)/max(airspeed_ft_s,1e-12)
    raw_gamma=math.degrees(math.asin(_clip(ratio,-1.,1.)))
    gamma=_clip(raw_gamma,config['flight_path_min_deg'],config['flight_path_max_deg'])
    return dict(height_agl_ft=height_ft,target_height_agl_ft=target_ft,height_error_ft=error,
        ground_vertical_speed_command_ft_s=ground_up,flight_path_command_deg=gamma,
        altitude_command_limited=raw!=ground_up or abs(ratio)>1 or gamma!=raw_gamma)


class CaptureController:
    def __init__(self,bench,trim_state_SI,trim_thrust_lbf,wind_N_ft_s):
        self.b=_bench(bench);self.c=self.b['outer_loop'];self.target=self.b['target']
        self.dt=self.b['timing']['plant_dt_s'];self.period=self.b['timing']['controller_period_s']
        self.stride=round(self.period/self.dt)
        state=RigidState.from_vector(_vector(trim_state_SI,13,'trim_state_SI'))
        self.trim_q=unit_quaternion(state.q_NB).tolist()
        R=rotation_matrix(self.trim_q)
        self.trim_pitch=math.degrees(math.asin(float(np.clip(-R[2,0],-1,1))))
        self.trim_roll=math.atan2(R[2,1],R[2,2])
        self.wind=_vector(wind_N_ft_s,3,'wind_N_ft_s')*.3048
        _number(trim_thrust_lbf,self.target['trim_thrust_min_lbf'],self.target['trim_thrust_max_lbf'],'trim_thrust_lbf')
        _number(self.trim_pitch,self.c['pitch_min_deg'],self.c['pitch_max_deg'],'trim pitch')
        self.trim_thrust=float(trim_thrust_lbf)
        self.reset()

    def reset(self):
        self.last_tick=None;self.Iv=0.;self.Ig=0.
        self.stable_since=None;self.engagement_time=None
        self.pitch=self.trim_pitch;self.thrust=self.trim_thrust

    def begin(self,tick,pitch_deg,thrust_lbf):
        """Start the outer loop at a later controller tick (launch handover, #220): integrators
        zero, pitch and thrust memories at the measured pitch and actual thrust (bumpless)."""
        if type(tick) is not int or tick<self.stride or tick%self.stride:raise ValueError('begin tick must be a later controller tick')
        self.reset();self.last_tick=tick-self.stride
        self.pitch=_clip(float(pitch_deg),self.c['pitch_min_deg'],self.c['pitch_max_deg'])
        self.thrust=_clip(float(thrust_lbf),self.target['trim_thrust_min_lbf'],self.target['trim_thrust_max_lbf'])

    def snapshot(self):
        result=dict(mode='autopilot' if self.engagement_time is not None else self.c['mode'],last_tick=self.last_tick,speed_integral_ft=self.Iv,
            flight_path_integral_deg_s=self.Ig,last_pitch_deg=self.pitch,last_thrust_lbf=self.thrust)
        if 'autopilot' in self.b:result.update(stabilization_start_s=self.stable_since,autopilot_engagement_time_s=self.engagement_time)
        return result

    def step(self,tick,measurement,actual_thrust_lbf):
        expected=0 if self.last_tick is None else self.last_tick+self.stride
        if type(tick) is not int or tick!=expected:raise ValueError('Expected controller plant tick '+str(expected))
        _object(measurement,MEASUREMENT_KEYS,'measurement')
        if measurement['adapter']!='ideal-state':raise ValueError('Expected ideal-state adapter')
        now=tick*self.dt
        _number(measurement['available_time_s'],0,now,'available_time_s')
        _number(measurement['acquisition_time_s'],0,measurement['available_time_s'],'acquisition_time_s')
        q=unit_quaternion(_vector(measurement['q_NB'],4,'q_NB'))
        for key in ('omega_B_rad_s','position_N_m'):_vector(measurement[key],3,key)
        velocity=_vector(measurement['velocity_N_m_s'],3,'velocity_N_m_s')-self.wind
        _number(actual_thrust_lbf,self.target['trim_thrust_min_lbf'],self.target['trim_thrust_max_lbf'],'actual_thrust_lbf')
        speed=math.hypot(*velocity)/.3048;horizontal=math.hypot(*velocity[:2])
        _number(speed,0,float('inf'),'sampled airspeed')
        gamma=None if speed<=1e-12 or horizontal<=1e-12 else math.degrees(math.atan2(-velocity[2],horizontal))
        R=rotation_matrix(q);pitch_actual=math.degrees(math.asin(float(np.clip(-R[2,0],-1,1))))
        c=self.c
        if c['mode']=='off':
            result=dict(desired_q_NB=self.trim_q.copy(),thrust_lbf=self.trim_thrust,
                outer_state=dict(mode='off',last_tick=tick,speed_integral_ft=0.,flight_path_integral_deg_s=0.,
                                 last_pitch_deg=self.trim_pitch,last_thrust_lbf=self.trim_thrust),
                outer_measurement=dict(acquisition_time_s=measurement['acquisition_time_s'],airspeed_ft_s=speed,flight_path_deg=gamma))
            self.reset();self.last_tick=tick
            return result
        if gamma is None:raise ValueError('Outer capture requires nonzero nonvertical air velocity')
        autopilot=self.b.get('autopilot');diagnostics={};gamma_target=c['flight_path_target_deg']
        if autopilot:
            criteria=self.b['criteria']
            heading=math.degrees(math.atan2(R[1,0],R[0,0]))
            stable=(abs(speed-self.target['airspeed_ft_s'])<=criteria['speed_error_ft_s']
                and abs(gamma-gamma_target)<=criteria['flight_path_error_deg']
                and abs((heading-self.target['heading_deg']+180)%360-180)<=criteria['heading_error_deg']
                and max(abs(math.degrees(x)) for x in measurement['omega_B_rad_s'])<=criteria['rate_error_deg_s'])
            if self.engagement_time is None:
                self.stable_since=(now if self.stable_since is None else self.stable_since) if stable else None
                if self.stable_since is not None and now-self.stable_since+1e-12>=autopilot['engagement_dwell_s']:
                    self.engagement_time=now
            diagnostics=altitude_command(-measurement['position_N_m'][2]/.3048,speed,self.wind[2]/.3048,
                                         self.target['height_agl_ft'],autopilot)
            if self.engagement_time is not None:gamma_target=diagnostics['flight_path_command_deg']
            diagnostics.update(autopilot_engagement_time_s=self.engagement_time,
                               stabilization_start_s=self.stable_since)
        ev=self.target['airspeed_ft_s']-speed;eg=gamma_target-gamma
        h=0. if self.last_tick is None else self.period
        trial_v=_clip(self.Iv+h*ev,-c['speed_integral_limit_ft'],c['speed_integral_limit_ft']) if c['speed_ki_lbf_per_ft'] else 0.
        trial_g=_clip(self.Ig+h*eg,-c['flight_path_integral_limit_deg_s'],c['flight_path_integral_limit_deg_s']) if c['flight_path_ki_per_s'] else 0.
        def commands(iv,ig):
            thrust_raw=self.trim_thrust+c['speed_kp_lbf_per_ft_s']*ev+c['speed_ki_lbf_per_ft']*iv
            pitch_raw=self.trim_pitch+gamma_target+c['flight_path_kp']*eg+c['flight_path_ki_per_s']*ig
            thrust=_clip(thrust_raw,self.target['trim_thrust_min_lbf'],self.target['trim_thrust_max_lbf'])
            pitch=_clip(pitch_raw,c['pitch_min_deg'],c['pitch_max_deg'])
            pitch=_clip(pitch,self.pitch-c['pitch_rate_deg_s']*h,self.pitch+c['pitch_rate_deg_s']*h)
            return thrust_raw,pitch_raw,thrust,pitch
        tr,pr,thrust,pitch=commands(trial_v,trial_g)
        freeze_v=(self.Iv*(trial_v-self.Iv)>=0 and c['speed_ki_lbf_per_ft']*(trial_v-self.Iv)*(tr-thrust+self.thrust-actual_thrust_lbf)>1e-12)
        freeze_g=(self.Ig*(trial_g-self.Ig)>=0 and c['flight_path_ki_per_s']*(trial_g-self.Ig)*(pr-pitch+self.pitch-pitch_actual)>1e-12)
        iv=self.Iv if freeze_v else trial_v;ig=self.Ig if freeze_g else trial_g
        tr,pr,thrust,pitch=commands(iv,ig)
        desired=quaternion_321(self.trim_roll,math.radians(pitch),math.radians(self.target['heading_deg'])).tolist()
        state=dict(mode='autopilot' if self.engagement_time is not None else 'capture',last_tick=tick,speed_integral_ft=iv,flight_path_integral_deg_s=ig,last_pitch_deg=pitch,last_thrust_lbf=thrust)
        if autopilot:state.update(stabilization_start_s=self.stable_since,autopilot_engagement_time_s=self.engagement_time)
        result=dict(desired_q_NB=desired,thrust_lbf=thrust,outer_state=state,
            outer_measurement=dict(acquisition_time_s=measurement['acquisition_time_s'],airspeed_ft_s=speed,flight_path_deg=gamma),
            outer_diagnostics=dict(**diagnostics,flight_path_target_deg=gamma_target,speed_error_ft_s=ev,flight_path_error_deg=eg,unlimited_thrust_lbf=tr,
                unlimited_pitch_deg=pr,pitch_command_deg=pitch,speed_integral_frozen=freeze_v,
                flight_path_integral_frozen=freeze_g,actual_thrust_lbf=actual_thrust_lbf,sampled_pitch_deg=pitch_actual))
        _json_values(result,'outer response')
        self.last_tick=tick;self.Iv=iv;self.Ig=ig;self.pitch=pitch;self.thrust=thrust
        return deepcopy(result)


@dataclass(frozen=True)
class ThrustSegment:
    tick:int
    dt:float
    start_lbf:float
    target_lbf:float
    rate_lbf_s:float
    requested_thrust_lbf:float|None
    travel_limited:bool
    pending_commands:int

    def at(self,elapsed_s):
        _number(elapsed_s,0,self.dt,'elapsed_s')
        distance=self.target_lbf-self.start_lbf
        return float(self.target_lbf if abs(distance)<=self.rate_lbf_s*elapsed_s else
            self.start_lbf+math.copysign(self.rate_lbf_s*elapsed_s,distance))

    def as_dict(self):
        end=self.at(self.dt)
        return dict(tick=self.tick,time_s=self.tick*self.dt,duration_s=self.dt,start_lbf=self.start_lbf,
            target_lbf=self.target_lbf,end_lbf=end,rate_lbf_s=self.rate_lbf_s,
            requested_thrust_lbf=self.requested_thrust_lbf,travel_limited=self.travel_limited,
            rate_limited=end!=self.target_lbf,pending_commands=self.pending_commands)


class ThrustActuator:
    def __init__(self,bench,trim_thrust_lbf):
        b=_bench(bench);c=b['outer_loop'];t=b['target']
        self.dt=b['timing']['plant_dt_s'];self.low=t['trim_thrust_min_lbf'];self.high=t['trim_thrust_max_lbf']
        _number(trim_thrust_lbf,self.low,self.high,'trim_thrust_lbf')
        self.trim=float(trim_thrust_lbf);self.rate=c['thrust_rate_lbf_s'];self.delay=round(c['thrust_delay_s']/self.dt)
        self.reset()

    def reset(self):
        self.tick=0;self.actual=self.trim;self.target=self.trim;self.queue=[]

    def snapshot(self):
        return dict(next_tick=self.tick,next_actual_lbf=self.actual,target_lbf=self.target,
                    queued_commands=[list(item) for item in self.queue])

    def plan_interval(self,tick,command=None):
        if type(tick) is not int or tick!=self.tick:raise ValueError('Expected thrust plant tick '+str(self.tick))
        if command is not None:_number(command,-float('inf'),float('inf'),'thrust command')
        limited=None if command is None else _clip(command,self.low,self.high)
        if command is not None:self.queue.append((tick+self.delay,limited))
        while self.queue and self.queue[0][0]<=tick:self.target=self.queue.pop(0)[1]
        segment=ThrustSegment(tick,float(self.dt),self.actual,self.target,self.rate,
            command,command is not None and command!=limited,len(self.queue))
        self.actual=segment.at(self.dt);self.tick+=1
        return segment
