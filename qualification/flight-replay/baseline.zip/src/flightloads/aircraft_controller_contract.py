"""Versioned bench inputs and interface declarations; no flight controller yet."""
from copy import deepcopy
import math
from .propulsion import validate_propulsion
from .aircraft_full_angle_field import (FullAngleField, default_environment, default_controls,
    default_settings, ENVIRONMENT, SETTINGS, CONTROLS, _validate as validate_field_group)
from .aircraft_full_angle_polar import validate_parameters, default_parameters
from .aircraft_workspace import validate_definition
from .aircraft_elastic import digest

MODEL_ID = 'aircraft-controller-contract-v1'
MAX_ELEMENT_INTERVALS = 8_000_000
MAX_WIND_COMPONENT_FT_S = 1000.
_DEFAULT = {
    'schema_version': 1,
    'name': 'Default bench configuration',
    'source': 'Architectural specification defaults',
    'target': {'airspeed_ft_s': 150.0, 'height_agl_ft': 1000.0, 'heading_deg': 0.0, 'thrust_mode': 'trim', 'fixed_thrust_lbf': 5.0, 'trim_thrust_min_lbf': 0.0, 'trim_thrust_max_lbf': 100.0},
    'timing': {'duration_s': 20.0, 'plant_dt_s': 0.01, 'sensor_period_s': 0.02, 'controller_period_s': 0.02},
    'controller': {'mode': 'rate-attitude', 'attitude_gain_per_s': [1.0, 1.0, 1.0], 'rate_gain_per_s': [2.0, 2.0, 2.0], 'rate_integral_gain_per_s2': [0.0, 0.0, 0.0], 'integral_limit_deg': [5.0, 5.0, 5.0], 'rate_limit_deg_s': [30.0, 30.0, 30.0], 'accel_limit_deg_s2': [90.0, 90.0, 90.0]},
    'actuators': {'left_tail': {'min_deg': -10.0, 'max_deg': 10.0, 'rate_deg_s': 90.0, 'delay_s': 0.02}, 'right_tail': {'min_deg': -10.0, 'max_deg': 10.0, 'rate_deg_s': 90.0, 'delay_s': 0.02}, 'aileron': {'min_deg': -20.0, 'max_deg': 20.0, 'rate_deg_s': 90.0, 'delay_s': 0.02}},
    'disturbance': {'attitude_body_deg': [0.0, 0.0, 0.0], 'rate_body_deg_s': [0.0, 0.0, 0.0]},
    'criteria': {'attitude_error_deg': 2.0, 'rate_error_deg_s': 1.0, 'speed_error_ft_s': 5.0, 'flight_path_error_deg': 2.0, 'heading_error_deg': 5.0, 'minimum_height_ft': 0.0, 'max_airspeed_ft_s': 1000.0, 'dwell_s': 2.0},
    'provenance': [{'path': 'target', 'status': 'estimated', 'source': 'Exploratory trim point'}, {'path': 'controller', 'status': 'estimated', 'source': 'Initial tuning parameters'}, {'path': 'actuators', 'status': 'estimated', 'source': 'Illustrative travel/rate/delay; no measured actuator capability'}, {'path': 'disturbance', 'status': 'estimated', 'source': 'Zero perturbation baseline'}, {'path': 'criteria', 'status': 'estimated', 'source': 'Acceptance thresholds for evaluation'}],
}


def _object(value, keys, path):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError(path + ' requires exactly the documented fields')


def _number(value, low, high, path, positive=False):
    try:
        valid = type(value) in (int, float) and math.isfinite(value) and low <= value <= high
    except OverflowError:
        valid = False
    if not valid or (positive and value <= 0):
        raise ValueError(f'{path} must be finite in {"(" if positive else "["}{low},{high}]')


def _text(value, maximum, path):
    if type(value) is not str or not value.strip() or len(value) > maximum:
        raise ValueError(f'{path} requires 1..{maximum} nonblank characters')


def _json_values(value, path):
    if type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                raise ValueError(path + ' requires string keys')
            _json_values(item, path + '.' + key)
    elif type(value) is list:
        for index, item in enumerate(value):
            _json_values(item, f'{path}[{index}]')
    elif type(value) in (int, float):
        _number(value, -float('inf'), float('inf'), path)
    elif type(value) not in (str, bool, type(None)):
        raise ValueError(path + ' requires JSON values')


def _vector(value, low, high, path, positive=False):
    if type(value) is not list or len(value) != 3:
        raise ValueError(path + ' requires a list of three components')
    for i, item in enumerate(value):
        _number(item, low, high, f'{path}[{i}]', positive)


def _ticks(value, dt, path):
    ratio = value / dt
    if abs(ratio - round(ratio)) > 1e-9:
        raise ValueError(path + ' must be an integer multiple of plant_dt_s')
    return round(ratio)


def default_bench():
    return deepcopy(_DEFAULT)


def validate_bench(value):
    """Validate strict JSON input without modifying caller values or references."""
    if type(value) is dict and type(value.get('schema_version')) is int and value['schema_version']==2:
        from .aircraft_controller_capture_contract import validate_capture_extension
        base=validate_capture_extension(value)
        validate_bench(base)
        _json_values(value,'bench')
        return deepcopy(value)
    _object(value, _DEFAULT, 'bench')
    _json_values(value, 'bench')
    if type(value['schema_version']) is not int or value['schema_version'] != 1:
        raise ValueError('schema_version must be integer 1')
    _text(value['name'], 200, 'name')
    _text(value['source'], 2000, 'source')
    for section in ('target', 'timing', 'controller', 'actuators', 'disturbance', 'criteria'):
        _object(value[section], _DEFAULT[section], section)
    target, timing = value['target'], value['timing']
    for key, low, high, positive in [
        ('airspeed_ft_s', 1, 1000, False), ('height_agl_ft', 0, 100000, True),
        ('heading_deg', -180, 180, False), ('fixed_thrust_lbf', 0, 100, False),
        ('trim_thrust_min_lbf', 0, 100, False), ('trim_thrust_max_lbf', 0, 100, False)]:
        _number(target[key], low, high, 'target.' + key, positive)
    if target['thrust_mode'] not in ('trim', 'fixed'):
        raise ValueError('target.thrust_mode must be trim or fixed')
    if target['trim_thrust_min_lbf'] >= target['trim_thrust_max_lbf']:
        raise ValueError('target.trim_thrust_min_lbf must be less than trim_thrust_max_lbf')
    if not target['trim_thrust_min_lbf'] <= target['fixed_thrust_lbf'] <= target['trim_thrust_max_lbf']:
        raise ValueError('target.fixed_thrust_lbf must be inside declared trim bounds')
    _number(timing['duration_s'], .1, 120, 'timing.duration_s')
    _number(timing['plant_dt_s'], .0001, .05, 'timing.plant_dt_s')
    dt = timing['plant_dt_s']
    for key in ('sensor_period_s', 'controller_period_s'):
        _number(timing[key], dt, 1, 'timing.' + key)
        _ticks(timing[key], dt, 'timing.' + key)
    if _ticks(timing['duration_s'], dt, 'timing.duration_s') > 24000:
        raise ValueError('timing exceeds 24000 plant intervals')
    controller = value['controller']
    if controller['mode'] not in ('off', 'rate', 'rate-attitude'):
        raise ValueError('controller.mode must be off, rate or rate-attitude')
    for key, maximum, positive in [
        ('attitude_gain_per_s', 1000, False), ('rate_gain_per_s', 1000, False),
        ('rate_integral_gain_per_s2', 1000, False), ('integral_limit_deg', 360, False),
        ('rate_limit_deg_s', 1000, True), ('accel_limit_deg_s2', 10000, True)]:
        _vector(controller[key], 0, maximum, 'controller.' + key, positive)
    for name, a in value['actuators'].items():
        path = 'actuators.' + name
        _object(a, _DEFAULT['actuators'][name], path)
        for key in ('min_deg', 'max_deg'):
            _number(a[key], -90, 90, path + '.' + key)
        if a['min_deg'] >= a['max_deg'] or not a['min_deg'] <= 0 <= a['max_deg']:
            raise ValueError(path + '.min_deg/max_deg must contain zero with min < max')
        _number(a['rate_deg_s'], 0, 10000, path + '.rate_deg_s', True)
        _number(a['delay_s'], 0, 1, path + '.delay_s')
        _ticks(a['delay_s'], dt, path + '.delay_s')
    for key, limit in [('attitude_body_deg', 180), ('rate_body_deg_s', 1000)]:
        _vector(value['disturbance'][key], -limit, limit, 'disturbance.' + key)
    criteria = value['criteria']
    for key, maximum in [('attitude_error_deg', 180), ('rate_error_deg_s', 1000),
        ('speed_error_ft_s', 1000), ('flight_path_error_deg', 180), ('heading_error_deg', 180),
        ('dwell_s', timing['duration_s'])]:
        _number(criteria[key], 0, maximum, 'criteria.' + key, True)
    _number(criteria['minimum_height_ft'], 0, 100000, 'criteria.minimum_height_ft')
    _number(criteria['max_airspeed_ft_s'], 1, 2000, 'criteria.max_airspeed_ft_s')
    provenance = value['provenance']
    paths = {'target', 'controller', 'actuators', 'disturbance', 'criteria'}
    if type(provenance) is not list or len(provenance) != len(paths):
        raise ValueError('provenance requires exactly five records')
    seen = set()
    for i, entry in enumerate(provenance):
        path = f'provenance[{i}]'
        _object(entry, ('path', 'status', 'source'), path)
        if type(entry['path']) is not str or entry['path'] not in paths or entry['path'] in seen:
            raise ValueError(path + '.path must uniquely identify a required section')
        seen.add(entry['path'])
        if entry['status'] not in ('estimated', 'owner-supplied', 'measured', 'derived'):
            raise ValueError(path + '.status is invalid')
        _text(entry['source'], 2000, path + '.source')
    return deepcopy(value)


def bench_digest(value):
    return digest(validate_bench(value))


def default_field_case():
    return dict(environment=default_environment(), parameters=default_parameters(),
        discretization=default_settings(), installation=dict(wing_incidence_deg=0., tail_incidence_deg=0.),
        wind_N_ft_s=[0., 0., 0.])


def validate_field_case(value):
    """Geometry-independent field validation; geometry is checked at composition.

    Optional `gusts` (#208): {"discrete": null|{...}, "turbulence": null|{...}}; see gusts.py.
    Optional `propulsion` (#209): estimate propeller map limiting delivered thrust (see propulsion.py).
    Optional `atmosphere` (#207): {"model": "isa", "field_elevation_ft", "temperature_offset_R"}.
    When present, air properties follow ISA at field elevation plus height above ground;
    `environment` then only seeds composition checks. Absent means uniform `environment`.
    """
    keys = set(default_field_case())
    for optional in ('atmosphere', 'propulsion', 'gusts', 'aero_dataset'):
        if type(value) is dict and optional in value:
            keys.add(optional)
    _object(value, keys, 'field_case')
    _json_values(value, 'field_case')
    result = deepcopy(value)
    if 'aero_dataset' in result:
        from .aero_snapshot import snapshot_provider
        snapshot_provider(result['aero_dataset'])
        defaults = default_field_case()
        for name in ('parameters', 'discretization', 'installation'):
            if result[name] != defaults[name]:
                raise ValueError('table aerodynamics does not use strip-model '+name+'; retain defaults or explicitly select the strip model')
    if 'atmosphere' in result:
        atmosphere = result['atmosphere']
        _object(atmosphere, {'model', 'field_elevation_ft', 'temperature_offset_R'}, 'field_case.atmosphere')
        if atmosphere['model'] != 'isa':
            raise ValueError('field_case.atmosphere.model must be "isa"')
        _number(atmosphere['field_elevation_ft'], -1000, 20000, 'field_case.atmosphere.field_elevation_ft')
        _number(atmosphere['temperature_offset_R'], -60, 60, 'field_case.atmosphere.temperature_offset_R')
    if 'propulsion' in result:
        result['propulsion'] = validate_propulsion(result['propulsion'])
    if 'gusts' in result:
        _validate_gusts(result['gusts'])
    result['environment'] = validate_field_group(result['environment'], ENVIRONMENT, 'environment', True)
    result['parameters'] = validate_parameters(result['parameters'])
    result['discretization'] = validate_field_group(result['discretization'], SETTINGS, 'discretization')
    installation = {key: CONTROLS[key] for key in ('wing_incidence_deg', 'tail_incidence_deg')}
    result['installation'] = validate_field_group(result['installation'], installation, 'installation')
    _vector(result['wind_N_ft_s'], -MAX_WIND_COMPONENT_FT_S, MAX_WIND_COMPONENT_FT_S, 'wind_N_ft_s')
    return result


def _validate_gusts(gusts):
    """Optional field_case.gusts (#208): discrete 1-cos gust and/or Dryden turbulence."""
    _object(gusts, {'discrete', 'turbulence'}, 'field_case.gusts')
    discrete, turbulence = gusts['discrete'], gusts['turbulence']
    if discrete is not None:
        _object(discrete, {'amplitude_ft_s', 'gradient_length_ft', 'direction_N', 'onset_distance_ft'}, 'field_case.gusts.discrete')
        _number(discrete['amplitude_ft_s'], -100, 100, 'field_case.gusts.discrete.amplitude_ft_s')
        _number(discrete['gradient_length_ft'], 1, 2000, 'field_case.gusts.discrete.gradient_length_ft')
        _vector(discrete['direction_N'], -1, 1, 'field_case.gusts.discrete.direction_N')
        if sum(x*x for x in discrete['direction_N']) < 1e-6:
            raise ValueError('field_case.gusts.discrete.direction_N must be nonzero')
        _number(discrete['onset_distance_ft'], 0, 1e6, 'field_case.gusts.discrete.onset_distance_ft')
    if turbulence is not None:
        _object(turbulence, {'sigma_ft_s', 'scale_length_ft', 'sample_period_s', 'seed'}, 'field_case.gusts.turbulence')
        _vector(turbulence['sigma_ft_s'], 0, 50, 'field_case.gusts.turbulence.sigma_ft_s')
        _vector(turbulence['scale_length_ft'], 1, 5000, 'field_case.gusts.turbulence.scale_length_ft')
        _number(turbulence['sample_period_s'], 1e-4, 0.1, 'field_case.gusts.turbulence.sample_period_s')
        if type(turbulence['seed']) is not int or not 0 <= turbulence['seed'] < 2**32:
            raise ValueError('field_case.gusts.turbulence.seed must be an integer in [0, 2^32)')


def make_run_inputs(definition, bench=None, field_case=None):
    """Compose immutable inputs with model bounds and actual ledger budget."""
    definition_copy = deepcopy(definition)
    validate_definition(definition_copy)

    bench = validate_bench(default_bench() if bench is None else bench)
    field_case = validate_field_case(default_field_case() if field_case is None else field_case)
    controls = dict(default_controls(), **field_case['installation'])
    if 'aero_dataset' in field_case:
        from .aero_snapshot import snapshot_provider
        count = len(snapshot_provider(field_case['aero_dataset'], definition_copy).components)+1
    else:
        field = FullAngleField(definition_copy, parameters=field_case['parameters'],
            environment=field_case['environment'], controls=controls, settings=field_case['discretization'])
        count = len(field.evaluate([0., 0., 0.], [0., 0., 0.], [0., 0., 0.])['ledger'])
    intervals = round(bench['timing']['duration_s'] / bench['timing']['plant_dt_s'])
    if count * intervals > MAX_ELEMENT_INTERVALS:
        raise ValueError(f'field_case/discretization and timing require {count * intervals} element-intervals; limit is {MAX_ELEMENT_INTERVALS}')
    a = bench['actuators']
    for left in (a['left_tail']['min_deg'], a['left_tail']['max_deg']):
        for right in (a['right_tail']['min_deg'], a['right_tail']['max_deg']):
            for aileron in (a['aileron']['min_deg'], a['aileron']['max_deg']):
                trial = dict(controls, common_tail_deg=(left + right) / 2,
                    differential_tail_deg=(left - right) / 2, aileron_deg=aileron)
                if 'aero_dataset' not in field_case:
                    FullAngleField(definition_copy, parameters=field_case['parameters'],
                        environment=field_case['environment'], controls=trial, settings=field_case['discretization'])

    envelope = {
        'schema': 'aircraft-controller-inputs-v'+str(bench['schema_version']),
        'model_id': 'aircraft-controller-contract-v'+str(bench['schema_version']),
        'definition': definition_copy,
        'bench': bench,
        'field_case': field_case,
        'definition_sha256': digest(definition_copy),
        'bench_sha256': bench_digest(bench),
        'field_case_sha256': digest(field_case)
    }

    envelope['inputs_sha256'] = digest({
        'definition': envelope['definition_sha256'],
        'bench': envelope['bench_sha256'],
        'field_case': envelope['field_case_sha256']
    })

    return envelope


def bench_metadata():
    """Return interface declarations, not simulated results."""
    frames = {
        'body_B': {
            'description': 'x forward (nose), y right, z down',
            'rotation_convention': 'Hamilton scalar-first active B-to-N'
        },
        'NED': {
            'description': 'North, East, Down (positive toward Earth center)',
            'rotation_convention': 'Hamilton scalar-first active B-to-N'
        }
    }

    signals = {
        'time_s': {'unit': 's', 'frame': 'simulation', 'meaning': 'Integration timestamp'},
        'acquisition_time_s': {'unit': 's', 'frame': 'simulation', 'meaning': 'Measurement acquisition timestamp'},
        'available_time_s': {'unit': 's', 'frame': 'simulation', 'meaning': 'Measurement available to controller'},
        'q_NB': {'unit': 'dimensionless', 'frame': 'body-to-NED', 'meaning': 'Hamilton scalar-first attitude'},
        'position_N_m': {'unit': 'm', 'frame': 'NED', 'meaning': 'Truth position relative to declared origin'},
        'velocity_N_m_s': {'unit': 'm/s', 'frame': 'NED', 'meaning': 'Ground-relative truth velocity'},
        'omega_B_rad_s': {'unit': 'rad/s', 'frame': 'body', 'meaning': 'Truth angular velocity'},
        'rate_request_deg_s': {'unit': 'deg/s', 'frame': 'body', 'meaning': 'Limited angular-rate request'},
        'accel_request_deg_s2': {'unit': 'deg/s^2', 'frame': 'body', 'meaning': 'Limited angular-acceleration request'},
        'requested_surface_deg': {'unit': 'deg', 'frame': 'surface', 'meaning': 'Left tail, right tail, aileron requests'},
        'actual_surface_deg': {'unit': 'deg', 'frame': 'surface', 'meaning': 'Left tail, right tail, aileron after actuator dynamics'}
    }

    result_fields = [
        'schema','inputs','inputs_sha256','trim','initial_state_SI','status',
        'stop_reason','stop_tick','stop_time_s','cancel_tick','truth','measurements',
        'commands','segments','events','located_loads','station_loads','governing_loads',
        'coverage_gaps','max_raw_stage_quaternion_norm_error','settings','model_id',
        'implementation_hashes','platform','aero_dataset','metrics','outcomes','report_sha256'
    ]

    numerical_acceptance = {
        'trim_accel_m_s2': 1e-5,
        'trim_angular_accel_rad_s2': 1e-5,
        'quaternion_norm_error': 1e-12,
        'replay_scope': 'same-platform-identical-version'
    }

    implementation_status = {
        'package_A': 'Implemented: versioned inputs and interface declarations',
        'package_B': 'Implemented: same-model trim and authority checks',
        'package_C': 'Implemented: version1 sampled rate/attitude recovery and load histories; sustained capture unavailable in version1',
        'package_E': 'Implemented: explicit version2 speed/flight-path/thrust regulation and capture evaluation; experimental gains do not pass every case'
    }

    return {
        'model_id': MODEL_ID,
        'defaults': default_bench(),
        'frames': frames,
        'signals': signals,
        'result_fields': result_fields,
        'numerical_acceptance': numerical_acceptance,
        'implementation_status': implementation_status
    }
