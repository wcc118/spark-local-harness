"""Deterministic, bounded E1 study. Archival I/O belongs to the caller."""
from copy import deepcopy
import math
from .aircraft_controller import attitude_error_body_deg
from .aircraft_controller_contract import make_run_inputs, _object, _number, _text, _json_values
from .aircraft_controller_run import run_bench
from .aircraft_elastic import digest
from .conventions import attitude_error

POLICY = ('recovery_deadline_s', 'max_peak_error_factor', 'max_speed_excursion_ft_s',
          'max_height_loss_ft', 'max_stop_duration_s')
TOLERANCES = dict(position_m=.05, velocity_m_s=.05, quaternion_deg=.05,
                  body_rate_deg_s=.1, cut_force_lbf=.05, cut_moment_in_lbf=1.)


def _policy(value):
    _object(value, POLICY, 'policy')
    for key in POLICY:
        _number(value[key], 0, float('inf'), key, positive=True)


def _inputs(case, candidate, *, off=False, refined=False):
    inputs = case['inputs']
    bench = deepcopy(inputs['bench'])
    bench['name'] = ('E1 '+case['id']+' '+candidate['id'])[:120]
    bench['controller'] = deepcopy(candidate['controller'])
    if off:
        bench['controller']['mode'] = 'off'
    if refined:
        bench['timing']['plant_dt_s'] /= 2
    return make_run_inputs(inputs['definition'], bench, inputs['field_case'])


def _intervals(inputs):
    timing = inputs['bench']['timing']
    return round(timing['duration_s']/timing['plant_dt_s'])


def _nonzero(case):
    disturbance = case['inputs']['bench']['disturbance']
    return any(disturbance['attitude_body_deg']+disturbance['rate_body_deg_s'])


def validate_plan(plan):
    """Copy and validate every possible run before any simulation executes."""
    _object(plan, ('schema','name','seed','source','policy','candidates','tuning','evaluation'), 'plan')
    _json_values(plan, 'plan')
    plan = deepcopy(plan)
    if plan['schema'] != 'aircraft-controller-study-plan-v1':
        raise ValueError('Unsupported study plan schema')
    _text(plan['name'], 200, 'name')
    _text(plan['source'], 2000, 'source')
    if type(plan['seed']) is not int or plan['seed'] < 0:
        raise ValueError('seed must be a nonnegative integer')
    _policy(plan['policy'])
    for name, maximum in (('candidates',8), ('tuning',12), ('evaluation',12)):
        if type(plan[name]) is not list or not 1 <= len(plan[name]) <= maximum:
            raise ValueError(name+' must be a bounded nonempty list')
    ids = set()
    for candidate in plan['candidates']:
        _object(candidate, ('id','controller'), 'candidate')
        _text(candidate['id'], 100, 'candidate.id')
        if candidate['id'] in ids:
            raise ValueError('Duplicate candidate id')
        ids.add(candidate['id'])
        if type(candidate['controller']) is not dict or candidate['controller'].get('mode') != 'rate-attitude':
            raise ValueError('Candidates require rate-attitude controller configurations')
    ids = set()
    for case in plan['tuning']+plan['evaluation']:
        _object(case, ('id','note','inputs'), 'case')
        _text(case['id'], 100, 'case.id')
        _text(case['note'], 2000, 'case.note')
        if case['id'] in ids:
            raise ValueError('Duplicate case id')
        ids.add(case['id'])
        inputs = case['inputs']
        if type(inputs) is not dict:
            raise ValueError('case.inputs must be an input envelope')
        try:
            rebuilt = make_run_inputs(inputs['definition'], inputs['bench'], inputs['field_case'])
        except KeyError as error:
            raise ValueError('Incomplete case input envelope') from error
        if rebuilt != inputs:
            raise ValueError('Case input envelope integrity mismatch')
    C,T,E = (len(plan[k]) for k in ('candidates','tuning','evaluation'))
    if C*T+T+2*E+1 > 64:
        raise ValueError('Study exceeds 64 possible runs')
    total = (C+1)*sum(_intervals(c['inputs']) for c in plan['tuning'])
    total += 2*sum(_intervals(c['inputs']) for c in plan['evaluation'])
    refine_case = next((c for c in plan['tuning'] if _nonzero(c)), None)
    if refine_case:
        total += 2*_intervals(refine_case['inputs'])
    if total > 64000:
        raise ValueError('Study exceeds 64000 plant intervals')
    for case in plan['tuning']+plan['evaluation']:
        for candidate in plan['candidates']:
            for off, refined in ((False,False), (True,False), (False,True)):
                if refined and case is not refine_case:
                    continue
                inputs = _inputs(case,candidate,off=off,refined=refined)
                if _intervals(inputs)>2000:
                    raise ValueError('Study run exceeds 2000 plant intervals including refinement')
    return plan


def summarize_run(report, policy):
    """Native outcomes plus predeclared gates; missing evidence cannot pass."""
    _policy(policy)
    _json_values(report, 'report')
    truth = report['truth']; metrics = report['metrics']; trim = report['trim']
    first = truth[0] if truth else {}
    initial = first.get('attitude_error_deg')
    peak = metrics.get('peak_attitude_error_deg')
    factor = None if initial is None or peak is None else peak/max(initial,1.)
    def excursion(key, loss=False):
        values = [row.get(key) for row in truth]
        if not values or any(v is None for v in values):
            return None
        return max(0., values[0]-min(values)) if loss else max(abs(v-values[0]) for v in values)
    speed = excursion('airspeed_ft_s'); height = excursion('height_ft', True)
    stops = metrics.get('travel_limit_duration_s')
    stop_duration = None if not stops else max(stops)
    candidate = trim.get('candidate') or {}
    overshoot = [None,None,None]
    if truth and candidate.get('state_SI') and all(row.get('state_SI') for row in truth):
        errors = [attitude_error_body_deg(row['state_SI'][6:10],candidate['state_SI'][6:10]) for row in truth]
        overshoot = [None if abs(errors[0][j])<=1e-8 else
                     max(0., max(-math.copysign(1.,errors[0][j])*e[j] for e in errors)) for j in range(3)]
    recovery = report['outcomes']['attitude_recovery']
    start = recovery['final_dwell_start_s']
    gates = dict(completed=report['status']=='completed', attitude_recovery=recovery['met'] is True)
    for name, value, bound in (('recovery_deadline',start,policy['recovery_deadline_s']),
            ('peak_error_factor',factor,policy['max_peak_error_factor']),
            ('speed_excursion',speed,policy['max_speed_excursion_ft_s']),
            ('height_loss',height,policy['max_height_loss_ft']),
            ('physical_stop_duration',stop_duration,policy['max_stop_duration_s'])):
        gates[name] = value is not None and value <= bound
    return dict(status=report['status'],reason=report.get('stop_reason'),
        inputs_sha256=report['inputs_sha256'],report_sha256=report['report_sha256'],
        metrics=deepcopy(metrics),outcomes=deepcopy(report['outcomes']),
        initial_attitude_error_deg=initial,initial_rate_deg_s=first.get('rate_max_deg_s'),
        trim_status=trim['status'],trim_margins=deepcopy(candidate.get('margins')),
        trim_thrust_margins_lbf=deepcopy(candidate.get('thrust_margins_lbf')),
        final_dwell_start_s=start,peak_error_factor=factor,max_speed_excursion_ft_s=speed,
        max_height_loss_ft=height,max_stop_duration_s=stop_duration,axis_overshoot_deg=overshoot,
        gates=gates,failed_gates=[k for k,v in gates.items() if not v],passed=all(gates.values()))


def _refinement(coarse, fine):
    """Match real timestamps; incomplete/missing evidence is unavailable."""
    result = dict(status='unavailable',reason=None,errors=None,tolerances=deepcopy(TOLERANCES),passed=False)
    if coarse['status']!='completed' or fine['status']!='completed':
        result['reason']='Both runs must complete'
        return result
    def match(left,right):
        if not left or not right or abs(left[0]['time_s']-right[0]['time_s'])>1e-10 or abs(left[-1]['time_s']-right[-1]['time_s'])>1e-10:
            return None
        pairs=[]; j=0
        for a in left:
            while j<len(right) and right[j]['time_s']<a['time_s']-1e-10:
                j+=1
            if j==len(right) or abs(a['time_s']-right[j]['time_s'])>1e-10:
                return None
            pairs.append((a,right[j])); j+=1
        return pairs
    pairs = match(coarse['truth'], fine['truth'])
    loads = match(coarse['located_loads'], fine['located_loads'])
    if pairs is None or loads is None:
        result['reason']='Accepted clock coverage does not match'
        return result
    errors = dict.fromkeys(TOLERANCES,0.)
    for a,b in pairs:
        x,y=a.get('state_SI'),b.get('state_SI')
        if not x or not y or len(x)!=13 or len(y)!=13:
            result['reason']='Missing state evidence'
            return result
        for key,lo,hi,scale in (('position_m',0,3,1.),('velocity_m_s',3,6,1.),('body_rate_deg_s',10,13,180/math.pi)):
            errors[key]=max(errors[key],max(abs(x[j]-y[j])*scale for j in range(lo,hi)))
        errors['quaternion_deg']=max(errors['quaternion_deg'],math.degrees(attitude_error(x[6:10],y[6:10])))
    for a,b in loads:
        for key,field in (('cut_force_lbf','cut_force_B_lbf'),('cut_moment_in_lbf','cut_moment_B_in_lbf')):
            x,y=a.get('recovery',{}).get(field),b.get('recovery',{}).get(field)
            if not x or not y or len(x)!=3 or len(y)!=3 or any(v is None for v in x+y):
                result['reason']='Missing concurrent cut-load evidence'
                return result
            errors[key]=max(errors[key],max(abs(u-v) for u,v in zip(x,y)))
    result.update(status='available',errors=errors,checks={k:errors[k]<=v for k,v in TOLERANCES.items()},
                  passed=all(errors[k]<=v for k,v in TOLERANCES.items()))
    return result


def run_study(plan, *, progress=None, cancelled=None, record=None):
    for name,callback in (('progress',progress),('cancelled',cancelled),('record',record)):
        if callback is not None and not callable(callback):
            raise ValueError(name+' must be callable or None')
    plan=validate_plan(plan)
    C,T,E=(len(plan[k]) for k in ('candidates','tuning','evaluation'))
    result=dict(schema='aircraft-controller-study-v1',plan=plan,plan_sha256=digest(plan),
        status='running',selection=None,holdout_consumed=False,runs=[],ranking=[],refinement=None,
        reserved_acceptance=dict(passed=0,observed=0,total=E),
        scope='Estimated aircraft; ideal sensing; known/retrimmed plant sensitivity, not unknown-model robustness or sustained capture.')
    current=dict(phase='preflight',current_case=None,current_candidate=None,run_progress=None)
    def emit(**changes):
        current.update(changes)
        if progress:
            progress(deepcopy(dict(current,completed_runs=len(result['runs']),planned_max_runs=C*T+T+2*E+1)))
    def stop():
        if cancelled is None:
            return False
        value=cancelled()
        if type(value) is not bool:
            raise ValueError('cancelled must return bool')
        return value
    def finish(status):
        result['status']=status
        result['study_sha256']=digest(result)
        emit(phase=status,run_progress=None)
        return deepcopy(result)
    def execute(case,candidate,phase,off=False,refined=False):
        emit(phase=phase,current_case=case['id'],current_candidate=candidate['id'],run_progress=None)
        report=run_bench(_inputs(case,candidate,off=off,refined=refined),
            progress=lambda p:emit(run_progress=p),cancelled=lambda p:stop())
        index=len(result['runs'])
        summary=summarize_run(report,plan['policy'])
        if record:
            record(index,deepcopy(report))
        result['runs'].append(dict(index=index,phase=phase,case_id=case['id'],candidate_id=candidate['id'],**summary))
        emit(run_progress=None)
        return report
    emit()
    # Keep only the first nonzero tuning report of the best feasible candidate.
    refine_case=next((c for c in plan['tuning'] if _nonzero(c)),None)
    best=None; coarse=None
    for candidate in plan['candidates']:
        rows=[]; candidate_coarse=None
        for case in plan['tuning']:
            if stop(): return finish('cancelled')
            report=execute(case,candidate,'tuning')
            if report['status']=='cancelled': return finish('cancelled')
            rows.append(result['runs'][-1])
            if case is refine_case: candidate_coarse=report
        passed=all(row['passed'] for row in rows)
        score=None
        if passed:
            score=[max(row['final_dwell_start_s'] for row in rows),max(row['peak_error_factor'] for row in rows),
                   sum(sum(row['metrics']['surface_travel_deg']) for row in rows),candidate['id']]
            if best is None or score<best['score']:
                best=dict(candidate_id=candidate['id'],controller=deepcopy(candidate['controller']),score=score,
                          tuning_report_sha256=[row['report_sha256'] for row in rows])
                coarse=candidate_coarse
        result['ranking'].append(dict(candidate_id=candidate['id'],passed=passed,score=score,
            failures=[dict(case_id=row['case_id'],gates=row['failed_gates']) for row in rows if not row['passed']]))
    for case in plan['tuning']:
        if stop(): return finish('cancelled')
        if execute(case,plan['candidates'][0],'tuning-off',off=True)['status']=='cancelled':
            return finish('cancelled')
    if stop(): return finish('cancelled')
    if best is None: return finish('no-feasible-candidate')
    best['selection_sha256']=digest(best)
    result['selection']=best
    emit(phase='selection-frozen',selection=best,run_progress=None)
    current.pop('selection',None)
    winner=next(c for c in plan['candidates'] if c['id']==best['candidate_id'])
    for case in plan['evaluation']:
        for off in (False,True):
            if stop(): return finish('cancelled')
            result['holdout_consumed']=True
            report=execute(case,winner,'evaluation-off' if off else 'evaluation',off=off)
            if not off:
                result['reserved_acceptance']['observed']+=1
                result['reserved_acceptance']['passed']+=int(result['runs'][-1]['passed'])
            if report['status']=='cancelled': return finish('cancelled')
    if refine_case:
        if stop(): return finish('cancelled')
        fine=execute(refine_case,winner,'refinement',refined=True)
        result['refinement']=dict(_refinement(coarse,fine),coarse_report_sha256=coarse['report_sha256'],fine_report_sha256=fine['report_sha256'])
        if fine['status']=='cancelled': return finish('cancelled')
    return finish('completed')
