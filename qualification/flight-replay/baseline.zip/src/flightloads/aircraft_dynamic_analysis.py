"""Current-aircraft local longitudinal modes and independent response evidence.

The four-state linear model is local to steady 1-g trim. Normalized modal traces
are exact linear-mode formulas, not long-duration nonlinear flight simulations.
"""
from copy import deepcopy
import hashlib
import math
from pathlib import Path
import numpy as np

from .aircraft_cg_study import digest
from .aircraft_workspace import evaluate_aircraft
from .aircraft_longitudinal import (LongitudinalModel, comparison_case, convergence_case,
                                   MODE_REAL_TOLERANCE)

MODEL_ID = 'current-aircraft-local-longitudinal-v1'
AMPLITUDES_DEG = (.01, .005, .0025)
MODAL_DURATION_S = 120.
MAX_MODAL_POINTS = 4001
MAX_MODAL_GAIN = 1e6
SCOPE = ('Local four-state longitudinal prediction at computed steady 1-g trim; '
         'not all-axis stability, broadside release capture, measured aircraft '
         'validation, structural acceptance or an approved flight condition.')


def mode_characteristics(modes):
    output = []
    for i, mode in enumerate(modes):
        sigma, omega = mode['real_per_s'], mode['imag_per_s']
        if not math.isfinite(sigma) or not math.isfinite(omega):
            raise ValueError('Mode eigenvalues must be finite')
        natural = math.hypot(sigma, omega)
        if not math.isfinite(natural):raise ValueError('Mode frequency exceeds finite representation')
        item=deepcopy(mode)
        item.update(mode_id=f'm{i}', natural_frequency_rad_s=natural,
            damped_frequency_hz=abs(omega)/(2*math.pi), damping_ratio=-sigma/natural if natural else None,
            period_s=None if abs(omega)<1e-12 else 2*math.pi/abs(omega),
            e_fold_time_s=None if abs(sigma)<MODE_REAL_TOLERANCE else 1/abs(sigma),
            tendency='growing' if sigma>MODE_REAL_TOLERANCE else 'decaying' if sigma<-MODE_REAL_TOLERANCE else 'near-neutral-or-indeterminate')
        output.append(item)
    return output


def modal_history(mode, duration_s=MODAL_DURATION_S):
    """Sample exp(sigma*t) and exp(sigma*t)*cos(omega*t), without integration.

    Forty samples per period/e-fold scale avoid an aliased fast mode. A bounded
    point count may shorten the displayed horizon; a growing gain cutoff is
    reported as truncation of this normalized display, never a flight event.
    """
    if type(duration_s) not in (int,float) or not math.isfinite(duration_s) or not .001<=duration_s<=300:
        raise ValueError('Modal display duration must be finite in [.001,300] s')
    sigma,omega=mode['real_per_s'],mode['imag_per_s']
    if not math.isfinite(sigma) or not math.isfinite(omega):
        raise ValueError('Mode eigenvalues must be finite')
    dt=duration_s/1000
    if abs(omega)>1e-12:dt=min(dt,2*math.pi/abs(omega)/40)
    if abs(sigma)>MODE_REAL_TOLERANCE:dt=min(dt,1/abs(sigma)/40)
    limited=duration_s>(MAX_MODAL_POINTS-1)*dt
    intervals=MAX_MODAL_POINTS-1 if limited else math.ceil(duration_s/dt)
    horizon=intervals*dt if limited else duration_s
    times=[];envelope=[];coordinate=[];status='resolution-limited-horizon' if limited else 'requested-horizon-completed'
    for i in range(intervals+1):
        t=horizon*i/intervals
        if sigma*t>math.log(MAX_MODAL_GAIN):
            status='normalized-growth-cutoff';break
        gain=math.exp(sigma*t)
        times.append(t);envelope.append(gain);coordinate.append(gain*math.cos(omega*t))
    return dict(mode_id=mode.get('mode_id'),time_s=times,envelope=envelope,normalized_coordinate=coordinate,
        requested_duration_s=duration_s,actual_duration_s=times[-1],status=status,
        maximum_points=MAX_MODAL_POINTS,maximum_normalized_gain=MAX_MODAL_GAIN,
        scope='Dimensionless local linear mode: envelope exp(sigma*t), coordinate exp(sigma*t)*cos(omega*t). Not a nonlinear trajectory or flight-validity test.')


def run_dynamic_analysis(definition):
    d=deepcopy(definition)
    workspace=evaluate_aircraft(d)
    static=(workspace.get('flight_condition') or {}).get('static_stability',{}).get('trim')
    output=dict(schema='aircraft-longitudinal-analysis-v1',model_id=MODEL_ID,scope=SCOPE,
        definition=d,input_sha256=digest(d),status='unavailable',diagnostic='',
        static_stability=deepcopy(static),linearization=None,modes=[],mode_histories=[],
        comparisons=[],convergence=None,
        verification=dict(derivatives=None,small_perturbation=None,amplitude_refinement=None,time_step_refinement=None),
        verification_case=dict(amplitudes_deg=list(AMPLITUDES_DEG),duration_s=.5,comparison_dt_s=.001,
            convergence_dt_s=[.01,.005,.0025],initial_height_agl_ft=1000,
            scope='Fixed small-pulse verification cases, independent of the saved maneuver settings. A short comparison cannot demonstrate slow-mode decay.'))
    failures=(ValueError,ArithmeticError,np.linalg.LinAlgError)
    try:
        linear=LongitudinalModel(d).linearization()
        output['linearization']=linear
        output['verification']['derivatives']=linear['derivative_verified']
        if not linear['derivative_verified']:
            output['diagnostic']='Mode verdict withheld: derivative or trim-residual verification failed.'
        else:
            modes=mode_characteristics(linear['modes'])
            histories=[modal_history(mode) for mode in modes]
            output.update(status='available',modes=modes,mode_histories=histories)
    except failures as error:
        output['diagnostic']=str(error)
    if output['status']=='available':
        for amplitude in AMPLITUDES_DEG:
            try:
                case=comparison_case(d,amplitude_deg=amplitude,dt_s=.001,duration_s=.5)
                case.pop('nonlinear_run')
                output['comparisons'].append(dict(amplitude_deg=amplitude,**case))
            except failures as error:
                output['comparisons'].append(dict(amplitude_deg=amplitude,status='unavailable',verified=False,diagnostic=str(error)))
        cases=output['comparisons']
        completed=all(c['status']=='completed' for c in cases)
        values=[c.get('amplitude_normalized_discrepancy') for c in cases]
        output['verification']['small_perturbation']=all(c['verified'] for c in cases)
        output['verification']['amplitude_refinement']=bool(completed and all(v is not None and math.isfinite(v) for v in values)
            and all(b<a or max(a,b)<1e-7 for a,b in zip(values,values[1:])))
        try:
            convergence=convergence_case(d);convergence.pop('runs')
            output['convergence']=convergence
            output['verification']['time_step_refinement']=convergence['verified']
        except failures as error:
            output['convergence']=dict(verified=False,diagnostic=str(error))
            output['verification']['time_step_refinement']=False
    output['all_verification_checks_passed']=all(v is True for v in output['verification'].values())
    source=Path(__file__).parent
    output['implementation_sha256']={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in
        ('aircraft_dynamic_analysis.py','aircraft_longitudinal.py','aircraft_flight.py','aircraft_transient.py',
         'aircraft_workspace.py','aircraft_input_limits.py','conventions.py','dynamics.py','state.py','mass.py','recovery.py','loads.py','integration.py')}
    output['analysis_sha256']=digest(output)
    return output
