"""Fixed-geometry inertia loads and signed section resultants in body axes."""
from dataclasses import dataclass
from typing import ClassVar
import numbers
import numpy as np
from ._arrays import readonly_copy
from .conventions import finite_vector, rotation_matrix
from .loads import AppliedLoads


def _arrays(record, **values):
    for name, value in values.items():
        if not np.all(np.isfinite(value)):
            raise ValueError(f'{name} contains nonfinite values')
        object.__setattr__(record, name, readonly_copy(value))


def _scalar(value, name, *, minimum=0, strict=False):
    value = float(value)
    if not np.isfinite(value) or value < minimum or (strict and value == minimum):
        raise ValueError(f'{name} must be finite and {">" if strict else ">="} {minimum}')
    return value


@dataclass(frozen=True, init=False)
class BalancedField:
    """Derived field; construction computes residuals/status, never accepts them.

    Inputs match recover_balance. Inertia forces mean negative mass acceleration.
    Arrays have one row per mass; applied loads retain their independent locations.
    """
    applied_loads: AppliedLoads
    rho_B_m: np.ndarray
    masses_kg: np.ndarray
    point_accel_B_mps2: np.ndarray
    gravity_B_mps2: np.ndarray
    gravity_force_B_N: np.ndarray
    inertia_force_B_N: np.ndarray
    force_residual_B_N: np.ndarray
    moment_residual_B_Nm: np.ndarray
    force_scale_N: float
    moment_scale_Nm: float
    force_limit_N: float
    moment_limit_Nm: float
    is_balanced: bool
    frame: ClassVar[str] = 'B'

    @np.errstate(over='ignore', invalid='ignore')
    def __init__(self, state, derivative, mass_model, applied_loads, g_N, *,
                 force_atol_N=1e-9, moment_atol_Nm=1e-9, rtol=1e-10):
        fa = _scalar(force_atol_N, 'force_atol_N', strict=True)
        ma = _scalar(moment_atol_Nm, 'moment_atol_Nm', strict=True)
        rt = _scalar(rtol, 'rtol')
        if not isinstance(applied_loads, AppliedLoads):
            raise TypeError('applied_loads must be AppliedLoads')
        mass_model.require_rigid_inertia()
        g = rotation_matrix(state.q_NB).T @ finite_vector(g_N, 3, 'g_N')
        rho, masses = mass_model.rho_B_m, mass_model.masses_kg
        w, alpha = state.omega_B_radps, derivative.omegadot_B_radps2
        a_cg = derivative.vdot_B_mps2 + np.cross(w, state.v_CG_B_mps)
        accel = a_cg + np.cross(alpha, rho) + np.cross(w, np.cross(w, rho))
        gravity, inertia = masses[:, None]*g, -masses[:, None]*accel
        force = applied_loads.forces_non_gravity_B_N
        couples = applied_loads.couples_B_Nm
        applied_moments = np.cross(applied_loads.locations_CG_B_m, force)
        gravity_moments, inertia_moments = np.cross(rho, gravity), np.cross(rho, inertia)
        mass_force = gravity + inertia
        f_res = force.sum(axis=0) + mass_force.sum(axis=0)
        m_res = (applied_moments + couples).sum(axis=0) + np.cross(rho, mass_force).sum(axis=0)
        # Scale before cancellation; free couples are counted exactly once.
        norms = lambda a: np.linalg.norm(a, axis=1).sum()
        f_scale = _scalar(norms(force)+norms(gravity)+norms(inertia), 'force scale')
        m_scale = _scalar(norms(applied_moments)+norms(couples)+norms(gravity_moments)
                          +norms(inertia_moments), 'moment scale')
        f_limit = _scalar(fa+rt*f_scale, 'force limit', strict=True)
        m_limit = _scalar(ma+rt*m_scale, 'moment limit', strict=True)
        fn = _scalar(np.linalg.norm(f_res), 'force residual norm')
        mn = _scalar(np.linalg.norm(m_res), 'moment residual norm')
        _arrays(self, rho_B_m=rho, masses_kg=masses, point_accel_B_mps2=accel,
                gravity_B_mps2=g, gravity_force_B_N=gravity, inertia_force_B_N=inertia,
                force_residual_B_N=f_res, moment_residual_B_Nm=m_res)
        for name, value in dict(applied_loads=applied_loads, force_scale_N=f_scale,
                                moment_scale_Nm=m_scale, force_limit_N=f_limit,
                                moment_limit_Nm=m_limit, is_balanced=fn<=f_limit and mn<=m_limit).items():
            object.__setattr__(self, name, value)


def recover_balance(state, derivative, mass_model, applied_loads, g_N, *,
                    force_atol_N=1e-9, moment_atol_Nm=1e-9, rtol=1e-10):
    return BalancedField(state, derivative, mass_model, applied_loads, g_N,
                         force_atol_N=force_atol_N, moment_atol_Nm=moment_atol_Nm, rtol=rtol)


@dataclass(frozen=True, init=False)
class CutDefinition:
    """Retain positive distance; apply explicit policy within incidence tolerance."""
    cut_id: str
    point_CG_B_m: np.ndarray
    normal_B: np.ndarray
    normal_orig_norm: float
    on_plane_policy: str
    incidence_tolerance_m: float
    positive_side: ClassVar[str] = 'positive'
    frame: ClassVar[str] = 'B'

    def __init__(self, cut_id, point_CG_B_m, normal_B, *, on_plane_policy='reject',
                 incidence_tolerance_m=1e-9):
        if not isinstance(cut_id, str) or not cut_id:
            raise ValueError('cut_id must be a nonempty string')
        point = finite_vector(point_CG_B_m, 3, 'point_CG_B_m')
        normal = finite_vector(normal_B, 3, 'normal_B')
        with np.errstate(over='ignore'):
            norm = _scalar(np.linalg.norm(normal), 'normal norm', minimum=1e-12, strict=True)
        if on_plane_policy not in ('reject', 'retain', 'exclude'):
            raise ValueError('on_plane_policy must be reject, retain or exclude')
        tol = _scalar(incidence_tolerance_m, 'incidence_tolerance_m')
        _arrays(self, point_CG_B_m=point, normal_B=normal/norm)
        for name, value in dict(cut_id=cut_id, normal_orig_norm=norm,
                                on_plane_policy=on_plane_policy, incidence_tolerance_m=tol).items():
            object.__setattr__(self, name, value)


def _selection(locations, cut, kind):
    with np.errstate(over='ignore', invalid='ignore'):
        distance = (locations-cut.point_CG_B_m) @ cut.normal_B
    if not np.all(np.isfinite(distance)):
        raise ValueError(f'nonfinite {kind} distances to cut')
    on = np.abs(distance) <= cut.incidence_tolerance_m
    if cut.on_plane_policy == 'reject' and np.any(on):
        raise RuntimeError(f'on-plane {kind} indices {np.flatnonzero(on).tolist()} rejected')
    return (distance > cut.incidence_tolerance_m) | (on & (cut.on_plane_policy == 'retain'))


@dataclass(frozen=True, init=False)
class SectionResult:
    """Force/moment exerted by removed material ON the retained positive side."""
    time_s: float
    cut_id: str
    cut_point_CG_B_m: np.ndarray
    force_on_retained_B_N: np.ndarray
    moment_on_retained_B_Nm: np.ndarray
    contributing_source_ids: tuple[str, ...]
    contributing_mass_indices: tuple[int, ...]
    frame: ClassVar[str] = 'B'

    def __init__(self, time_s, cut_id, frame, cut_point_CG_B_m, force_on_retained_B_N,
                 moment_on_retained_B_Nm, contributing_source_ids, contributing_mass_indices):
        if not np.isfinite(time_s):
            raise ValueError('time_s must be finite')
        if not isinstance(cut_id, str) or not cut_id or frame != 'B':
            raise ValueError('nonempty cut_id and frame B required')
        ids, indices = tuple(contributing_source_ids), tuple(contributing_mass_indices)
        if any(not isinstance(s, str) or not s for s in ids):
            raise ValueError('source IDs must be nonempty strings')
        if any(isinstance(i, bool) or not isinstance(i, numbers.Integral) or i<0 for i in indices):
            raise ValueError('mass indices must be nonnegative integers')
        _arrays(self, cut_point_CG_B_m=finite_vector(cut_point_CG_B_m, 3, 'cut point'),
                force_on_retained_B_N=finite_vector(force_on_retained_B_N, 3, 'section force'),
                moment_on_retained_B_Nm=finite_vector(moment_on_retained_B_Nm, 3, 'section moment'))
        for name, value in dict(time_s=float(time_s), cut_id=cut_id,
                                contributing_source_ids=ids, contributing_mass_indices=indices).items():
            object.__setattr__(self, name, value)


@np.errstate(over='ignore', invalid='ignore')
def recover_section(balanced_field, cut_definition, *, time_s):
    """Negate retained applied, gravitational and negative-inertia resultants."""
    b, cut = balanced_field, cut_definition
    if not np.isfinite(time_s):
        raise ValueError('time_s must be finite')
    if not b.is_balanced:
        raise RuntimeError(f'unbalanced field: force norm {np.linalg.norm(b.force_residual_B_N):.6g}'
                           f' N (limit {b.force_limit_N:.6g}); moment norm '
                           f'{np.linalg.norm(b.moment_residual_B_Nm):.6g} Nm '
                           f'(limit {b.moment_limit_Nm:.6g})')
    loads = b.applied_loads
    j = _selection(loads.locations_CG_B_m, cut, 'applied load')
    i = _selection(b.rho_B_m, cut, 'mass')
    forces = loads.forces_non_gravity_B_N[j]
    mass_forces = b.gravity_force_B_N[i]+b.inertia_force_B_N[i]
    f = -(forces.sum(axis=0)+mass_forces.sum(axis=0))
    m = -((np.cross(loads.locations_CG_B_m[j]-cut.point_CG_B_m, forces)
           +loads.couples_B_Nm[j]).sum(axis=0)
          +np.cross(b.rho_B_m[i]-cut.point_CG_B_m, mass_forces).sum(axis=0))
    return SectionResult(time_s, cut.cut_id, 'B', cut.point_CG_B_m, f, m,
                         tuple(loads.source_ids[k] for k in np.flatnonzero(j)),
                         tuple(int(k) for k in np.flatnonzero(i)))
