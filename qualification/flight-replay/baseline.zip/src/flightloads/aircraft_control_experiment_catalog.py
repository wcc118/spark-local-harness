"""Durable bounded sequential learning studies, reusing verified controller jobs."""
from copy import deepcopy
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import threading
import time
import uuid
from itertools import islice
from .aircraft_controller_catalog import ControllerCatalog
from .aircraft_controller_store import (_id,_identity,_read,_write,_decode,_inputs,MAX_INPUT,MAX_METADATA)
from .aircraft_elastic import digest
from .aircraft_controller_trim import _identity as model_identity
from .aircraft_control_experiments import plan,variant,MAX_POINTS,MAX_INTERVALS,MAX_BYTES,MAX_WALL,VARIABLES

_clock=time.monotonic
MAX_STUDIES=8
TERMINAL=('finished','cancelled','failed','interrupted','budget-stopped')

def now():return datetime.now(timezone.utc).isoformat()

def names(fd,limit):
    with os.scandir(fd) as entries:result=[e.name for e in islice(entries,limit+1)]
    if len(result)>limit:raise ValueError('Unknown or excess study directory entries; entry budget exceeded')
    return result


class ExperimentCatalog:
    def __init__(self,root,execution_lock):
        self.root=Path(root).absolute();self.root.mkdir(parents=True,exist_ok=True)
        self._fd=os.open(self.root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);self._identity=_identity(os.fstat(self._fd))
        self._lease=None;self._rows={};self._unavailable={};self._lock=threading.RLock();self._execution=execution_lock;self._closing=False;self._active=None
        try:
            self._lease=os.open('catalog.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=self._fd)
            if not stat.S_ISREG(os.fstat(self._lease).st_mode):raise ValueError('Study ownership lock must be regular')
            self._lease_identity=_identity(os.fstat(self._lease));fcntl.flock(self._lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
            entries=names(self._fd,MAX_STUDIES+1)
            for identifier in entries:
                if identifier=='catalog.lock':continue
                try:
                    _id(identifier);info=os.stat(identifier,dir_fd=self._fd,follow_symlinks=False)
                    if not stat.S_ISDIR(info.st_mode):raise ValueError('Study must be a directory')
                    row=dict(identity=_identity(info),catalog=None,cancel=threading.Event(),thread=None)
                    self._rows[identifier]=row
                    with self._directory(identifier) as fd:
                        saved=self._read_plan(fd);meta=self._read_meta(fd,identifier,saved)
                    row['plan']=saved;row['meta']=meta
                    row['catalog']=self._open_catalog(identifier)
                    if meta['status'] not in TERMINAL:
                        meta['status']='interrupted';meta['error']='Server ended before study completion; no automatic restart'
                        self._recover_points(row)
                        for p in meta['points']:
                            if p['status'] in ('queued','running'):p['status']='interrupted';p['error']=meta['error']
                        self._save(identifier)
                except (ValueError,KeyError,TypeError,OSError,RuntimeError) as e:
                    row=self._rows.pop(identifier,None)
                    if row and row.get('catalog'):row['catalog'].close()
                    if row and row.get('directory_fd') is not None:os.close(row['directory_fd'])
                    self._unavailable[identifier]=str(e)
        except BaseException:
            self.close();raise

    def _recover_points(self,row):
        """Reconcile already-saved artifacts after interruption; never run a solver."""
        cat=row['catalog'];points=row['meta']['points'];claimed={p['run_id'] for p in points if p['run_id']};candidates={}
        for record in cat.listing()['records']:
            if record['kind']=='run' and record['id'] not in claimed:
                inputs=cat.artifact(record['id'],'inputs.json');candidates.setdefault(inputs['inputs_sha256'],[]).append(record['id'])
        for p in points:
            if p['status'] not in ('queued','running'):continue
            if p['run_id'] is None:
                matches=candidates.get(p['inputs_sha256'],[])
                if len(matches)==1:p['run_id']=matches[0]
            if p['run_id']:
                record=cat.snapshot(p['run_id'])
                if record['phase']=='finished':
                    from .aircraft_control_experiment_metrics import summarize
                    report=cat.artifact(p['run_id'],'report.json')
                    if dict(hashes=report['implementation_hashes'],platform=report['platform'])!=row['plan']['plan']['implementation_identity']:raise ValueError('Saved study member model identity mismatch')
                    p.update(summary=summarize(report),status=report['status'],error=None)
                else:p.update(status=record['phase'],error=record.get('error') or 'Interrupted before result publication')

    def _check(self):
        if self._fd is None:raise RuntimeError('Study catalog closed')
        if _identity(os.stat(self.root,follow_symlinks=False))!=self._identity or _identity(os.stat('catalog.lock',dir_fd=self._fd,follow_symlinks=False))!=self._lease_identity:raise RuntimeError('Study root or ownership lease changed')

    @contextmanager
    def _directory(self,identifier):
        self._check();_id(identifier);row=self._rows[identifier]
        fd=os.open(identifier,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=self._fd)
        try:
            if _identity(os.fstat(fd))!=row['identity']:raise RuntimeError('Study directory changed')
            entries=names(fd,3)
            if set(entries)-{'inputs.json','record.json','runs'}:raise ValueError('Unknown study files; manual inspection required')
            if 'runs' in entries and not stat.S_ISDIR(os.stat('runs',dir_fd=fd,follow_symlinks=False).st_mode):raise ValueError('Study run directory unsafe')
            yield fd
        finally:os.close(fd)

    def _open_catalog(self,identifier):
        row=self._rows[identifier]
        with self._directory(identifier) as fd:row['directory_fd']=os.dup(fd)
        try:return ControllerCatalog('/proc/self/fd/'+str(row['directory_fd'])+'/runs',threading.Lock())
        except BaseException:
            os.close(row['directory_fd']);row['directory_fd']=None;raise

    def _read_plan(self,fd):
        saved=_decode(_read(fd,'inputs.json'))
        if type(saved) is not dict or set(saved)!={'plan','reference'}:raise ValueError('Invalid study plan envelope')
        _inputs(saved['reference']);p=dict(saved['plan']);sha=p.pop('plan_sha256',None)
        if digest(p)!=sha or p.get('schema')!='aircraft-control-experiment-plan-v1' or p['reference_inputs_sha256']!=saved['reference']['inputs_sha256']:raise ValueError('Study plan identity mismatch')
        if not 1<=len(p['points'])<=MAX_POINTS or len(p['spec']['values'])!=len(p['points']):raise ValueError('Invalid study point count')
        return saved

    def _read_meta(self,fd,identifier,saved):
        meta=_decode(_read(fd,'record.json'));unsigned=dict(meta);sha=unsigned.pop('record_sha256',None)
        if digest(unsigned)!=sha or meta.get('schema')!='aircraft-control-experiment-v1' or meta.get('id')!=identifier or meta.get('plan_sha256')!=saved['plan']['plan_sha256']:raise ValueError('Study metadata identity mismatch')
        if meta.get('status') not in TERMINAL+('running',) or len(meta['points'])!=len(saved['plan']['points']):raise ValueError('Invalid study lifecycle')
        _id(meta['reference_config_id'])
        for point,expected in zip(meta['points'],saved['plan']['points']):
            if any(point.get(k)!=v for k,v in expected.items()):raise ValueError('Study point provenance mismatch')
            if point['run_id'] is not None:_id(point['run_id'])
        return meta

    def _save(self,identifier):
        row=self._rows[identifier];meta=row['meta'];meta['updated_utc']=now();meta.pop('record_sha256',None);meta['record_sha256']=digest(meta)
        with self._directory(identifier) as fd:
            name='.record-'+str(uuid.uuid4())+'.tmp'
            try:
                _write(fd,name,meta,MAX_METADATA);os.replace(name,'record.json',src_dir_fd=fd,dst_dir_fd=fd);os.fsync(fd)
            finally:
                try:os.unlink(name,dir_fd=fd)
                except FileNotFoundError:pass

    def snapshot(self,identifier):
        with self._lock:
            with self._directory(identifier) as fd:
                saved=self._read_plan(fd);meta=self._read_meta(fd,identifier,saved)
            row=self._rows[identifier];result=deepcopy(meta)
            if row.get('runtime_error'):result.update(status='failed',error=row['runtime_error'])
            result['plan']=saved['plan'];result['active']=bool(row['thread'] and row['thread'].is_alive());result['cancel_requested']=row['cancel'].is_set();result['progress']=None
            current=next((p for p in meta['points'] if p['status']=='running' and p['run_id']),None)
            if current:result['progress']=row['catalog'].snapshot(current['run_id'])['progress']
            return result

    def listing(self):
        with self._lock:
            self._check();rows=[];unavailable=dict(self._unavailable)
            for identifier in self._rows:
                try:rows.append(self.snapshot(identifier))
                except (ValueError,RuntimeError,KeyError,OSError) as e:unavailable[identifier]=str(e)
            return dict(studies=rows,unavailable=[dict(id=k,error=v) for k,v in unavailable.items()],active=self._active,limits=dict(max_studies=MAX_STUDIES,max_points=MAX_POINTS,max_intervals=MAX_INTERVALS,max_storage_bytes=MAX_BYTES,max_wall_seconds=MAX_WALL))

    def start(self,reference,spec,expected_plan_sha):
        prepared=plan(reference,spec)
        if prepared['plan_sha256']!=expected_plan_sha:raise ValueError('Plan changed; preview the study again')
        saved=dict(plan=prepared,reference=deepcopy(reference))
        if len(json.dumps(saved,allow_nan=False).encode())>MAX_INPUT:raise ValueError('Study plan exceeds input byte budget')
        with self._lock:
            self._check()
            if self._closing or self._active is not None:raise RuntimeError('A study is already active or catalog is closing')
            if len(names(self._fd,MAX_STUDIES+1))>=MAX_STUDIES+1:raise RuntimeError('Saved study capacity reached')
            if not self._execution.acquire(blocking=False):raise RuntimeError('Another aircraft analysis is active; retry when idle')
            identifier=str(uuid.uuid4())
            try:os.mkdir(identifier,mode=0o700,dir_fd=self._fd)
            except BaseException:
                self._execution.release();raise
            row=dict(identity=_identity(os.stat(identifier,dir_fd=self._fd,follow_symlinks=False)),plan=saved,meta=None,catalog=None,cancel=threading.Event(),thread=None)
            self._rows[identifier]=row
            try:
                with self._directory(identifier) as fd:_write(fd,'inputs.json',saved,MAX_INPUT)
                row['catalog']=self._open_catalog(identifier)
                config=row['catalog'].configuration(reference)
                row['meta']=dict(schema='aircraft-control-experiment-v1',id=identifier,name=spec['name'],created_utc=now(),updated_utc=now(),status='running',error=None,plan_sha256=prepared['plan_sha256'],reference_config_id=config['id'],points=[dict(p,run_id=None,status='queued',summary=None,error=None) for p in prepared['points']])
                self._save(identifier);self._active=identifier
                row['thread']=threading.Thread(target=self._run,args=(identifier,),name='control-study-'+identifier,daemon=True);row['thread'].start()
                return self.snapshot(identifier)
            except BaseException as e:
                if row.get('thread') and row['thread'].ident is not None:raise
                self._active=None;self._execution.release()
                if row.get('meta'):
                    row['meta'].update(status='failed',error=str(e)[:1000]);self._save(identifier)
                else:self._unavailable[identifier]=str(e)
                raise

    def _run(self,identifier):
        row=self._rows[identifier];meta=row['meta'];saved=row['plan'];cat=row['catalog'];deadline=_clock()+saved['plan']['spec']['budget']['wall_seconds'];final='finished'
        try:
            for p in meta['points']:
                if row['cancel'].is_set():final='cancelled';break
                if _clock()>=deadline:final='budget-stopped';break
                hashes,platform=model_identity()
                if dict(hashes=hashes,platform=platform)!=saved['plan']['implementation_identity']:raise RuntimeError('Model implementation changed; remaining points were not run')
                inputs=variant(saved['reference'],saved['plan']['spec']['variable'],p['value'])
                if inputs['inputs_sha256']!=p['inputs_sha256']:raise RuntimeError('Planned sample inputs changed')
                with self._lock:
                    job=cat.start(inputs,parent_config_id=meta['reference_config_id']);p.update(run_id=job['id'],status='running');self._save(identifier)
                requested=False
                while True:
                    job=cat.snapshot(job['id'])
                    if not job['active']:break
                    expired=_clock()>=deadline
                    if (row['cancel'].is_set() or expired) and not requested and job['cancellable']:
                        cat.cancel(job['id']);requested=True
                    if expired:final='budget-stopped'
                    row['cancel'].wait(.1) if not row['cancel'].is_set() else time.sleep(.05)
                with self._lock:
                    if job['phase']=='finished':
                        from .aircraft_control_experiment_metrics import summarize
                        report=cat.artifact(job['id'],'report.json')
                        if dict(hashes=report['implementation_hashes'],platform=report['platform'])!=saved['plan']['implementation_identity']:raise RuntimeError('Study member model identity differs from the frozen plan')
                        p['summary']=summarize(report);p['status']=report['status'];del report
                    else:p.update(status=job['phase'],error=job.get('error') or 'Run did not publish a report')
                    self._save(identifier)
                if row['cancel'].is_set():final='cancelled';break
                if final=='budget-stopped':break
            with self._lock:
                meta['status']=final
                for p in meta['points']:
                    if p['status']=='queued':p['status']='not-run';p['error']='Study '+final
                self._save(identifier)
        except BaseException as e:
            with self._lock:
                meta.update(status='failed',error=(type(e).__name__+': '+str(e))[:1500])
                for p in meta['points']:
                    if p['status'] in ('queued','running'):p.update(status='not-run' if p['run_id'] is None else 'failed',error=meta['error'])
                try:self._save(identifier)
                except BaseException as publication_error:row['runtime_error']='Study metadata publication failed: '+str(publication_error)[:1000]
        finally:
            # Cancellation/cleanup uses the owned process handles even if a
            # corrupted archive makes metadata lookup impossible.
            with cat._lock:owned=list(cat._jobs.values())
            for job in owned:
                if not job['done'].is_set():job['cancel'].set();job['done'].wait()
            with self._lock:
                self._active=None;self._execution.release()

    def cancel(self,identifier):
        with self._lock:
            row=self._rows[identifier]
            if self._active!=identifier or row['meta']['status']!='running':raise RuntimeError('No active study to cancel')
            row['cancel'].set();return self.snapshot(identifier)

    def download(self,identifier,index,name):
        with self._lock:
            state=self.snapshot(identifier)
            if type(index) is not int or not 0<=index<len(state['points']):raise KeyError('Study point not found')
            point=state['points'][index]
            if point['run_id'] is None:raise RuntimeError('Study point has not run')
            return self._rows[identifier]['catalog'].download(point['run_id'],name)

    def reference(self,identifier):
        with self._lock,self._directory(identifier) as fd:return deepcopy(self._read_plan(fd)['reference'])

    def delete(self,identifier,confirmation):
        if confirmation!=identifier:raise ValueError('Confirm the exact study ID')
        with self._lock:
            state=self.snapshot(identifier);row=self._rows[identifier]
            if state['active'] or state['status'] not in TERMINAL:raise RuntimeError('Cannot delete an active study')
            cat=row['catalog'];listing=cat.listing()
            if listing['unavailable'] or any(r['active'] for r in listing['records']):raise RuntimeError('Study run storage requires inspection before deletion')
            # Preflight every record before any removal; individual deletion retains
            # ControllerStore identity/no-follow checks and never follows user paths.
            for r in listing['records']:cat.store.snapshot(r['id'])
            with self._directory(identifier) as fd:
                for r in listing['records']:cat.delete(r['id'],r['id'])
                runsfd=os.open('runs',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
                try:
                    if _identity(os.fstat(runsfd))!=cat.store._root_identity or set(names(runsfd,1))!={'catalog.lock'}:raise RuntimeError('Study run directory changed during deletion')
                    if _identity(os.stat('catalog.lock',dir_fd=runsfd,follow_symlinks=False))!=cat.store._lock_identity:raise RuntimeError('Study run lease changed')
                    os.unlink('catalog.lock',dir_fd=runsfd);os.rmdir('runs',dir_fd=fd)
                finally:os.close(runsfd)
                cat.close();row['catalog']=None
                for name in ('inputs.json','record.json'):os.unlink(name,dir_fd=fd)
                os.rmdir(identifier,dir_fd=self._fd);os.fsync(self._fd)
            os.close(row['directory_fd']);row['directory_fd']=None;del self._rows[identifier]
            return dict(deleted=identifier)

    def close(self):
        with self._lock:
            self._closing=True;threads=[]
            for row in self._rows.values():
                row['cancel'].set()
                if row['thread']:threads.append(row['thread'])
        for thread in threads:thread.join()
        for row in self._rows.values():
            if row.get('catalog'):row['catalog'].close()
            if row.get('directory_fd') is not None:os.close(row['directory_fd']);row['directory_fd']=None
        if self._lease is not None:os.close(self._lease);self._lease=None
        if self._fd is not None:os.close(self._fd);self._fd=None
