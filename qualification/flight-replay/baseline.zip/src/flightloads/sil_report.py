"""Reproducible SIL report export and bounded history replay comparison."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import zipfile
import numpy as np
from .benchmark import code_identity
from .sil import SILConfig, SILHistory, UNITS, VECTOR_FIELDS, INTEGER_FIELDS
from .sil_verification import ATOL, RTOL, compute_study, compare_histories

FILES = ('histories.npz', 'history.csv', 'controller.c', 'plots.svg', 'report.html')
MAX_BYTES = 64*1024*1024
MODEL = dict(id='manufactured-yaw-sil-v1', mass_kg=4., inertia_CG_B_kg_m2=[[4,0,0],[0,4,0],[0,0,8]],
    masses_kg=[1,1,1,1], mass_locations_CG_B_m=[[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0]],
    gravity_N_mps2=[0,0,0], actuator_location_CG_B_m=[0,0,0],
    cut_point_CG_B_m=[.5,0,0], cut_normal_B=[1,0,0], retained_side='positive x',
    section_convention='force and moment exerted by removed material on retained material, body axes',
    controller=dict(Kp_Nm_per_rad=24., Ki_Nm_per_rad_s=8., Kd_Nm_per_radps=24.,
                    integral_limit_rad_s=.2, integral_rule='previous held error forward Euler'),
    validity='manufactured constant-mass pure yaw, abs(yaw)<1 rad; not an aircraft model')


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def export(output, histories, checks, provenance, replay=None):
    """Create a fresh report directory; never overwrite existing evidence."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    source = Path(__file__).with_name('sil_controller.c').read_bytes()
    if hashlib.sha256(source).hexdigest() != provenance['source_sha256']:
        raise RuntimeError('C source changed after compilation')
    (output/'controller.c').write_bytes(source)
    np.savez_compressed(output/'histories.npz', **{
        name+'__'+key: value for name,run in histories.items() for key,value in run.arrays.items()})
    fields = [(key, index) for key in UNITS for index in
              (range(VECTOR_FIELDS[key]) if key in VECTOR_FIELDS else [None])]
    columns = ['case_id'] + [key if i is None else f'{key}_{i}' for key,i in fields]
    with (output/'history.csv').open('w', newline='') as stream:
        writer = csv.writer(stream); writer.writerow(columns)
        for name, run in histories.items():
            for k in range(run.config.steps+1):
                writer.writerow([name] + [run.arrays[key][k] if i is None else run.arrays[key][k,i]
                                         for key,i in fields])
    passed = all(item['passed'] for group in checks.values() for item in group)
    if replay is not None:
        passed = passed and all(item['passed'] for group in replay['checks'].values() for item in group)
    manifest = dict(schema_version=1, study_id=MODEL['id'], created_utc=datetime.now(timezone.utc).isoformat(),
        code=code_identity(), model=MODEL, compiled_controller=provenance,
        cases={name: run.config.to_dict() for name,run in histories.items()}, units=UNITS,
        tolerances=dict(component_atol=ATOL, rtol=RTOL, rule='abs(observed-reference) <= atol[unit] + rtol*abs(reference); integer clocks exact'),
        numerics=dict(plant='existing normalized-accepted-state RK4, torque held over each interval',
            event_order='truth, command, capture, release, controller, actuator, record, propagate',
            sensor='zero-order hold, explicitly at-rest prehistory capture=-delay, release=0',
            actuator='clip absolute command, then clip previous torque +/- slew*plant_dt',
            saved_time='right-hand instantaneous state/load; final sample does not propagate',
            capture_fields='captured values/scheduled release valid only when capture_event=1; zeros otherwise',
            elapsed_field='controller elapsed seconds valid at controller_event=1; zero otherwise',
            frame='Hamilton scalar-first quaternion actively maps body B to inertial N',
            refinement='sampling_1/2/4 halve plant and sensor/controller periods together over 4 s; plant_2 preserves physical sensor/controller periods'),
        status=dict(run_completion='completed', numerical_verification='passed' if passed else 'failed',
                    sil_parity=('passed' if all(item['passed'] for key,group in checks.items() if key.endswith('_parity') for item in group) else 'failed') if all(key in checks for key in ('nominal_parity','delayed_parity','limited_parity')) else 'not_performed',
                    model_validation='not_performed', design_acceptance='not_performed'),
        checks=checks, replay=replay)
    from .sil_report_view import render_plots, render_report
    render_plots(output, histories)
    render_report(output, manifest)
    manifest['artifacts'] = {name: dict(bytes=(output/name).stat().st_size, sha256=_sha(output/name)) for name in FILES}
    (output/'manifest.json').write_text(json.dumps(manifest, indent=2, allow_nan=False)+'\n')
    return manifest


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def read_replay(directory):
    """Integrity/shape validation; stored pass flags are never accepted as evidence."""
    directory = Path(directory)
    path = directory/'manifest.json'
    if path.stat().st_size > 4*1024*1024:
        raise ValueError('manifest too large')
    def invalid(value):
        raise ValueError('nonfinite JSON')
    manifest = json.loads(path.read_text(), object_pairs_hook=_unique, parse_constant=invalid)
    if manifest['schema_version'] != 1 or manifest['model'] != MODEL or manifest['units'] != UNITS:
        raise ValueError('incompatible SIL reference manifest')
    if set(manifest['artifacts']) != set(FILES) or len(manifest['cases']) != 10:
        raise ValueError('unexpected SIL artifacts/cases')
    for name in FILES:
        file = directory/name
        if file.stat().st_size > MAX_BYTES or file.stat().st_size != manifest['artifacts'][name]['bytes'] or _sha(file) != manifest['artifacts'][name]['sha256']:
            raise ValueError('artifact integrity failure: '+name)
    if _sha(directory/'controller.c') != manifest['compiled_controller']['source_sha256']:
        raise ValueError('compiled source integrity failure')
    configs = {name: SILConfig(**value) for name,value in manifest['cases'].items()}
    expected = {name+'__'+key: ((c.steps+1,) + ((VECTOR_FIELDS[key],) if key in VECTOR_FIELDS else ()),
                                np.dtype('int64' if key in INTEGER_FIELDS else 'float64'))
                for name,c in configs.items() for key in UNITS}
    with zipfile.ZipFile(directory/'histories.npz') as archive:
        members = archive.infolist()
        if len(members) != len(expected) or {m.filename for m in members} != {key+'.npy' for key in expected} or sum(m.file_size for m in members) > MAX_BYTES:
            raise ValueError('invalid/oversized history archive')
        # Inspect bounded NPY headers before NumPy allocates from declared shapes.
        for member in members:
            with archive.open(member) as stream:
                version = np.lib.format.read_magic(stream)
                if version != (1,0):
                    raise ValueError('unexpected NPY version')
                shape, fortran, dtype = np.lib.format.read_array_header_1_0(stream)
                eshape, edtype = expected[member.filename[:-4]]
                if shape != eshape or dtype != edtype or fortran or member.file_size-stream.tell() != int(np.prod(shape))*dtype.itemsize:
                    raise ValueError('invalid NPY shape/type/length')
    with np.load(directory/'histories.npz', allow_pickle=False) as data:
        histories = {name: SILHistory(c, {key: data[name+'__'+key] for key in UNITS}) for name,c in configs.items()}
    return manifest, histories


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--replay', type=Path)
    args = parser.parse_args(argv)
    try:
        if args.output.exists():
            raise ValueError('output already exists; choose a fresh directory')
        previous = read_replay(args.replay) if args.replay else None
        histories, checks, provenance = compute_study()
        replay = None
        if previous:
            old_manifest, old_runs = previous
            if set(old_runs) != set(histories):
                raise ValueError('replay case set differs from this reference version')
            replay = dict(source_manifest_sha256=_sha(args.replay/'manifest.json'),
                source_code=old_manifest['code'], source_compiler=old_manifest['compiled_controller'],
                checks={name: compare_histories(run, old_runs[name]) for name,run in histories.items()})
        manifest = export(args.output, histories, checks, provenance, replay)
        print(f"{args.output}/report.html: numerical verification {manifest['status']['numerical_verification']}")
        return 0 if manifest['status']['numerical_verification'] == 'passed' else 1
    except (ValueError, RuntimeError, OSError, ImportError, KeyError, TypeError, zipfile.BadZipFile) as exc:
        print(f'SIL reference error: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
