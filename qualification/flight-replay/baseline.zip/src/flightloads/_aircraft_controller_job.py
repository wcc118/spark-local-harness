"""Private fresh-process numerical worker; receives only service-owned FDs."""
import argparse
import json
import os
import resource
import threading

MAX_MESSAGE = 64*1024


def _send(fd, value, *, final=False):
    raw = json.dumps(value,allow_nan=False,separators=(',',':')).encode()+b'\n'
    if len(raw)>MAX_MESSAGE: raise ValueError('Worker message exceeds limit')
    if final:
        os.set_blocking(fd,True)
        while raw:
            count = os.write(fd,raw); raw = raw[count:]
    else:
        # Progress is smaller than PIPE_BUF: either one complete write or drop.
        if len(raw)>4096: raise ValueError('Progress message exceeds atomic pipe bound')
        try: os.write(fd,raw)
        except BlockingIOError: pass


def _watch_parent(fd, cancelled):
    while True:
        try: message = os.read(fd,1)
        except OSError: os._exit(78)
        if not message: os._exit(78)  # keep inherited ownership lease until exit
        if message==b'C': cancelled.set()


def main(argv=None):
    global __package__
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('directory-fd','lease-fd','control-fd','progress-fd','memory-bytes'):
        parser.add_argument('--'+name,type=int,required=True)
    parser.add_argument('--source-fd',type=int)
    parser.add_argument('--source-sha')
    parser.add_argument('--identity-sha',required=True)
    parser.add_argument('--kind',choices=('run','replay'),required=True)
    args = parser.parse_args(argv)
    cancelled = threading.Event()
    threading.Thread(target=_watch_parent,args=(args.control_fd,cancelled),daemon=True).start()
    os.set_blocking(args.progress_fd,False)
    try:
        # Before importing NumPy/plant code. RLIMIT_AS is virtual address space.
        resource.setrlimit(resource.RLIMIT_AS,(args.memory_bytes,args.memory_bytes))
        if not __package__: __package__ = 'flightloads'
        from .aircraft_controller_store import _read, _decode, _descriptor, write_artifact
        from .aircraft_controller_run import run_bench, replay_bench
        from .aircraft_controller_trim import _identity
        from .aircraft_elastic import digest
        hashes,platform = _identity()
        identity = dict(hashes=hashes,platform=platform)
        if digest(identity)!=args.identity_sha: raise ValueError('Implementation/platform changed before worker start')
        inputs = _decode(_read(args.directory_fd,'inputs.json'))
        if args.kind=='run':
            def progress(value): _send(args.progress_fd,dict(event='progress',progress=value))
            report = run_bench(inputs,progress=progress,cancelled=lambda _:cancelled.is_set())
            if (report['implementation_hashes'],report['platform'])!=(hashes,platform):
                raise ValueError('Implementation/platform changed during run')
            write_artifact(args.directory_fd,'report.json',report)
            result = dict(event='done',kind='run')
        else:
            raw = _read(args.source_fd,'report.json')
            if _descriptor('report.json',raw)['sha256']!=args.source_sha: raise ValueError('Replay source artifact changed')
            source = _decode(raw)
            if source['inputs']!=inputs: raise ValueError('Replay source inputs differ')
            verdict = dict(schema='aircraft-controller-replay-v1',status='matched',
                source_report_sha256=source['report_sha256'],replayed_report_sha256=None,
                implementation_hashes=hashes,platform=platform,error=None)
            try:
                replayed = replay_bench(source)
                verdict['replayed_report_sha256'] = replayed['report_sha256']
            except ValueError as error:
                verdict.update(status='mismatched',error=str(error)[:2000] or type(error).__name__)
            if _identity()!=(hashes,platform): raise ValueError('Implementation/platform changed during replay')
            # Parent is the only verdict writer, resolving user-cancel vs exit races.
            result = dict(event='done',kind='replay',verdict=verdict)
        result['resources'] = dict(address_space_limit_bytes=resource.getrlimit(resource.RLIMIT_AS)[0],
                                   peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
        _send(args.progress_fd,result,final=True)
        return 0
    except BaseException as error:
        try: _send(args.progress_fd,dict(event='error',error=(type(error).__name__+': '+str(error))[:1500]),final=True)
        except BaseException: pass
        return 70


if __name__=='__main__':
    raise SystemExit(main())
