"""Local lateral linearization, independently assembled in imperial mechanics."""
from copy import deepcopy
import math
import numpy as np
from .aircraft_workspace import G_IN_S2
from .aircraft_spatial import symmetric_trim, field

STATE_NAMES=('beta_rad','p_rad_s','r_rad_s','phi_rad')
CONTROL_NAMES=('aileron_rad','tail_differential_rad')


class LateralModel:
    def __init__(self,definition):
        self.definition=deepcopy(definition);self.trim=symmetric_trim(definition)
        if not self.trim['feasible']:raise ValueError('Feasible four-panel trim required')
        self.mp=self.trim['mass_properties'];self.inertia=np.array(self.mp['inertia_CG'])
        self.speed=definition['flight_condition']['speed_ft_s'];self.alpha=math.radians(self.trim['alpha_deg'])

    def flow(self,state):
        beta,p,r,phi=np.asarray(state,dtype=float)
        return self.speed*np.array([math.cos(beta)*math.cos(self.alpha),math.sin(beta),math.cos(beta)*math.sin(self.alpha)]),np.array([p,0.,r])

    def forces(self,state,controls=(0.,0.)):
        v,w=self.flow(state)
        result=field(self.definition,self.mp,v,w,common_tail_deg=self.trim['common_tail_deg'],
            thrust_lbf=self.trim['thrust_lbf'],aileron_deg=math.degrees(controls[0]),differential_tail_deg=math.degrees(controls[1]))
        if not result['within_assumed_domain']:raise ValueError('Lateral derivative left assumed model domain')
        return np.array(result['non_gravity_force_B_lbf']),np.array(result['moment_about_CG_B_in_lbf'])

    def rhs(self,state):
        beta,p,r,phi=np.asarray(state,dtype=float);v,w=self.flow(state);f,m=self.forces(state)
        # Independent equations, not the production rigid_derivative provider.
        gravity=(G_IN_S2/12)*np.array([-math.sin(self.alpha),math.sin(phi)*math.cos(self.alpha),math.cos(phi)*math.cos(self.alpha)])
        mass_slug=self.mp['weight_lbf']/(G_IN_S2/12)
        vdot=f/mass_slug+gravity-np.cross(w,v)
        wdot=np.linalg.solve(self.inertia,m-np.cross(w,self.inertia@w))
        speed_dot=float(v@vdot)/self.speed
        beta_dot=(vdot[1]*self.speed-v[1]*speed_dot)/(self.speed**2*math.cos(beta))
        return np.array([beta_dot,wdot[0],wdot[2],p+math.tan(self.alpha)*r*math.cos(phi)])

    def linearization(self):
        def jacobian(step):
            eye=np.eye(4)*step
            return np.column_stack([(self.rhs(e)-self.rhs(-e))/(2*step) for e in eye])
        coarse,fine=jacobian(1e-5),jacobian(5e-6)
        error=abs(coarse-fine);tolerance=1e-7+1e-4*abs(fine)
        force_jac=[]
        for step in (1e-5,5e-6):
            columns=[]
            for axis in range(5):
                def evaluate(sign):
                    state=np.zeros(4);controls=np.zeros(2)
                    if axis<3:state[axis]=sign*step
                    else:controls[axis-3]=sign*step
                    f,m=self.forces(state,controls)
                    return np.array([f[1],m[0],m[2]])
                columns.append((evaluate(1)-evaluate(-1))/(2*step))
            force_jac.append(np.column_stack(columns))
        force_error=abs(force_jac[0]-force_jac[1]);force_tolerance=1e-7+1e-4*abs(force_jac[1])
        eig=np.linalg.eigvals(fine);largest=float(max(eig.real))
        tendency='unstable' if largest>1e-6 else ('asymptotically stable' if largest < -1e-6 else 'neutral or unresolved within1e-6/s')
        return dict(state_names=list(STATE_NAMES),A=fine.tolist(),derivative_steps=[1e-5,5e-6],
            matrix_step_error=error.tolist(),matrix_step_tolerance=tolerance.tolist(),
            force_derivatives=force_jac[1].tolist(),force_rows=['Fy_lbf','Mx_in_lbf','Mz_in_lbf'],
            force_columns=['beta_rad','p_rad_s','r_rad_s',*CONTROL_NAMES],
            force_step_error=force_error.tolist(),force_step_tolerance=force_tolerance.tolist(),
            passed=bool(np.all(error<=tolerance) and np.all(force_error<=force_tolerance)),
            eigenvalues_per_s=[dict(real=float(v.real),imag=float(v.imag)) for v in eig],classification=tendency,
            scope='Local controls-fixed dynamics of this assumed four-panel model; derivative signs alone are not dynamic stability.')


def matrix_exponential(matrix):
    """Independent scaled Taylor exponential for the small verification matrix."""
    matrix=np.asarray(matrix,dtype=float)
    if matrix.ndim!=2 or matrix.shape[0]!=matrix.shape[1] or not np.all(np.isfinite(matrix)):
        raise ValueError('Finite square matrix required')
    scale=max(0,int(math.ceil(math.log2(max(1.,float(np.linalg.norm(matrix,ord=np.inf))/.5)))))
    a=matrix/(2**scale);result=np.eye(len(a));term=result.copy()
    for k in range(1,129):
        term=term@a/k;result+=term
        if np.max(abs(term))<=1e-16*max(1.,float(np.max(abs(result)))):break
    else:raise ValueError('Verification matrix exponential did not converge')
    for _ in range(scale):result=result@result
    return result
