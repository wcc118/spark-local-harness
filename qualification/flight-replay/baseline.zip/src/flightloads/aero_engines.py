"""Aero engine helper module.

This module provides utilities for locating and verifying built aero engines
(XFOIL, AVL).

Usage:
    from flightloads.aero_engines import locate

    xfoil_path, manifest = locate("xfoil")
    avl_path, manifest = locate("avl")
"""

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Tuple, Dict, Any, NamedTuple


class EngineVerificationResult(NamedTuple):
    """Result of engine verification."""
    engine: str
    observed: Dict[str, float]
    expected: Dict[str, Dict[str, float]]
    tolerances: Dict[str, float]
    pass_per_quantity: Dict[str, bool]
    overall_pass: bool
    error: Optional[str] = None


def get_install_dir() -> Path:
    """Get the installation directory for built engines."""
    env_dir = os.environ.get("FLIGHTLOADS_ENGINE_DIR")
    if env_dir:
        return Path(env_dir).expanduser()
    return Path("~/.local/share/flight-loads/engines").expanduser()


def locate(engine: str) -> Tuple[Path, Dict[str, Any]]:
    """
    Locate a built engine and return its binary path and manifest.

    Args:
        engine: Engine name ("xfoil" or "avl")

    Returns:
        Tuple of (binary_path, manifest_dict)

    Raises:
        FileNotFoundError: If the engine is not built
        RuntimeError: If the manifest is invalid
    """
    install_dir = get_install_dir()

    if engine == "xfoil":
        engine_dir = install_dir / "xfoil-6.996"
        binary_name = "xfoil"
    elif engine == "avl":
        engine_dir = install_dir / "avl-3.52"
        binary_name = "avl"
    else:
        raise ValueError(f"Unknown engine: {engine}. Expected 'xfoil' or 'avl'.")

    if not engine_dir.exists():
        raise FileNotFoundError(
            f"Engine '{engine}' not built at {engine_dir}\n"
            f"Build it first with: python scripts/build_aero_engines.py --engine {engine}"
        )

    manifest_path = engine_dir / "build-manifest.json"
    if not manifest_path.exists():
        raise RuntimeError(
            f"Build manifest not found at {manifest_path}\n"
            f"Engine directory exists but build may be incomplete."
        )

    with open(manifest_path, "r") as f:
        manifest = json.load(f)

    # Verify binary exists
    binary_path = engine_dir / manifest["bin_dir"] / binary_name
    if not binary_path.exists():
        raise FileNotFoundError(
            f"Engine binary not found at {binary_path}\n"
            f"Manifest references this path but it does not exist."
        )

    # Verify binary is executable
    if not os.access(binary_path, os.X_OK):
        # Try to make it executable
        try:
            os.chmod(binary_path, 0o755)
        except OSError:
            raise RuntimeError(
                f"Engine binary {binary_path} is not executable and cannot be made executable."
            )

    return binary_path, manifest


def check_engine(engine: str) -> bool:
    """
    Check if an engine is built and functional.

    Args:
        engine: Engine name ("xfoil" or "avl")

    Returns:
        True if the engine is built and appears functional
    """
    try:
        binary_path, manifest = locate(engine)

        # Try to get version info
        if engine == "xfoil":
            result = subprocess.run(
                [str(binary_path), "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            # XFOIL may not support --version, so just check it runs
            return True
        elif engine == "avl":
            # AVL doesn't support command-line flags, so run with 'quit' command
            result = subprocess.run(
                [str(binary_path)],
                input="quit\n",
                capture_output=True,
                text=True,
                timeout=5
            )
            return True

        return True
    except (FileNotFoundError, RuntimeError, subprocess.TimeoutExpired):
        return False
    except Exception:
        return False


def verify_engine(engine: str) -> EngineVerificationResult:
    """
    Run a smoke test to verify an engine is functional.

    Args:
        engine: Engine name ("xfoil" or "avl")

    Returns:
        EngineVerificationResult with observed values, expected values, and pass/fail

    A failed comparison or engine run is reported through overall_pass=False
    and the error field; it is not raised.

    Raises:
        FileNotFoundError: If the engine is not built
        RuntimeError: If the AVL sample files are missing from the install
    """
    binary_path, manifest = locate(engine)

    if engine == "avl":
        # AVL smoke test: run with vanilla.avl from samples directory
        return _verify_avl(binary_path)
    elif engine == "xfoil":
        # XFOIL smoke test: run with NACA 0012
        return _verify_xfoil(binary_path)

    raise RuntimeError(f"Unknown engine: {engine}")


def _parse_avl_output(output: str) -> Dict[str, float]:
    """Parse AVL output to extract CLtot, CDind, and e values."""
    result = {}

    # Pattern for CLtot: "CLtot =   0.83502"
    cltot_match = re.search(r"CLtot\s*=\s*([0-9.-]+)", output)
    if cltot_match:
        result["CLtot"] = float(cltot_match.group(1))

    # Pattern for CDind: "CDind = 0.0184801"
    cdind_match = re.search(r"CDind\s*=\s*([0-9.-]+)", output)
    if cdind_match:
        result["CDind"] = float(cdind_match.group(1))

    # Pattern for e: "e =    0.9938"
    # "e" follows CYff on the same line, so it is not anchored at line start.
    e_match = re.search(r"(?<![A-Za-z0-9_'])e\s*=\s*([-0-9.]+)", output)
    if e_match:
        result["e"] = float(e_match.group(1))

    return result


def _verify_avl(binary_path: Path) -> EngineVerificationResult:
    """Run AVL smoke test using vanilla.avl from samples directory."""
    import tempfile

    # Get install directory from binary path
    install_dir = binary_path.parent.parent  # .../avl-3.52
    samples_dir = install_dir / "samples"

    if not samples_dir.exists():
        raise RuntimeError(
            f"AVL samples directory not found at {samples_dir}. "
            f"Rebuild AVL to copy sample files."
        )

    vanilla_avl = samples_dir / "vanilla.avl"
    if not vanilla_avl.exists():
        raise RuntimeError(f"vanilla.avl not found at {vanilla_avl}")

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)

        # Copy samples to temp directory for isolated run
        temp_samples = tmpdir_path / "samples"
        shutil.copytree(samples_dir, temp_samples, symlinks=True)

        # Run AVL with commands using the vanilla.avl file
        commands = [
            "load vanilla.avl",
            "oper",
            "a a 5",
            "x",
            "",
            "",
            "quit"
        ]

        full_input = "\n".join(commands)

        try:
            result = subprocess.run(
                [str(binary_path)],
                input=full_input,
                capture_output=True,
                text=True,
                cwd=temp_samples,
                timeout=30
            )

            output = result.stdout + result.stderr
            observed = _parse_avl_output(output)

            # Get expected values from config
            config = _load_engine_config()
            expected_config = config["engines"]["avl"]["smoke_test"]["expected"]

            expected = {k: v["value"] for k, v in expected_config.items()}
            tolerances = {k: v["tolerance"] for k, v in expected_config.items()}

            # Check each value against tolerance
            pass_per_quantity = {}
            for key in expected:
                if key in observed:
                    diff = abs(observed[key] - expected[key])
                    pass_per_quantity[key] = diff <= tolerances[key]
                else:
                    pass_per_quantity[key] = False

            overall_pass = all(pass_per_quantity.values())

            return EngineVerificationResult(
                engine="avl",
                observed=observed,
                expected=expected,
                tolerances=tolerances,
                pass_per_quantity=pass_per_quantity,
                overall_pass=overall_pass
            )

        except (subprocess.TimeoutExpired, OSError, KeyError, ValueError) as error:
            return EngineVerificationResult(
                engine="avl",
                observed={},
                expected={},
                tolerances={},
                pass_per_quantity={},
                overall_pass=False,
                error=f"{type(error).__name__}: {error}"
            )


def _load_engine_config() -> Dict[str, Any]:
    """Load the aero_engines.json configuration."""
    script_dir = Path(__file__).parent
    config_path = script_dir.parent.parent / "third_party" / "aero_engines.json"
    with open(config_path, "r") as f:
        return json.load(f)


def _parse_xfoil_polar(polar_content: str, alpha_deg: float = 4.0) -> Optional[Dict[str, float]]:
    """Return the alpha, CL, CD row for alpha_deg from a saved XFOIL polar file.

    Data rows follow the dashed separator line under the column headings.
    Returns None when the separator or the requested alpha row is absent.
    """
    lines = polar_content.splitlines()
    try:
        start = next(i for i, line in enumerate(lines) if line.strip().startswith('------')) + 1
    except StopIteration:
        return None
    for line in lines[start:]:
        parts = line.split()
        if len(parts) < 3:
            continue
        try:
            alpha, cl, cd = float(parts[0]), float(parts[1]), float(parts[2])
        except ValueError:
            continue
        if abs(alpha - alpha_deg) < 0.01:
            return {"alpha": alpha, "CL": cl, "CD": cd}
    return None


def _verify_xfoil(binary_path: Path) -> EngineVerificationResult:
    """Run XFOIL smoke test."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        polar_file = tmpdir_path / "polar.dat"

        # Create input file for headless mode
        # Graphics off, then accumulate the alpha=4 point into a relative polar
        # file (XFOIL truncates long file names, so keep it inside cwd).
        commands = [
            "plop", "g", "",
            "naca 0012",
            "oper",
            "visc 3000000",
            "iter 200",
            "pacc", polar_file.name, "",
            "a 4",
            "",
            "quit",
        ]

        full_input = "\n".join(commands)

        try:
            result = subprocess.run(
                [str(binary_path)],
                input=full_input,
                capture_output=True,
                text=True,
                cwd=tmpdir,
                timeout=30
            )

            # Parse polar file (not stdout)
            if polar_file.exists():
                polar_content = polar_file.read_text()
                observed = _parse_xfoil_polar(polar_content)

                if observed is None:
                    return EngineVerificationResult(
                        engine="xfoil",
                        observed={},
                        expected={},
                        tolerances={},
                        pass_per_quantity={},
                        overall_pass=False,
                        error="alpha=4 row missing from saved polar file"
                    )

                # Get expected values from config
                config = _load_engine_config()
                expected_config = config["engines"]["xfoil"]["smoke_test"]["expected"]

                expected = {k: v["value"] for k, v in expected_config.items()}
                tolerances = {k: v["tolerance"] for k, v in expected_config.items()}

                # Check each value against tolerance
                pass_per_quantity = {}
                for key in expected:
                    if key in observed:
                        diff = abs(observed[key] - expected[key])
                        pass_per_quantity[key] = diff <= tolerances[key]
                    else:
                        pass_per_quantity[key] = False

                overall_pass = all(pass_per_quantity.values())

                return EngineVerificationResult(
                    engine="xfoil",
                    observed=observed,
                    expected=expected,
                    tolerances=tolerances,
                    pass_per_quantity=pass_per_quantity,
                    overall_pass=overall_pass
                )
            else:
                return EngineVerificationResult(
                    engine="xfoil",
                    observed={},
                    expected={},
                    tolerances={},
                    pass_per_quantity={},
                    overall_pass=False,
                    error="XFOIL did not write a polar file"
                )

        except (subprocess.TimeoutExpired, OSError, KeyError, ValueError) as error:
            return EngineVerificationResult(
                engine="xfoil",
                observed={},
                expected={},
                tolerances={},
                pass_per_quantity={},
                overall_pass=False,
                error=f"{type(error).__name__}: {error}"
            )


def get_engine_info(engine: str) -> Dict[str, Any]:
    """
    Get information about a built engine.

    Args:
        engine: Engine name ("xfoil" or "avl")

    Returns:
        Dictionary with engine information

    Raises:
        FileNotFoundError: If the engine is not built
    """
    binary_path, manifest = locate(engine)

    return {
        "engine": engine,
        "version": manifest["version"],
        "binary_path": str(binary_path),
        "binary_sha256": manifest["binary_sha256"],
        "build_time": manifest["build_time"],
        "gfortran_version": manifest["gfortran_version"],
        "gcc_version": manifest["gcc_version"],
        "host_arch": manifest["host_arch"]
    }
