"""Bench baseline store and override management (issue #284).

This module provides:
- builtin_contents() -> dict with stable_example_definition and default_propulsion
- canonical() / sha() helpers for deterministic JSON hashing
- validate_overrides() for override list validation
- apply_overrides() with JSON pointer resolution and stale check
- overrides_sha() for override list hashing
- BaselineStore class for getting, listing, and creating baseline revisions
- resolve_bench() for applying bench overrides to station inputs
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .aircraft_workspace import stable_example_definition
from .propulsion import default_propulsion


def builtin_contents() -> dict[str, Any]:
    """Return the built-in baseline contents.

    Returns a deep copy with:
    - definition: stable_example_definition()
    - propulsion: default_propulsion()
    - atmosphere: None
    - aero_dataset: None
    """
    return {
        'definition': stable_example_definition(),
        'propulsion': default_propulsion(),
        'atmosphere': None,
        'aero_dataset': None,
    }


def _canonical(obj: Any) -> str:
    """Return canonical JSON string for obj (deterministic, compact)."""
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False)


def canonical(obj: Any) -> str:
    """Public alias for canonical JSON serialization."""
    return _canonical(obj)


def _sha(obj: Any) -> str:
    """Return SHA-256 hex digest of canonical JSON representation."""
    return hashlib.sha256(_canonical(obj).encode()).hexdigest()


def sha(obj: Any) -> str:
    """Public alias for SHA-256 hash of canonical JSON."""
    return _sha(obj)


def aircraft_import_preview(definition: dict) -> dict:
    """Validate the aircraft editor's export without changing any revision."""
    from .aircraft_workspace import evaluate_aircraft
    definition = copy.deepcopy(definition)
    # Reject non-finite JSON anywhere, including optional editor metadata.
    digest = _sha(definition)
    result = evaluate_aircraft(definition)
    if result['mass_properties'] is None:
        missing = '; '.join(f"{c['name']}: {', '.join(c['fields'])}" for c in result['missing'])
        raise ValueError('Aircraft mass model is incomplete: ' + (missing or 'no components'))
    mass = result['mass_properties']
    return dict(definition=definition, definition_sha256=digest,
                name=definition['name'], weight_lbf=mass['weight_lbf'],
                cg_B_in=mass['cg_B_in'], geometry=copy.deepcopy(definition['geometry']))


def validate_overrides(overrides: list[dict]) -> None:
    """Validate an override list.

    Args:
        overrides: List of override dicts with keys: path, baseline_value, value, note, created_utc

    Raises:
        ValueError: if validation fails
    """
    if not isinstance(overrides, list):
        raise ValueError('overrides must be a list')

    if len(overrides) > 200:
        raise ValueError('overrides list exceeds maximum of 200 entries')

    seen_paths = set()

    for i, override in enumerate(overrides):
        if not isinstance(override, dict):
            raise ValueError(f'override[{i}] must be a dict')

        keys = set(override.keys())
        expected_keys = {'path', 'baseline_value', 'value', 'note', 'created_utc'}

        if keys != expected_keys:
            missing = expected_keys - keys
            extra = keys - expected_keys
            errors = []
            if missing:
                errors.append(f'missing keys: {missing}')
            if extra:
                errors.append(f'extra keys: {extra}')
            raise ValueError(f'override[{i}] has incorrect keys: {"; ".join(errors)}')

        path = override['path']
        if not isinstance(path, str):
            raise ValueError(f'override[{i}].path must be a string')
        if len(path) > 200:
            raise ValueError(f'override[{i}].path exceeds 200 characters')
        if not path.startswith('/'):
            raise ValueError(f'override[{i}].path must start with /')

        baseline_value = override['baseline_value']
        value = override['value']

        # Reject bool values - must be int or float (but not bool)
        for val, name in [(baseline_value, 'baseline_value'), (value, 'value')]:
            if isinstance(val, bool):
                raise ValueError(f'override[{i}].{name} must not be a boolean')
            if not isinstance(val, (int, float)):
                raise ValueError(f'override[{i}].{name} must be an int or float')
            if not math.isfinite(val):
                raise ValueError(f'override[{i}].{name} must be finite')

        note = override['note']
        if not isinstance(note, str):
            raise ValueError(f'override[{i}].note must be a string')
        note_stripped = note.strip()
        if len(note_stripped) < 1 or len(note_stripped) > 500:
            raise ValueError(f'override[{i}].note must be 1-500 characters after strip')

        created_utc = override['created_utc']
        if not isinstance(created_utc, str):
            raise ValueError(f'override[{i}].created_utc must be a string')

        # Check for duplicate paths
        if path in seen_paths:
            raise ValueError(f'duplicate override path: {path}')
        seen_paths.add(path)


def _parse_json_pointer(pointer: str) -> list[str]:
    """Parse a JSON pointer per RFC 6901.

    Handles ~0 -> ~ and ~1 -> / unescaping.
    Returns list of segments (empty string for root).
    """
    if pointer == '':
        return []
    if not pointer.startswith('/'):
        raise ValueError('JSON pointer must start with /')

    segments = pointer[1:].split('/')
    result = []
    for seg in segments:
        # Unescape ~1 then ~0 (order matters)
        seg = seg.replace('~1', '/').replace('~0', '~')
        result.append(seg)
    return result


def _list_index(seg: str, length: int) -> int:
    # RFC 6901 array index: '0' or a decimal without leading zeros; never negative.
    if not re.fullmatch(r'0|[1-9][0-9]*', seg):
        raise ValueError(f'list index must be a non-negative decimal integer: {seg}')
    idx = int(seg)
    if idx >= length:
        raise ValueError(f'list index out of range: {idx}')
    return idx


def _resolve_pointer(obj: Any, pointer: str) -> Any:
    """Resolve a JSON pointer to the value at that location.

    Args:
        obj: The object to navigate
        pointer: JSON pointer string (e.g., '/propulsion/static_thrust_lbf')

    Returns:
        The value at the pointer location

    Raises:
        ValueError: if pointer is invalid or path doesn't exist
    """
    segments = _parse_json_pointer(pointer)

    current = obj
    for seg in segments:
        if isinstance(current, dict):
            if seg not in current:
                raise ValueError(f'path segment not found: {seg}')
            current = current[seg]
        elif isinstance(current, list):
            current = current[_list_index(seg, len(current))]
        else:
            raise ValueError(f'cannot navigate through non-container at segment: {seg}')

    return current


def apply_overrides(contents: dict, overrides: list[dict]) -> dict[str, Any]:
    """Apply overrides to baseline contents.

    Args:
        contents: The baseline contents dict
        overrides: List of validated override dicts

    Returns:
        A new deep-copied dict with overrides applied

    Raises:
        ValueError: if baseline_value doesn't match actual value (stale override)
    """
    result = copy.deepcopy(contents)

    for override in overrides:
        path = override['path']
        baseline_value = override['baseline_value']
        value = override['value']

        # Navigate with the same strict rules as _resolve_pointer: every segment must exist,
        # list indices are non-negative decimal integers in range, nothing is created.
        segments = _parse_json_pointer(path)
        if not segments:
            raise ValueError('override path must name a leaf, not the whole baseline')
        parent_pointer = '/' + '/'.join(seg.replace('~', '~0').replace('/', '~1') for seg in segments[:-1]) if len(segments) > 1 else ''
        current = _resolve_pointer(result, parent_pointer)
        leaf_key = segments[-1]
        current_leaf = _resolve_pointer(current, '/' + leaf_key.replace('~', '~0').replace('/', '~1'))

        # Check that current leaf is a finite number (not bool) and matches baseline_value
        if isinstance(current_leaf, bool):
            raise ValueError(f'override at {path}: leaf is boolean, expected numeric')

        if not isinstance(current_leaf, (int, float)):
            raise ValueError(f'override at {path}: leaf is not numeric')

        import math
        if not math.isfinite(current_leaf):
            raise ValueError(f'override at {path}: leaf is not finite')

        # Compare using float() for proper int/float comparison
        if float(current_leaf) != float(baseline_value):
            raise ValueError(f'stale override at {path}: baseline has {current_leaf}, override was written against {baseline_value}')

        # Apply the override
        if isinstance(current, dict):
            current[leaf_key] = value
        else:
            current[_list_index(leaf_key, len(current))] = value

    return result


def overrides_sha(overrides: list[dict]) -> str:
    """Return SHA-256 of the override list sorted by path.

    Empty list -> sha of [].
    """
    if not overrides:
        return _sha([])

    # Sort by path
    sorted_overrides = sorted(overrides, key=lambda o: o['path'])
    return _sha(sorted_overrides)


class BaselineStore:
    """Store for baseline revisions.

    Stores baselines in root/'baselines' directory as ID.json files.
    The 'builtin' baseline is special and never stored.
    """

    UUID_PATTERN = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')

    def __init__(self, root: Path):
        self.root = Path(root)
        self.baselines_dir = self.root / 'baselines'
        self.baselines_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()

    def get(self, id: str) -> dict:
        """Get a baseline record by ID.

        Args:
            id: 'builtin' or a UUID4 string

        Returns:
            The baseline record dict

        Raises:
            KeyError: if id is 'builtin' but built-in is not supported, or invalid UUID
        """
        if id == 'builtin':
            return {
                'schema': 'bench-baseline-v1',
                'id': 'builtin',
                'parent': None,
                'created_utc': None,
                'label': 'built-in estimates (code defaults)',
                'contents': copy.deepcopy(builtin_contents()),
                'contents_sha256': _sha(builtin_contents()),
                'promoted_overrides': [],
            }

        if not self.UUID_PATTERN.match(id):
            raise KeyError(id)

        path = self.baselines_dir / f'{id}.json'
        if not path.exists():
            raise KeyError(id)

        record = json.loads(path.read_text())
        # A revision is immutable: its contents must still hash to the recorded digest.
        if record.get('id') != id or _sha(record.get('contents')) != record.get('contents_sha256'):
            raise ValueError(f'baseline {id} failed its integrity check (contents do not match contents_sha256)')
        return record

    def listing(self) -> list[dict]:
        """List all baseline records.

        Returns:
            List of dicts with: id, label, parent, created_utc, contents_sha256, promoted_overrides count
            builtin first, then stored records (newest last by created_utc).
        """
        rows = []

        # Add builtin first
        builtin = self.get('builtin')
        rows.append({
            'id': 'builtin',
            'label': builtin['label'],
            'parent': None,
            'created_utc': None,
            'contents_sha256': builtin['contents_sha256'],
            'promoted_overrides_count': len(builtin['promoted_overrides']),
        })

        # Add stored baselines
        for path in self.baselines_dir.glob('*.json'):
            try:
                record = json.loads(path.read_text())
                rows.append({
                    'id': record['id'],
                    'label': record['label'],
                    'parent': record.get('parent'),
                    'created_utc': record['created_utc'],
                    'contents_sha256': record['contents_sha256'],
                    'promoted_overrides_count': len(record.get('promoted_overrides', [])),
                })
            except (OSError, ValueError, KeyError):
                continue

        # Sort by created_utc (newest last), None first
        def sort_key(r):
            if r['created_utc'] is None:
                return (0, '')  # builtin first
            return (1, r['created_utc'])

        return sorted(rows, key=sort_key)

    def import_aircraft(self, parent_id: str, label: str, definition: dict) -> dict:
        """Create a new immutable revision from an explicit aircraft JSON import.

        The caller selects the new revision separately. Parent propulsion and
        atmosphere are retained; a parent geometry-bound aero table is cleared.
        Existing promotion requests and baseline records keep their v1 shape.
        """
        if not isinstance(label, str) or not 1 <= len(label.strip()) <= 120:
            raise ValueError('label must be 1-120 nonblank characters')
        preview = aircraft_import_preview(definition)
        parent = self.get(parent_id)
        contents = copy.deepcopy(parent['contents'])
        contents['definition'] = preview['definition']
        contents['aero_dataset'] = None
        identifier = str(uuid.uuid4())
        record = dict(schema='bench-baseline-v1', id=identifier, parent=parent_id,
                      created_utc=datetime.now(timezone.utc).isoformat(timespec='seconds'),
                      label=label.strip(), contents=contents, contents_sha256=_sha(contents),
                      promoted_overrides=[], import_provenance=dict(kind='aircraft-json',
                          definition_sha256=preview['definition_sha256']))
        path = self.baselines_dir / f'{identifier}.json'
        with self.lock:
            if path.exists():
                raise RuntimeError('baseline identifier collision')
            temporary = path.with_suffix('.tmp')
            temporary.write_text(_canonical(record))
            temporary.replace(path)
        return record

    def create(self, parent_id: str, label: str, overrides: list[dict]) -> dict:
        """Create a new baseline revision.

        Args:
            parent_id: Parent baseline ID ('builtin' or UUID)
            label: 1-120 character label
            overrides: List of override dicts to apply

        Returns:
            The new baseline record

        Raises:
            ValueError: if validation fails
            KeyError: if parent_id not found
        """
        # Validate label
        if not isinstance(label, str) or len(label) < 1 or len(label) > 120:
            raise ValueError('label must be a string of 1-120 characters')

        # Validate overrides
        validate_overrides(overrides)

        # Get parent baseline
        parent = self.get(parent_id)

        # Apply overrides to create new contents
        contents = apply_overrides(parent['contents'], overrides)

        # Create new record
        new_id = str(uuid.uuid4())
        created_utc = datetime.now(timezone.utc).isoformat(timespec='seconds')

        # Sort overrides by path for storage
        sorted_overrides = sorted(overrides, key=lambda o: o['path'])

        record = {
            'schema': 'bench-baseline-v1',
            'id': new_id,
            'parent': parent_id,
            'created_utc': created_utc,
            'label': label,
            'contents': contents,
            'contents_sha256': _sha(contents),
            'promoted_overrides': sorted_overrides,
        }

        path = self.baselines_dir / f'{new_id}.json'

        with self.lock:
            # Check if file already exists (shouldn't with uuid4, but be safe)
            if path.exists():
                raise RuntimeError(f'baseline file already exists: {path}')

            # Write atomically
            tmp = path.with_suffix('.tmp')
            tmp.write_text(_canonical(record))
            tmp.replace(path)

        return record


def resolve_bench(bench: dict, store: BaselineStore, station: str, body: dict) -> tuple[dict, dict]:
    """Resolve bench overrides and prepare station inputs.

    Args:
        bench: Dict with baseline_id and overrides
        store: BaselineStore instance
        station: Station name (propulsion, plant, plant-run, launch, loads)
        body: Original request body

    Returns:
        (new_body, bench_identity) tuple

    Raises:
        ValueError: if validation fails or station not supported
    """
    # Validate bench structure
    if not isinstance(bench, dict):
        raise ValueError('bench_baseline must be a dict')

    if set(bench.keys()) != {'baseline_id', 'overrides'}:
        raise ValueError('bench_baseline must have exactly baseline_id and overrides keys')

    baseline_id = bench['baseline_id']
    overrides = bench['overrides']

    # Validate overrides (but don't apply yet - need baseline first)
    validate_overrides(overrides)

    # Get baseline
    baseline = store.get(baseline_id)

    # Apply overrides to get contents'
    contents_prime = apply_overrides(baseline['contents'], overrides)

    # Prepare new body (deep copy)
    new_body = copy.deepcopy(body)

    # Determine used sections and unused overrides
    used_sections = set()
    supported_stations = {'propulsion', 'plant', 'plant-run', 'launch', 'launch-preview', 'loads',
                          'capture', 'controller-design', 'aero-3d', 'dataset', 'dataset-snapshot'}

    if station not in supported_stations:
        raise ValueError(f"bench mode supports stations: {', '.join(sorted(supported_stations))}")

    # Check if this station uses definition or propulsion
    # For 'propulsion' station: body['propulsion'] = contents'.propulsion
    # For 'plant', 'plant-run', 'launch', 'launch-preview', 'loads' stations:
    #   - if body['definition'] is not None -> error
    #   - set body['definition'] = contents'.definition
    #   - if body['propulsion'] is not None, set to contents'.propulsion

    if station == 'propulsion':
        # This station provides propulsion data
        if 'propulsion' in new_body:
            new_body['propulsion'] = contents_prime['propulsion']
            used_sections.add('propulsion')
    else:
        # Other stations use definition
        if new_body.get('definition') is not None:
            raise ValueError('bench supplies the aircraft definition; send definition null')

        new_body['definition'] = contents_prime['definition']
        used_sections.add('definition')

        # For these stations, also handle propulsion if provided
        if station in ('plant', 'plant-run', 'launch', 'launch-preview', 'loads', 'capture', 'controller-design'):
            if new_body.get('propulsion') is not None:
                new_body['propulsion'] = contents_prime['propulsion']
                used_sections.add('propulsion')

    # Find unused override paths (first segment not in used_sections)
    unused_override_paths = []
    for override in overrides:
        path = override['path']
        # Get first segment
        if path.startswith('/'):
            first_segment = path[1:].split('/')[0]
            if first_segment not in used_sections:
                unused_override_paths.append(path)

    # Build bench identity
    overrides_sorted = sorted(overrides, key=lambda o: o['path'])
    bench_identity = {
        'baseline_id': baseline_id,
        'baseline_sha256': baseline['contents_sha256'],
        'overrides_sha256': overrides_sha(overrides),
        'overrides': overrides_sorted,
        'used_sections': sorted(used_sections),
        'unused_override_paths': sorted(unused_override_paths),
    }

    if station in ('capture', 'controller-design'):
        # Keep the exact canonical run-input schema. Existing source metadata is
        # included in its digest and travels unchanged through study snapshots.
        provenance = (f"Bench aircraft: revision {baseline_id}; baseline {baseline['contents_sha256']}; "
                      f"overrides {bench_identity['overrides_sha256']}; definition {_sha(contents_prime['definition'])}.")
        source = new_body['bench']['source']
        if not source.endswith(provenance):
            new_body['bench']['source'] = source + '\n' + provenance

    return new_body, bench_identity
