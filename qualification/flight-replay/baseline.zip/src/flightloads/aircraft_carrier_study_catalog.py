"""Bounded local study jobs, with persisted artifacts distinct from live threads."""
from copy import deepcopy
from io import BytesIO
from itertools import islice
import os
from pathlib import Path
import shutil
import stat
import threading
import uuid
import zipfile
from .aircraft_carrier_study import make_plan
from .aircraft_carrier_study_store import MAX_INPUT_BYTES, StudyArchive, _bytes, run_study

MAX_STUDIES = 8
MAX_DIRECTORY_ENTRIES = 64


class CarrierStudyCatalog:
    def __init__(self, root, execution_lock):
        self.root = Path(root).absolute()
        self.root.mkdir(parents=True, exist_ok=True)
        if self.root.is_symlink() or not self.root.is_dir():
            raise ValueError('Carrier study root must be a real directory')
        root_stat = self.root.stat()
        self._root_identity = (root_stat.st_dev, root_stat.st_ino)
        self._execution = execution_lock
        self._lock = threading.RLock()
        self._jobs = {}
        self._unavailable = []
        with os.scandir(self.root) as entries:
            directories = list(islice(entries, MAX_DIRECTORY_ENTRIES + 1))
        if len(directories) > MAX_DIRECTORY_ENTRIES:
            raise ValueError('Carrier study directory scan limit exceeded; choose a smaller catalog')
        for entry in sorted(directories, key=lambda value: value.name):
            try:
                identifier = entry.name
                if str(uuid.UUID(identifier)) != identifier:
                    raise ValueError('Study directory name must be a canonical UUID')
                if entry.is_symlink() or not entry.is_dir(follow_symlinks=False):
                    raise ValueError('Study directory must be a real directory')
                if len(self._jobs) >= MAX_STUDIES:
                    raise ValueError('Loaded study capacity reached')
                archive = StudyArchive(entry.path)
                overview = archive.overview()
                phase = 'unmanaged' if overview['state'] in ('prepared', 'running') else overview['state']
                self._jobs[identifier] = dict(path=Path(entry.path), phase=phase,
                    overview=overview, name=archive.specification()['name'], error=None,
                    thread=None, cancel=None, planned_count=len(overview['samples']))
            except (ValueError, TypeError, KeyError, OSError) as error:
                self._unavailable.append(dict(name=entry.name, error=str(error)))

    def _snapshot(self, identifier, job):
        active = job['thread'] is not None and job['thread'].is_alive()
        return deepcopy(dict(id=identifier, name=job['name'], phase=job['phase'],
            active=active, cancellable=active and job['phase'] in ('preparing', 'running'),
            cancel_requested=job['cancel'] is not None and job['cancel'].is_set(),
            error=job['error'], planned_count=job['planned_count'], overview=job['overview']))

    def listing(self):
        with self._lock:
            rows = []
            for identifier, job in self._jobs.items():
                row = self._snapshot(identifier, job)
                overview = row.pop('overview')
                row['summary'] = overview['summary'] if overview else None
                rows.append(row)
            return dict(studies=rows, unavailable=deepcopy(self._unavailable),
                limits=dict(max_studies=MAX_STUDIES), busy=self._execution.locked())

    def snapshot(self, identifier):
        with self._lock:
            return self._snapshot(identifier, self._jobs[identifier])

    def start(self, spec):
        spec = deepcopy(spec)
        if len(_bytes(spec)) > MAX_INPUT_BYTES:
            raise ValueError('Study specification exceeds 128 KiB')
        # Validate before admission; this constructs inputs but does not integrate cases.
        plan = make_plan(spec)
        if not self._execution.acquire(blocking=False):
            raise RuntimeError('An aircraft analysis is already running')
        identifier = str(uuid.uuid4())
        try:
            with self._lock:
                if len(self._jobs) + len(self._unavailable) >= MAX_STUDIES:
                    raise RuntimeError('Study capacity reached; choose a fresh carrier study directory')
                job = dict(path=self.root / identifier, phase='preparing', name=spec['name'],
                    error=None, overview=None, thread=None, cancel=threading.Event(),
                    planned_count=len(plan['samples']))
                worker = threading.Thread(target=self._run, args=(identifier, spec),
                    name='carrier-study-' + identifier, daemon=True)
                job['thread'] = worker
                self._jobs[identifier] = job
                try:
                    worker.start()
                except Exception:
                    del self._jobs[identifier]
                    raise
                return self._snapshot(identifier, job)
        except Exception:
            self._execution.release()
            raise

    def _run(self, identifier, spec):
        with self._lock:
            job = self._jobs[identifier]
        def progress(index):
            with self._lock:
                job.update(overview=deepcopy(index), phase='running')
        try:
            run_study(spec, job['path'], cancel=job['cancel'], progress=progress)
            with self._lock:
                job['phase'] = 'verifying'
            verified = StudyArchive(job['path']).overview()
            with self._lock:
                job.update(overview=verified, phase=verified['state'], error=verified['error'])
        except Exception as error:
            with self._lock:
                job.update(phase='failed', error=type(error).__name__ + ': ' + str(error))
            # A failed write may leave a useful archive. Never invent a terminal disk state.
            try:
                verified = StudyArchive(job['path']).overview()
                with self._lock:
                    job['overview'] = verified
            except (ValueError, TypeError, KeyError, OSError):
                pass
        finally:
            self._execution.release()

    def cancel(self, identifier):
        with self._lock:
            job = self._jobs[identifier]
            if not self._snapshot(identifier, job)['cancellable']:
                raise RuntimeError('No managed running study to cancel')
            job['cancel'].set()
            return self._snapshot(identifier, job)

    def delete(self, identifier, confirmation):
        """Remove one inactive registered archive, never a caller-supplied path."""
        if not isinstance(identifier, str) or str(uuid.UUID(identifier)) != identifier:
            raise ValueError('A canonical study UUID is required')
        if confirmation != identifier:
            raise ValueError('Confirmation must identify the selected study')
        with self._lock:
            job = self._jobs[identifier]
            if job['thread'] is not None and job['thread'].is_alive():
                raise RuntimeError('Wait for the study to finish or cancel after the current case before deleting')
            if not shutil.rmtree.avoids_symlink_attacks:
                raise RuntimeError('Safe archive deletion is unavailable on this platform')
            # Pin the trusted root. rmtree's fd-based traversal does not follow
            # symlinks within the archive, or a replaced top-level symlink.
            root_fd = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                current_root = os.fstat(root_fd)
                if (current_root.st_dev, current_root.st_ino) != self._root_identity:
                    raise RuntimeError('Study root changed; reload the catalog before deleting')
                try:
                    child = os.stat(identifier, dir_fd=root_fd, follow_symlinks=False)
                except FileNotFoundError:
                    # A job may fail before creating its archive. The root was
                    # verified above; this registered entry has no files to delete.
                    child = None
                if child is not None:
                    if not stat.S_ISDIR(child.st_mode):
                        raise ValueError('Selected archive must be a real directory, not a symlink')
                    shutil.rmtree(identifier, dir_fd=root_fd)
            finally:
                os.close(root_fd)
            # A failed filesystem operation leaves the entry available for retry.
            del self._jobs[identifier]
            return dict(deleted=identifier)

    def _archive(self, identifier, *, frozen=False):
        with self._lock:
            job = self._jobs[identifier]
            if frozen and job['thread'] is not None and job['thread'].is_alive():
                raise RuntimeError('Wait for study execution and archive verification before downloading')
            if job['overview'] is None:
                raise RuntimeError('Study archive is not available yet')
            path = job['path']
        return StudyArchive(path)

    def sample(self, identifier, sample_id):
        with self._lock:
            return self._archive(identifier).sample(sample_id)

    def artifact(self, identifier, name):
        with self._lock:
            return self._archive(identifier).artifact(name)

    def bundle(self, identifier):
        with self._lock:
            return self._bundle(identifier)

    def _bundle(self, identifier):
        archive = self._archive(identifier, frozen=True)
        names = ['index.json', 'spec.json']
        for row in archive.overview()['samples']:
            names.append(row['input_artifact']['name'])
            if row['report_artifact'] is not None:
                names.append(row['report_artifact']['name'])
        output = BytesIO()
        with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as bundle:
            for name in names:
                bundle.writestr(name, archive.artifact(name))
        return output.getvalue()
