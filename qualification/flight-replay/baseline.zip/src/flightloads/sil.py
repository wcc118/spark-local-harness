"""Integer-clock, held-load SIL reference using the accepted rigid-body solver."""
from collections import deque
from dataclasses import dataclass, asdict
import math
from types import MappingProxyType
import numpy as np
from .dynamics import rigid_derivative
from .integration import integrate
from .loads import AppliedLoads
from .mass import MassModel
from .recovery import CutDefinition, recover_balance, recover_section
from .state import RigidState
from .sil_controller import Command, ControllerState, Measurement


@dataclass(frozen=True)
class SILConfig:
    case: str = 'nominal'
    dt_s: float = .002
    steps: int = 6000
    sensor_ticks: int = 5
    controller_ticks: int = 10
    delay_ticks: int = 0
    command_tick: int = 100
    command_rad: float = .1
    torque_limit_Nm: float = 10.
    slew_Nmps: float = 10000.

    def __post_init__(self):
        if self.case not in ('nominal', 'delayed', 'limited', 'verification'):
            raise ValueError('unknown reference case')
        for key in ('steps', 'sensor_ticks', 'controller_ticks', 'delay_ticks', 'command_tick'):
            value = getattr(self, key)
            if type(value) is not int or value < (0 if key in ('delay_ticks', 'command_tick') else 1) or value > 100000:
                raise ValueError(f'invalid integer clock {key}')
        for key in ('dt_s', 'command_rad', 'torque_limit_Nm', 'slew_Nmps'):
            value = getattr(self, key)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f'invalid finite scalar {key}')
        if not (1e-6 <= self.dt_s <= .05 and self.steps*self.dt_s <= 30
                and abs(self.command_rad) <= .2 and 0 < self.torque_limit_Nm <= 10
                and 0 < self.slew_Nmps <= 10000 and self.command_tick <= self.steps and self.steps+self.delay_ticks <= 100000):
            raise ValueError('configuration outside manufactured reference bounds')

    def to_dict(self):
        return asdict(self)


CASES = (SILConfig(), SILConfig(case='delayed', delay_ticks=30),
         SILConfig(case='limited', delay_ticks=30, torque_limit_Nm=.4, slew_Nmps=1.))

# Mixed state is split so every archived field has one physical unit.
UNITS = dict(tick='tick', time_s='s', position_N_m='m', velocity_B_mps='m/s',
    quaternion_NB='1', omega_B_radps='rad/s', yaw_rad='rad', command_rad='rad',
    capture_event='boolean', captured_yaw_rad='rad', captured_rate_radps='rad/s',
    scheduled_release_tick='tick', release_event='boolean', measurement_capture_tick='tick',
    measurement_release_tick='tick', measurement_age_s='s', measured_yaw_rad='rad',
    measured_rate_radps='rad/s', controller_event='boolean', controller_elapsed_s='s',
    integral_rad_s='rad s', previous_error_rad='rad', unlimited_torque_Nm='N m',
    actuator_torque_Nm='N m', saturation_event='boolean', slew_event='boolean',
    section_force_B_N='N', section_moment_B_Nm='N m', force_residual_B_N='N',
    moment_residual_B_Nm='N m', force_limit_N='N', moment_limit_Nm='N m')
INTEGER_FIELDS = {k for k, u in UNITS.items() if u in ('tick', 'boolean')}
VECTOR_FIELDS = {'position_N_m': 3, 'velocity_B_mps': 3, 'quaternion_NB': 4,
                 'omega_B_radps': 3, 'section_force_B_N': 3, 'section_moment_B_Nm': 3,
                 'force_residual_B_N': 3, 'moment_residual_B_Nm': 3}


@dataclass(frozen=True)
class SILHistory:
    config: SILConfig
    arrays: object

    def __post_init__(self):
        if not isinstance(self.config, SILConfig) or set(self.arrays) != set(UNITS):
            raise ValueError('SIL config and exact history fields required')
        saved = {}
        for key, value in self.arrays.items():
            array = np.asarray(value)
            shape = (self.config.steps+1,) + ((VECTOR_FIELDS[key],) if key in VECTOR_FIELDS else ())
            if array.shape != shape or array.dtype.kind not in 'fiu' or not np.all(np.isfinite(array)):
                raise ValueError(f'invalid history array {key}')
            if key in INTEGER_FIELDS and (np.any(array != np.floor(array))
                    or np.any(abs(array) > 100001)):
                raise ValueError(f'invalid clock/event array {key}')
            dtype = np.int64 if key in INTEGER_FIELDS else np.float64
            saved[key] = np.frombuffer(np.asarray(array, dtype=dtype).tobytes(), dtype=dtype).reshape(shape)
        object.__setattr__(self, 'arrays', MappingProxyType(saved))


def reference_mass():
    return MassModel([1, 1, 1, 1], [[1, 1, 0], [1, -1, 0], [-1, 1, 0], [-1, -1, 0]])


def run_sil(config, controller):
    if not isinstance(config, SILConfig) or not callable(getattr(controller, 'step', None)):
        raise TypeError('SILConfig and explicit controller adapter required')
    n = config.steps + 1
    a = {key: np.zeros((n,) + ((VECTOR_FIELDS[key],) if key in VECTOR_FIELDS else ()),
                      dtype=np.int64 if key in INTEGER_FIELDS else float) for key in UNITS}
    a['tick'][:] = np.arange(n)
    a['time_s'][:] = a['tick'] * config.dt_s
    state = RigidState([0, 0, 0], [0, 0, 0], [1, 0, 0, 0], [0, 0, 0])
    mass = reference_mass()
    cut = CutDefinition('x-half', [.5, 0, 0], [1, 0, 0])
    control_state = ControllerState()
    measured = Measurement(0., 0.)
    # Explicit at-rest prehistory, available at tick zero.
    measured_capture, measured_release = -config.delay_ticks, 0
    pending = deque()
    previous_controller_tick = 0
    unlimited, actuator = 0., 0.
    for k, time in enumerate(a['time_s']):
        yaw = float(2*np.arctan2(state.q_NB[3], state.q_NB[0]))
        if abs(yaw) >= 1.:
            raise RuntimeError('reference left declared |yaw| < 1 rad branch')
        rate = float(state.omega_B_radps[2])
        command = Command(config.command_rad if k >= config.command_tick else 0.)
        capture = k % config.sensor_ticks == 0
        if capture:
            pending.append((k+config.delay_ticks, k, Measurement(yaw, rate)))
            a['captured_yaw_rad'][k], a['captured_rate_radps'][k] = yaw, rate
            a['scheduled_release_tick'][k] = k+config.delay_ticks
        released = False
        while pending and pending[0][0] <= k:
            measured_release, measured_capture, measured = pending.popleft()
            released = True
        update = k % config.controller_ticks == 0
        elapsed = 0.
        if update:
            elapsed = (k-previous_controller_tick)*config.dt_s
            output = controller.step(measured, command, control_state, elapsed)
            control_state, unlimited = output.state, output.torque_Nm
            previous_controller_tick = k
        clipped = max(-config.torque_limit_Nm, min(config.torque_limit_Nm, unlimited))
        bound = config.slew_Nmps*config.dt_s
        next_actuator = max(actuator-bound, min(actuator+bound, clipped))
        a['saturation_event'][k] = clipped != unlimited
        a['slew_event'][k] = next_actuator != clipped
        actuator = next_actuator
        loads = AppliedLoads([[0, 0, 0]], [[0, 0, 0]], [[0, 0, actuator]], ('CG-actuator',))
        derivative = rigid_derivative(state, mass, loads, [0, 0, 0])
        field = recover_balance(state, derivative, mass, loads, [0, 0, 0])
        section = recover_section(field, cut, time_s=time)
        values = dict(position_N_m=state.r_CG_N_m, velocity_B_mps=state.v_CG_B_mps,
            quaternion_NB=state.q_NB, omega_B_radps=state.omega_B_radps, yaw_rad=yaw,
            command_rad=command.yaw_rad, capture_event=capture, release_event=released,
            measurement_capture_tick=measured_capture, measurement_release_tick=measured_release,
            measurement_age_s=(k-measured_capture)*config.dt_s,
            measured_yaw_rad=measured.yaw_rad, measured_rate_radps=measured.rate_radps,
            controller_event=update, controller_elapsed_s=elapsed,
            integral_rad_s=control_state.integral_rad_s, previous_error_rad=control_state.previous_error_rad,
            unlimited_torque_Nm=unlimited, actuator_torque_Nm=actuator,
            section_force_B_N=section.force_on_retained_B_N,
            section_moment_B_Nm=section.moment_on_retained_B_Nm,
            force_residual_B_N=field.force_residual_B_N,
            moment_residual_B_Nm=field.moment_residual_B_Nm,
            force_limit_N=field.force_limit_N, moment_limit_Nm=field.moment_limit_Nm)
        for key, value in values.items():
            a[key][k] = value
        if k < config.steps:
            end = a['time_s'][k+1]
            result = integrate(state, mass, end, end-time,
                lambda t, s, context: loads, lambda t, r, context: [0, 0, 0],
                t0=time, max_steps=1)
            state = result.state_at(1)
    return SILHistory(config, a)
