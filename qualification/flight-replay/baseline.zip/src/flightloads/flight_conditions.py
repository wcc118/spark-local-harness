"""Concurrent CG flight conditions from a production plant evaluation (SI state, imperial ledger)."""
import math
import numpy as np


def flight_condition(plant, state, field, derivative):
    """Independent F=ma check, not the identically balanced d'Alembert residual.

    Body n_z is upward specific force divided by standard gravity. Vertical
    support uses NED and is 1 in steady level flight even at nonzero pitch.
    """
    from .conventions import rotation_matrix
    from .aircraft_transient import G_N
    from .station_loads import _row_component
    R = rotation_matrix(state.q_NB)
    weight = plant.mass_properties['weight_lbf']
    force = np.sum([row['force_B_lbf'] for row in field['ledger']], axis=0)
    acceleration = derivative.vdot_B_mps2 + np.cross(state.omega_B_radps, state.v_CG_B_mps)
    accel_N_g = R @ acceleration / float(np.linalg.norm(G_N))
    force_N = R @ force
    groups = {}
    for row in field['ledger']:
        key = _row_component(dict(kind='applied', name=row['name']))
        groups[key] = groups.get(key, np.zeros(3)) + np.asarray(row['force_B_lbf'])
    height = -float(state.r_CG_N_m[2]) / .3048
    atmosphere = plant.inputs['field_case'].get('atmosphere')
    air = np.asarray(field['velocity_air_B_ft_s'])
    speed = float(np.linalg.norm(air))
    air_N = R @ air
    return dict(weight_lbf=weight, height_agl_ft=height,
        altitude_msl_ft=None if atmosphere is None else atmosphere['field_elevation_ft'] + height,
        airspeed_ft_s=speed, pitch_deg=math.degrees(math.asin(float(np.clip(-R[2, 0], -1, 1)))),
        flight_path_deg=None if speed <= 1e-12 else math.degrees(math.atan2(-air_N[2], math.hypot(*air_N[:2]))),
        body_rate_deg_s=np.degrees(state.omega_B_radps).tolist(), acceleration_N_g=accel_N_g.tolist(),
        normal_load_factor=-float(force[2])/weight, vertical_support_factor=-float(force_N[2])/weight,
        non_gravity_force_B_lbf=force.tolist(), non_gravity_force_N_lbf=force_N.tolist(),
        vertical_force_balance_residual_lbf=float(force_N[2]+weight-weight*accel_N_g[2]),
        source_upward_lbf={key: -float((R @ value)[2]) for key, value in groups.items()},
        definition='n_z = -F_non_gravity_Bz / W; vertical support = -F_non_gravity_Ndown / W. '
                   'F_non_gravity_Ndown + W = (W/g0) * a_Ndown. Dynamic balance does not imply steady 1 g flight.')
