"""Versioned aero dataset interface: the only way aerodynamics enters the plant.

Interface units are imperial: ft/s, in, lbf, in-lbf, slug/ft^3, degrees. Vectors
are in the repository body frame (x forward, y right, z down). Every result keeps
located component loads (never inferred from six totals), a per-load source tag
and the weakest contributing evidence level. See docs/mechanics/AERO_DATASET.md.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass, field, replace
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
from typing import Mapping, Protocol, Sequence

import numpy as np

SCHEMA_VERSION = 1
EVIDENCE_LEVELS = ('estimate', 'cfd', 'cfd-validated')
AXES = ('alpha_deg', 'beta_deg', 'mach', 'left_tail_deg', 'right_tail_deg', 'aileron_deg')
CONTROL_KEYS = ('left_tail_deg', 'right_tail_deg', 'aileron_deg')
COEFFICIENTS = ('CX', 'CY', 'CZ', 'Cl', 'Cm', 'Cn')
RATES = ('p_hat', 'q_hat', 'r_hat')
ZERO_SPEED_FT_S = 1e-6


def _vector(value, name):
    array = np.asarray(value, dtype=float)
    if array.shape != (3,) or not np.all(np.isfinite(array)):
        raise ValueError(f'{name} requires three finite components')
    return tuple(float(x) for x in array)


def weakest_evidence(levels):
    levels = list(levels)
    for level in levels:
        if level not in EVIDENCE_LEVELS:
            raise ValueError(f'unknown evidence level: {level!r}')
    if not levels:
        raise ValueError('at least one evidence level is required')
    return min(levels, key=EVIDENCE_LEVELS.index)


@dataclass(frozen=True)
class AeroQuery:
    velocity_air_B_ft_s: tuple
    omega_B_rad_s: tuple
    reference_point_B_in: tuple
    controls_deg: Mapping[str, float]
    density_slug_ft3: float
    sound_speed_ft_s: float
    viscosity_slug_ft_s: float = 3.737e-7

    def __post_init__(self):
        object.__setattr__(self, 'velocity_air_B_ft_s', _vector(self.velocity_air_B_ft_s, 'velocity_air_B_ft_s'))
        object.__setattr__(self, 'omega_B_rad_s', _vector(self.omega_B_rad_s, 'omega_B_rad_s'))
        object.__setattr__(self, 'reference_point_B_in', _vector(self.reference_point_B_in, 'reference_point_B_in'))
        if set(self.controls_deg) != set(CONTROL_KEYS):
            raise ValueError(f'controls_deg requires exactly {CONTROL_KEYS}')
        controls = {k: float(self.controls_deg[k]) for k in CONTROL_KEYS}
        if not all(math.isfinite(v) for v in controls.values()):
            raise ValueError('controls must be finite')
        object.__setattr__(self, 'controls_deg', controls)
        for name in ('density_slug_ft3', 'sound_speed_ft_s', 'viscosity_slug_ft_s'):
            value = float(getattr(self, name))
            # Zero density (vacuum) is valid and gives zero aerodynamic load.
            if not math.isfinite(value) or value < 0 or (value == 0 and name != 'density_slug_ft3'):
                raise ValueError(f'{name} must be finite and positive (density may be zero)')
            object.__setattr__(self, name, value)


def flow_state(query, span_in, chord_in):
    """Speed, flow angles, Mach, dynamic pressure and nondimensional rates.

    alpha = atan2(w, u); beta = asin(v / V); q_dyn = 0.5*rho*V^2 (lbf/ft^2);
    p_hat = p*b/(2V), q_hat = q*c/(2V), r_hat = r*b/(2V) with b, c in ft.
    Returns None below ZERO_SPEED_FT_S, where the angles are undefined.
    """
    u, v, w = query.velocity_air_B_ft_s
    speed = math.sqrt(u*u + v*v + w*w)
    if speed < ZERO_SPEED_FT_S:
        return None
    p, q, r = query.omega_B_rad_s
    b_ft, c_ft = span_in/12, chord_in/12
    return dict(speed_ft_s=speed, alpha_deg=math.degrees(math.atan2(w, u)),
                beta_deg=math.degrees(math.asin(max(-1.0, min(1.0, v/speed)))),
                mach=speed/query.sound_speed_ft_s, dynamic_pressure_lbf_ft2=0.5*query.density_slug_ft3*speed**2,
                p_hat=p*b_ft/(2*speed), q_hat=q*c_ft/(2*speed), r_hat=r*b_ft/(2*speed))


@dataclass(frozen=True)
class LocatedLoad:
    component: str
    position_B_in: tuple
    force_B_lbf: tuple
    couple_B_in_lbf: tuple
    source: str
    evidence_level: str
    element: str = ''            # originating element (e.g. strip name) for traceability; '' for tables

    def __post_init__(self):
        for name in ('position_B_in', 'force_B_lbf', 'couple_B_in_lbf'):
            object.__setattr__(self, name, _vector(getattr(self, name), name))
        weakest_evidence([self.evidence_level])


@dataclass(frozen=True)
class AeroResult:
    force_B_lbf: tuple
    moment_B_in_lbf: tuple
    reference_point_B_in: tuple
    loads: tuple
    evidence_level: str
    in_coverage: bool
    coverage_violations: tuple
    provider_id: str
    dataset_digest: str


def assemble(loads, reference_point_B_in, *, provider_id, dataset_digest, violations=(), evidence_level=None):
    """Sum located loads: F = sum(F_i); M_ref = sum((r_i - r_ref) x F_i + C_i)."""
    ref = np.array(_vector(reference_point_B_in, 'reference_point_B_in'))
    force, moment = np.zeros(3), np.zeros(3)
    for load in loads:
        f = np.array(load.force_B_lbf)
        force += f
        moment += np.cross(np.array(load.position_B_in) - ref, f) + np.array(load.couple_B_in_lbf)
    level = evidence_level or (weakest_evidence(l.evidence_level for l in loads) if loads else 'estimate')
    return AeroResult(tuple(force.tolist()), tuple(moment.tolist()), tuple(ref.tolist()), tuple(loads), level,
                      not violations, tuple(violations), provider_id, dataset_digest)


class Provider(Protocol):
    identity: Mapping[str, str]

    def evaluate(self, query: AeroQuery) -> AeroResult: ...


@dataclass(frozen=True)
class GridAxis:
    name: str
    values: tuple
    singleton_tolerance: float = 0.0

    def __post_init__(self):
        if self.name not in AXES:
            raise ValueError(f'unknown axis {self.name!r}')
        values = tuple(float(v) for v in self.values)
        if not values or not all(math.isfinite(v) for v in values) or any(b <= a for a, b in zip(values, values[1:])):
            raise ValueError(f'axis {self.name} requires finite strictly increasing values')
        tolerance = float(self.singleton_tolerance)
        if not math.isfinite(tolerance) or tolerance < 0 or (tolerance and len(values) != 1):
            raise ValueError(f'axis {self.name}: singleton_tolerance applies only to single-value axes')
        object.__setattr__(self, 'values', values)
        object.__setattr__(self, 'singleton_tolerance', tolerance)

    def locate(self, x):
        """Return (lower index, weight, violation or None); never extrapolates."""
        v = self.values
        if not math.isfinite(x):
            raise ValueError('finite grid coordinate required')
        # atan2/speed reconstruction can place an exact input knot a few ULPs outside.
        # Snap only machine-roundoff neighbors, not a physical extrapolation margin.
        for endpoint in (v[0], v[-1]):
            if abs(x-endpoint) <= 8*max(math.ulp(x), math.ulp(endpoint)):
                x = endpoint
                break
        if len(v) == 1:
            if abs(x - v[0]) <= self.singleton_tolerance:
                return 0, 0.0, None
            return 0, 0.0, f'{self.name}={x:.6g} outside [{v[0]:.6g} +/- {self.singleton_tolerance:.6g}]'
        if x < v[0] or x > v[-1]:
            clamped = v[0] if x < v[0] else v[-1]
            i = 0 if x < v[0] else len(v) - 2
            return i, 0.0 if x < v[0] else 1.0, f'{self.name}={x:.6g} outside [{v[0]:.6g}, {v[-1]:.6g}] (nearest {clamped:.6g})'
        i = min(int(np.searchsorted(v, x, side='right')) - 1, len(v) - 2)
        return i, (x - v[i]) / (v[i + 1] - v[i]), None


def _interpolate(table, located):
    """Multilinear interpolation over the leading axes of table."""
    result = 0.0
    for corner in itertools.product((0, 1), repeat=len(located)):
        weight, index = 1.0, []
        for bit, (i, t, size) in zip(corner, located):
            if size == 1:
                if bit:
                    weight = 0.0
                    break
                index.append(0)
                continue
            weight *= t if bit else 1 - t
            index.append(i + bit)
        if weight:
            result = result + weight*table[tuple(index)]
    return result


@dataclass(frozen=True)
class ComponentTable:
    """Body-axis coefficients about the component reference point.

    coefficients: shape [len(axis) for axis in axes] + [6] for CX,CY,CZ,Cl,Cm,Cn.
    rate_derivatives (optional): shape [alpha, beta, mach] + [6, 3], d(coef)/d(p_hat, q_hat, r_hat).
    """
    component: str
    reference_point_B_in: tuple
    coefficients: np.ndarray
    rate_derivatives: np.ndarray | None = None
    source: str = 'table'


@dataclass(frozen=True)
class TabulatedDataset:
    dataset_id: str
    evidence_level: str
    source: Mapping[str, str]
    reference_area_in2: float
    reference_span_in: float
    reference_chord_in: float
    axes: tuple
    components: tuple
    validation_reference: str | None = None
    notes: str = ''
    digest: str = field(init=False)

    def __post_init__(self):
        weakest_evidence([self.evidence_level])
        if self.evidence_level == 'cfd-validated' and not self.validation_reference:
            raise ValueError('cfd-validated datasets require a validation_reference')
        names = [a.name for a in self.axes]
        if names != list(AXES):
            raise ValueError(f'axes must be exactly {AXES} in order')
        for name in ('reference_area_in2', 'reference_span_in', 'reference_chord_in'):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f'{name} must be positive')
            object.__setattr__(self, name, value)
        shape = tuple(len(a.values) for a in self.axes)
        seen = set()
        for table in self.components:
            if table.component in seen:
                raise ValueError(f'duplicate component {table.component!r}')
            seen.add(table.component)
            _vector(table.reference_point_B_in, 'reference_point_B_in')
            coefficients = np.asarray(table.coefficients, dtype=float)
            if coefficients.shape != shape + (6,) or not np.all(np.isfinite(coefficients)):
                raise ValueError(f'{table.component}: coefficients must be finite with shape {shape + (6,)}')
            if table.rate_derivatives is not None:
                rates = np.asarray(table.rate_derivatives, dtype=float)
                if rates.shape != shape[:3] + (6, 3) or not np.all(np.isfinite(rates)):
                    raise ValueError(f'{table.component}: rate derivatives must have shape {shape[:3] + (6, 3)}')
        if not self.components:
            raise ValueError('at least one component table is required')
        atmosphere = self.source.get('reference_atmosphere_json')
        if atmosphere is not None:
            values = json.loads(atmosphere)
            if set(values) != {'density_slug_ft3', 'sound_speed_ft_s', 'viscosity_slug_ft_s'} or any(
                    type(v) not in (int, float) or not math.isfinite(v) or v <= 0 for v in values.values()):
                raise ValueError('reference atmosphere requires positive finite density, sound speed and viscosity')
        velocity_reference = self.source.get('velocity_reference_point_B_in_json')
        object.__setattr__(self, '_velocity_reference', None if velocity_reference is None else _vector(json.loads(velocity_reference), 'velocity reference'))
        cell_sources = {}
        if 'cell_sources_json' in self.source:
            tags = json.loads(self.source['cell_sources_json'])
            if set(tags) != seen:
                raise ValueError('cell source components must match coefficient components')
            for component, entries in tags.items():
                array = np.asarray(entries, dtype=object)
                if array.shape != shape or any(not isinstance(x, str) or not x or len(x) > 256 for x in array.flat):
                    raise ValueError('cell source tags require one short nonempty string per grid cell')
                cell_sources[component] = array
        object.__setattr__(self, '_cell_sources', cell_sources)
        object.__setattr__(self, 'digest', _digest(self))

    @property
    def identity(self):
        return {'id': self.dataset_id, 'digest': self.digest, 'evidence_level': self.evidence_level,
                'schema_version': str(SCHEMA_VERSION)}

    def evaluate(self, query, *, allow_clamp=False):
        if 'reference_atmosphere_json' in self.source:
            atmosphere = json.loads(self.source['reference_atmosphere_json'])
            if any(not math.isclose(getattr(query, k), v, rel_tol=1e-10, abs_tol=0.) for k, v in atmosphere.items()):
                return assemble([], query.reference_point_B_in, provider_id=self.dataset_id, dataset_digest=self.digest,
                                violations=('query atmosphere differs from fixed Reynolds/Mach reference atmosphere',),
                                evidence_level=self.evidence_level)
        flow_query = query
        if self._velocity_reference is not None:
            velocity = np.asarray(query.velocity_air_B_ft_s)+np.cross(query.omega_B_rad_s,
                (np.asarray(self._velocity_reference)-query.reference_point_B_in)/12)
            flow_query = replace(query, velocity_air_B_ft_s=tuple(velocity))
        flow = flow_state(flow_query, self.reference_span_in, self.reference_chord_in)
        if flow is None:
            return assemble([], query.reference_point_B_in, provider_id=self.dataset_id, dataset_digest=self.digest,
                            violations=('speed below 1e-6 ft/s: flow angles undefined; zero aerodynamic load',),
                            evidence_level=self.evidence_level)
        values = dict(alpha_deg=flow['alpha_deg'], beta_deg=flow['beta_deg'], mach=flow['mach'], **query.controls_deg)
        located, violations = [], []
        for axis in self.axes:
            i, t, violation = axis.locate(values[axis.name])
            located.append((i, t, len(axis.values)))
            if violation:
                violations.append(violation)
        tag = '' if not violations else '-clamped'
        if violations and not allow_clamp:
            return assemble([], query.reference_point_B_in, provider_id=self.dataset_id, dataset_digest=self.digest,
                            violations=tuple(violations), evidence_level=self.evidence_level)
        qS = flow['dynamic_pressure_lbf_ft2'] * self.reference_area_in2 / 144.0
        rates = np.array([flow['p_hat'], flow['q_hat'], flow['r_hat']])
        loads = []
        for table in self.components:
            c = np.asarray(_interpolate(np.asarray(table.coefficients, dtype=float), located), dtype=float)
            if table.rate_derivatives is not None:
                c = c + np.asarray(_interpolate(np.asarray(table.rate_derivatives, dtype=float), located[:3])) @ rates
            force = qS * c[:3]
            couple = qS * np.array([c[3]*self.reference_span_in, c[4]*self.reference_chord_in, c[5]*self.reference_span_in])
            source = table.source
            if table.component in self._cell_sources:
                corners = [(0,) if size == 1 else ((i,) if t == 0 else (i+1,) if t == 1 else (i, i+1))
                           for i, t, size in located]
                contributing = {part for index in itertools.product(*corners)
                                for part in self._cell_sources[table.component][index].split('+')}
                source = '+'.join(sorted(contributing))
            loads.append(LocatedLoad(table.component, table.reference_point_B_in, force, couple,
                                     source + tag, self.evidence_level, table.component))
        return assemble(loads, query.reference_point_B_in, provider_id=self.dataset_id, dataset_digest=self.digest,
                        violations=tuple(violations))

    def save(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=False)
        (directory / 'dataset.json').write_text(json.dumps(_metadata(self), indent=2, sort_keys=True) + '\n')
        arrays = {}
        for table in self.components:
            arrays[f'{table.component}/coefficients'] = np.asarray(table.coefficients, dtype='<f8')
            if table.rate_derivatives is not None:
                arrays[f'{table.component}/rate_derivatives'] = np.asarray(table.rate_derivatives, dtype='<f8')
        np.savez(directory / 'arrays.npz', **arrays)
        return directory

    @classmethod
    def load(cls, directory):
        directory = Path(directory)
        meta = json.loads((directory / 'dataset.json').read_text())
        if meta.get('schema_version') != SCHEMA_VERSION:
            raise ValueError('unsupported dataset schema_version')
        with np.load(directory / 'arrays.npz') as arrays:
            components = tuple(ComponentTable(
                c['component'], tuple(c['reference_point_B_in']), arrays[f"{c['component']}/coefficients"].copy(),
                arrays[f"{c['component']}/rate_derivatives"].copy() if c['has_rate_derivatives'] else None,
                c['source']) for c in meta['components'])
        dataset = cls(meta['dataset_id'], meta['evidence_level'], meta['source'], meta['reference_area_in2'],
                      meta['reference_span_in'], meta['reference_chord_in'],
                      tuple(GridAxis(a['name'], tuple(a['values']), a['singleton_tolerance']) for a in meta['axes']),
                      components, meta.get('validation_reference'), meta.get('notes', ''))
        if dataset.digest != meta['digest']:
            raise ValueError('dataset digest mismatch: files were modified')
        return dataset


def _metadata(dataset, *, with_digest=True):
    meta = dict(schema_version=SCHEMA_VERSION, dataset_id=dataset.dataset_id, evidence_level=dataset.evidence_level,
                source=dict(dataset.source), reference_area_in2=dataset.reference_area_in2,
                reference_span_in=dataset.reference_span_in, reference_chord_in=dataset.reference_chord_in,
                axes=[dict(name=a.name, values=list(a.values), singleton_tolerance=a.singleton_tolerance) for a in dataset.axes],
                components=[dict(component=t.component, reference_point_B_in=list(t.reference_point_B_in),
                                 has_rate_derivatives=t.rate_derivatives is not None, source=t.source)
                            for t in dataset.components],
                validation_reference=dataset.validation_reference, notes=dataset.notes,
                units=dict(force='lbf', length='in', moment='in-lbf', angle='deg', frame='body x forward, y right, z down',
                           coefficients='body-axis CX,CY,CZ; Cl,Cm,Cn about component reference point; '
                                        'moments use span (Cl, Cn) and chord (Cm)'))
    if with_digest:
        meta['digest'] = dataset.digest
    return meta


def _digest(dataset):
    h = hashlib.sha256(json.dumps(_metadata(dataset, with_digest=False), sort_keys=True, separators=(',', ':')).encode())
    for table in dataset.components:
        h.update(np.ascontiguousarray(table.coefficients, dtype='<f8').tobytes())
        if table.rate_derivatives is not None:
            h.update(np.ascontiguousarray(table.rate_derivatives, dtype='<f8').tobytes())
    return h.hexdigest()


FLIGHTSTREAM_COLUMNS = ('component', *AXES, *COEFFICIENTS)


def read_flightstream_csv(path_or_text, dataset_id):
    """Import a FlightStream export in the documented CSV layout (schema slot; see AERO_DATASET.md).

    Header comments: '# key: value' for reference_area_in2, reference_span_in,
    reference_chord_in, evidence_level (cfd or cfd-validated), validation_reference,
    source, and 'ref.<component>: x y z' component reference points (body inches).
    Rows must form a complete grid for every component; missing cells are named.
    """
    text = Path(path_or_text).read_text() if isinstance(path_or_text, Path) else str(path_or_text)
    header, body = {}, []
    for line in text.splitlines():
        if line.startswith('#'):
            key, _, value = line[1:].partition(':')
            header[key.strip()] = value.strip()
        elif line.strip():
            body.append(line)
    rows = list(csv.DictReader(io.StringIO('\n'.join(body))))
    if not rows or tuple(rows[0].keys()) != FLIGHTSTREAM_COLUMNS:
        raise ValueError(f'FlightStream CSV requires columns {FLIGHTSTREAM_COLUMNS}')
    evidence = header.get('evidence_level', 'cfd')
    if evidence not in ('cfd', 'cfd-validated'):
        raise ValueError('FlightStream imports carry evidence_level cfd or cfd-validated')
    axis_values = {name: sorted({float(r[name]) for r in rows}) for name in AXES}
    axes = tuple(GridAxis(name, tuple(axis_values[name])) for name in AXES)
    shape = tuple(len(axis_values[name]) for name in AXES)
    required = math.prod(shape)*len({r['component'] for r in rows})
    if required > len(rows):
        raise ValueError(f'missing grid cells: complete component grids require {required} rows, got {len(rows)}')
    index = {name: {v: i for i, v in enumerate(axis_values[name])} for name in AXES}
    tables = {}
    for row in rows:
        c = row['component']
        if c not in tables:
            tables[c] = np.full(shape + (6,), np.nan)
        table = tables[c]
        key = tuple(index[name][float(row[name])] for name in AXES)
        if not np.all(np.isnan(table[key])):
            raise ValueError(f'duplicate row for {c} at {dict(zip(AXES, key))}')
        table[key] = [float(row[k]) for k in COEFFICIENTS]
    components = []
    for c, table in sorted(tables.items()):
        missing = np.argwhere(np.isnan(table[..., 0]))
        if len(missing):
            cells = [{name: axis_values[name][i] for name, i in zip(AXES, cell)} for cell in missing[:5]]
            raise ValueError(f'{c}: {len(missing)} missing grid cells, e.g. {cells}')
        ref = header.get(f'ref.{c}')
        if ref is None:
            raise ValueError(f'missing reference point header ref.{c}')
        components.append(ComponentTable(c, tuple(float(x) for x in ref.split()), table, None, 'flightstream'))
    return TabulatedDataset(dataset_id, evidence, {'kind': 'flightstream-csv', 'source': header.get('source', '')},
                            float(header['reference_area_in2']), float(header['reference_span_in']),
                            float(header['reference_chord_in']), axes, tuple(components),
                            header.get('validation_reference'))
