"""XFOIL polar computation and section verification.

This module provides utilities for running XFOIL to generate viscous section
polars and analyzing the results against published reference data.

Usage:
    from flightloads.xfoil_polars import run_polar, section_characteristics

    polar = run_polar(
        airfoil="NACA 4412",
        reynolds=3e6,
        alphas_deg=numpy.linspace(-6, 18, 49),
        mach=0.0,
        ncrit=9.0
    )

    # Analyze the polar over the attached range
    attached_range = (-3.5, 9.0)
    chars = section_characteristics(polar, attached_range)
    print(f"Zero-lift alpha: {chars.zero_lift_alpha_deg:.2f} deg")
    print(f"Lift slope: {chars.lift_slope_per_deg:.4f}/deg")
"""

import dataclasses
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


@dataclass(frozen=True)
class SectionPolar:
    """Typed polar record with provenance.

    Units:
        alpha: degrees
        CL, CD, CDp, CM: per section chord
        CM: about quarter chord, nose-up positive
        Top_Xtr, Bot_Xtr: chordwise location (x/c)
    """
    requested_alpha_deg: List[float]
    converged_alpha_deg: List[float]
    nonconverged_alpha_deg: List[float]
    CL: List[float]
    CD: List[float]
    CDp: List[float]
    CM: List[float]
    Top_Xtr: List[float]
    Bot_Xtr: List[float]
    inputs: Dict[str, Any]
    engine_manifest: Dict[str, Any]
    input_script_sha256: str
    polar_file_sha256: str

    def __post_init__(self):
        """Validate record consistency."""
        n = len(self.converged_alpha_deg)
        if len(self.CL) != n:
            raise ValueError("CL must match converged alpha count")
        if len(self.CD) != n:
            raise ValueError("CD must match converged alpha count")
        if len(self.CDp) != n:
            raise ValueError("CDp must match converged alpha count")
        if len(self.CM) != n:
            raise ValueError("CM must match converged alpha count")
        if len(self.Top_Xtr) != n:
            raise ValueError("Top_Xtr must match converged alpha count")
        if len(self.Bot_Xtr) != n:
            raise ValueError("Bot_Xtr must match converged alpha count")


def _compute_input_hash(
    airfoil: str,
    reynolds: float,
    alphas_deg: List[float],
    mach: float,
    ncrit: float,
    xtr_top: float,
    xtr_bottom: float,
    panels: Optional[int],
    flap: Optional[Tuple[float, float, float]],
    engine_sha256: str = "",
) -> str:
    """SHA256 cache key over every input that can change XFOIL output.

    Coordinate-file inputs contribute their contents, not just their path, and
    the XFOIL binary digest is included so a rebuilt engine never reuses results.
    """
    airfoil_file_sha256 = None
    if not airfoil.startswith("NACA "):
        airfoil_file_sha256 = hashlib.sha256(Path(airfoil).read_bytes()).hexdigest()
    data = {
        "airfoil": airfoil,
        "airfoil_file_sha256": airfoil_file_sha256,
        "engine_sha256": engine_sha256,
        "reynolds": reynolds,
        "alphas_deg": alphas_deg,
        "mach": mach,
        "ncrit": ncrit,
        "xtr_top": xtr_top,
        "xtr_bottom": xtr_bottom,
        "panels": panels,
        "flap": flap,
    }
    content = json.dumps(data, sort_keys=True)
    return hashlib.sha256(content.encode()).hexdigest()


def _generate_xfoil_script(
    airfoil: str,
    reynolds: float,
    mach: float,
    ncrit: float,
    alphas_deg: List[float],
    xtr_top: float,
    xtr_bottom: float,
    panels: Optional[int],
    flap: Optional[Tuple[float, float, float]],
    polar_file: str,
) -> str:
    """Generate XFOIL command script for polar computation.

    Graphics disabled (PLOP G), polar accumulation to file.

    Flap is applied using save/load cycle:
    - Generate modified airfoil and save to temp file
    - Load saved airfoil for polar run

    xtr is set via VPAR sub-menu (not after VPAR returns to OPER).
    """
    lines = []

    # Disable graphics
    lines.append("plop")
    lines.append("g")
    lines.append("")

    # Airfoil definition
    if airfoil.startswith("NACA "):
        lines.append(f"naca {airfoil[5:]}")
    else:
        # Treat as coordinate file path
        lines.append("load")
        lines.append(airfoil)
        lines.append("")

    # Flap definition using save/load cycle
    # GDES -> flap -> copy buffer to current -> save -> load
    if flap is not None:
        hinge_x, hinge_y, defl = flap
        lines.append("gdes")
        lines.append("flap")
        lines.append(f"{hinge_x}")  # Hinge x location (first prompt)
        lines.append(f"{hinge_y}")  # Hinge y location (second prompt)
        lines.append(f"{defl}")  # Deflection in degrees (third prompt)
        # x copies buffer to current and exits GDES
        lines.append("x")  # Set current airfoil = buffer airfoil
        # Save modified airfoil to temp file (at top level)
        lines.append("save flap_airfoil.tmp")
        lines.append("")  # Confirm save filename
        # Load saved airfoil back
        lines.append("load flap_airfoil.tmp")
        lines.append("")  # Confirm load filename

    # Panel distribution (optional). PPAR is a top-level menu: repanel before OPER.
    if panels is not None:
        lines.append("ppar")
        lines.append(f"n {panels}")
        lines.append("")
        lines.append("")

    # Operating conditions
    lines.append("oper")
    lines.append(f"visc {reynolds:g}")
    lines.append(f"mach {mach}")
    # ncrit and xtr are set via VPAR sub-menu in XFOIL
    lines.append("vpar")
    lines.append(f"n {ncrit}")
    lines.append(f"xtr {xtr_top} {xtr_bottom}")
    lines.append("")  # Exit VPAR, return to OPER

    # Polar accumulation
    # After providing dump filename (empty = no dump), stay in pacc mode
    # so alphas can be entered directly
    lines.append("pacc")
    lines.append(polar_file)
    lines.append("")  # Dump filename (empty = no dump, stays in pacc mode)

    # Alpha sequence - apply each alpha individually to support non-uniform lists
    # Insert 'init' between alphas to reset boundary layer for proper convergence
    for i, alpha in enumerate(alphas_deg):
        if i > 0:
            lines.append("init")  # Reset BL before next alpha
        lines.append(f"Alfa {alpha}")

    # Quit at top level (need blank line to return to top level first)
    lines.append("")  # Return to top level from OPER
    lines.append("QUIT")

    return "\n".join(lines)


def _parse_xfoil_polar_file(polar_content: str) -> Dict[str, List[Any]]:
    """Parse a saved XFOIL polar file into structured data.

    Returns:
        Dictionary with keys:
            - converged_alpha_deg: list of successfully converged alphas
            - nonconverged_alpha_deg: list of alphas with convergence issues
            - CL, CD, CDp, CM, Top_Xtr, Bot_Xtr: coefficient lists

    XFOIL polar file format (after dashed separator):
        alpha    CL        CD       CDp       CM      Top_Xtr  Bot_Xtr   Top_Itr  Bot_Itr
        ------ -------- --------- --------- --------  -------- --------  -------- --------
        0.000   0.0000   0.00512   0.00032  -0.0000    0.5138  47.7796   0.5138 193.2204

    Non-converged points may have '***' in CL or other fields.
    """
    lines = polar_content.splitlines()

    # Find the start of data (first line after dashed separator)
    data_start = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("------"):
            data_start = i + 1
            break

    if data_start is None:
        raise ValueError("Could not find data separator in polar file")

    # Parse data rows
    converged_alpha = []
    nonconverged_alpha = []
    CL = []
    CD = []
    CDp = []
    CM = []
    Top_Xtr = []
    Bot_Xtr = []

    for line in lines[data_start:]:
        line = line.strip()
        if not line:
            continue

        parts = line.split()
        if len(parts) < 8:
            # Non-converged or malformed row
            # XFOIL may output *** for failed convergence
            if parts and parts[0].replace("-", "").replace(".", "").isdigit():
                alpha = float(parts[0])
                nonconverged_alpha.append(alpha)
            continue

        try:
            alpha = float(parts[0])
            cl = float(parts[1])
            cd = float(parts[2])
            cdp = float(parts[3])
            cm = float(parts[4])
            top_xtr = float(parts[5])
            bot_xtr = float(parts[6])

            converged_alpha.append(alpha)
            CL.append(cl)
            CD.append(cd)
            CDp.append(cdp)
            CM.append(cm)
            Top_Xtr.append(top_xtr)
            Bot_Xtr.append(bot_xtr)
        except (ValueError, IndexError):
            # Try to detect non-converged rows
            if parts and parts[0].replace("-", "").replace(".", "").isdigit():
                alpha = float(parts[0])
                nonconverged_alpha.append(alpha)

    return {
        "converged_alpha_deg": converged_alpha,
        "nonconverged_alpha_deg": nonconverged_alpha,
        "CL": CL,
        "CD": CD,
        "CDp": CDp,
        "CM": CM,
        "Top_Xtr": Top_Xtr,
        "Bot_Xtr": Bot_Xtr,
    }


def run_polar(
    airfoil: str,
    reynolds: float,
    alphas_deg: List[float],
    *,
    mach: float = 0.0,
    ncrit: float = 9.0,
    xtr_top: float = 1.0,
    xtr_bottom: float = 1.0,
    panels: Optional[int] = None,
    flap: Optional[Tuple[float, float, float]] = None,
    timeout_s: float = 120,
    cache_dir: Optional[str] = None,
) -> SectionPolar:
    """Run XFOIL to generate a viscous section polar.

    Args:
        airfoil: NACA 4-digit designation (e.g., "NACA 4412") or path to .dat file
        reynolds: Reynolds number based on chord
        alphas_deg: List of alpha values to sweep (degrees)
        mach: Mach number (default 0.0)
        ncrit: Ncrit for transition (default 9.0)
        xtr_top: Top surface transition location (x/c, default 1.0 = forced)
        xtr_bottom: Bottom surface transition location (x/c, default 1.0 = forced)
        panels: Optional panel count override (default uses XFOIL's ppar)
        flap: Optional flap parameters (hinge_x_over_c, hinge_y_over_c, deflection_deg)
        timeout_s: Command timeout in seconds (default 120)
        cache_dir: Cache directory override (default ~/.cache/flight-loads/xfoil)

    Returns:
        SectionPolar record with all coefficients and provenance

    Raises:
        subprocess.TimeoutExpired: If XFOIL execution exceeds timeout
        RuntimeError: If XFOIL fails or polar file is missing
    """
    from flightloads.aero_engines import locate

    xfoil_path, manifest = locate("xfoil")

    # Compute input hash for caching
    input_hash = _compute_input_hash(
        engine_sha256=manifest.get("binary_sha256", ""),
        airfoil=airfoil,
        reynolds=reynolds,
        alphas_deg=alphas_deg,
        mach=mach,
        ncrit=ncrit,
        xtr_top=xtr_top,
        xtr_bottom=xtr_bottom,
        panels=panels,
        flap=flap,
    )

    # Determine cache directory
    if cache_dir is None:
        cache_dir = os.environ.get("FLIGHTLOADS_XFOIL_CACHE_DIR")
    if cache_dir is None:
        cache_dir = Path.home() / ".cache" / "flight-loads" / "xfoil"
    cache_dir = Path(cache_dir).expanduser()
    cache_dir.mkdir(parents=True, exist_ok=True)

    # Check cache first
    cache_file = cache_dir / f"{input_hash}.json"
    if cache_file.exists():
        with open(cache_file, "r") as f:
            cached_data = json.load(f)
        return SectionPolar(**cached_data)

    # Create temporary directory for execution
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        polar_file = "polar.dat"  # XFOIL expects short filename
        polar_path = tmpdir_path / polar_file

        # Generate XFOIL command script
        script = _generate_xfoil_script(
            airfoil=airfoil,
            reynolds=reynolds,
            mach=mach,
            ncrit=ncrit,
            alphas_deg=alphas_deg,
            xtr_top=xtr_top,
            xtr_bottom=xtr_bottom,
            panels=panels,
            flap=flap,
            polar_file=polar_file,
        )

        # Compute input script hash
        input_script_sha256 = hashlib.sha256(script.encode()).hexdigest()

        # Write script to temp file
        script_path = tmpdir_path / "commands.txt"
        script_path.write_text(script)

        # Run XFOIL in batch mode
        try:
            result = subprocess.run(
                [str(xfoil_path)],
                input=script,
                capture_output=True,
                text=True,
                cwd=tmpdir,
                timeout=timeout_s,
            )
        except subprocess.TimeoutExpired as e:
            raise subprocess.TimeoutExpired(
                f"XFOIL execution exceeded {timeout_s}s timeout"
            ) from e

        # Check for errors
        if result.returncode != 0:
            raise RuntimeError(
                f"XFOIL failed with return code {result.returncode}\n"
                f"stdout:\n{result.stdout}\n"
                f"stderr:\n{result.stderr}"
            )

        # Check polar file was created
        if not polar_path.exists():
            raise RuntimeError("XFOIL did not create polar file")

        # Read and parse polar file
        polar_content = polar_path.read_text()
        polar_file_sha256 = hashlib.sha256(polar_content.encode()).hexdigest()

        polar_parsed = _parse_xfoil_polar_file(polar_content)

    # XFOIL appends only converged points to the polar file, so every requested
    # alpha without a row is a non-converged gap. Polar rows carry 3 decimals.
    converged_rows = polar_parsed["converged_alpha_deg"]
    polar_parsed["nonconverged_alpha_deg"] = [
        alpha for alpha in alphas_deg
        if not any(abs(alpha - row) < 5e-4 for row in converged_rows)
    ]

    # Build the polar record
    polar = SectionPolar(
        requested_alpha_deg=list(alphas_deg),
        converged_alpha_deg=polar_parsed["converged_alpha_deg"],
        nonconverged_alpha_deg=polar_parsed["nonconverged_alpha_deg"],
        CL=polar_parsed["CL"],
        CD=polar_parsed["CD"],
        CDp=polar_parsed["CDp"],
        CM=polar_parsed["CM"],
        Top_Xtr=polar_parsed["Top_Xtr"],
        Bot_Xtr=polar_parsed["Bot_Xtr"],
        inputs={
            "airfoil": airfoil,
            "reynolds": reynolds,
            "alphas_deg": alphas_deg,
            "mach": mach,
            "ncrit": ncrit,
            "xtr_top": xtr_top,
            "xtr_bottom": xtr_bottom,
            "panels": panels,
            "flap": flap,
        },
        engine_manifest=manifest,
        input_script_sha256=input_script_sha256,
        polar_file_sha256=polar_file_sha256,
    )

    # Cache the result
    with open(cache_file, "w") as f:
        json.dump(dataclasses.asdict(polar), f, indent=2)

    return polar


def section_characteristics(
    polar: SectionPolar,
    attached_range_deg: Tuple[float, float],
) -> Dict[str, Any]:
    """Compute section aerodynamic characteristics over an attached range.

    Args:
        polar: SectionPolar record
        attached_range_deg: (alpha_min, alpha_max) for linear range fit

    Returns:
        Dictionary with:
            - zero_lift_alpha_deg: alpha where CL=0 (linear fit)
            - lift_slope_per_deg: dCL/dalpha over attached range
            - lift_slope_per_rad: dCL/dalpha (radians)
            - cm_quarter_chord: mean CM over attached range
            - cd_min: minimum CD over converged points
            - cl_max: maximum CL over whole sweep
            - cl_max_alpha: alpha at CLmax
            - attached_alpha_range: actual alpha range in data
    """
    # Convert attached range to indices
    alpha_min, alpha_max = attached_range_deg

    # Get indices within attached range
    indices = []
    for i, alpha in enumerate(polar.converged_alpha_deg):
        if alpha_min <= alpha <= alpha_max:
            indices.append(i)

    if not indices:
        raise ValueError(f"No converged points in attached range [{alpha_min}, {alpha_max}]")

    # Extract data over attached range
    alphas_attached = [polar.converged_alpha_deg[i] for i in indices]
    cls_attached = [polar.CL[i] for i in indices]

    # Linear fit: CL = a + b*alpha
    # numpy.polyfit returns [b, a] where y = a + b*x
    coeffs = np.polyfit(alphas_attached, cls_attached, 1)
    lift_slope_per_deg = coeffs[0]  # dCL/dalpha (per degree)
    intercept = coeffs[1]

    # Zero-lift alpha: where CL = 0
    zero_lift_alpha_deg = -intercept / lift_slope_per_deg if lift_slope_per_deg != 0 else 0.0

    # Lift slope in per radian
    lift_slope_per_rad = lift_slope_per_deg * (180.0 / np.pi)

    # Mean CM over attached range
    cms_attached = [polar.CM[i] for i in indices]
    cm_quarter_chord = np.mean(cms_attached)

    # Minimum CD over all converged points
    cd_min = min(polar.CD)

    # CLmax and stall angle over whole sweep
    cl_max = max(polar.CL)
    cl_max_idx = polar.CL.index(cl_max)
    cl_max_alpha = polar.converged_alpha_deg[cl_max_idx]

    # Actual attached alpha range in data
    actual_attached = (
        min(polar.converged_alpha_deg[i] for i in indices),
        max(polar.converged_alpha_deg[i] for i in indices),
    )

    return {
        "zero_lift_alpha_deg": zero_lift_alpha_deg,
        "lift_slope_per_deg": lift_slope_per_deg,
        "lift_slope_per_rad": lift_slope_per_rad,
        "cm_quarter_chord": cm_quarter_chord,
        "cd_min": cd_min,
        "cl_max": cl_max,
        "cl_max_alpha": cl_max_alpha,
        "attached_alpha_range": actual_attached,
    }


def evaluate_gates(
    observed: Dict[str, Any],
    reference: Dict[str, Any],
    tolerances: Dict[str, float],
) -> Dict[str, Dict[str, Any]]:
    """Evaluate acceptance gates against reference data.

    Args:
        observed: section_characteristics() output
        reference: Reference values from fixture (e.g., zero_lift_alpha_deg, lift_slope_per_deg)
        tolerances: Gate tolerances (alpha0_deg, slope_per_deg, cm, cd_min_frac)

    Returns:
        Dictionary with observed, expected, difference, pass/fail for each quantity
    """
    results = {}

    # Zero-lift alpha: gate on absolute difference
    alpha0_diff = abs(observed["zero_lift_alpha_deg"] - reference["zero_lift_alpha_deg"])
    results["zero_lift_alpha_deg"] = {
        "observed": observed["zero_lift_alpha_deg"],
        "expected": reference["zero_lift_alpha_deg"],
        "difference": alpha0_diff,
        "tolerance": tolerances["alpha0_deg"],
        "pass": alpha0_diff <= tolerances["alpha0_deg"],
    }

    # Lift slope: gate on percentage difference
    slope_diff = abs(observed["lift_slope_per_deg"] - reference["lift_slope_per_deg"])
    slope_pct = (slope_diff / abs(reference["lift_slope_per_deg"])) * 100
    results["lift_slope_per_deg"] = {
        "observed": observed["lift_slope_per_deg"],
        "expected": reference["lift_slope_per_deg"],
        "difference": slope_diff,
        "difference_pct": slope_pct,
        "tolerance_pct": tolerances["slope_per_deg_pct"],
        "pass": slope_pct <= tolerances["slope_per_deg_pct"],
    }

    # CM: gate on absolute difference
    cm_diff = abs(observed["cm_quarter_chord"] - reference["cm_quarter_chord"])
    results["cm_quarter_chord"] = {
        "observed": observed["cm_quarter_chord"],
        "expected": reference["cm_quarter_chord"],
        "difference": cm_diff,
        "tolerance": tolerances["cm"],
        "pass": cm_diff <= tolerances["cm"],
    }

    # Cd min: gate on fractional difference (25% tolerance means within 25% of reference)
    cd_diff = abs(observed["cd_min"] - reference["cd_min"])
    cd_frac = cd_diff / reference["cd_min"]
    results["cd_min"] = {
        "observed": observed["cd_min"],
        "expected": reference["cd_min"],
        "difference": cd_diff,
        "difference_frac": cd_frac,
        "tolerance_frac": tolerances["cd_min_frac"],
        "pass": cd_frac <= tolerances["cd_min_frac"],
    }

    return results


# Expose SectionPolar for convenient import
__all__ = [
    "SectionPolar",
    "run_polar",
    "section_characteristics",
    "evaluate_gates",
]
