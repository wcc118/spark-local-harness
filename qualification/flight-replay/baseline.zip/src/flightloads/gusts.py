"""Discrete 1-cos gusts and Dryden continuous turbulence (issue #208).

Wind is ground-referenced, in NED ft/s, and added to any steady wind. Gusts are
sampled at the CG: for this aircraft (4 ft span, 2.5 ft body) the penetration
delay is about 0.01 s against gust lengths of tens of feet, so spanwise and
lengthwise gust gradients are neglected. See docs/mechanics/GUSTS.md (Station 4).

Discrete gust (frozen in space along a horizontal path axis e):
    s = (r_N - r_ref) . e - onset_distance
    U(s) = (U_max/2) * (1 - cos(pi*s/H))   for 0 <= s <= 2H, else 0
    wind += U(s) * d                         (d: unit gust direction, NED)

Dryden turbulence (MIL-HDBK-1797 forms, frozen field at nominal speed V):
    Phi_u(w) = sigma_u^2 * (2 L_u / (pi V)) / (1 + (L_u w / V)^2)
    Phi_v,w  = sigma^2 * (L / (pi V)) * (1 + 3 (L w / V)^2) / (1 + (L w / V)^2)^2
realized on its own fixed sample clock (exact discretization, seeded), then
linearly interpolated in time. The plant step never changes the realization.
Components u, v, w are along the path axis, its right-hand horizontal
normal, and down.
"""
from __future__ import annotations

import math

import numpy as np

MAX_SAMPLES = 2_000_000


def _unit(vector, name):
    v = np.asarray(vector, dtype=float)
    n = float(np.linalg.norm(v))
    if v.shape != (3,) or not np.all(np.isfinite(v)) or n < 1e-12:
        raise ValueError(f'{name} requires a finite nonzero 3-vector')
    return v / n


def one_minus_cosine(s, amplitude, gradient_length):
    """U(s) = (A/2)(1 - cos(pi s / H)) for 0 <= s <= 2H, else 0."""
    if s <= 0.0 or s >= 2.0*gradient_length:
        return 0.0
    return 0.5*amplitude*(1.0 - math.cos(math.pi*s/gradient_length))


class DiscreteGust:
    def __init__(self, amplitude_ft_s, gradient_length_ft, direction_N, path_axis_N, reference_N_ft, onset_distance_ft):
        self.amplitude = float(amplitude_ft_s)
        self.length = float(gradient_length_ft)
        if not math.isfinite(self.amplitude) or not (math.isfinite(self.length) and self.length > 0):
            raise ValueError('gust amplitude must be finite and gradient length positive')
        self.direction = _unit(direction_N, 'direction_N')
        axis = np.asarray(path_axis_N, dtype=float)
        axis = np.array([axis[0], axis[1], 0.0])
        self.axis = _unit(axis, 'path_axis_N (horizontal part)')
        self.reference = np.asarray(reference_N_ft, dtype=float)
        self.onset = float(onset_distance_ft)

    def velocity_N(self, time_s, position_N_ft):
        s = float(np.dot(np.asarray(position_N_ft, dtype=float) - self.reference, self.axis)) - self.onset
        return one_minus_cosine(s, self.amplitude, self.length)*self.direction


def _discretize(a, b, period):
    """Exact zero-order-hold discretization of x' = A x + B n (unit white noise):
    Ad = exp(A T), Qd = int_0^T exp(A t) B B^T exp(A^T t) dt (Van Loan)."""
    n = a.shape[0]
    m = np.zeros((2*n, 2*n))
    m[:n, :n] = -a
    m[:n, n:] = b @ b.T
    m[n:, n:] = a.T
    e = _expm(m*period)
    ad = e[n:, n:].T
    qd = ad @ e[:n, n:]
    return ad, 0.5*(qd + qd.T)


def _expm(m):
    """Matrix exponential by scaling and squaring with a Taylor series (small matrices)."""
    norm = np.max(np.sum(np.abs(m), axis=1))
    squarings = max(0, int(math.ceil(math.log2(norm))) + 1) if norm > 0.5 else 0
    x = m / (2**squarings)
    result, term = np.eye(m.shape[0]), np.eye(m.shape[0])
    for k in range(1, 30):
        term = term @ x / k
        result = result + term
    for _ in range(squarings):
        result = result @ result
    return result


def _steady_covariance(ad, qd):
    """Solve P = Ad P Ad^T + Qd by vectorization."""
    n = ad.shape[0]
    lhs = np.eye(n*n) - np.kron(ad, ad)
    return np.linalg.solve(lhs, qd.reshape(-1)).reshape(n, n)


def dryden_filter(kind, scale_length_ft, speed_ft_s):
    """Continuous state-space (A, B, C) whose output has the Dryden PSD shape (unit intensity)."""
    tau = scale_length_ft/speed_ft_s
    if kind == 'u':
        return np.array([[-1/tau]]), np.array([[1.0]]), np.array([[1.0]])
    # (1 + sqrt(3) tau s)/(1 + tau s)^2 in controllable canonical form.
    a = np.array([[0.0, 1.0], [-1/tau**2, -2/tau]])
    b = np.array([[0.0], [1.0]])
    c = np.array([[1/tau**2, math.sqrt(3)/tau]])
    return a, b, c


def discrete_dryden(kind, sigma, length, speed, period):
    """Exactly discretized Dryden filter scaled so the sampled output variance is sigma^2."""
    a, b, c = dryden_filter(kind, length, speed)
    ad, qd = _discretize(a, b, period)
    p = _steady_covariance(ad, qd)
    gain = sigma/math.sqrt((c @ p @ c.T).item())
    return dict(ad=ad, chol=np.linalg.cholesky(qd), c=gain*c, p=p, qd=qd, period=period)


def _run_filter(f, start, noise):
    """x_{k+1} = Ad x_k + chol(Qd) n_k, y_k = C x_k; pure-float loop (1 or 2 states)."""
    ad, g, c = f['ad'], f['chol'], f['c'][0]
    x = np.linalg.cholesky(f['p']) @ start          # stationary initial state
    out = np.empty(len(noise))
    if len(ad) == 1:
        a, q, cc, x0 = float(ad[0, 0]), float(g[0, 0]), float(c[0]), float(x[0])
        for i, n in enumerate(noise[:, 0].tolist()):
            out[i] = cc*x0
            x0 = a*x0 + q*n
        return out
    a00, a01, a10, a11 = (float(v) for v in ad.ravel())
    g00, g10, g11 = float(g[0, 0]), float(g[1, 0]), float(g[1, 1])
    c0, c1, x0, x1 = float(c[0]), float(c[1]), float(x[0]), float(x[1])
    for i, (n0, n1) in enumerate(noise.tolist()):
        out[i] = c0*x0 + c1*x1
        x0, x1 = a00*x0 + a01*x1 + g00*n0, a10*x0 + a11*x1 + g10*n0 + g11*n1
    return out


def discrete_psd(f, omega_rad_s):
    """Exact one-sided PSD (per rad/s) of the sampled filter output, for omega below Nyquist:
    S(w) = (T/pi) * C (e^{jwT} I - Ad)^-1 Qd (e^{jwT} I - Ad)^-H C^T."""
    ad, qd, c, period = f['ad'], f['qd'], f['c'], f['period']
    z = np.exp(1j*omega_rad_s*period)
    h = c @ np.linalg.inv(z*np.eye(len(ad)) - ad)
    return float((period/math.pi)*np.real(h @ qd @ h.conj().T).item())


class DrydenTurbulence:
    def __init__(self, sigma_ft_s, scale_length_ft, nominal_speed_ft_s, sample_period_s, duration_s, seed,
                 path_axis_N=(1.0, 0.0, 0.0)):
        self.sigma = np.asarray(sigma_ft_s, dtype=float)
        self.lengths = np.asarray(scale_length_ft, dtype=float)
        if self.sigma.shape != (3,) or np.any(self.sigma < 0) or not np.all(np.isfinite(self.sigma)):
            raise ValueError('sigma_ft_s requires three finite nonnegative intensities (u, v, w)')
        if self.lengths.shape != (3,) or np.any(self.lengths <= 0) or not np.all(np.isfinite(self.lengths)):
            raise ValueError('scale_length_ft requires three positive lengths (u, v, w)')
        self.speed, self.period, self.duration = float(nominal_speed_ft_s), float(sample_period_s), float(duration_s)
        if not (self.speed > 0 and self.period > 0 and self.duration > 0):
            raise ValueError('speed, sample period and duration must be positive')
        count = int(math.ceil(self.duration/self.period)) + 2
        if count > MAX_SAMPLES:
            raise ValueError(f'turbulence realization needs {count} samples; limit {MAX_SAMPLES}')
        axis = np.asarray(path_axis_N, dtype=float)
        e_u = _unit(np.array([axis[0], axis[1], 0.0]), 'path_axis_N')
        e_w = np.array([0.0, 0.0, 1.0])
        e_v = np.cross(e_w, e_u)
        self.axes = np.stack([e_u, e_v, e_w])        # rows: u, v, w directions in NED
        self.seed = int(seed)
        rng = np.random.default_rng(self.seed)
        samples = np.zeros((count, 3))
        self.filters = {}
        for k, kind in enumerate('uvw'):
            if self.sigma[k] == 0:
                continue
            f = discrete_dryden('u' if kind == 'u' else 'vw', self.sigma[k], self.lengths[k], self.speed, self.period)
            self.filters[kind] = f
            samples[:, k] = _run_filter(f, rng.standard_normal(len(f['ad'])), rng.standard_normal((count, len(f['ad']))))
        self.samples = samples

    def velocity_N(self, time_s, position_N_ft=None):
        t = float(time_s)
        if not 0.0 <= t <= self.duration + 1e-9:
            raise ValueError(f'turbulence time {t:g} s outside realized [0, {self.duration:g}] s')
        i = min(int(t//self.period), len(self.samples) - 2)
        w = t/self.period - i
        components = (1 - w)*self.samples[i] + w*self.samples[i + 1]
        return components @ self.axes


def dryden_psd(kind, omega_rad_s, sigma, length, speed):
    """Two-sided-in-time Dryden PSD as written above (per rad/s)."""
    x = length*omega_rad_s/speed
    if kind == 'u':
        return sigma**2*(2*length/(math.pi*speed))/(1 + x**2)
    return sigma**2*(length/(math.pi*speed))*(1 + 3*x**2)/(1 + x**2)**2


class WindField:
    """Steady wind plus optional discrete gust and turbulence, NED ft/s."""

    def __init__(self, steady_N_ft_s, discrete=None, turbulence=None):
        self.steady = np.asarray(steady_N_ft_s, dtype=float)
        self.discrete, self.turbulence = discrete, turbulence

    def velocity_N(self, time_s, position_N_ft):
        wind = self.steady.copy()
        if self.discrete is not None:
            wind = wind + self.discrete.velocity_N(time_s, position_N_ft)
        if self.turbulence is not None:
            wind = wind + self.turbulence.velocity_N(time_s, position_N_ft)
        return wind
