"""Headless, parallel, resumable closed-loop Monte Carlo over the capture bench (issue #224).

A study perturbs a base run input (definition, bench, field_case) with declared
random variables and runs every sample through the same run_bench used by the
dashboard and CLI. Each sample keeps a compact summary; full histories are not
stored because any sample replays exactly from (seed, index).

Sampling is order-independent: sample k draws from numpy's default_rng([seed, k]),
so serial, parallel and resumed studies give identical samples.

Variables:
    uniform          params {low, high}
    normal           params {mean, std}
    truncated-normal params {mean, std, low, high}   (inverse-CDF on the truncated range)
    discrete         params {values: [...], weights: [...] optional}
Correlation: variables naming the same `latent` share one standard-uniform draw u
(transformed through each variable's inverse CDF), giving perfect rank correlation;
`reverse: true` uses 1 - u. Each binding writes the value at a JSON path in the
base inputs (list of keys/indices), with transform set, add or scale.

Probabilities describe the declared input model, not real-world failure rates.
See docs/mechanics/MONTE_CARLO.md (Station 10).
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path

import numpy as np

SCHEMA = 'monte-carlo-study-v1'
SUMMARY_SCHEMA = 'monte-carlo-sample-v1'
DISTRIBUTIONS = ('uniform', 'normal', 'truncated-normal', 'discrete')
TRANSFORMS = ('set', 'add', 'scale')
MAX_SAMPLES, MAX_VARIABLES = 20000, 64


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _norm_ppf(p):
    """Inverse standard normal CDF (Acklam's rational approximation, |error| < 1.2e-9)."""
    a = (-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02,
         -3.066479806614716e+01, 2.506628277459239e+00)
    b = (-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01,
         -1.328068155288572e+01)
    c = (-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00,
         4.374664141464968e+00, 2.938163982698783e+00)
    d = (7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00)
    p = min(max(p, 1e-300), 1 - 1e-16)
    if p < 0.02425:
        q = math.sqrt(-2*math.log(p))
        return (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5])/((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)
    if p > 1 - 0.02425:
        q = math.sqrt(-2*math.log(1 - p))
        return -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5])/((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)
    q = p - 0.5
    r = q*q
    return (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q/(((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1)


def _norm_cdf(x):
    return 0.5*(1 + math.erf(x/math.sqrt(2)))


def inverse_cdf(variable, u):
    """Map a standard-uniform u to the variable's value."""
    kind, p = variable['distribution'], variable['params']
    if kind == 'uniform':
        return p['low'] + u*(p['high'] - p['low'])
    if kind == 'normal':
        return p['mean'] + p['std']*_norm_ppf(u)
    if kind == 'truncated-normal':
        lo, hi = _norm_cdf((p['low'] - p['mean'])/p['std']), _norm_cdf((p['high'] - p['mean'])/p['std'])
        return min(max(p['mean'] + p['std']*_norm_ppf(lo + u*(hi - lo)), p['low']), p['high'])
    values = p['values']
    weights = np.asarray(p.get('weights') or [1.0]*len(values), dtype=float)
    cumulative = np.cumsum(weights/weights.sum())
    return values[int(min(np.searchsorted(cumulative, u, side='right'), len(values) - 1))]


def validate_study(study):
    keys = {'schema', 'name', 'source', 'base', 'variables', 'seed', 'count', 'budget'}
    if type(study) is not dict or set(study) != keys or study['schema'] != SCHEMA:
        raise ValueError(f'study requires exactly {sorted(keys)} with schema {SCHEMA}')
    if set(study['base']) != {'definition', 'bench', 'field_case'}:
        raise ValueError('base requires definition, bench and field_case')
    if type(study['seed']) is not int or not 0 <= study['seed'] < 2**32:
        raise ValueError('seed must be an integer in [0, 2^32)')
    if type(study['count']) is not int or not 1 <= study['count'] <= MAX_SAMPLES:
        raise ValueError(f'count must be 1..{MAX_SAMPLES}')
    budget = study['budget']
    if type(budget) is not dict or set(budget) != {'max_workers', 'max_run_seconds'}:
        raise ValueError('budget requires max_workers and max_run_seconds')
    if type(budget['max_workers']) is not int or budget['max_workers'] < 1:
        raise ValueError('max_workers must be a positive integer')
    if (type(budget['max_run_seconds']) not in (int, float)
            or not math.isfinite(budget['max_run_seconds']) or budget['max_run_seconds'] <= 0):
        raise ValueError('advisory max_run_seconds must be finite and positive')
    variables = study['variables']
    if not isinstance(variables, list) or not 0 <= len(variables) <= MAX_VARIABLES:
        raise ValueError(f'variables must be a list of at most {MAX_VARIABLES}')
    ids = set()
    for v in variables:
        if set(v) - {'id', 'source', 'distribution', 'params', 'latent', 'reverse', 'bindings'} or not {'id', 'source', 'distribution', 'params', 'bindings'} <= set(v):
            raise ValueError('variable requires id, source, distribution, params, bindings (latent, reverse optional)')
        if v['id'] in ids:
            raise ValueError(f'duplicate variable id {v["id"]}')
        ids.add(v['id'])
        if v['distribution'] not in DISTRIBUTIONS:
            raise ValueError(f'{v["id"]}: distribution must be one of {DISTRIBUTIONS}')
        p = v['params']
        if v['distribution'] == 'uniform' and not p['low'] < p['high']:
            raise ValueError(f'{v["id"]}: uniform requires low < high')
        if v['distribution'] in ('normal', 'truncated-normal') and not p['std'] > 0:
            raise ValueError(f'{v["id"]}: std must be positive')
        if v['distribution'] == 'truncated-normal' and not p['low'] < p['high']:
            raise ValueError(f'{v["id"]}: truncated-normal requires low < high')
        if v['distribution'] == 'discrete' and not p.get('values'):
            raise ValueError(f'{v["id"]}: discrete requires values')
        if v['distribution'] == 'discrete' and 'weights' in p:
            weights = p['weights']
            if (not isinstance(weights, list) or len(weights) != len(p['values'])
                    or any(type(w) not in (int, float) or not math.isfinite(w) or w < 0 for w in weights)
                    or not 0 < sum(weights) < math.inf):
                raise ValueError(f'{v["id"]}: weights must be finite nonnegative values with positive sum, one per value')
        for b in v['bindings']:
            if set(b) != {'path', 'transform'} or b['transform'] not in TRANSFORMS or not isinstance(b['path'], list) or not b['path']:
                raise ValueError(f'{v["id"]}: binding requires a non-empty path list and transform in {TRANSFORMS}')
            _resolve(study['base'], b['path'])
    _canonical(study)  # Reject nonfinite numbers anywhere in the declared JSON input model.
    return deepcopy(study)


def sample_values(study, index):
    """Order-independent draws for sample `index`: one uniform per latent group or variable."""
    rng = np.random.default_rng([study['seed'], index])
    latent = {}
    values = {}
    for v in study['variables']:
        key = v.get('latent') or ('own:' + v['id'])
        if key not in latent:
            latent[key] = float(rng.random())
        u = latent[key]
        values[v['id']] = inverse_cdf(v, 1 - u if v.get('reverse') else u)
    return values


def _resolve(target, path):
    """Container and final key of a binding path; ValueError if any element is missing."""
    node = target
    for depth, key in enumerate(path):
        exists = (isinstance(node, dict) and key in node) or (
            isinstance(node, list) and type(key) is int and 0 <= key < len(node))
        if not exists:
            raise ValueError(f'binding path {path} does not exist in the base inputs')
        if depth < len(path) - 1:
            node = node[key]
    return node, path[-1]


def _apply(target, path, transform, value):
    node, last = _resolve(target, path)
    old = node[last]
    node[last] = value if transform == 'set' else old + value if transform == 'add' else old*value


def sample_inputs(study, index):
    inputs = deepcopy(study['base'])
    values = sample_values(study, index)
    for v in study['variables']:
        for b in v['bindings']:
            _apply(inputs, b['path'], b['transform'], values[v['id']])
    return inputs, values


def summarize(report, index, values):
    """Compact per-sample summary: outcomes, flight envelope and station peaks with the
    concurrent station field (all stations) at each peak instant."""
    truth = report.get('truth') or []
    stations = report.get('station_loads') or []
    peaks = {}
    for row in stations:
        field = {s['id']: dict(force_B_lbf=[round(x, 6) for x in s['force_B_lbf']],
                               moment_B_in_lbf=[round(x, 6) for x in s['moment_B_in_lbf']]) for s in row['stations']}
        for s in row['stations']:
            for quantity, key in (('force', 'force_B_lbf'), ('moment', 'moment_B_in_lbf')):
                magnitude = float(np.linalg.norm(s[key]))
                slot = peaks.setdefault(s['id'], {})
                if magnitude > slot.get(quantity, {}).get('magnitude', -1.0):
                    slot[quantity] = dict(magnitude=magnitude, time_s=row['time_s'], tick=row['tick'], concurrent=field)
    objective = 'autopilot' if 'autopilot' in report.get('inputs',{}).get('bench',{}) else 'sustained_capture'
    capture = (report.get('outcomes') or {}).get(objective) or {}
    apogee = None
    apogee_time = None
    min_after_apogee = None
    if truth:
        max_height = max(r['height_ft'] for r in truth)
        for r in truth:
            if r['height_ft'] == max_height:
                apogee = max_height
                apogee_time = r['time_s']
                break
        rows_at_or_after_apogee = [r for r in truth if r['time_s'] >= apogee_time]
        if rows_at_or_after_apogee:
            min_after_apogee = min(r['height_ft'] for r in rows_at_or_after_apogee)
    return dict(schema=SUMMARY_SCHEMA, index=index, values=values, status=report.get('status'),
                stop_reason=report.get('stop_reason'), report_sha256=report.get('report_sha256'),
                aero_dataset=report.get('aero_dataset'),
                capture=dict(objective=objective,met=capture.get('met'), first_entry_time_s=capture.get('first_entry_time_s'),
                             final_dwell_duration_s=capture.get('final_dwell_duration_s'), reason=capture.get('reason')),
                flight_objectives={k:v for k,v in (report.get('outcomes') or {}).items() if k in ('stabilization','autopilot')},
                apogee_ft=apogee, apogee_time_s=apogee_time, min_height_after_apogee_ft=min_after_apogee,
                min_height_ft=min((r['height_ft'] for r in truth), default=None),
                max_rate_deg_s=max((r['rate_max_deg_s'] for r in truth), default=None),
                min_airspeed_ft_s=min((r['airspeed_ft_s'] for r in truth), default=None),
                max_airspeed_ft_s=max((r['airspeed_ft_s'] for r in truth), default=None),
                station_peaks=peaks)


def run_sample(study, index):
    """Run one sample through the production run_bench; never raises for model failures."""
    from .aircraft_controller_contract import make_run_inputs
    from .aircraft_controller_run import run_bench
    inputs, values = sample_inputs(study, index)
    try:
        report = run_bench(make_run_inputs(inputs['definition'], bench=inputs['bench'], field_case=inputs['field_case']))
    except ValueError as error:
        return dict(schema=SUMMARY_SCHEMA, index=index, values=values, status='input-rejected', stop_reason=str(error),
                    report_sha256=None, aero_dataset=None, capture={}, apogee_ft=None, apogee_time_s=None, min_height_after_apogee_ft=None,
                    min_height_ft=None, max_rate_deg_s=None, min_airspeed_ft_s=None, max_airspeed_ft_s=None, station_peaks={})
    return summarize(report, index, values)


def _worker(args):
    study, index = args
    return run_sample(study, index)


def run_study(study, directory, *, workers=None, cancelled=None, progress=None):
    """Run (or resume) a study into `directory`: study.json plus samples.jsonl (one summary per
    line, append-only). Returns the list of summaries ordered by index."""
    study = validate_study(study)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    spec_path, results_path = directory / 'study.json', directory / 'samples.jsonl'
    digest = hashlib.sha256(_canonical(study).encode()).hexdigest()
    if spec_path.exists():
        saved = json.loads(spec_path.read_text())
        if saved.get('study_sha256') != digest:
            raise ValueError('directory holds a different study; use a new directory')
    else:
        spec_path.write_text(json.dumps(dict(study=study, study_sha256=digest), indent=1) + '\n')
    done = {}
    if results_path.exists():
        for line in results_path.read_text().splitlines():
            if line.strip():
                row = json.loads(line)
                done[row['index']] = row
    pending = [i for i in range(study['count']) if i not in done]
    workers = min(workers or study['budget']['max_workers'], study['budget']['max_workers'], max(1, os.cpu_count() or 1))
    with results_path.open('a') as out:
        def accept(summary):
            out.write(json.dumps(summary, sort_keys=True, allow_nan=False) + '\n')
            out.flush()
            done[summary['index']] = summary
            if progress is not None:
                progress(dict(completed=len(done), total=study['count']))

        if workers <= 1:
            for index in pending:
                if cancelled is not None and cancelled():
                    break
                accept(run_sample(study, index))
        else:
            import multiprocessing
            context = multiprocessing.get_context('spawn')
            with context.Pool(workers) as pool:
                for summary in pool.imap_unordered(_worker, [(study, i) for i in pending]):
                    accept(summary)
                    if cancelled is not None and cancelled():
                        pool.terminate()
                        break
    return [done[i] for i in sorted(done)]


def replay_sample(study, index):
    """Full report for one sample (for governing or failed cases), reproduced from (seed, index)."""
    from .aircraft_controller_contract import make_run_inputs
    from .aircraft_controller_run import run_bench
    inputs, _ = sample_inputs(validate_study(study), index)
    return run_bench(make_run_inputs(inputs['definition'], bench=inputs['bench'], field_case=inputs['field_case']))
