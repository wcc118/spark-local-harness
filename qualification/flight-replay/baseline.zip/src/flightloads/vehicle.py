"""Fixed-configuration data; input completeness is not model validation."""
from __future__ import annotations

from dataclasses import dataclass, fields
import json
import math
from numbers import Real
from pathlib import Path
from types import MappingProxyType
from typing import ClassVar
import numpy as np
from ._arrays import readonly_copy
from .mass import MassModel

# Exact customary-unit definitions; lb alone deliberately has no conversion.
UNITS = MappingProxyType({
    'm': ('length', 1.), 'ft': ('length', .3048), 'in': ('length', .0254),
    'm2': ('area', 1.), 'ft2': ('area', .3048**2), 'in2': ('area', .0254**2),
    'rad': ('angle', 1.), 'deg': ('angle', math.pi/180),
    'kg': ('mass', 1.), 'lbm': ('mass', .45359237),
    'N': ('force', 1.), 'lbf': ('force', 4.4482216152605),
    'lb': ('ambiguous', None),
})
GEOMETRY = MappingProxyType({
    'fuselage_length': 'length', 'wing_span': 'length', 'wing_chord': 'length',
    'wing_le_station_aft_of_nose': 'length', 'wing_le_alternative_aft_of_nose': 'length',
    'forward_diameter': 'length', 'aft_diameter': 'length', 'wing_area': 'area',
    'wing_sweep': 'angle', 'tail_area': 'area', 'tail_span': 'length',
    'tail_chord': 'length', 'tail_dihedral': 'angle',
    'cg_station_aft_of_nose': 'length', 'neutral_point_station_aft_of_nose': 'length',
})
AXES = 'B: x forward, y right, z down'


def _text(value, name, *, empty=False):
    if not isinstance(value, str) or (not empty and not value.strip()):
        raise ValueError(f'{name} must be a {"possibly empty" if empty else "nonempty"} string')


def _object(data, names, label):
    if not isinstance(data, dict) or set(data) != set(names):
        raise ValueError(f'{label} requires exactly: {", ".join(names)}')
    return data


def _record(data, cls):
    return cls(**_object(data, [f.name for f in fields(cls)], cls.__name__))


def _sequence(data, label):
    if not isinstance(data, (list, tuple)):
        raise ValueError(f'{label} must be an array')
    return tuple(data)


def _unique(values, label):
    if len(values) != len(set(values)):
        raise ValueError(f'duplicate {label}')


@dataclass(frozen=True)
class Quantity:
    value: float | None
    unit: str
    provenance: str
    status: str
    notes: str = ''

    def __post_init__(self):
        _text(self.unit, 'unit')
        if self.unit not in UNITS:
            raise ValueError(f'unsupported unit: {self.unit}')
        _text(self.provenance, 'provenance')
        _text(self.notes, 'notes', empty=True)
        if self.status not in ('estimate', 'measured', 'derived', 'unknown'):
            raise ValueError('unsupported quantity status')
        if (self.value is None) != (self.status == 'unknown'):
            raise ValueError('unknown status requires null; known value requires non-unknown status')
        if self.value is not None:
            if isinstance(self.value, bool) or not isinstance(self.value, Real) or not math.isfinite(self.value):
                raise ValueError('quantity value must be a finite real number or null')
            object.__setattr__(self, 'value', float(self.value))
            factor = UNITS[self.unit][1]
            if factor is not None and not math.isfinite(self.value*factor):
                raise ValueError('SI conversion overflow')

    @property
    def dimension(self):
        return UNITS[self.unit][0]

    @property
    def si_value(self):
        factor = UNITS[self.unit][1]
        return None if self.value is None or factor is None else self.value*factor

    def require_si(self, dimension):
        if self.dimension != dimension or self.si_value is None:
            raise ValueError(f'requires known {dimension}; got {self.unit} ({self.status})')
        return self.si_value

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @classmethod
    def from_dict(cls, data):
        return _record(data, cls)


@dataclass(frozen=True)
class Fact:
    value: str | None
    provenance: str
    status: str
    notes: str = ''

    def __post_init__(self):
        _text(self.provenance, 'fact provenance')
        _text(self.notes, 'fact notes', empty=True)
        if self.status not in ('estimate', 'measured', 'derived', 'unknown'):
            raise ValueError('unsupported fact status')
        if (self.value is None) != (self.status == 'unknown'):
            raise ValueError('unknown fact requires null')
        if self.value is not None:
            _text(self.value, 'fact value')

    def to_dict(self):
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @classmethod
    def from_dict(cls, data):
        return _record(data, cls)


@dataclass(frozen=True)
class Location:
    x: Quantity
    y: Quantity
    z: Quantity

    def __post_init__(self):
        if any(not isinstance(q, Quantity) or q.dimension != 'length' for q in (self.x, self.y, self.z)):
            raise ValueError('location components must be length quantities')

    def si_vector(self):
        return readonly_copy([q.require_si('length') for q in (self.x, self.y, self.z)])

    def to_dict(self):
        return {axis: getattr(self, axis).to_dict() for axis in ('x', 'y', 'z')}

    @classmethod
    def from_dict(cls, data):
        data = _object(data, ('x', 'y', 'z'), 'Location')
        return cls(*(Quantity.from_dict(data[axis]) for axis in ('x', 'y', 'z')))


@dataclass(frozen=True)
class MassPoint:
    source_id: str
    mass: Quantity
    location: Location

    def __post_init__(self):
        _text(self.source_id, 'mass source_id')
        if not isinstance(self.mass, Quantity) or self.mass.dimension not in ('mass', 'ambiguous'):
            raise ValueError('point mass must have mass units (lb remains unresolved)')
        if self.mass.value is not None and self.mass.value <= 0:
            raise ValueError('point mass must be positive')
        if not isinstance(self.location, Location):
            raise ValueError('point location must be Location')

    def to_dict(self):
        return dict(source_id=self.source_id, mass=self.mass.to_dict(), location=self.location.to_dict())

    @classmethod
    def from_dict(cls, data):
        d = _object(data, ('source_id', 'mass', 'location'), 'MassPoint')
        return cls(d['source_id'], Quantity.from_dict(d['mass']), Location.from_dict(d['location']))


@dataclass(frozen=True)
class NamedPoint:
    name: str
    source_id: str
    location: Location
    description: Fact

    def __post_init__(self):
        _text(self.name, 'point name')
        _text(self.source_id, 'point source_id')
        if not isinstance(self.location, Location) or not isinstance(self.description, Fact):
            raise ValueError('named point requires Location and Fact description')

    def to_dict(self):
        return dict(name=self.name, source_id=self.source_id, location=self.location.to_dict(),
                    description=self.description.to_dict())

    @classmethod
    def from_dict(cls, data):
        d = _object(data, ('name', 'source_id', 'location', 'description'), 'NamedPoint')
        return cls(d['name'], d['source_id'], Location.from_dict(d['location']), Fact.from_dict(d['description']))


@dataclass(frozen=True)
class FixedConfiguration:
    schema_version: int
    configuration_id: str
    description: str
    datum_id: str
    datum_description: str
    axis_convention: str
    geometry: dict[str, Quantity]
    qualitative_facts: dict[str, Fact]
    reported_weight: Quantity
    nominal_mass: Quantity
    mass_points: tuple[MassPoint, ...]
    load_locations: tuple[NamedPoint, ...]
    structural_points: tuple[NamedPoint, ...]
    notes: tuple[str, ...]
    model_validation: ClassVar[str] = 'not_performed'
    design_acceptance: ClassVar[str] = 'not_performed'

    def __post_init__(self):
        if type(self.schema_version) is not int or self.schema_version != 1:
            raise ValueError('schema_version must be integer 1')
        for name in ('configuration_id', 'description', 'datum_id', 'datum_description'):
            _text(getattr(self, name), name)
        if self.axis_convention != AXES:
            raise ValueError(f'axis_convention must be {AXES}')
        for name, cls in (('geometry', Quantity), ('qualitative_facts', Fact)):
            values = getattr(self, name)
            if not isinstance(values, (dict, MappingProxyType)):
                raise ValueError(f'{name} must be an object')
            for key, value in values.items():
                _text(key, f'{name} key')
                if not isinstance(value, cls):
                    raise ValueError(f'{name}.{key} must be {cls.__name__}')
                if name == 'geometry':
                    if key not in GEOMETRY or value.dimension != GEOMETRY[key]:
                        raise ValueError(f'unknown geometry key or wrong dimension: {key}')
                    if (value.value is not None and value.dimension in ('length', 'area')
                            and 'station' not in key and 'aft_of_nose' not in key and value.value <= 0):
                        raise ValueError(f'geometry size must be positive: {key}')
            object.__setattr__(self, name, MappingProxyType(dict(values)))
        for name, dimensions in (('nominal_mass', ('mass',)), ('reported_weight', ('force', 'ambiguous'))):
            q = getattr(self, name)
            if not isinstance(q, Quantity) or q.dimension not in dimensions:
                raise ValueError(f'{name} has incompatible units')
            if q.value is not None and q.value <= 0:
                raise ValueError(f'{name} must be positive when known')
        for name, cls in (('mass_points', MassPoint), ('load_locations', NamedPoint), ('structural_points', NamedPoint)):
            items = _sequence(getattr(self, name), name)
            if any(not isinstance(item, cls) for item in items):
                raise ValueError(f'{name} contains wrong record type')
            _unique([p.source_id for p in items], f'{name} source_id')
            if cls is NamedPoint:
                _unique([p.name for p in items], f'{name} name')
            object.__setattr__(self, name, items)
        notes = _sequence(self.notes, 'notes')
        for note in notes:
            _text(note, 'note')
        object.__setattr__(self, 'notes', notes)

    def to_dict(self):
        out = {f.name: getattr(self, f.name) for f in fields(self)}
        for name in ('geometry', 'qualitative_facts'):
            out[name] = {k: v.to_dict() for k, v in out[name].items()}
        for name in ('reported_weight', 'nominal_mass'):
            out[name] = out[name].to_dict()
        for name in ('mass_points', 'load_locations', 'structural_points'):
            out[name] = [v.to_dict() for v in out[name]]
        out['notes'] = list(self.notes)
        return out

    @classmethod
    def from_dict(cls, data):
        d = dict(_object(data, [f.name for f in fields(cls)], 'FixedConfiguration'))
        for name, kind in (('geometry', Quantity), ('qualitative_facts', Fact)):
            if not isinstance(d[name], dict):
                raise ValueError(f'{name} must be an object')
            d[name] = {key: kind.from_dict(value) for key, value in d[name].items()}
        for name in ('reported_weight', 'nominal_mass'):
            d[name] = Quantity.from_dict(d[name])
        for name, kind in (('mass_points', MassPoint), ('load_locations', NamedPoint), ('structural_points', NamedPoint)):
            d[name] = tuple(kind.from_dict(v) for v in _sequence(d[name], name))
        return cls(**d)

    def to_mass_model(self):
        if not self.mass_points:
            raise ValueError('explicit mass_points required; nominal mass supplies no distribution')
        try:
            with np.errstate(over='raise', invalid='raise', divide='raise'):
                model = MassModel([p.mass.require_si('mass') for p in self.mass_points],
                                  [p.location.si_vector() for p in self.mass_points], self.datum_id)
                model.require_rigid_inertia()
        except FloatingPointError as exc:
            raise ValueError('mass distribution arithmetic overflow/invalid operation') from exc
        return model

    def translate_to_cg(self, location: Location):
        if not isinstance(location, Location):
            raise ValueError('translation requires a datum-relative Location in B axes')
        return readonly_copy(location.si_vector() - self.to_mass_model().cg_from_datum_B_m)

    def named_point_CG_B_m(self, kind, name):
        if kind not in ('load_locations', 'structural_points'):
            raise ValueError('kind must be load_locations or structural_points')
        for point in getattr(self, kind):
            if point.name == name:
                return self.translate_to_cg(point.location)
        raise ValueError(f'unknown {kind} reference: {name}')

    def assessment(self):
        missing = {key: [] for key in ('geometry', 'mass', 'loads', 'structural')}
        diagnostics = []
        for key in GEOMETRY:
            if key == 'wing_le_alternative_aft_of_nose':
                continue  # An alternative is not a required design input.
            if key not in self.geometry or self.geometry[key].si_value is None:
                missing['geometry'].append(key)
        model = None
        try:
            model = self.to_mass_model()
        except (ValueError, RuntimeError) as exc:
            missing['mass'].append(str(exc))
        if self.reported_weight.dimension == 'ambiguous' and self.reported_weight.value is not None:
            diagnostics.append('reported_weight unit lb is ambiguous; no mass/force conversion applied')
        if model is not None and self.nominal_mass.si_value is not None:
            difference = model.mass_kg-self.nominal_mass.si_value
            limit = 1e-9+1e-6*self.nominal_mass.si_value
            diagnostics.append(f'nominal_mass difference_kg={difference:.12g}; limit_kg={limit:.12g}; '
                               f'consistent={abs(difference) <= limit}')
        for section, name in (('loads', 'load_locations'), ('structural', 'structural_points')):
            points = getattr(self, name)
            if not points:
                missing[section].append(name)
            for point in points:
                for axis in ('x', 'y', 'z'):
                    if getattr(point.location, axis).si_value is None:
                        missing[section].append(f'{point.name}.{axis}')
        # Location inventories are not force models or structural constitutive models.
        missing['loads'].append('aerodynamic/propulsive load model and validity evidence (outside this schema)')
        missing['structural'].append('load paths, stiffness, constraints and allowables (outside this schema)')
        return MappingProxyType({
            'missing_inputs': MappingProxyType({k: tuple(v) for k, v in missing.items()}),
            'consistency_diagnostics': tuple(diagnostics),
            'mass_adapter_ready': model is not None,
            'aero_ready': False, 'structural_ready': False,
            'model_validation': self.model_validation, 'design_acceptance': self.design_acceptance,
        })


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key: {key}')
        result[key] = value
    return result


def load_configuration(path: str | Path):
    return FixedConfiguration.from_dict(json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=_unique_object))


def save_configuration(config: FixedConfiguration, path: str | Path):
    Path(path).write_text(json.dumps(config.to_dict(), indent=2, allow_nan=False)+'\n', encoding='utf-8')
