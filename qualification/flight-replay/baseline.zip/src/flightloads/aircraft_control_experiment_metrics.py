"""Read-only learning metrics; missing evidence never becomes zero or success."""
from copy import deepcopy
import math
from .aircraft_workspace import resolve_components
from .aircraft_controller import attitude_error_body_deg

METRICS=[dict(key=k,label=l,unit=u,description=d) for k,l,u,d in (
 ('cg_station_in','Aircraft CG station','in','Weighted resolved mass station, positive aft from nose.'),
 ('battery_station_in','Battery station','in','Resolved battery station, positive aft; differs from aircraft CG.'),
 ('trim_left_deg','Left-tail trim candidate','deg','Candidate angle, including failed trim. A candidate is not proof of balance.'),
 ('trim_right_deg','Right-tail trim candidate','deg','Candidate angle, including failed trim. A candidate is not proof of balance.'),
 ('trim_aileron_deg','Aileron trim candidate','deg','Candidate angle, including failed trim.'),
 ('headroom_left_deg','Left-tail travel margin','deg','Smallest distance from left-tail candidate to either stop. Negative means outside travel.'),
 ('headroom_right_deg','Right-tail travel margin','deg','Smallest distance from right-tail candidate to either stop. Negative means outside travel.'),
 ('headroom_aileron_deg','Aileron travel margin','deg','Smallest distance from aileron candidate to either stop. Negative means outside travel.'),
 ('trim_headroom_deg','Smallest trim travel margin','deg','Smallest distance from candidate angle to either stop across three surfaces. Negative means outside travel.'),
 ('recovery_time_s','Recovery settling time','s','Start of the final uninterrupted qualifying dwell, only for a completed run whose attitude-recovery check is met.'),
 ('capture_time_s','Capture settling time','s','Start of final simultaneous capture dwell, only when the completed run meets capture. Otherwise unavailable.'),
 ('peak_attitude_deg','Peak orientation error','deg','Maximum total quaternion orientation error from original trim over recorded history.'),
 ('peak_roll_rate_deg_s','Peak roll rate magnitude','deg/s','Maximum absolute body x rotation rate over recorded history.'),
 ('peak_pitch_rate_deg_s','Peak pitch rate magnitude','deg/s','Maximum absolute body y rotation rate over recorded history.'),
 ('peak_yaw_rate_deg_s','Peak yaw rate magnitude','deg/s','Maximum absolute body z rotation rate over recorded history.'),
 ('roll_overshoot_deg','Roll overshoot past trim','deg','Largest roll component opposite the initial trim-relative error. Unavailable for zero initial roll error; original trim, not moving desired attitude.'),
 ('yaw_overshoot_deg','Yaw overshoot past trim','deg','Largest yaw component opposite the initial trim-relative error. Unavailable for zero initial yaw error; original trim, not moving desired attitude.'),
 ('pitch_overshoot_deg','Pitch overshoot past trim','deg','Largest pitch component opposite the initial trim-relative error. Unavailable for zero initial pitch error; original trim, not moving capture command.'),
 ('speed_error_peak_ft_s','Peak airspeed error','ft/s','Maximum absolute departure from the declared airspeed target.'),
 ('path_error_peak_deg','Peak flight-path error','deg','Maximum absolute departure from the outer flight-path target, or zero degrees when absent.'),
 ('height_deviation_peak_ft','Peak height change','ft','Maximum absolute change from first accepted height, not an altitude-hold target.'),
 ('final_attitude_ptp_deg','Final-window orientation variation','deg','Maximum minus minimum orientation error in the final requested dwell window ending at the last accepted sample. Variation is not a stability proof.'),
 ('final_rate_ptp_deg_s','Final-window rate variation','deg/s','Largest signed rate range among body axes in the final requested dwell window. Can reflect trend or oscillation, not causal proof.'),
 ('rate_limited_max_s','Worst surface slew-limited duration','s','Largest recorded rate-limited duration among three surfaces; not the sum or union of their intervals.'),
 ('travel_limited_max_s','Worst surface stop duration','s','Largest recorded travel-limited duration among three surfaces; not the sum or union of their intervals.'),
)]


def finite(v):
    try:return type(v) in (int,float) and math.isfinite(v)
    except OverflowError:return False


def number(v):
    if not finite(v):raise ValueError('Unavailable number')
    return v


def series(rows,read):
    values=[]
    for row in rows:
        try:v=read(row)
        except (KeyError,TypeError,IndexError,ValueError):return []
        if not finite(v):return []
        values.append(v)
    return values


def aggregate(values,kind='max'):
    if not values or not all(finite(v) for v in values):return None
    return max(values)-min(values) if kind=='range' else max(values)


def summarize(report):
    truth=report.get('truth') or [];inputs=report.get('inputs') or {};bench=inputs.get('bench') or {};candidate=(report.get('trim') or {}).get('candidate') or {};controls=candidate.get('controls') or {};outcomes=report.get('outcomes') or {};recorded=report.get('metrics') or {}
    m={d['key']:None for d in METRICS}
    try:
        cs=resolve_components(inputs['definition']);weights=[c['weight_lbf'] for c in cs];stations=[c['station_in'] for c in cs]
        if weights and all(finite(w) and w>=0 for w in weights) and sum(weights)>0 and all(finite(s) for s in stations):m['cg_station_in']=sum(w*s for w,s in zip(weights,stations))/sum(weights)
        battery=next((c for c in cs if c['id']=='battery'),None)
        if battery and finite(battery['station_in']):m['battery_station_in']=battery['station_in']
    except (ValueError,KeyError,TypeError):pass
    margins=[]
    for surface,key in [('left_tail','trim_left_deg'),('right_tail','trim_right_deg'),('aileron','trim_aileron_deg')]:
        v=controls.get(surface+'_deg');m[key]=v if finite(v) else None;a=bench.get('actuators',{}).get(surface,{})
        if finite(v) and finite(a.get('min_deg')) and finite(a.get('max_deg')):
            pair=[v-a['min_deg'],a['max_deg']-v];margins.extend(pair);m['headroom_'+key.removeprefix('trim_')]=min(pair)
    if len(margins)==6:m['trim_headroom_deg']=min(margins)
    for key,name in [('recovery_time_s','attitude_recovery'),('capture_time_s','sustained_capture')]:
        o=outcomes.get(name) or {};t=o.get('final_dwell_start_s')
        if report.get('status')=='completed' and o.get('met') is True and finite(t):m[key]=t
    m['peak_attitude_deg']=aggregate(series(truth,lambda r:r['attitude_error_deg']))
    for i,axis in enumerate(('roll','pitch','yaw')):m['peak_'+axis+'_rate_deg_s']=aggregate(series(truth,lambda r:abs(number(r['state_SI'][10+i]))*180/math.pi))
    try:
        q=candidate['state_SI'][6:10]
        errors=[]
        if len(q)!=4 or not all(finite(v) for v in q):raise ValueError('Missing trim orientation')
        for row in truth:
            qi=row['state_SI'][6:10]
            if len(qi)!=4 or not all(finite(v) for v in qi):raise ValueError('Missing orientation')
            errors.append([float(v) for v in attitude_error_body_deg(qi,q)])
        for axis,name in enumerate(('roll','pitch','yaw')):
            values=[e[axis] for e in errors]
            if values and all(finite(v) for v in values) and abs(values[0])>1e-8:m[name+'_overshoot_deg']=max(0.,max(-math.copysign(1.,values[0])*v for v in values))
    except (ValueError,KeyError,TypeError,IndexError):pass
    target=bench.get('target',{}).get('airspeed_ft_s');path=(bench.get('outer_loop') or {}).get('flight_path_target_deg',0.)
    if finite(target):m['speed_error_peak_ft_s']=aggregate(series(truth,lambda r:abs(number(r['airspeed_ft_s'])-target)))
    if finite(path):m['path_error_peak_deg']=aggregate(series(truth,lambda r:abs(number(r['flight_path_deg'])-path)))
    if truth and finite(truth[0].get('height_ft')):m['height_deviation_peak_ft']=aggregate(series(truth,lambda r:abs(number(r['height_ft'])-truth[0]['height_ft'])))
    dwell=bench.get('criteria',{}).get('dwell_s');window=[]
    if truth and finite(dwell):window=[r for r in truth if r['time_s']>=max(truth[0]['time_s'],truth[-1]['time_s']-dwell)]
    m['final_attitude_ptp_deg']=aggregate(series(window,lambda r:r['attitude_error_deg']),'range')
    m['final_rate_ptp_deg_s']=aggregate([aggregate(series(window,lambda r:number(r['state_SI'][10+i])*180/math.pi),'range') for i in range(3)])
    for key,field in [('rate_limited_max_s','rate_limit_duration_s'),('travel_limited_max_s','travel_limit_duration_s')]:
        values=recorded.get(field);m[key]=aggregate(values) if isinstance(values,list) and len(values)==3 else None
    return dict(status=report.get('status'),stop_reason=report.get('stop_reason'),trim_status=(report.get('trim') or {}).get('status'),outcomes=deepcopy(outcomes),inputs_sha256=report.get('inputs_sha256'),report_sha256=report.get('report_sha256'),metrics=m)
