"""P6b: frozen gain-schedule study across the launch envelope (issue #221).

The manifest (cases, candidates, criteria, selection rule, verification plan) is built
deterministically here and committed as data/experiments/p6b-manifest.json BEFORE any
search result exists. The runner then:

  1. development: every candidate on every development case;
  2. selection: the frozen rule below, applied to development results only;
  3. reserved: the selected candidate and the unscheduled baseline on the reserved cases
     (never seen during selection);
  4. verification: exact replay and fixed-clock refinement (plant dt 0.01 vs 0.005 s)
     of the selected candidate on one development case.

Every run outcome is kept. Capture criteria are the #149/E2 criteria, unchanged.
See docs/mechanics/GAIN_SCHEDULING.md.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path

import numpy as np

SCHEMA = 'gain-schedule-study-v1'
ROOT = Path(__file__).resolve().parents[2]


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def base_bench():
    """E2 capture bench started from tube exit, 130 ft/s capture target (within the estimated
    propeller's level-trim window, #199 F1), ground floor instead of the 900 ft trim floor."""
    from .aircraft_controller_capture_contract import default_capture_bench, default_launch_phases
    bench = default_capture_bench()
    bench['disturbance'].update(airspeed_delta_ft_s=0.0)
    bench['criteria'].update(minimum_height_ft=0.0)
    bench['target'].update(airspeed_ft_s=130.0)
    bench['launch'] = default_launch_phases()
    return bench


def _development_cases():
    cases = []
    for speed in (110.0, 150.0, 190.0):
        for elevation in (45.0, 70.0):
            for tip_name, tip in (('none', [0.0, 0.0, 0.0]), ('tipoff', [30.0, -20.0, 10.0])):
                cases.append(dict(id=f'dev-v{speed:.0f}-el{elevation:.0f}-{tip_name}', exit_speed_ft_s=speed,
                                  tube_elevation_deg=elevation, tip_off_rate_B_deg_s=tip, battery_weight_scale=1.0,
                                  actuator_rate_deg_s=90.0, actuator_delay_s=0.02))
    return cases


def _reserved_cases(seed=221, count=16):
    rng = np.random.default_rng(seed)
    cases = []
    for k in range(count):
        tip = [float(np.clip(rng.normal(0.0, 15.0), -40.0, 40.0)) for _ in range(3)]
        cases.append(dict(id=f'res-{k:02d}', exit_speed_ft_s=round(float(rng.uniform(100.0, 200.0)), 3),
                          tube_elevation_deg=round(float(rng.uniform(45.0, 80.0)), 3),
                          tip_off_rate_B_deg_s=[round(t, 3) for t in tip],
                          battery_weight_scale=round(float(np.clip(rng.normal(1.0, 0.05), 0.9, 1.1)), 4),
                          actuator_rate_deg_s=round(float(rng.uniform(70.0, 110.0)), 2),
                          actuator_delay_s=float(rng.choice([0.01, 0.02, 0.03, 0.04]))))
    return cases


def _candidates():
    out = []
    for exponent in (None, 0.5, 1.0):
        for attitude, rate in ((4.0, 20.0), (6.0, 30.0), (8.0, 40.0)):
            name = ('unscheduled' if exponent is None else f'q^{exponent:g}') + f'-K{attitude:g}/{rate:g}'
            out.append(dict(id=name, exponent=exponent, attitude_gain_per_s=attitude, rate_gain_per_s=rate))
    return out


def _candidates_v2():
    """v2 (after v1 found the proportional-only, 90 deg/s^2-limited rate loop cannot hold the
    pitch-over rate): rate integral and acceleration limit enter the search; E1 gains 6/30 kept."""
    out = []
    for exponent in (None, 1.0):
        for ki in (0.0, 10.0, 30.0):
            for accel in (90.0, 360.0):
                name = ('unscheduled' if exponent is None else f'q^{exponent:g}') + f'-Ki{ki:g}-A{accel:g}'
                out.append(dict(id=name, exponent=exponent, attitude_gain_per_s=6.0, rate_gain_per_s=30.0,
                                rate_integral_gain_per_s2=ki, integral_limit_deg=20.0, accel_limit_deg_s2=accel))
    return out


def _candidates_v3():
    """v3 (after v2 found launches level off at 80-90 ft/s, below the ~120 ft/s level-flight floor,
    and capture then saturates): the speed-recovery launch phase (#199 D-P6b-2) enters; the E2
    baseline without recovery is kept for comparison."""
    out = [dict(id='baseline-E2', exponent=None, attitude_gain_per_s=6.0, rate_gain_per_s=30.0,
                rate_integral_gain_per_s2=0.0, integral_limit_deg=5.0, accel_limit_deg_s2=90.0, speed_recovery=None)]
    for exponent in (None, 1.0):
        for ki in (10.0, 30.0):
            for pitch in (-10.0, -20.0):
                name = ('unscheduled' if exponent is None else f'q^{exponent:g}') + f'-Ki{ki:g}-dive{-pitch:g}'
                out.append(dict(id=name, exponent=exponent, attitude_gain_per_s=6.0, rate_gain_per_s=30.0,
                                rate_integral_gain_per_s2=ki, integral_limit_deg=20.0, accel_limit_deg_s2=360.0,
                                speed_recovery=dict(min_airspeed_ft_s=125.0, pitch_deg=pitch, dwell_s=0.2, max_s=6.0)))
    return out


def build_manifest(version=1):
    if version == 4:
        m = build_manifest(3)
        candidates = [deepcopy(m['candidates'][0])]
        for exponent in (None, 1.0):
            for attitude, rate, integral in ((2., 8., 3.), (3., 12., 5.)):
                candidates.append(dict(id=f"{'unscheduled' if exponent is None else 'q^1'}-K{attitude:g}-{rate:g}-Ki{integral:g}",
                    exponent=exponent, attitude_gain_per_s=attitude, rate_gain_per_s=rate,
                    rate_integral_gain_per_s2=integral, integral_limit_deg=20., accel_limit_deg_s2=360.,
                    speed_recovery=dict(min_airspeed_ft_s=125., pitch_deg=-10., dwell_s=.2, max_s=6.)))
        m.update(version=4, candidates=candidates, reserved_cases=_reserved_cases(seed=2444),
                 previous='p6b-v3-manifest.json (reserved set consumed)',
                 design_note='Issue244: lower-bandwidth PI inner-loop candidates, existing explicit 30deg/s rate-command bound and 360deg/s2 acceleration bound. No hidden phase gains or servo model change. Six development-only probes at dev-v150-el45-tipoff and disturbed trim informed these candidates; reserved seed2444 has not been evaluated. Frozen-lateral sampled pitch diagnostic reports ZOH, delay, poles, margins and finite-amplitude servo limits; nonlinear study is decisive.')
        m['reserved_generation'] = dict(m['reserved_generation'], seed=2444)
        m['selection_rule'] = ['maximize development captures', 'then minimize largest development wing-root bending',
                               'then existing deterministic select() tie break (exponent, Ki, acceleration, dive, attitude gain, manifest order)']
        return m
    if version == 3:
        m = build_manifest(2)
        m.update(version=3, candidates=_candidates_v3(), baseline='baseline-E2',
                 reserved_cases=_reserved_cases(seed=2213), previous='p6b-v2-manifest.json (v2, reserved set consumed)',
                 v2_finding='All v2 candidates failed (0/12, 0/16); refinement failed (chaotic saturated loop). Launches '
                            'level off at 80-90 ft/s, below the ~120 ft/s level-flight floor (#199 F1); capture then '
                            'saturates the tails and loses control. v3 adds the speed-recovery phase (#199 D-P6b-2).')
        m.pop('v1_finding', None)
        m['reserved_generation'] = dict(m['reserved_generation'], seed=2213)
        m['selection_rule'] = ['maximize the number of development cases with sustained capture met',
                               'then minimize the largest wing-root bending |Mx| over all development runs',
                               'then prefer unscheduled, then the smaller Ki, then the shallower dive (manifest order)']
        return m
    if version == 2:
        m = build_manifest(1)
        m.update(version=2, candidates=_candidates_v2(), baseline='unscheduled-Ki0-A90',
                 reserved_cases=_reserved_cases(seed=2212), previous='p6b-manifest.json (v1, reserved set consumed)',
                 v1_finding='All v1 candidates failed (0/12, 0/16). The proportional-only rate loop saturates at the '
                            '90 deg/s^2 acceleration limit, about a 4 deg tail change, and cannot hold the ~30 deg/s '
                            'pitch-over rate a steep launch needs (a 2.4 g path curvature needs ~10 deg). Pitch rate '
                            'stays near 0-3 deg/s; the aircraft climbs ballistically and stalls. Physics sets v2: '
                            'rate integral and acceleration limit enter the search.')
        m['reserved_generation'] = dict(m['reserved_generation'], seed=2212)
        m['selection_rule'] = ['maximize the number of development cases with sustained capture met',
                               'then minimize the largest wing-root bending |Mx| over all development runs',
                               'then prefer unscheduled, then the smaller Ki, then the smaller acceleration limit']
        m['verification'] = dict(case='the development case where the selected candidate has the longest final '
                                      'capture dwell (ties: manifest order; completed runs only)',
                                 refinement='plant dt 0.01 vs 0.005 s, sensor/controller periods fixed',
                                 tolerances='aircraft_controller_study.TOLERANCES (E2)', replay='exact report hash')
        return m
    from .propulsion import default_propulsion
    definition_path = ROOT / 'examples/aircraft-stable.json'
    return dict(
        schema=SCHEMA, issue=221,
        purpose='Schedule the allocation effectiveness with dynamic pressure and evaluate launch-to-capture '
                'over the launch envelope with a reserved case set.',
        definition=dict(path='examples/aircraft-stable.json',
                        sha256=hashlib.sha256(definition_path.read_bytes()).hexdigest()),
        field_case=dict(propulsion=default_propulsion(), note='estimated propeller map (P3d); uniform sea-level air'),
        base_bench=base_bench(),
        schedule_form=dict(mode='dynamic-pressure', min_scale=0.25, max_scale=4.0,
                           law='B(q) = B_trim * clip((q/q_trim)^exponent, min_scale, max_scale)'),
        candidates=_candidates(),
        baseline='unscheduled-K6/30',
        development_cases=_development_cases(),
        reserved_cases=_reserved_cases(),
        reserved_generation=dict(seed=221, exit_speed='U(100,200) ft/s', elevation='U(45,80) deg',
                                 tip_off='N(0,15) deg/s per axis, clipped +/-40', battery_weight='N(1,0.05) clipped [0.9,1.1]',
                                 actuator_rate='U(70,110) deg/s', actuator_delay='choice {0.01,0.02,0.03,0.04} s'),
        criteria_note='Capture criteria are the E2/#149 criteria unchanged: speed +/-2 ft/s, flight path +/-1 deg, '
                      'heading +/-2 deg, body rates <= 1 deg/s simultaneously for the final 5 s of 20 s; '
                      'altitude is clearance only (ground contact stops the run).',
        selection_rule=['maximize the number of development cases with sustained capture met',
                        'then minimize the largest wing-root bending |Mx| over all development runs',
                        'then prefer the smaller exponent (unscheduled < 0.5 < 1), then the smaller gains'],
        verification=dict(case='dev-v150-el45-tipoff', refinement='plant dt 0.01 vs 0.005 s, sensor/controller periods fixed',
                          tolerances='aircraft_controller_study.TOLERANCES (E2)', replay='exact report hash'),
        acceptance='Capture performance is reported as found (pass fractions); nothing is asserted.')


def run_inputs(manifest, case, candidate, plant_dt_s=None):
    from .aircraft_controller_capture_contract import default_schedule
    from .aircraft_controller_contract import default_field_case, make_run_inputs
    definition = json.loads((ROOT / manifest['definition']['path']).read_text())
    if hashlib.sha256((ROOT / manifest['definition']['path']).read_bytes()).hexdigest() != manifest['definition']['sha256']:
        raise ValueError('aircraft definition changed since the manifest was frozen')
    battery = next(c for c in definition['components'] if c['id'] == 'battery')
    battery['weight_lbf'] = battery['weight_lbf']*case['battery_weight_scale']
    bench = deepcopy(manifest['base_bench'])
    bench['launch']['scenario'].update(exit_speed_ft_s=case['exit_speed_ft_s'], tube_elevation_deg=case['tube_elevation_deg'],
                                       tip_off_rate_B_deg_s=list(case['tip_off_rate_B_deg_s']))
    for actuator in bench['actuators'].values():
        actuator.update(rate_deg_s=case['actuator_rate_deg_s'], delay_s=case['actuator_delay_s'])
    bench['controller'].update(attitude_gain_per_s=[candidate['attitude_gain_per_s']]*3,
                               rate_gain_per_s=[candidate['rate_gain_per_s']]*3)
    for key in ('rate_integral_gain_per_s2', 'integral_limit_deg', 'accel_limit_deg_s2'):
        if key in candidate:
            bench['controller'][key] = [candidate[key]]*3
    if candidate.get('speed_recovery') is not None:
        bench['launch']['speed_recovery'] = dict(candidate['speed_recovery'])
    if candidate['exponent'] is not None:
        bench['schedule'] = dict(default_schedule(), exponent=candidate['exponent'],
                                 min_scale=manifest['schedule_form']['min_scale'], max_scale=manifest['schedule_form']['max_scale'])
    if plant_dt_s is not None:
        bench['timing']['plant_dt_s'] = plant_dt_s
    field_case = dict(default_field_case(), propulsion=dict(manifest['field_case']['propulsion']))
    return make_run_inputs(definition, bench=bench, field_case=field_case)


def summarize_run(report, cohort, case, candidate):
    capture = (report.get('outcomes') or {}).get('sustained_capture') or {}
    truth = report.get('truth') or []
    peak = 0.0
    for row in report.get('station_loads') or []:
        for s in row['stations']:
            if s['id'].startswith('wing-root'):
                peak = max(peak, abs(s['moment_B_in_lbf'][0]))
    phases = [dict(time_s=e['time_s'], reason=e['reason'], trigger=e.get('trigger'))
              for e in report.get('events') or [] if e['kind'] == 'launch-phase']
    return dict(cohort=cohort, case=case['id'], candidate=candidate['id'], status=report['status'],
                stop_reason=report['stop_reason'], captured=bool(capture.get('met')),
                capture_reason=capture.get('reason'), first_entry_time_s=capture.get('first_entry_time_s'),
                final_dwell_duration_s=capture.get('final_dwell_duration_s'), phases=phases,
                min_height_ft=min((r['height_ft'] for r in truth), default=None),
                final_airspeed_ft_s=truth[-1]['airspeed_ft_s'] if truth else None,
                peak_wing_root_bending_in_lbf=peak, inputs_sha256=report['inputs_sha256'],
                report_sha256=report['report_sha256'])


def _job(args):
    from .aircraft_controller_run import run_bench
    manifest, cohort, case, candidate = args
    return summarize_run(run_bench(run_inputs(manifest, case, candidate)), cohort, case, candidate)


def select(manifest, development):
    """The frozen selection rule applied to development summaries only."""
    order = {c['id']: k for k, c in enumerate(manifest['candidates'])}
    score = {}
    for c in manifest['candidates']:
        rows = [r for r in development if r['candidate'] == c['id']]
        if len(rows) != len(manifest['development_cases']):
            raise ValueError(f'candidate {c["id"]} lacks development results')
        exponent_rank = -1 if c['exponent'] is None else c['exponent']
        score[c['id']] = (-sum(r['captured'] for r in rows), max(r['peak_wing_root_bending_in_lbf'] for r in rows),
                          exponent_rank, c.get('rate_integral_gain_per_s2', 0.0), c.get('accel_limit_deg_s2', 0.0),
                          -((c.get('speed_recovery') or {}).get('pitch_deg', 0.0)),
                          c['attitude_gain_per_s'], order[c['id']])
    return min(score, key=score.get), {k: list(v[:2]) for k, v in score.items()}


def run_pool(jobs, workers):
    import multiprocessing
    with multiprocessing.get_context('spawn').Pool(workers) as pool:
        return list(pool.imap(_job, jobs))


def verification_case(manifest, development, selected):
    """v1: the named case. v2: the selected candidate's completed development case with the
    longest final capture dwell (ties: manifest order)."""
    if manifest.get('version', 1) == 1:
        return next(c for c in manifest['development_cases'] if c['id'] == manifest['verification']['case'])
    rows = {r['case']: r for r in development if r['candidate'] == selected and r['status'] == 'completed'}
    ranked = [c for c in manifest['development_cases'] if c['id'] in rows]
    if not ranked:
        return None
    return max(ranked, key=lambda c: (rows[c['id']]['final_dwell_duration_s'] or 0.0, -manifest['development_cases'].index(c)))
