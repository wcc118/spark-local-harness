"""Independent chain-rule longitudinal verification of the production strip plant.

State [u,w,q,theta]: ft/s, ft/s, rad/s, rad. Fixed controls, uniform atmosphere,
zero wind, symmetric level trim. No fitted derivatives or changed aero parameters.
"""
import math
from copy import deepcopy
import numpy as np
from .aircraft_controller_plant import ControllerPlant
from .aircraft_controller_trim import trim_bench
from .aircraft_full_angle_field import FullAngleField, default_controls
from .aircraft_full_angle_polar import BLEND_START_DEG, BLEND_END_DEG
from .aircraft_release import quaternion_321
from .aircraft_transient import FT_M, G_N
from .state import RigidState


def polar_value_slope(alpha, kind, parameters, aspect_ratio):
    """CL,CD,CM and their analytic derivatives per radian, independently expanded."""
    p = parameters
    if not math.isfinite(alpha) or abs(alpha) >= math.pi:
        raise ValueError('analytic polar requires an angle strictly inside (-pi,pi)')
    start, end = map(math.radians, (BLEND_START_DEG, BLEND_END_DEG))
    t = max(0., min(1., (abs(alpha)-start)/(end-start)))
    blend = t*t*(3-2*t)
    db = 6*t*(1-t)*math.copysign(1., alpha)/(end-start) if 0 < t < 1 else 0.
    slope = p[kind+'_cl_alpha_per_rad']
    cl = p[kind+'_cl0']+slope*alpha
    drag_factor = math.pi*aspect_ratio*p['efficiency']
    low = np.array([cl, p[kind+'_cd0']+cl*cl/drag_factor, p[kind+'_cm0']])
    dlow = np.array([slope, 2*cl*slope/drag_factor, 0.])
    s, c = math.sin(alpha), math.cos(alpha)
    lift = p['section_cl45']*math.sin(2*alpha)
    dlift = 2*p['section_cl45']*math.cos(2*alpha)
    drag = p[kind+'_cd0']*c*c+p['section_cd90']*s*s
    ddrag = 2*(p['section_cd90']-p[kind+'_cd0'])*s*c
    arm = p['high_angle_cp_fraction']-.25
    high = np.array([lift, drag, -arm*(lift*c+drag*s)])
    dhigh = np.array([dlift, ddrag, -arm*(dlift*c-lift*s+ddrag*s+drag*c)])
    return (1-blend)*low+blend*high, (1-blend)*dlow+blend*dhigh+db*(high-low)


def strip_force_jacobian(field, state, cg_B_in):
    """d[X,Z,My]/d[u,w,q], lbf and in-lbf, at fixed geometry/controls.

    Geometry is shared; no production force evaluation or finite difference is
    used here. Span drag, body drag, and free section couples are differentiated.
    """
    u, w, q, _ = state
    rho, p = field.configuration['environment']['density_slug_ft3'], field.configuration['parameters']
    force_jac, moment_jac = np.zeros((3, 3)), np.zeros((3, 3))
    for element in field._elements:
        kind = element['kind']
        if kind == 'propulsion':
            continue  # Fixed thrust/couple have zero state derivative in this contract.
        arm_in = np.asarray(element['position_B_in'])-cg_B_in
        arm = arm_in/12
        velocity = np.array([u+q*arm[2], 0., w-q*arm[0]])
        jac = np.array([[1., 0., arm[2]], [0., 0., 0.], [0., 1., -arm[0]]])
        couple_jac = np.zeros((3, 3))
        if kind in ('wing', 'tail'):
            c, n, span = (np.asarray(element[k]) for k in ('chord_unit_B', 'normal_unit_B', 'span_unit_B'))
            vc, vn, vs = velocity@c, velocity@n, velocity@span
            dc, dn, ds = c@jac, n@jac, span@jac
            speed = math.hypot(vc, vn)
            if speed < 1e-6:
                raise ValueError('nonzero strip-plane speed required for linearization')
            angle = math.atan2(vn, vc)
            if abs(angle) >= math.radians(30):
                raise ValueError('longitudinal verification restricted to local strip angles below30deg')
            coeff, slope = polar_value_slope(angle, kind, p, element['aspect_ratio'])
            da = (vc*dn-vn*dc)/speed**2
            dv = (vc*dc+vn*dn)/speed
            lift_dir, drag_dir = vn*c-vc*n, vc*c+vn*n
            dl = np.outer(c, dn)-np.outer(n, dc)
            dd = np.outer(c, dc)+np.outer(n, dn)
            scale = .5*rho*element['area_in2']/144
            force = coeff[0]*lift_dir-coeff[1]*drag_dir
            derivative = (np.outer(lift_dir, slope[0]*da)+coeff[0]*dl
                          -np.outer(drag_dir, slope[1]*da)-coeff[1]*dd)
            df = scale*(np.outer(force, dv)+speed*derivative)
            df -= rho*p['edge_cd']*element['edge_area_in2']/144*abs(vs)*np.outer(span, ds)
            couple_jac = scale*element['chord_in']*np.outer(span, 2*speed*dv*coeff[2]+speed**2*slope[2]*da)
        else:
            mask = np.array([0., 1., 1.] if kind == 'body-crossflow' else [1., 0., 0.])
            v, j = velocity*mask, jac*mask[:, None]
            speed = np.linalg.norm(v)
            scale = .5*rho*element['area_in2']/144*p['body_crossflow_cd' if kind == 'body-crossflow' else 'body_axial_cd']
            df = -scale*(speed*j+np.outer(v, v@j/speed)) if speed > 0 else np.zeros((3, 3))
        force_jac += df
        moment_jac += np.cross(arm_in, df.T).T+couple_jac
    return np.vstack([force_jac[0], force_jac[2], moment_jac[1]])


class StripLongitudinalModel:
    """Production numerical RHS compared with independent analytic strip derivatives."""
    def __init__(self, inputs):
        self.plant = ControllerPlant(inputs)
        case = self.plant.inputs['field_case']
        if any(case.get(k) is not None for k in ('atmosphere', 'propulsion', 'gusts', 'aero_dataset')) or any(case['wind_N_ft_s']):
            raise ValueError('cross-check requires uniform atmosphere, fixed thrust, and zero wind/gusts')
        if inputs['bench']['target']['heading_deg'] != 0:
            raise ValueError('cross-check requires heading zero')
        self.trim = trim_bench(inputs, verify_hold=False)
        if self.trim['status'] != 'feasible':
            raise ValueError('cross-check requires feasible production trim')
        candidate = self.trim['candidate']
        self.controls = candidate['controls']
        mp = self.plant.mass_properties
        if (abs(candidate['roll_deg']) > 1e-8 or abs(self.controls['left_tail_deg']-self.controls['right_tail_deg']) > 1e-8
                or abs(self.controls['aileron_deg']) > 1e-8
                or np.max(np.abs(np.array(mp['inertia_CG'])[[0, 1], [1, 2]])) > 1e-10):
            raise ValueError('cross-check requires symmetric longitudinal trim and inertia')
        self.state_SI = RigidState.from_vector(candidate['state_SI'])
        theta = math.radians(candidate['alpha_deg'])
        self.state0 = np.array([self.state_SI.v_CG_B_mps[0]/FT_M, self.state_SI.v_CG_B_mps[2]/FT_M, 0., theta])
        controls = dict(default_controls(), **case['installation'],
            common_tail_deg=self.controls['left_tail_deg'], differential_tail_deg=0.,
            aileron_deg=0., thrust_lbf=self.controls['thrust_lbf'])
        self.field = FullAngleField(inputs['definition'], parameters=case['parameters'],
            environment=case['environment'], controls=controls, settings=case['discretization'])
        self.mass_slug = mp['weight_lbf']/(G_N[2]/FT_M)
        self.inertia = mp['inertia_CG'][1][1]
        self.cg = np.array(mp['cg_B_in'])

    def rhs(self, state):
        u, w, q, theta = state
        s = RigidState(self.state_SI.r_CG_N_m, [u*FT_M, 0., w*FT_M], quaternion_321(0., theta, 0.), [0., q, 0.])
        derivative = self.plant.evaluate(s, self.controls)[2]
        return np.array([derivative.vdot_B_mps2[0]/FT_M, derivative.vdot_B_mps2[2]/FT_M,
                         derivative.omegadot_B_radps2[1], q])

    def analytic_jacobian(self):
        aero = strip_force_jacobian(self.field, self.state0, self.cg)
        u, w, q, theta = self.state0
        jac = np.zeros((4, 4))
        jac[:3, :3] = aero/np.array([self.mass_slug, self.mass_slug, self.inertia])[:, None]
        jac[0, 1] -= q
        jac[0, 2] -= w
        jac[1, 0] += q
        jac[1, 2] += u
        jac[0, 3] = -G_N[2]/FT_M*math.cos(theta)
        jac[1, 3] = -G_N[2]/FT_M*math.sin(theta)
        jac[3, 2] = 1.
        return jac

    def numeric_jacobian(self, factor=1.):
        if not math.isfinite(factor) or factor <= 0:
            raise ValueError('positive finite step factor required')
        cols = []
        for i, h in enumerate(np.array([.001, .001, 1e-5, 1e-5])*factor):
            delta = np.eye(4)[i]*h
            cols.append((self.rhs(self.state0+delta)-self.rhs(self.state0-delta))/(2*h))
        return np.column_stack(cols)

    def report(self):
        analytic = self.analytic_jacobian()
        coarse, fine = self.numeric_jacobian(), self.numeric_jacobian(.5)
        def modes(matrix):
            return sorted([v for v in np.linalg.eigvals(matrix) if v.imag > 1e-8], key=abs)
        a, c, f = modes(analytic), modes(coarse), modes(fine)
        if len(a) != 2 or len(c) != 2 or len(f) != 2:
            raise ValueError('two oscillatory longitudinal modes required; cannot label phugoid/short-period')
        rows = []
        for name, av, cv, fv in zip(('phugoid', 'short-period'), a, c, f):
            frequency_error = abs(abs(cv)/abs(av)-1)
            refinement_error = abs(cv-fv)/abs(fv)
            rows.append(dict(name=name, analytic_frequency_rad_s=abs(av), numeric_frequency_rad_s=abs(cv),
                analytic_eigenvalue=[av.real, av.imag], numeric_eigenvalue=[cv.real, cv.imag],
                frequency_relative_error=frequency_error, refinement_relative_error=refinement_error,
                passed=bool(frequency_error <= .05 and refinement_error < .01)))
        return dict(schema='strip-longitudinal-crosscheck-v1', state_names=['u', 'w', 'q', 'theta'],
            inputs=self.plant.inputs, trim_candidate=self.trim['candidate'],
            implementation_hashes=self.trim['implementation_hashes'],
            state_units=['ft/s', 'ft/s', 'rad/s', 'rad'], state0=self.state0.tolist(),
            rhs_at_trim=self.rhs(self.state0).tolist(), analytic_A=analytic.tolist(), numeric_A=coarse.tolist(),
            refined_A=fine.tolist(), max_jacobian_error=float(np.max(np.abs(analytic-coarse))),
            modes=rows, passed=all(row['passed'] for row in rows), frequency_tolerance=.05, refinement_tolerance=.01,
            evidence_level='estimate', note='Same-model numerical verification, not physical model validation; legacy different-aero model remains a separate reference.')


def reference_crosscheck(definition=None, airspeed_ft_s=200., field_case=None, include_avl=True):
    """Standalone reference report; different-model results are explicitly not agreement gates."""
    from .aircraft_controller_contract import default_bench, default_field_case, make_run_inputs
    from .aircraft_workspace import stable_example_definition
    from .aircraft_flight import default_condition
    from .aircraft_longitudinal import LongitudinalModel
    from .aircraft_lateral import LateralModel
    definition = deepcopy(stable_example_definition() if definition is None else definition)
    bench = default_bench()
    bench['target']['airspeed_ft_s'] = airspeed_ft_s
    for name in ('left_tail', 'right_tail'):
        bench['actuators'][name].update(min_deg=-20, max_deg=20)
    inputs = make_run_inputs(definition, bench, default_field_case() if field_case is None else field_case)
    model = StripLongitudinalModel(inputs)
    report = model.report()
    legacy_definition = deepcopy(definition)
    legacy_definition['flight_condition'] = {**default_condition(), **definition.get('flight_condition', {}), 'speed_ft_s': airspeed_ft_s}
    comparisons = {}
    for name, cls in [('legacy_longitudinal', LongitudinalModel), ('four_panel_lateral', LateralModel)]:
        try:
            result = cls(legacy_definition).linearization()
            comparisons[name] = dict(status='available', result=result,
                scope='Separate aerodynamic assumptions and own trim; not the production strip model and not a same-model agreement gate.')
        except ValueError as error:
            comparisons[name] = dict(status='unavailable', reason=str(error))
    if include_avl:
        from dataclasses import asdict
        from .avl_model import run_avl
        controls = model.controls
        case = [model.trim['candidate']['alpha_deg'], 0, 0, 0, 0,
                controls['left_tail_deg'], controls['right_tail_deg'], controls['aileron_deg'], 0]
        try:
            comparisons['avl'] = dict(status='available', result=asdict(run_avl(definition, [case])),
                scope='Attached-flow AVL at production trim geometry/controls and Mach0. Different aerodynamic assumptions; raw stability derivatives retained, not claimed agreement with strip model.')
        except (ValueError, RuntimeError, OSError) as error:
            comparisons['avl'] = dict(status='unavailable', reason=str(error))
    else:
        comparisons['avl'] = dict(status='not-requested')
    report['reference_models'] = comparisons
    return report
