"""Uniform Euler-Bernoulli beam with an explicit prescribed-base partition."""
from dataclasses import dataclass
import hashlib
import json
from numbers import Integral, Real
from types import MappingProxyType
import numpy as np
from ._arrays import readonly_copy
from .conventions import rotation_matrix, unit_quaternion
from .loads import AppliedLoads


def vector(value, size, name):
    raw=np.asarray(value)
    if raw.dtype.kind not in 'iuf':
        raise ValueError(f'{name} must contain real numbers')
    out=np.asarray(value,dtype=float)
    if out.shape!=(size,) or not np.all(np.isfinite(out)):
        raise ValueError(f'{name} must be a finite {size}-vector')
    return readonly_copy(out)


def shape_local(s,ell,order=0):
    if isinstance(order,bool) or not isinstance(order,Integral) or not 0<=order<=3:
        raise ValueError('shape derivative order must be integer0..3')
    if order==0: return np.array([1-3*s*s+2*s**3,ell*(s-2*s*s+s**3),3*s*s-2*s**3,ell*(-s*s+s**3)])
    if order==1: return np.array([(-6*s+6*s*s)/ell,1-4*s+3*s*s,(6*s-6*s*s)/ell,-2*s+3*s*s])
    if order==2: return np.array([(-6+12*s)/ell**2,(-4+6*s)/ell,(6-12*s)/ell**2,(-2+6*s)/ell])
    if order==3: return np.array([12/ell**3,6/ell**2,-12/ell**3,6/ell**2])
    raise ValueError('shape derivative order must be 0..3')


@dataclass(frozen=True,init=False)
class BeamModel:
    config: object
    model_id: str
    nodes_m: np.ndarray
    mass_full: np.ndarray
    stiffness_full: np.ndarray
    damping_full: np.ndarray
    rigid_map: np.ndarray
    elastic_extractor: np.ndarray
    mass_free: np.ndarray
    stiffness_free: np.ndarray
    damping_free: np.ndarray
    modes: np.ndarray
    omega_radps: np.ndarray
    area_m2: float
    second_moment_m4: float
    EI_Nm2: float
    mass_per_length_kgpm: float

    def __init__(self,*,length_m=1.,width_m=.02,thickness_m=.001,young_Pa=70e9,
                 density_kgpm3=2700.,elements=4,damping_ratio=.02):
        props=dict(length_m=length_m,width_m=width_m,thickness_m=thickness_m,
                   young_Pa=young_Pa,density_kgpm3=density_kgpm3)
        for name,value in props.items():
            if isinstance(value,bool) or not isinstance(value,Real) or not np.isfinite(value) or value<=0:
                raise ValueError(f'{name} must be finite positive real')
            props[name]=float(value)
        if isinstance(elements,bool) or not isinstance(elements,Integral) or not 1<=elements<=32:
            raise ValueError('elements must be integer1..32')
        if isinstance(damping_ratio,bool) or not isinstance(damping_ratio,Real) or not np.isfinite(damping_ratio) or not 0<=damping_ratio<=.2:
            raise ValueError('damping_ratio must be finite in0..0.2')
        props.update(elements=int(elements),damping_ratio=float(damping_ratio))
        length_m,width_m,thickness_m,young_Pa,density_kgpm3=(props[k] for k in
            ('length_m','width_m','thickness_m','young_Pa','density_kgpm3'))
        try:
            area=width_m*thickness_m; inertia=width_m*thickness_m**3/12
            EI=young_Pa*inertia; mu=density_kgpm3*area
        except OverflowError as exc:
            raise ValueError('section arithmetic overflow') from exc
        if not all(np.isfinite(x) and x>0 for x in (area,inertia,EI,mu)):
            raise ValueError('section arithmetic overflow/underflow')
        nodes=np.linspace(0,length_m,elements+1); ndof=2*len(nodes); ell=length_m/elements
        M=np.zeros((ndof,ndof));K=M.copy(); me=np.zeros((4,4));ke=me.copy()
        points,weights=np.polynomial.legendre.leggauss(4)
        for point,weight in zip(points,weights):
            s=(point+1)/2; N=shape_local(s,ell); curvature=shape_local(s,ell,2)
            me+=mu*ell*weight/2*np.outer(N,N)
            ke+=EI*ell*weight/2*np.outer(curvature,curvature)
        for i in range(elements):
            ids=np.arange(2*i,2*i+4);M[np.ix_(ids,ids)]+=me;K[np.ix_(ids,ids)]+=ke
        mf,kf=M[2:,2:],K[2:,2:]
        if not np.all(np.isfinite(M)) or not np.all(np.isfinite(K)):
            raise ValueError('nonfinite beam matrices')
        if max(np.linalg.cond(mf),np.linalg.cond(kf))>1e14:
            raise ValueError('beam matrices numerically ill-conditioned in SI coordinates')
        chol=np.linalg.cholesky(mf)
        A=np.linalg.solve(chol,kf);A=np.linalg.solve(chol,A.T).T
        eigenvalues,eigenvectors=np.linalg.eigh((A+A.T)/2)
        if np.any(eigenvalues<=0): raise ValueError('nonpositive elastic eigenvalue')
        phi=np.linalg.solve(chol.T,eigenvectors);omega=np.sqrt(eigenvalues)
        for j in range(len(omega)):
            if phi[np.argmax(abs(phi[:,j])),j]<0: phi[:,j]*=-1
        C=mf@phi@np.diag(2*damping_ratio*omega)@phi.T@mf
        R=np.zeros((ndof,2));R[::2,0]=1;R[::2,1]=nodes;R[1::2,1]=1
        B=np.column_stack([-R[2:],np.eye(ndof-2)])
        fullC=B.T@C@B
        for name,value in dict(nodes_m=nodes,mass_full=M,stiffness_full=K,damping_full=fullC,
            rigid_map=R,elastic_extractor=B,mass_free=mf,stiffness_free=kf,damping_free=C,
            modes=phi,omega_radps=omega).items(): object.__setattr__(self,name,readonly_copy(value))
        for name,value in dict(area_m2=area,second_moment_m4=inertia,EI_Nm2=EI,
                               mass_per_length_kgpm=mu).items(): object.__setattr__(self,name,float(value))
        object.__setattr__(self,'config',MappingProxyType(props))
        digest=hashlib.sha256(json.dumps(dict(schema_version=1,**props),sort_keys=True).encode())
        for value in (M,K,C,phi,omega):
            digest.update(np.asarray(value,dtype='<f8').tobytes())
        identity=digest.hexdigest()
        object.__setattr__(self,'model_id','linear-beam-v1:'+identity)

    def shape(self,x_m,*,order=0,side='right'):
        if isinstance(x_m,bool) or not isinstance(x_m,Real) or not np.isfinite(x_m) or not 0<=x_m<=self.nodes_m[-1]:
            raise ValueError('station must lie on beam [0,L]')
        if side not in ('left','right'): raise ValueError('side must be left/right')
        i=int(np.clip(np.searchsorted(self.nodes_m,x_m,side=side)-1,0,len(self.nodes_m)-2))
        ell=self.nodes_m[i+1]-self.nodes_m[i];s=(x_m-self.nodes_m[i])/ell
        result=np.zeros(len(self.mass_full));result[2*i:2*i+4]=shape_local(s,ell,order)
        return readonly_copy(result)

    def point_load(self,x_m,*,force_N,couple_slope_Nm=0.):
        values=vector([force_N,couple_slope_Nm],2,'point load')
        return readonly_copy(values[0]*self.shape(x_m)+values[1]*self.shape(x_m,order=1))

    def uniform_load(self,load_Npm):
        value=vector([load_Npm],1,'uniform load')[0]
        # M R[:,0] is the consistent integral of shape functions times mu.
        return readonly_copy(value/self.mass_per_length_kgpm*(self.mass_full@self.rigid_map[:,0]))

    def static_displacement(self,load_free):
        load=vector(load_free,len(self.mass_free),'free nodal load')
        return readonly_copy(np.linalg.solve(self.stiffness_free,load))

    def recover(self,displacement_free,stations_m,*,side='right'):
        free=vector(displacement_free,len(self.mass_free),'elastic displacement')
        full=np.concatenate([[0,0],free]);stations=np.asarray(stations_m,dtype=float)
        if stations.ndim!=1 or len(stations)==0: raise ValueError('stations must be a nonempty vector')
        values=np.array([[self.shape(x,order=k,side=side)@full for k in range(4)] for x in stations])
        moment=self.EI_Nm2*values[:,2];shear=self.EI_Nm2*values[:,3]
        stress=-self.config['young_Pa']*self.config['thickness_m']/2*values[:,2]
        return MappingProxyType({k:readonly_copy(v) for k,v in dict(stations_m=stations,
            displacement_m=values[:,0],slope_rad=values[:,1],curvature_per_m=values[:,2],
            moment_on_retained_y_Nm=moment,shear_on_retained_z_N=shear,
            stress_positive_z_Pa=stress,stress_negative_z_Pa=-stress).items()})

    def residual_flexibility(self,modes):
        if isinstance(modes,bool) or not isinstance(modes,Integral) or not 1<=modes<=len(self.omega_radps):
            raise ValueError('retained mode count outside model')
        if modes==len(self.omega_radps): return readonly_copy(np.zeros_like(self.stiffness_free))
        phi=self.modes[:,:modes]
        return readonly_copy(np.linalg.solve(self.stiffness_free,np.eye(len(self.mass_free)))-
                             (phi/self.omega_radps[:modes]**2)@phi.T)


@dataclass(frozen=True,init=False)
class Excitation:
    model_id: str
    applied_full: np.ndarray
    applied_rate_full: np.ndarray
    applied_accel_full: np.ndarray
    base_accel: np.ndarray
    base_jerk: np.ndarray
    base_snap: np.ndarray
    effective_free: np.ndarray
    effective_rate_free: np.ndarray
    effective_accel_free: np.ndarray

    def __init__(self,model,applied_full,*,applied_rate_full=None,applied_accel_full=None,
                 base_accel=(0.,0.),base_jerk=(0.,0.),base_snap=(0.,0.)):
        n=len(model.mass_full);zero=np.zeros(n)
        values=dict(applied_full=vector(applied_full,n,'applied_full'),
            applied_rate_full=vector(zero if applied_rate_full is None else applied_rate_full,n,'applied_rate_full'),
            applied_accel_full=vector(zero if applied_accel_full is None else applied_accel_full,n,'applied_accel_full'),
            base_accel=vector(base_accel,2,'base_accel'),base_jerk=vector(base_jerk,2,'base_jerk'),
            base_snap=vector(base_snap,2,'base_snap'))
        for name,value in values.items():object.__setattr__(self,name,value)
        for destination,applied,base in (('effective_free','applied_full','base_accel'),
            ('effective_rate_free','applied_rate_full','base_jerk'),
            ('effective_accel_free','applied_accel_full','base_snap')):
            result=values[applied]-model.mass_full@model.rigid_map@values[base]
            object.__setattr__(self,destination,vector(result[2:],n-2,destination))
        object.__setattr__(self,'model_id',model.model_id)


@dataclass(frozen=True)
class BeamHistory:
    model: BeamModel
    retained_modes: int
    residual_correction: bool
    requested_dt_s: float
    times_s: np.ndarray
    arrays: object

    def __post_init__(self):
        object.__setattr__(self,'times_s',readonly_copy(self.times_s))
        object.__setattr__(self,'arrays',MappingProxyType({k:readonly_copy(v) for k,v in self.arrays.items()}))


def integrate_modal(model,forcing,*,t_final_s=4.,dt_s=.002,retained_modes=None,
                    residual_correction=True,initial_q=None,initial_qdot=None,max_steps=20000):
    """Average-acceleration Newmark on retained mass-normalized modes."""
    count=len(model.omega_radps) if retained_modes is None else retained_modes
    H=model.residual_flexibility(count)
    if type(residual_correction) is not bool:raise ValueError('residual_correction must be bool')
    if not residual_correction:H=np.zeros_like(H)
    for name,value in (('t_final_s',t_final_s),('dt_s',dt_s)):
        if isinstance(value,bool) or not isinstance(value,Real) or not np.isfinite(value) or value<=0:
            raise ValueError(f'{name} must be finite positive')
    if isinstance(max_steps,bool) or not isinstance(max_steps,Integral) or max_steps<1:
        raise ValueError('max_steps must be positive integer')
    if t_final_s>dt_s*max_steps: raise ValueError('max_steps exceeded')
    phi=model.modes[:,:count];omega=model.omega_radps[:count];damping=2*model.config['damping_ratio']*omega
    q=np.zeros(count) if initial_q is None else vector(initial_q,count,'initial_q')
    v=np.zeros(count) if initial_qdot is None else vector(initial_qdot,count,'initial_qdot')
    def sample(t):
        f=forcing(t)
        if not isinstance(f,Excitation) or f.model_id!=model.model_id:
            raise ValueError('forcing must be an Excitation for this model')
        return f
    force=sample(0.)
    a=phi.T@force.effective_free-damping*v-omega**2*q
    times=[];records=[]
    def store(t,f):
        # Omitted modes are quasistatic: their time derivatives are retained explicitly.
        u=phi@q+H@f.effective_free
        udot=phi@v+H@f.effective_rate_free
        uddot=phi@a+H@f.effective_accel_free
        full_u=np.concatenate([[0,0],u]);full_a=np.concatenate([[0,0],uddot])+model.rigid_map@f.base_accel
        residual=model.mass_full@full_a+model.elastic_extractor.T@model.damping_free@udot+model.stiffness_full@full_u-f.applied_full
        response=model.recover(u,model.nodes_m,side='right')
        record=dict(modal_q=q,modal_qdot=v,modal_qddot=a,displacement_free=u,velocity_free=udot,
            acceleration_free=uddot,applied_full=f.applied_full,effective_free=f.effective_free,
            base_accel=f.base_accel,dynamic_residual_free=residual[2:],
            root_reaction_z_N=residual[0],root_reaction_y_Nm=-residual[1],
            equivalent_free_load=model.stiffness_free@u,
            section_force_on_retained_z_N=response['shear_on_retained_z_N'],
            section_moment_on_retained_y_Nm=response['moment_on_retained_y_Nm'],
            stress_positive_z_Pa=response['stress_positive_z_Pa'],stress_negative_z_Pa=response['stress_negative_z_Pa'])
        if not all(np.all(np.isfinite(value)) for value in record.values()): raise RuntimeError('nonfinite elastic response')
        records.append({k:np.array(value,copy=True) for k,value in record.items()});times.append(t)
    t=0.;step=0;store(t,force)
    while t<t_final_s:
        if step>=max_steps:raise ValueError('max_steps exceeded')
        target=min((step+1)*dt_s,t_final_s);h=target-t
        if not np.isfinite(h) or h<=0:raise ValueError('time cannot advance')
        force=sample(target)
        load=phi.T@force.effective_free
        qnext=(load+4/h**2*q+4/h*v+a+damping*(2/h*q+v))/(omega**2+4/h**2+2*damping/h)
        anext=4/h**2*(qnext-q)-4/h*v-a
        vnext=v+h/2*(a+anext)
        q,v,a=qnext,vnext,anext;t=target;step+=1;store(t,force)
    arrays={key:np.asarray([row[key] for row in records]) for key in records[0]}
    return BeamHistory(model,count,residual_correction,dt_s,np.array(times),arrays)


def smooth_pulse(t,*,start=0.,duration=.5):
    """Value and first two derivatives of sin^4(pi*(t-start)/duration), zero outside."""
    for name,value in (('t',t),('start',start),('duration',duration)):
        if isinstance(value,bool) or not isinstance(value,Real) or not np.isfinite(value):
            raise ValueError(f'{name} must be finite real')
    if duration<=0:raise ValueError('pulse duration must be positive')
    if t<=start or t>=start+duration:return np.zeros(3)
    rate=np.pi/duration;angle=rate*(t-start);s,c=np.sin(angle),np.cos(angle)
    return np.array([s**4,4*rate*s**3*c,4*rate**2*(3*s*s*c*c-s**4)])


def reference_forcing(model,t):
    tip=smooth_pulse(t,duration=.5);middle=smooth_pulse(t,start=.15,duration=.65)
    base=smooth_pulse(t,duration=.8)
    ftip=model.point_load(model.nodes_m[-1],force_N=.001)
    fmiddle=model.point_load(model.nodes_m[-1]*.5,force_N=-.0006)
    f=[ftip*tip[k]+fmiddle*middle[k] for k in range(3)]
    return Excitation(model,f[0],applied_rate_full=f[1],applied_accel_full=f[2],
                       base_accel=(.02*base[0],0),base_jerk=(.02*base[1],0),base_snap=(.02*base[2],0))


@dataclass(frozen=True)
class LoadProjection:
    model_id: str
    incidence_tolerance_m: float
    root_CG_B_m: np.ndarray
    q_BS: np.ndarray
    source_ids: tuple[str,...]
    stations_m: np.ndarray
    line_offsets_S_m: np.ndarray
    projected_full: np.ndarray
    omitted_force_S_N: np.ndarray
    omitted_couple_S_Nm: np.ndarray

    def __post_init__(self):
        for name in ('root_CG_B_m','q_BS','stations_m','line_offsets_S_m','projected_full',
                     'omitted_force_S_N','omitted_couple_S_Nm'):
            object.__setattr__(self,name,readonly_copy(getattr(self,name)))
        object.__setattr__(self,'source_ids',tuple(self.source_ids))


def project_applied_loads(model,loads,*,root_CG_B_m,q_BS=(1.,0.,0.,0.),incidence_tolerance_m=1e-9):
    """Project one explicit distributed field into transverse beam virtual work.

    q_BS actively maps local beam S to body B. Points must lie on the beam line
    within the stated geometric tolerance; admitted offsets are retained and
    their force lever arms condensed exactly before selecting bending moment.
    Axial/lateral forces and other moments are returned explicitly as omitted.
    """
    if not isinstance(loads,AppliedLoads):raise ValueError('loads must be AppliedLoads')
    root=vector(root_CG_B_m,3,'root_CG_B_m');q=unit_quaternion(vector(q_BS,4,'q_BS'))
    R=rotation_matrix(q)
    if isinstance(incidence_tolerance_m,bool) or not isinstance(incidence_tolerance_m,Real) or not np.isfinite(incidence_tolerance_m) or incidence_tolerance_m<0:
        raise ValueError('incidence_tolerance_m must be finite nonnegative')
    points=(loads.locations_CG_B_m-root)@R
    force=loads.forces_non_gravity_B_N@R;couples=loads.couples_B_Nm@R
    tol=incidence_tolerance_m;length=model.nodes_m[-1]
    if np.any(abs(points[:,1:])>tol) or np.any(points[:,0]<-tol) or np.any(points[:,0]>length+tol):
        raise ValueError('application point is outside supported beam line/domain')
    stations=np.clip(points[:,0],0,length)
    offsets=points-np.column_stack([stations,np.zeros((len(stations),2))])
    line_couples=couples+np.cross(offsets,force)
    projected=np.zeros(len(model.mass_full))
    for station,F,M in zip(stations,force,line_couples):
        projected+=model.point_load(float(station),force_N=F[2],couple_slope_Nm=-M[1])
    omitted_force=force.copy();omitted_force[:,2]=0
    omitted_couple=line_couples.copy();omitted_couple[:,1]=0
    return LoadProjection(model.model_id,float(tol),root,q,loads.source_ids,stations,offsets,projected,
                          omitted_force,omitted_couple)
