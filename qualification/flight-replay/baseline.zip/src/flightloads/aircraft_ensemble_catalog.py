"""Read-only, allowlisted browsing of a completed aircraft ensemble archive.

Serving verifies identities, not numerical equations. Use the archive replay CLI
for numerical acceptance; the UI reports the recorded checks as such.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
from .aircraft_elastic import digest
from .aircraft_sampling import SPEC, SPEC_ID
from .aircraft_ensemble_archive import MAX_BYTES, plan, read_artifact, complete_summary


class AircraftEnsembleCatalog:
    def __init__(self, directory):
        self.root = Path(directory).absolute()
        if self.root.is_symlink():
            raise ValueError('ensemble directory cannot be a symlink')
        path = self.root / 'manifest.json'
        if path.is_symlink() or path.stat().st_size > MAX_BYTES:
            raise ValueError('invalid ensemble manifest')
        self.raw = path.read_bytes()
        self.manifest = json.loads(self.raw)
        m = self.manifest
        body = dict(m)
        identity = body.pop('study_sha256')
        if m['schema'] != 'aircraft-ensemble-v1' or m['state'] != 'completed' or digest(body) != identity:
            raise ValueError('invalid completed ensemble identity')
        if m['spec'] != SPEC or m['spec_identity'] != SPEC_ID:
            raise ValueError('unsupported ensemble specification')
        expected = plan(m['seed'], m['training_realizations'], m['heldout_realizations'])
        if len(expected) != len(m['records']):
            raise ValueError('event count mismatch')
        self.events = {}; self.cases = {}
        for wanted, row in zip(expected, m['records']):
            for key in wanted.keys() - {'status'}:
                if row[key] != wanted[key]:
                    raise ValueError('event input identity mismatch')
            self.events[row['id']] = row
            for candidate in row['candidates']:
                identifier = row['id'] + f"-t{candidate['index']:04d}"
                if candidate['id'] != identifier or identifier in self.cases or row['status'] != 'completed':
                    raise ValueError('invalid candidate identity')
                self.cases[identifier] = (row, candidate)
            for key in ('rigid_artifact', 'pilot_artifact', 'review_artifact'):
                if key in row and row[key] not in m['artifacts']:
                    raise ValueError('missing event artifact')
        if complete_summary(m['records'], m['numerical_checks']) != m['summary']:
            raise ValueError('ensemble summary mismatch')
        for name, metadata in m['artifacts'].items():
            if not re.fullmatch(r'[A-Za-z0-9_-]+\.json(?:\.gz)?', name) or not 0 < metadata['bytes'] <= MAX_BYTES:
                raise ValueError('invalid artifact metadata')
        for row, candidate in self.cases.values():
            if candidate['artifact'] != candidate['id'] + '.json' or candidate['artifact'] not in m['artifacts']:
                raise ValueError('missing candidate artifact')

    def overview(self):
        result = deepcopy(self.manifest)
        result.pop('artifacts')
        result['serving_verification'] = 'Archive identity and accounting checked; numerical checks are recorded producer results. Run the replay CLI to repeat them.'
        return result

    def event_detail(self, identifier):
        return deepcopy(self.events[identifier])

    def case_detail(self, identifier):
        row, candidate = self.cases[identifier]
        case = read_artifact(self.root, candidate['artifact'], self.manifest['artifacts'])
        body = dict(case); identity = body.pop('canonical_case_sha256')
        if digest(body) != identity or identity != candidate['case_sha256']:
            raise ValueError('case identity mismatch')
        if (case['selected_index'] != candidate['index'] or case['selected_time'] != candidate['time_s'] or
                case['source_history_identity'] != row['pilot_sha256'] or case['definition'] != row['definition']):
            raise ValueError('case/event provenance mismatch')
        history = read_artifact(self.root, row['review_artifact'], self.manifest['artifacts'])
        if history['times_s'][candidate['index']] != candidate['time_s']:
            raise ValueError('case/history time mismatch')
        return dict(case=case, event=deepcopy(row), candidate=deepcopy(candidate), history=history)

    def artifact(self, name):
        if name == 'manifest.json':
            return self.raw
        metadata = self.manifest['artifacts'][name]
        path = self.root / name
        if self.root.is_symlink() or path.is_symlink() or path.stat().st_size > MAX_BYTES:
            raise ValueError('invalid artifact path or size')
        raw = path.read_bytes()
        if len(raw) != metadata['bytes'] or hashlib.sha256(raw).hexdigest() != metadata['sha256']:
            raise ValueError('artifact changed since archive creation')
        return raw
