"""XFOIL attached data and a continuous, explicitly estimate-grade full-angle extension."""
from dataclasses import asdict
import math
import numpy as np


class ExtendedSection:
    """Independent positive/negative Viterna matches; no changes to attached knots.

    Angles in degrees at the interface; CL/CD and quarter-chord CM dimensionless.
    Reverse-flow lift factor 0.7 and post-stall center of pressure at half chord
    are declared estimates, not XFOIL results or measured aircraft aerodynamics.
    """
    def __init__(self, polar, aspect_ratio):
        if not math.isfinite(aspect_ratio) or not 0 < aspect_ratio <= 100:
            raise ValueError('aspect ratio must be finite in (0,100]')
        self.record = asdict(polar) if not isinstance(polar, dict) else dict(polar)
        self.alpha = np.asarray(self.record['converged_alpha_deg'], dtype=float)
        self.values = np.array([self.record[k] for k in ('CL', 'CD', 'CM')], dtype=float).T
        if (len(self.alpha) < 3 or self.values.shape != (len(self.alpha), 3)
                or not np.isfinite(self.alpha).all() or not np.isfinite(self.values).all()
                or not np.all(np.diff(self.alpha) > 0)
                or not -90 < self.alpha[0] < 0 < self.alpha[-1] < 90
                or np.any(self.values[:, 1] < 0)):
            raise ValueError('section needs finite ordered attached knots spanning zero, inside +/-90deg')
        self.aspect_ratio = float(aspect_ratio)
        self.cdmax = 1.11 + .018*self.aspect_ratio
        if max(self.values[:, 1]) > self.cdmax:
            raise ValueError('attached drag exceeds aspect-ratio CDmax; cannot apply this extension')
        self.reverse_cd0 = float(np.interp(0., self.alpha, self.values[:, 1]))

    def evaluate(self, alpha_deg):
        if not math.isfinite(alpha_deg) or not -180 <= alpha_deg <= 180:
            raise ValueError('section angle must be finite inside +/-180deg')
        if self.alpha[0] <= alpha_deg <= self.alpha[-1]:
            value = [float(np.interp(alpha_deg, self.alpha, self.values[:, k])) for k in range(3)]
            return dict(zip(('CL', 'CD', 'CM'), value), source='xfoil')
        sign = 1 if alpha_deg > 0 else -1
        endpoint = -1 if sign > 0 else 0
        match = abs(math.radians(self.alpha[endpoint]))
        clm, cdm, cmm = self.values[endpoint]
        clm *= sign
        a = abs(math.radians(alpha_deg))
        sm, cm = math.sin(match), math.cos(match)
        A = (clm-self.cdmax*sm*cm)*sm/cm**2
        B = (cdm-self.cdmax*sm**2)/cm

        def forward(angle):
            s, c = math.sin(angle), math.cos(angle)
            return self.cdmax*s*c+A*c*c/s, self.cdmax*s*s+B*c

        if a <= math.pi/2:
            cl, cd = forward(a)
        elif a <= math.pi-match:
            cl, cd = forward(math.pi-a)
            cl *= -.7
        else:
            # Close reverse flow to a common periodic endpoint without a singular 1/sin(a).
            fraction = (math.pi-a)/match
            cl = -.7*clm*fraction
            cd = self.reverse_cd0+(cdm-self.reverse_cd0)*fraction
        cl *= sign
        # Blend the endpoint XFOIL moment to the declared flat-plate CP assumption.
        weight = min(1., max(0., (a-match)/(math.pi/2-match)))
        weight = weight*weight*(3-2*weight)
        cm_plate = -.25*(cl*math.cos(math.radians(alpha_deg))+cd*math.sin(math.radians(alpha_deg)))
        moment = (1-weight)*cmm+weight*cm_plate
        if abs(alpha_deg) == 180:
            cl, moment = 0., 0.
        return dict(CL=float(cl), CD=float(max(0., cd)), CM=float(moment), source='viterna')

    def manifest(self):
        return dict(method='two-sided-viterna-v1', aspect_ratio=self.aspect_ratio,
                    cdmax=self.cdmax, reverse_lift_factor=.7,
                    poststall_cp_chord_fraction=.5, attached_record=self.record,
                    evidence_level='estimate', poststall_confidence='low')
