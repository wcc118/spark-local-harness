"""Bounded, inspectable carrier-study archives and sequential CLI execution."""
from copy import deepcopy
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import uuid
from .aircraft_elastic import digest
from .aircraft_carrier_study import (SCHEMA,MAX_CASES,make_plan,execute_sample,event_metrics,summarize)

ARCHIVE_SCHEMA='carrier-study-archive-v1'
MAX_INPUT_BYTES=128*1024
MAX_REPORT_BYTES=16*1024**2
MAX_INDEX_BYTES=8*1024**2
MAX_ARCHIVE_BYTES=128*1024**2
SAMPLE_ID=re.compile(r'(?:mandatory-[a-z][a-z0-9-]{0,39}|(?:monte-carlo|heldout)-[0-9]{4})\Z')
STATES=('prepared','running','finished','cancelled','failed')


def _bytes(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def _sha(raw):return hashlib.sha256(raw).hexdigest()
def _now():return datetime.now(timezone.utc).isoformat()


def _decode(raw):
    def invalid(value):raise ValueError('Nonfinite JSON constant '+value)
    return json.loads(raw,parse_constant=invalid)


def _directory(root):
    return os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)


def _read(root,name,limit):
    if Path(name).name!=name:raise ValueError('Artifact name must be a basename')
    directory=_directory(root)
    try:
        fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=directory)
        with os.fdopen(fd,'rb') as f:
            info=os.fstat(f.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size>limit:raise ValueError('Artifact type or byte limit invalid')
            raw=f.read(limit+1)
            if len(raw)>limit:raise ValueError('Artifact grew beyond byte limit')
            return raw
    finally:os.close(directory)


def _exclusive(root,name,raw,limit):
    if len(raw)>limit:raise ValueError(f'{name} exceeds {limit} byte limit')
    directory=_directory(root);created=False
    try:
        fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=directory);created=True
        with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        os.fsync(directory)
    except Exception:
        if created:os.unlink(name,dir_fd=directory)
        raise
    finally:os.close(directory)
    return dict(name=name,sha256=_sha(raw),bytes=len(raw))


def _write_index(root,index):
    index['updated_utc']=_now();index['summary']=summarize(index['samples'])
    signed=dict(index,index_sha256=digest(index));raw=_bytes(signed)
    if len(raw)>MAX_INDEX_BYTES:raise ValueError('Study index exceeds byte limit')
    name='.index-'+str(uuid.uuid4())+'.tmp';directory=_directory(root)
    try:
        fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=directory)
        with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(name,'index.json',src_dir_fd=directory,dst_dir_fd=directory);os.fsync(directory)
    finally:
        try:os.unlink(name,dir_fd=directory)
        except FileNotFoundError:pass
        os.close(directory)
    return signed


def run_study(spec,output,*,cancel=None,progress=None,order=None):
    """New exclusive archive. Cancellation is checked between cases, never mid-step."""
    spec_raw=_bytes(spec)
    if len(spec_raw)>MAX_INPUT_BYTES:raise ValueError('Study specification exceeds 128 KiB')
    plan=make_plan(spec);planned=plan['samples'];ids=[r['id'] for r in planned]
    sequence=ids if order is None else list(order)
    if len(sequence)!=len(ids) or set(sequence)!=set(ids):raise ValueError('Execution order must be a permutation of planned sample IDs')
    record_bytes={r['id']:_bytes(r) for r in planned}
    if any(len(raw)>MAX_INPUT_BYTES for raw in record_bytes.values()):raise ValueError('Planned input record exceeds 128 KiB')
    used=len(spec_raw)+sum(map(len,record_bytes.values()))
    if used>MAX_ARCHIVE_BYTES-MAX_INDEX_BYTES:raise ValueError('Planned artifacts exceed archive byte budget')
    root=Path(output).absolute();root.mkdir(mode=0o700)
    created=[]
    try:
        spec_artifact=_exclusive(root,'spec.json',spec_raw,MAX_INPUT_BYTES);created.append('spec.json');rows=[]
        for record in planned:
            name='sample-'+record['id']+'-inputs.json';artifact=_exclusive(root,name,record_bytes[record['id']],MAX_INPUT_BYTES);created.append(name)
            rows.append(dict({k:deepcopy(v) for k,v in record.items() if k!='inputs'},input_artifact=artifact,report_artifact=None,metrics=None,event=None,error=None,cloud=[]))
        index=dict(schema=ARCHIVE_SCHEMA,study_id=str(uuid.uuid4()),spec_artifact=spec_artifact,spec_sha256=plan['spec_sha256'],sampler=plan['sampler'],
            implementation_sha256=plan['implementation_sha256'],created_utc=_now(),updated_utc=None,state='prepared',error=None,samples=rows,summary=None)
        created.append('index.json');_write_index(root,index)
    except Exception as error:
        # Only files created by this failed preparation are removed; never traverse or erase an existing output directory.
        # Register index.json for cleanup BEFORE _write_index to handle fsync failures after os.replace.
        # Tolerate only FileNotFoundError when cleaning; collect other errors as notes on original exception.
        cleanup_errors=[]
        for name in created:
            try:(root/name).unlink()
            except FileNotFoundError:pass
            except OSError as cleanup_err:
                cleanup_errors.append(cleanup_err)
        try:root.rmdir()
        except FileNotFoundError:pass
        except OSError as cleanup_err:
            cleanup_errors.append(cleanup_err)
        # Preserve original exception as primary; attach cleanup errors as notes (Python 3.11+)
        if cleanup_errors:
            for err in cleanup_errors:
                error.add_note(f'Cleanup also failed: {type(err).__name__}: {err}')
        raise
    lookup={r['id']:r for r in planned};positions={r['id']:i for i,r in enumerate(rows)}
    def publish():
        signed=_write_index(root,index)
        if progress is not None:progress(deepcopy(signed))
    try:
        index['state']='running';publish()
        for identifier in sequence:
            if cancel is not None and cancel.is_set():index['state']='cancelled';break
            i=positions[identifier];index['samples'][i]['status']='running';publish()
            result=execute_sample(lookup[identifier]);report=result.pop('report');compact={k:v for k,v in result.items() if k!='inputs'}
            compact.update(input_artifact=index['samples'][i]['input_artifact'],report_artifact=None)
            try:
                if report is not None:
                    raw=_bytes(report)
                    if used+len(raw)>MAX_ARCHIVE_BYTES-MAX_INDEX_BYTES:raise ValueError('Study archive byte budget exhausted')
                    name='sample-'+identifier+'-report.json';compact['report_artifact']=_exclusive(root,name,raw,MAX_REPORT_BYTES);used+=len(raw)
            except (ValueError,OSError) as error:
                compact.update(status='execution-failed',error='Report persistence failed: '+str(error),metrics=None,cloud=[])
            index['samples'][i]=compact;publish()
            if compact['status']=='execution-failed':
                index.update(state='failed',error=compact['error']);break
        else:index['state']='finished'
        publish()
    except Exception as error:
        index.update(state='failed',error=type(error).__name__+': '+str(error))
        for row in index['samples']:
            if row['status']=='running':row.update(status='execution-failed',error='Execution/persistence interrupted: '+str(error))
        _write_index(root,index)
        raise
    return deepcopy(dict(index,index_sha256=digest(index)))


class StudyArchive:
    """Verified read-only snapshot; an unfinished file is not proof of a live worker."""
    def __init__(self,directory):
        self.root=Path(directory).absolute();raw=_read(self.root,'index.json',MAX_INDEX_BYTES);index=_decode(raw)
        if not isinstance(index,dict) or index.get('schema')!=ARCHIVE_SCHEMA:raise ValueError('Study archive schema required')
        if index.get('index_sha256')!=digest({k:v for k,v in index.items() if k!='index_sha256'}):raise ValueError('Index checksum mismatch')
        if index.get('state') not in STATES:raise ValueError('Unknown study execution state')
        if str(uuid.UUID(index['study_id']))!=index['study_id']:raise ValueError('Invalid study UUID')
        rows=index['samples']
        if not isinstance(rows,list) or not 1<=len(rows)<=MAX_CASES:raise ValueError('Invalid saved sample count')
        self._index=index;self._index_bytes=raw;self._artifacts={'index.json':dict(sha256=_sha(raw),bytes=len(raw),limit=MAX_INDEX_BYTES)}
        spec_raw=self._register(index['spec_artifact'],'spec.json',MAX_INPUT_BYTES);self._spec=_decode(spec_raw)
        if digest(self._spec)!=index['spec_sha256']:raise ValueError('Saved specification checksum mismatch')
        plan=make_plan(self._spec)
        if plan['sampler']!=index['sampler']:raise ValueError('Unsupported saved sampler identity')
        self._expected={r['id']:r for r in plan['samples']}
        self._rows={}
        for row in rows:
            identifier=row['id']
            if not isinstance(identifier,str) or not SAMPLE_ID.fullmatch(identifier) or identifier in self._rows:raise ValueError('Invalid or duplicate sample ID')
            self._rows[identifier]=row
            if not isinstance(row['cloud'],list) or len(row['cloud'])>1001:raise ValueError('Saved trajectory cloud exceeds limit')
            planned=_decode(self._register(row['input_artifact'],'sample-'+identifier+'-inputs.json',MAX_INPUT_BYTES))
            if planned!=self._expected.get(identifier):raise ValueError('Saved input record differs from deterministic study plan')
            if digest(planned['inputs'])!=planned['input_sha256'] or planned['input_sha256']!=row['input_sha256']:raise ValueError('Planned input checksum mismatch')
            for key in ('id','cohort','index','label','source','draws'):
                if planned[key]!=row[key]:raise ValueError('Saved sample provenance differs from plan')
            if row['report_artifact'] is not None:
                report=_decode(self._register(row['report_artifact'],'sample-'+identifier+'-report.json',MAX_REPORT_BYTES))
                self._check_report(row,planned,report)
            elif row['status'] in ('completed','stopped','initial-rejected'):raise ValueError('Computed sample report is missing')
        if sum(a['bytes'] for a in self._artifacts.values())>MAX_ARCHIVE_BYTES:raise ValueError('Saved archive exceeds byte budget')
        if summarize(rows)!=index['summary']:raise ValueError('Saved cohort statistics differ from records')
        self._check_cohort_plan()

    def _register(self,artifact,name,limit):
        if not isinstance(artifact,dict) or set(artifact)!={'name','sha256','bytes'} or artifact['name']!=name:raise ValueError('Artifact mapping is not allowlisted')
        raw=_read(self.root,name,limit)
        if len(raw)!=artifact['bytes'] or _sha(raw)!=artifact['sha256']:raise ValueError('Artifact checksum or size mismatch: '+name)
        self._artifacts[name]=dict(sha256=artifact['sha256'],bytes=len(raw),limit=limit)
        return raw

    def _check_cohort_plan(self):
        expected=sorted((r['id'],r['cohort'],r['index']) for r in self._expected.values())
        actual=sorted((r['id'],r['cohort'],r['index']) for r in self._rows.values())
        if actual!=expected:raise ValueError('Saved records do not cover the full planned cohorts')

    @staticmethod
    def _check_report(row,planned,report):
        if report.get('schema')!='carrier-trajectory-v1' or report.get('report_sha256')!=digest({k:v for k,v in report.items() if k!='report_sha256'}):raise ValueError('Trajectory report checksum mismatch')
        if report['inputs']!=planned['inputs'] or report['input_sha256']!=planned['input_sha256']:raise ValueError('Report inputs differ from planned draw')
        if len(report['snapshots'])>1001:raise ValueError('Report snapshot count exceeds limit')
        if row['status'] in ('completed','stopped','initial-rejected'):
            cloud=[dict(time_s=f['time_s'],position_N_ft=f['position_N_ft']) for f in report['snapshots']]
            if row['status']!=report['status'] or row['metrics']!=event_metrics(report) or row['event']!=report['event'] or row['cloud']!=cloud:
                raise ValueError('Saved metrics/status/cloud differ from full report')

    def overview(self):
        value=deepcopy(self._index)
        value['runtime_note']='Saved unfinished state; this archive alone does not establish a live worker.' if value['state'] in ('prepared','running') else 'Saved terminal study execution state; individual outcomes remain separate.'
        return value

    def artifact(self,name):
        if name not in self._artifacts:raise KeyError('Unknown artifact')
        expected=self._artifacts[name];raw=_read(self.root,name,expected['limit'])
        if len(raw)!=expected['bytes'] or _sha(raw)!=expected['sha256']:raise ValueError('Artifact changed since loading; reopen the archive')
        return raw

    def sample(self,identifier):
        row=self._rows[identifier];planned=_decode(self.artifact(row['input_artifact']['name']));report=None
        if row['report_artifact'] is not None:report=_decode(self.artifact(row['report_artifact']['name']))
        return dict(sample=deepcopy(row),planned=planned,report=report)

    def specification(self):return deepcopy(self._spec)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('specification',type=Path);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args(argv)
    try:
        with args.specification.open('rb') as f:raw=f.read(MAX_INPUT_BYTES+1)
        if len(raw)>MAX_INPUT_BYTES:raise ValueError('Specification exceeds 128 KiB')
        result=run_study(_decode(raw),args.output);StudyArchive(args.output)
        if result['state']=='failed':raise ValueError('Study failed: '+str(result['error'])+'; inspect '+str(args.output/'index.json'))
    except (ValueError,OSError,KeyError,TypeError) as error:parser.error(str(error))
    print(f"Study execution {result['state']}; {result['summary']['total_requested']} planned cases; {args.output/'index.json'}")


if __name__=='__main__':main()
