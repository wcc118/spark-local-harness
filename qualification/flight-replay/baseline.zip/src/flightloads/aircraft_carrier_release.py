"""Carrier-air-speed release kinematics; independent of trim and force models."""
from copy import deepcopy
import hashlib
import math
from pathlib import Path
import numpy as np
from .aircraft_workspace import validate_definition
from .aircraft_release import quaternion_321
from .conventions import quaternion_multiply, rotation_matrix, unit_quaternion
from .aircraft_elastic import digest
from .aircraft_input_limits import FLIGHT_BOUNDS, RELEASE_BOUNDS

MODEL_ID = 'carrier-relative-release-kinematics-v1'
KNOT_FT_S = 1852 / .3048 / 3600
ZERO_SPEED_FT_S = 1e-10
# Numerical preview bounds only. No aerodynamic or launch qualification implied.
FIELDS = {
    'carrier_tas_kts': (0, 1000, 200, 'Carrier true airspeed', 'kt'),
    'carrier_alpha_deg': (-180, 180, 0, 'Carrier air-velocity alpha', 'deg'),
    'carrier_beta_deg': (-90, 90, 0, 'Carrier air-velocity beta', 'deg'),
    'height_agl_ft': (0, 100000, 1000, 'Release CG height above ground', 'ft'),
}
for prefix, label in [('carrier', 'Carrier to NED'), ('relative', 'Vehicle to carrier')]:
    for axis in ['roll', 'pitch', 'yaw']:
        FIELDS[f'{prefix}_{axis}_deg'] = (-180, 180, 90 if prefix=='relative' and axis=='yaw' else 0, f'{label}: {axis}', 'deg')
for axis in ['x', 'y', 'z']:
    FIELDS[f'ejection_{axis}_ft_s'] = (-1000, 1000, 0, f'Ejection in selected frame: +{axis}', 'ft/s')
for axis, label in [('north', 'north'), ('east', 'east'), ('down', 'down')]:
    FIELDS[f'wind_{axis}_ft_s'] = (-1000, 1000, 0, f'Atmospheric air-mass velocity toward {label}', 'ft/s')
for axis in ['p', 'q', 'r']:
    FIELDS[f'{axis}_deg_s'] = (-1000, 1000, 0, f'Initial vehicle body rate {axis}', 'deg/s')
for key, label, unit, lo, hi in [
    ('thrust_lbf', 'Initial thrust (+body x)', 'lbf', 0, 100),
    ('prop_torque_in_lbf', 'Initial propulsion torque (+body x)', 'in-lbf', -100, 100),
    ('common_tail_deg', 'Initial common tail deflection', 'deg', -90, 90),
    ('differential_tail_deg', 'Initial differential tail deflection', 'deg', -90, 90),
    ('aileron_deg', 'Initial aileron deflection', 'deg', -90, 90),
]:
    FIELDS[key] = (lo, hi, 0, label, unit)
ASSUMPTIONS = [
    'Carrier input is true airspeed, not indicated airspeed or ground speed; no IAS conversion is inferred.',
    'Default 200 kt and broadside +90 deg relative yaw reflect the requested scenario; other defaults are illustrative placeholders, not measured launch data.',
    'Zero carrier alpha/beta assumes carrier air velocity aligned with its +x axis. Ejection is relative CG translational velocity in the selected frame.',
    'Wind is uniform air-mass ground velocity toward positive north/east/down, not meteorological wind FROM. It is added once to air velocity to obtain ground velocity.',
    'Zero ejection, body rates, thrust, torque and control deflections are unmeasured placeholders; attitude is independent of carrier inherited translation.',
    'Free flight begins fully separated. Carrier rotation times release offset, tube contact, carrier wake and release transients are omitted.',
    'Preview evaluates kinematics only: no aerodynamic forces, trajectory, flight capture, stability or structural acceptance. Initial propulsion/controls are recorded only.',
]


def default_scenario():
    return dict(schema_version=1, ejection_frame='vehicle', **{k:v[2] for k,v in FIELDS.items()})


def scenario_metadata():
    return dict(schema='carrier-release-inputs-v1', defaults=default_scenario(),
        fields={k:dict(min=v[0], max=v[1], default=v[2], label=v[3], unit=v[4]) for k,v in FIELDS.items()},
        ejection_frames=['vehicle','carrier'], assumptions=list(ASSUMPTIONS),
        scope='Numerical kinematic preview bounds only; force-model applicability is separate.')


def validate_scenario(s):
    if not isinstance(s, dict) or set(s)!=set(default_scenario()):
        raise ValueError('Release scenario requires exactly the documented fields')
    if type(s['schema_version']) is not int or s['schema_version']!=1:
        raise ValueError('Release scenario schema_version must be 1')
    if s['ejection_frame'] not in ('vehicle','carrier'):
        raise ValueError('ejection_frame must be vehicle or carrier')
    for k,(lo,hi,*_) in FIELDS.items():
        v=s[k]
        if type(v) not in (int,float) or not math.isfinite(v) or not lo<=v<=hi:
            raise ValueError(f'{k} must be finite in [{lo},{hi}]')
    return deepcopy(s)


def air_angles(v):
    speed=float(np.linalg.norm(v));plane=math.hypot(v[0],v[2])
    return dict(airspeed_ft_s=speed, alpha_deg=None if plane<=ZERO_SPEED_FT_S else math.degrees(math.atan2(v[2],v[0])),
        beta_deg=None if speed<=ZERO_SPEED_FT_S else math.degrees(math.atan2(v[1],plane)))


def release_kinematics(scenario):
    s=validate_scenario(scenario)
    qs=[quaternion_321(*np.radians([s[f'{p}_{a}_deg'] for a in ['roll','pitch','yaw']])) for p in ['carrier','relative']]
    q_NB=unit_quaternion(quaternion_multiply(*qs))
    R_NC,R_CB=map(rotation_matrix,qs);R_NB=rotation_matrix(q_NB)
    alpha,beta=np.radians([s['carrier_alpha_deg'],s['carrier_beta_deg']])
    carrier_air_C=s['carrier_tas_kts']*KNOT_FT_S*np.array([math.cos(beta)*math.cos(alpha),math.sin(beta),math.cos(beta)*math.sin(alpha)])
    eject=np.array([s[f'ejection_{a}_ft_s'] for a in ['x','y','z']])
    eject_N=(R_NB if s['ejection_frame']=='vehicle' else R_NC)@eject
    inherited_N=R_NC@carrier_air_C
    air_N=inherited_N+eject_N
    wind_N=np.array([s[f'wind_{a}_ft_s'] for a in ['north','east','down']])
    ground_N=air_N+wind_N;air_B=R_NB.T@air_N
    vectors=dict(carrier_air_C=carrier_air_C,inherited_air_N=inherited_N,ejection_N=eject_N,
        carrier_ground_N=inherited_N+wind_N,air_N=air_N,ground_N=ground_N,wind_N=wind_N,
        air_B=air_B,ground_B=R_NB.T@ground_N,wind_B=R_NB.T@wind_N,relative_wind_B=-air_B)
    angles=air_angles(air_B)
    reasons=[]
    lo,hi=FLIGHT_BOUNDS['speed_ft_s']
    if not lo<=angles['airspeed_ft_s']<=hi:reasons.append(f'Air speed outside existing small-angle model {lo}..{hi} ft/s')
    if angles['beta_deg'] is None or abs(angles['beta_deg'])>RELEASE_BOUNDS['beta_deg'][1]+1e-10:
        reasons.append('Sideslip outside existing small-angle model +/-10 deg or undefined at zero speed')
    if angles['alpha_deg'] is None:reasons.append('Alpha undefined: chord-normal-plane air velocity is zero within 1e-10 ft/s')
    return dict(q_NC=qs[0].tolist(),q_CB=qs[1].tolist(),q_NB=q_NB.tolist(),
        R_NC=R_NC.tolist(),R_CB=R_CB.tolist(),R_NB=R_NB.tolist(),
        vectors_ft_s={k:v.tolist() for k,v in vectors.items()},**angles,
        groundspeed_ft_s=float(np.linalg.norm(ground_N)),
        position_N_ft=[0.,0.,-s['height_agl_ft']],omega_B_deg_s=[s[f'{a}_deg_s'] for a in ['p','q','r']],
        legacy_model=dict(status='unsupported-initial-kinematics' if reasons else 'not-evaluated', reasons=reasons,
            scope='Kinematic checks can reject the old model; passing them does not establish local panel, Reynolds, trim or force-model validity. No old-model bounds are expanded.'))


def preview_release(definition,scenario):
    d=deepcopy(definition);validate_definition(d);s=validate_scenario(scenario)
    out=dict(schema='carrier-release-preview-v1',model_id=MODEL_ID,status='kinematic-preview-only',
        definition=d,scenario=s,initial=release_kinematics(s),assumptions=list(ASSUMPTIONS),
        frames=dict(N='north/east/down navigation',C='carrier x forward/y right/z down',B='vehicle x forward/y right/z down'),
        rotation='Hamilton scalar-first active quaternions; R_NB = R_NC * R_CB. 321 yaw/pitch/roll composition.',
        units='ft, ft/s, kt (1852/0.3048/3600 ft/s), deg, deg/s, lbf, in-lbf',
        equations=['V_air_N = R_NC * V_carrier_air_C + V_ejection_N','V_ground_N = V_air_N + wind_N',
            'V_ground_B = transpose(R_NB) * V_ground_N','V_air_B(t) = V_ground_B(t) - transpose(R_NB(t)) * wind_N'],
        source_sha256=digest(d),input_sha256=digest(dict(definition=d,scenario=s)))
    root=Path(__file__).parent
    out['implementation_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in
        ['aircraft_carrier_release.py','aircraft_release.py','conventions.py','aircraft_workspace.py','aircraft_input_limits.py','aircraft_elastic.py']}
    out['preview_sha256']=digest(out)
    return out
