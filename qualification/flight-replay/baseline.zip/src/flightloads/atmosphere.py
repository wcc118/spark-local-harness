"""ISA 1976 troposphere in imperial units, with temperature offset and density altitude.

Valid from sea level to the tropopause, 36,089 ft (geopotential; geometric altitude
is used directly, which differs by less than 0.1% below 20,000 ft). All outputs
are imperial: degR, lbf/ft^2, slug/ft^3, slug/(ft s), ft/s.
See docs/mechanics/ATMOSPHERE.md (Station 4).
"""
from __future__ import annotations

import math

T0_R = 518.67                  # sea-level standard temperature
P0_LBF_FT2 = 2116.22           # sea-level standard pressure
LAPSE_R_FT = 0.00356616        # 6.5 K/km
R_FT_LBF_SLUG_R = 1716.49      # specific gas constant of air
G0_FT_S2 = 32.174
GAMMA = 1.4
MU_REF = 3.737e-7              # slug/(ft s) at T0
SUTHERLAND_R = 198.72          # 110.4 K
TROPOPAUSE_FT = 36089.24
EXPONENT = G0_FT_S2 / (R_FT_LBF_SLUG_R * LAPSE_R_FT)   # 5.2559


def _finite(value, name):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f'{name} must be finite')
    return value


def isa(altitude_ft, temperature_offset_R=0.0):
    """Air properties at pressure altitude h with a temperature offset dT.

    T   = T0 - L*h + dT
    p   = p0 * (1 - L*h/T0)^(g0/(R*L))          (pressure follows the standard lapse)
    rho = p / (R*T)
    mu  = mu_ref * (T/T0)^1.5 * (T0 + S)/(T + S)  (Sutherland)
    a   = sqrt(gamma*R*T)
    """
    h = _finite(altitude_ft, 'altitude_ft')
    dT = _finite(temperature_offset_R, 'temperature_offset_R')
    if not -1000.0 <= h <= TROPOPAUSE_FT:
        raise ValueError(f'altitude {h:g} ft outside the troposphere model [-1000, {TROPOPAUSE_FT}] ft')
    if not -60.0 <= dT <= 60.0:
        raise ValueError('temperature_offset_R must be within +/-60 degR')
    theta_std = 1 - LAPSE_R_FT*h/T0_R
    temperature = T0_R*theta_std + dT
    pressure = P0_LBF_FT2*theta_std**EXPONENT
    density = pressure/(R_FT_LBF_SLUG_R*temperature)
    viscosity = MU_REF*(temperature/T0_R)**1.5*(T0_R + SUTHERLAND_R)/(temperature + SUTHERLAND_R)
    return dict(altitude_ft=h, temperature_offset_R=dT, temperature_R=temperature, pressure_lbf_ft2=pressure,
                density_slug_ft3=density, viscosity_slug_ft_s=viscosity,
                sound_speed_ft_s=math.sqrt(GAMMA*R_FT_LBF_SLUG_R*temperature),
                density_ratio=density/(P0_LBF_FT2/(R_FT_LBF_SLUG_R*T0_R)))


def density_altitude_ft(density_slug_ft3):
    """Standard-day altitude with this density: rho/rho0 = theta^(EXPONENT - 1)."""
    rho = _finite(density_slug_ft3, 'density_slug_ft3')
    rho0 = P0_LBF_FT2/(R_FT_LBF_SLUG_R*T0_R)
    if rho <= 0:
        raise ValueError('density must be positive')
    theta = (rho/rho0)**(1/(EXPONENT - 1))
    return T0_R*(1 - theta)/LAPSE_R_FT


def environment(altitude_ft, temperature_offset_R=0.0):
    """The environment dictionary the aero plant consumes, with its provenance."""
    air = isa(altitude_ft, temperature_offset_R)
    return dict(density_slug_ft3=air['density_slug_ft3'], viscosity_slug_ft_s=air['viscosity_slug_ft_s'],
                sound_speed_ft_s=air['sound_speed_ft_s'],
                source=f'ISA 1976 troposphere at {air["altitude_ft"]:.1f} ft, dT {air["temperature_offset_R"]:+.1f} degR')
