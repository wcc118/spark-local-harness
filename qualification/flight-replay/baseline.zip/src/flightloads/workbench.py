"""Glass-box station workbench: station registry and station functions (plan section 3.1).

Every station function takes a JSON-compatible input dictionary, calls the production
modules directly (no reimplementation), and returns a JSON-compatible result that shows
the intermediate values with units, frames and signs. The HTTP adapter is
workbench_http.py; the page is static/workbench.html.

Stations (plan section 3.1):
    1 Aero sections   2 3D aero        3 Aero dataset   4 Atmosphere & gusts
    5 Propulsion      6 6DOF plant     7 Launch         8 Controller & capture
    9 Load recovery  10 Monte Carlo   11 Load envelopes & export
"""
from __future__ import annotations

from copy import deepcopy
import json
import math
from pathlib import Path

import numpy as np

FT_M = 0.3048

STATIONS = [
    dict(id='sections', number=1, title='Aero sections', issue=196, notes=['AERO_SECTIONS.md']),
    dict(id='aero-3d', number=2, title='3D aero', issue=196, notes=['AERO_3D.md']),
    dict(id='dataset', number=3, title='Aero dataset', issue=204, notes=['AERO_DATASET.md']),
    dict(id='environment', number=4, title='Atmosphere & gusts', issue=211, notes=['ATMOSPHERE.md', 'GUSTS.md']),
    dict(id='propulsion', number=5, title='Propulsion', issue=211, notes=['PROPULSION.md']),
    dict(id='plant', number=6, title='6DOF plant', issue=211, notes=['PLANT.md', 'AERO_DATASET.md', 'STRIP_LINEARIZATION.md']),
    dict(id='launch', number=7, title='Launch', issue=218, notes=['LAUNCH.md']),
    dict(id='capture', number=8, title='Controller & capture', issue=222, notes=['LAUNCH_CAPTURE.md', 'ALTITUDE_AUTOPILOT.md', 'CONTROLLER_DESIGN.md']),
    dict(id='loads', number=9, title='Load recovery', issue=215, notes=['STATION_LOADS.md']),
    dict(id='monte-carlo', number=10, title='Monte Carlo', issue=225, notes=['MONTE_CARLO.md']),
    dict(id='envelopes', number=11, title='Load envelopes & export', issue=228, notes=['LOAD_ENVELOPES.md']),
]
AVAILABLE = ('sections', 'aero-3d', 'dataset', 'environment', 'propulsion', 'plant', 'launch', 'capture', 'loads', 'monte-carlo', 'envelopes')
MAX_TABLE_ROWS = 400
MAX_PLOT_POINTS = 2000


def plain(value):
    """JSON-safe copy: NumPy scalars/arrays to Python, non-finite floats to None."""
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return plain(value.tolist())
    if isinstance(value, (np.floating, float)):
        value = float(value)
        return value if math.isfinite(value) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def _exact(value, keys, name):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError(f'{name} requires exactly: {", ".join(sorted(keys))}')


def _number(value, low, high, name):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f'{name} must be a finite number in [{low:g}, {high:g}]')
    return float(value)


def _vector(value, low, high, name):
    if not isinstance(value, list) or len(value) != 3:
        raise ValueError(f'{name} requires three numbers')
    return [_number(v, low, high, f'{name}[{i}]') for i, v in enumerate(value)]


def stations():
    return [dict(s, available=s['id'] in AVAILABLE) for s in STATIONS]


# ---------------------------------------------------------------- station 1

SECTION_GATES = dict(alpha0_deg=0.5, slope_per_deg_pct=10.0, cm=0.02, cd_min_frac=0.25)   # frozen in #194


def default_sections():
    return dict(airfoil='NACA 4412', reynolds=3e6, mach=0.0, ncrit=9.0, alpha_start_deg=-15.0, alpha_end_deg=18.0,
                alpha_step_deg=0.5, attached_start_deg=-3.5, attached_end_deg=9.0,
                flap=dict(enabled=False, hinge_x_over_c=0.75, hinge_y_over_c=0.0, deflection_deg=0.0))


def sections_station(inputs):
    """XFOIL through the pinned P1b adapter (run_polar), the attached-range characteristics,
    and, for the NACA Report 824 sections, the frozen #194 comparison."""
    import re
    from .xfoil_polars import evaluate_gates, run_polar, section_characteristics
    _exact(inputs, default_sections(), 'sections inputs')
    airfoil = inputs['airfoil']
    if not isinstance(airfoil, str) or not re.fullmatch(r'NACA \d{4}', airfoil):
        raise ValueError('airfoil must be a NACA 4-digit designation such as "NACA 4412"')
    reynolds = _number(inputs['reynolds'], 5e4, 2e7, 'reynolds')
    mach = _number(inputs['mach'], 0, 0.6, 'mach')
    ncrit = _number(inputs['ncrit'], 1, 14, 'ncrit')
    a0 = _number(inputs['alpha_start_deg'], -20, 25, 'alpha_start_deg')
    a1 = _number(inputs['alpha_end_deg'], a0 + 0.1, 30, 'alpha_end_deg')
    step = _number(inputs['alpha_step_deg'], 0.1, 5, 'alpha_step_deg')
    alphas = [round(float(a), 6) for a in np.arange(a0, a1 + step/2, step)]
    if len(alphas) > 200:
        raise ValueError('at most 200 alpha points')
    attached = (_number(inputs['attached_start_deg'], a0, a1, 'attached_start_deg'),
                _number(inputs['attached_end_deg'], a0, a1, 'attached_end_deg'))
    if attached[0] >= attached[1]:
        raise ValueError('attached range requires start < end')
    f = inputs['flap']
    _exact(f, default_sections()['flap'], 'flap')
    flap = None
    if f['enabled'] is True:
        flap = (_number(f['hinge_x_over_c'], 0.5, 0.95, 'flap.hinge_x_over_c'),
                _number(f['hinge_y_over_c'], -0.1, 0.1, 'flap.hinge_y_over_c'),
                _number(f['deflection_deg'], -30, 30, 'flap.deflection_deg'))
    elif f['enabled'] is not False:
        raise ValueError('flap.enabled must be true or false')
    polar = run_polar(airfoil, reynolds, alphas, mach=mach, ncrit=ncrit, flap=flap)
    result = dict(polar=dict(requested_alpha_deg=polar.requested_alpha_deg, converged_alpha_deg=polar.converged_alpha_deg,
                             nonconverged_alpha_deg=polar.nonconverged_alpha_deg, CL=polar.CL, CD=polar.CD, CDp=polar.CDp,
                             CM=polar.CM, Top_Xtr=polar.Top_Xtr,
                             # The pinned build writes a corrupt Bot_Xtr column to its polar file (values far
                             # outside 0..1; its console output is correct), #199 F5. Shown as gaps, not plotted.
                             Bot_Xtr=[x if 0.0 <= x <= 1.0 else None for x in polar.Bot_Xtr]),
                  warnings=([f'{sum(not 0.0 <= x <= 1.0 for x in polar.Bot_Xtr)} bottom-transition values in the XFOIL '
                             'polar file are outside 0..1 and are withheld (known defect of the pinned build, #199 F5).']
                            if any(not 0.0 <= x <= 1.0 for x in polar.Bot_Xtr) else []),
                  provenance=dict(inputs=polar.inputs, engine_manifest=polar.engine_manifest,
                                  input_script_sha256=polar.input_script_sha256, polar_file_sha256=polar.polar_file_sha256),
                  evidence_level='estimate', characteristics=None, reference=None, gates=None,
                  frame='section coefficients per chord; CM about the quarter chord, nose-up positive; alpha in deg')
    converged_in_range = [a for a in polar.converged_alpha_deg if attached[0] <= a <= attached[1]]
    if len(converged_in_range) >= 3:
        result['characteristics'] = section_characteristics(polar, attached)
    fixture = json.loads((Path(__file__).resolve().parents[2] / 'tests/fixtures/naca824_section_reference.json').read_text())
    ref = fixture['airfoils'].get(airfoil)
    if ref is not None:
        result['reference'] = dict(ref, citation=fixture['source']['citation'])
        comparable = (flap is None and abs(reynolds - 3e6) < 1 and mach == 0 and result['characteristics'] is not None)
        if comparable:
            values = {k: ref[k]['value'] for k in ('zero_lift_alpha_deg', 'lift_slope_per_deg', 'cm_quarter_chord', 'cd_min')}
            result['gates'] = evaluate_gates(result['characteristics'], values, SECTION_GATES)
        else:
            result['gates_note'] = 'The #194 comparison applies only at Re 3e6, Mach 0, no flap, with a fitted attached range.'
    return plain(result)


# ---------------------------------------------------------------- station 3

SWEEP_AXES = ('alpha_deg', 'beta_deg', 'speed_ft_s', 'left_tail_deg', 'right_tail_deg', 'aileron_deg')


def default_dataset_station():
    return dict(primary=dict(kind='strip-model', id=None), compare=None,
                sweep=dict(axis='alpha_deg', start=-10.0, end=20.0, step=1.0),
                fixed=dict(alpha_deg=4.0, beta_deg=0.0, speed_ft_s=150.0, left_tail_deg=0.0, right_tail_deg=0.0,
                           aileron_deg=0.0, rates_B_deg_s=[0.0, 0.0, 0.0], density_slug_ft3=0.0023769,
                           sound_speed_ft_s=1116.45))


def _provider(ref, datasets_root, definition=None):
    from .aero_dataset import TabulatedDataset
    from .aero_strip_provider import StripModelProvider
    from .aircraft_controller_contract import default_field_case
    from .aircraft_workspace import stable_example_definition
    import re
    _exact(ref, ('kind', 'id'), 'provider')
    if ref['kind'] == 'strip-model':
        if ref['id'] is not None:
            raise ValueError('strip-model provider id must be null')
        case = default_field_case()
        return StripModelProvider(stable_example_definition() if definition is None else definition, parameters=case['parameters'],
                                  settings=case['discretization'], installation=case['installation'])
    if ref['kind'] == 'dataset':
        if not isinstance(ref['id'], str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}', ref['id']) or ref['id'].startswith('.'):
            raise ValueError('dataset id must be 1-80 letters, digits, dot, dash or underscore')
        if not (Path(datasets_root) / ref['id'] / 'dataset.json').exists():
            raise ValueError(f'dataset {ref["id"]!r} not found')
        return TabulatedDataset.load(Path(datasets_root) / ref['id'])
    raise ValueError('provider kind must be strip-model or dataset')


def dataset_slice(inputs, datasets_root):
    """Sweep one axis through a provider (and optionally a second one) with the others held.
    Every point is the provider's own AeroResult: resultant about the CG, components,
    coverage flags and evidence level."""
    from .aero_dataset import AeroQuery
    from .aero_strip_provider import component_of
    from .aircraft_workspace import evaluate_aircraft, stable_example_definition
    _exact(inputs, (*default_dataset_station(), *(('definition',) if 'definition' in inputs else ())), 'dataset inputs')
    sweep, fixed = inputs['sweep'], inputs['fixed']
    _exact(sweep, default_dataset_station()['sweep'], 'sweep')
    _exact(fixed, default_dataset_station()['fixed'], 'fixed')
    if sweep['axis'] not in SWEEP_AXES:
        raise ValueError(f'sweep.axis must be one of {SWEEP_AXES}')
    limits = dict(alpha_deg=(-180, 180), beta_deg=(-90, 90), speed_ft_s=(.001, 400),
                  left_tail_deg=(-45, 45), right_tail_deg=(-45, 45), aileron_deg=(-45, 45))
    lo, hi = limits[sweep['axis']]
    start = _number(sweep['start'], lo, hi, 'sweep.start')
    end = _number(sweep['end'], start + 1e-9, hi, 'sweep.end')
    step = _number(sweep['step'], 0.01, 100, 'sweep.step')
    values = [round(float(v), 9) for v in np.arange(start, end + 1e-10, step)]
    if len(values) > 200:
        raise ValueError('at most 200 sweep points')
    held = {k: _number(fixed[k], *limits[k], 'fixed.' + k) for k in SWEEP_AXES}
    rates = np.radians(_vector(fixed['rates_B_deg_s'], -2000, 2000, 'fixed.rates_B_deg_s'))
    rho = _number(fixed['density_slug_ft3'], 0, 0.01, 'fixed.density_slug_ft3')
    sound = _number(fixed['sound_speed_ft_s'], 500, 1500, 'fixed.sound_speed_ft_s')
    definition = inputs.get('definition')
    if definition is None:
        definition = stable_example_definition()
    mp = evaluate_aircraft(definition)['mass_properties']
    g = definition['geometry']
    s_ref, c_ref = g['wing_exposed_span_in']*g['wing_chord_in'], g['wing_chord_in']
    providers = [('primary', inputs['primary'])] + ([('compare', inputs['compare'])] if inputs['compare'] is not None else [])
    out = {}
    for label, ref in providers:
        provider = _provider(ref, datasets_root, definition)
        rows = []
        for v in values:
            point = dict(held, **{sweep['axis']: v})
            a, b, speed = (math.radians(point['alpha_deg']), math.radians(point['beta_deg']), point['speed_ft_s'])
            velocity = speed*np.array([math.cos(a)*math.cos(b), math.sin(b), math.sin(a)*math.cos(b)])
            query = AeroQuery(velocity, rates, mp['cg_B_in'], {k: point[k] for k in ('left_tail_deg', 'right_tail_deg', 'aileron_deg')},
                              rho, sound)
            r = provider.evaluate(query)
            force = np.array(r.force_B_lbf)
            drag_axis = -velocity/speed if speed > 0 else np.zeros(3)
            lift_axis = np.array([math.sin(a), 0.0, -math.cos(a)])   # perpendicular to V in the symmetry plane, up
            q_s = 0.5*rho*speed**2*s_ref/144.0
            components = {}
            for load in r.loads:
                name = load.component if load.component != 'fixed propulsion' else 'propulsion'
                slot = components.setdefault(name, dict(force_B_lbf=np.zeros(3), moment_CG_B_in_lbf=np.zeros(3)))
                slot['force_B_lbf'] += load.force_B_lbf
                slot['moment_CG_B_in_lbf'] += np.cross(np.array(load.position_B_in) - mp['cg_B_in'], load.force_B_lbf) + load.couple_B_in_lbf
            lift, drag = float(force @ lift_axis), float(force @ drag_axis)
            rows.append(dict(value=v, force_B_lbf=r.force_B_lbf, moment_B_in_lbf=r.moment_B_in_lbf, lift_lbf=lift, drag_lbf=drag,
                             CL=lift/q_s if q_s else None, CD=drag/q_s if q_s else None,
                             Cm=r.moment_B_in_lbf[1]/(q_s*c_ref) if q_s else None,
                             components=components, in_coverage=r.in_coverage, violations=list(r.coverage_violations),
                             evidence_level=r.evidence_level))
        out[label] = dict(provider=dict(provider.identity), rows=rows)
    return plain(dict(axis=sweep['axis'], values=values, aircraft=dict(name=definition['name'],definition=definition), reference=dict(point_B_in=mp['cg_B_in'], area_in2=s_ref, chord_in=c_ref),
                      frame='body x forward, y right, z down; moments about the CG; lift and drag in wind axes (lbf)',
                      **out))


# ---------------------------------------------------------------- station 4

def default_aero_3d():
    from .aircraft_workspace import stable_example_definition
    return dict(definition=stable_example_definition(), wing_section='4412', tail_section='0009',
                case=dict(alpha_deg=5., beta_deg=0., p_hat=0., q_hat=0., r_hat=0.,
                          left_tail_deg=0., right_tail_deg=0., aileron_deg=0., mach=0.),
                n_chord=8, n_span=24, refine=True)


def aero_3d_station(inputs):
    """One editable attached-flow case and optional doubled-mesh diagnostic, same AVL adapter."""
    from dataclasses import asdict
    from .avl_model import build_avl_geometry, run_avl
    _exact(inputs, default_aero_3d(), '3D aero inputs')
    case = inputs['case']
    _exact(case, default_aero_3d()['case'], 'AVL case')
    values = [_number(case[k], lo, hi, k) for k, lo, hi in (
        ('alpha_deg', -15, 15), ('beta_deg', -15, 15),
        ('p_hat', -.2, .2), ('q_hat', -.2, .2), ('r_hat', -.2, .2),
        ('left_tail_deg', -20, 20), ('right_tail_deg', -20, 20), ('aileron_deg', -20, 20),
        ('mach', 0, .6))]
    if type(inputs['refine']) is not bool:
        raise ValueError('refine must be boolean')
    args = dict(definition=inputs['definition'], n_chord=inputs['n_chord'], n_span=inputs['n_span'],
                wing_section=inputs['wing_section'], tail_section=inputs['tail_section'])
    build_avl_geometry(**args)  # Validate both requested meshes before starting either engine run.
    fine_args = dict(args, n_chord=2*inputs['n_chord'], n_span=2*inputs['n_span'])
    if inputs['refine']:
        build_avl_geometry(**fine_args)
    coarse = run_avl(**args, cases=[values])
    refined = run_avl(**fine_args, cases=[values]) if inputs['refine'] else None
    comparison = None
    if refined is not None:
        checks = {}
        for key in ('CL', 'Cm'):
            a, b = coarse.total_forces[0][key], refined.total_forces[0][key]
            # Relative checks are undefined at a vanishing reference coefficient; never silently pass.
            relative = abs((a-b)/b) if abs(b) > 1e-12 else None
            checks[key] = dict(coarse=a, refined=b, absolute_change=abs(a-b),
                               relative_change=relative, passed=relative is not None and relative <= .005)
        comparison = dict(tolerance=.005, checks=checks, passed=all(c['passed'] for c in checks.values()))
    total = coarse.total_forces[0]
    ar = total['Bref']**2/total['Sref']
    efficiency = total.get('e', 0.)
    alpha_i = total['CL']/(math.pi*ar*efficiency) if efficiency > 0 else None
    return plain(dict(coarse=asdict(coarse), refined=asdict(refined) if refined else None,
        refinement=comparison, induced_handcheck=dict(aspect_ratio=ar, efficiency=efficiency,
            alpha_i_rad=alpha_i, scope='Idealized reference-area equivalent CL/(pi AR e), not local strip angle'),
        evidence_level='estimate', frame='FT forces/moments: body x forward, y right, z down; ST derivatives: stability axes; geometry feet; moments about reported CG reference',
        warning='Attached-flow estimate only. FS far-wake downwash/V is not an angle. Tail OB downwash includes all surfaces and rates, not wing-only downwash.'))


def default_environment():
    return dict(atmosphere=dict(field_elevation_ft=0.0, temperature_offset_R=0.0, top_height_ft=2000.0, step_ft=250.0),
                discrete=dict(amplitude_ft_s=10.0, gradient_length_ft=50.0, airspeed_ft_s=150.0),
                turbulence=dict(sigma_ft_s=[5.0, 5.0, 5.0], scale_length_ft=[200.0, 100.0, 100.0], airspeed_ft_s=150.0,
                                sample_period_s=0.01, duration_s=20.0, seed=1))


def environment_station(inputs):
    """ISA table from the field elevation up, a 1-cos gust profile, and a Dryden realization with
    its continuous (MIL-HDBK-1797) and exact discrete PSDs."""
    from .atmosphere import density_altitude_ft, isa
    from .gusts import DrydenTurbulence, discrete_psd, dryden_psd, one_minus_cosine
    _exact(inputs, ('atmosphere', 'discrete', 'turbulence'), 'environment inputs')
    a, d, t = inputs['atmosphere'], inputs['discrete'], inputs['turbulence']
    _exact(a, default_environment()['atmosphere'], 'atmosphere')
    _exact(d, default_environment()['discrete'], 'discrete')
    _exact(t, default_environment()['turbulence'], 'turbulence')
    field = _number(a['field_elevation_ft'], -1000, 20000, 'atmosphere.field_elevation_ft')
    offset = _number(a['temperature_offset_R'], -60, 60, 'atmosphere.temperature_offset_R')
    top = _number(a['top_height_ft'], 0, 15000, 'atmosphere.top_height_ft')
    step = _number(a['step_ft'], 1, 5000, 'atmosphere.step_ft')
    heights = np.arange(0.0, top + step/2, step)
    if len(heights) > MAX_TABLE_ROWS:
        raise ValueError(f'atmosphere table would have {len(heights)} rows; limit {MAX_TABLE_ROWS}')
    table = []
    for h in heights:
        air = isa(field + float(h), offset)
        table.append(dict(height_agl_ft=float(h), **air, density_altitude_ft=density_altitude_ft(air['density_slug_ft3'])))

    amplitude = _number(d['amplitude_ft_s'], -100, 100, 'discrete.amplitude_ft_s')
    length = _number(d['gradient_length_ft'], 1, 2000, 'discrete.gradient_length_ft')
    speed = _number(d['airspeed_ft_s'], 1, 400, 'discrete.airspeed_ft_s')
    s = np.linspace(-0.25*length, 2.25*length, 201)
    gust = dict(distance_ft=s.tolist(), time_s=(s/speed).tolist(),
                velocity_ft_s=[one_minus_cosine(float(x), amplitude, length) for x in s],
                peak_time_s=length/speed, duration_s=2*length/speed)

    sigma = _vector(t['sigma_ft_s'], 0, 50, 'turbulence.sigma_ft_s')
    lengths = _vector(t['scale_length_ft'], 1, 5000, 'turbulence.scale_length_ft')
    t_speed = _number(t['airspeed_ft_s'], 1, 400, 'turbulence.airspeed_ft_s')
    period = _number(t['sample_period_s'], 1e-3, 0.1, 'turbulence.sample_period_s')
    duration = _number(t['duration_s'], 0.1, 600, 'turbulence.duration_s')
    if type(t['seed']) is not int or not 0 <= t['seed'] < 2**32:
        raise ValueError('turbulence.seed must be an integer in [0, 2^32)')
    turbulence = DrydenTurbulence(sigma, lengths, t_speed, period, duration, t['seed'])
    count = int(math.floor(duration/period)) + 1
    stride = max(1, math.ceil(count/MAX_PLOT_POINTS))
    times = [k*period for k in range(0, count, stride)]
    record = turbulence.samples[:count]
    omega = np.logspace(-2, math.log10(0.95*math.pi/period), 80)
    psd = {}
    for k, kind in enumerate('uvw'):
        if sigma[k] == 0:
            continue
        f = turbulence.filters[kind]
        psd[kind] = dict(continuous=[dryden_psd('u' if kind == 'u' else 'vw', float(w), sigma[k], lengths[k], t_speed) for w in omega],
                         discrete=[discrete_psd(f, float(w)) for w in omega])
    return plain(dict(
        atmosphere=dict(table=table, units=dict(height='ft above field', temperature='degR', pressure='lbf/ft^2',
                                                density='slug/ft^3', viscosity='slug/(ft s)', sound_speed='ft/s'),
                        hand_check=isa(0.0, 0.0)),
        discrete=gust,
        turbulence=dict(time_s=times, velocity_ft_s={kind: record[::stride, k].tolist() for k, kind in enumerate('uvw')},
                        sample_std_ft_s={kind: float(np.std(record[:, k])) for k, kind in enumerate('uvw')},
                        target_std_ft_s=dict(zip('uvw', sigma)), omega_rad_s=omega.tolist(), psd=psd,
                        # Expected sampling scatter of the sample sigma for a finite record (approximation):
                        # N_eff ~ T V / (2 L) independent samples, SE(sigma_hat) ~ sigma / sqrt(2 N_eff).
                        sampling=dict(duration_s=duration, airspeed_ft_s=t_speed, scale_length_ft=dict(zip('uvw', lengths)),
                                      independent_samples={kind: duration*t_speed/(2*lengths[k]) for k, kind in enumerate('uvw')},
                                      std_error_ft_s={kind: sigma[k]/math.sqrt(2*duration*t_speed/(2*lengths[k])) for k, kind in enumerate('uvw')},
                                      note='N_eff ~ T V / (2 L); SE(sigma) ~ sigma / sqrt(2 N_eff); an approximation for the scatter of a finite record, not a pass/fail gate'),
                        frame='u along the path axis (north here), v to its right (east), w down; ft/s'),
    ))


# ---------------------------------------------------------------- station 5

def default_propulsion_station():
    from .propulsion import default_propulsion
    return dict(propulsion=default_propulsion(), commanded_thrust_lbf=5.0, max_speed_ft_s=250.0, step_ft_s=5.0)


def propulsion_station(inputs):
    """Thrust available versus axial airspeed, the two bounds, and delivered thrust/torque for a command."""
    from .propulsion import PARAMETERS, available_thrust_lbf, crossover_speed_ft_s, delivered, validate_propulsion
    _exact(inputs, default_propulsion_station(), 'propulsion inputs')
    p = validate_propulsion(inputs['propulsion'])
    command = _number(inputs['commanded_thrust_lbf'], 0, 100, 'commanded_thrust_lbf')
    top = _number(inputs['max_speed_ft_s'], 1, 400, 'max_speed_ft_s')
    step = _number(inputs['step_ft_s'], 0.5, 100, 'step_ft_s')
    speeds = np.arange(0.0, top + step/2, step)
    if len(speeds) > MAX_TABLE_ROWS:
        raise ValueError(f'propulsion table would have {len(speeds)} rows; limit {MAX_TABLE_ROWS}')
    rows = []
    for v in speeds:
        v = float(v)
        thrust, torque, available, saturated = delivered(command, v, p)
        rows.append(dict(axial_speed_ft_s=v,
                         linear_bound_lbf=p['static_thrust_lbf']*max(0.0, 1 - v/p['pitch_speed_ft_s']),
                         power_bound_lbf=p['shaft_power_ft_lbf_s']*p['propulsive_efficiency']/v if v > 1e-9 else None,
                         available_lbf=available_thrust_lbf(v, p), delivered_lbf=thrust, shaft_torque_in_lbf=torque,
                         saturated=saturated))
    return plain(dict(propulsion=p, table=rows, crossover_speed_ft_s=crossover_speed_ft_s(p),
                      parameters={k: dict(low=v[0], high=v[1], default=v[2], unit=v[3], basis=v[4]) for k, v in PARAMETERS.items()},
                      hand_check=dict(static_available_lbf=available_thrust_lbf(0.0, p), static_thrust_lbf=p['static_thrust_lbf']),
                      evidence_level='estimate',
                      frame='thrust along body +x; shaft torque is a couple about body +x (in-lbf)'))


# ---------------------------------------------------------------- station 6

CONTROL_KEYS = ('left_tail_deg', 'right_tail_deg', 'aileron_deg', 'thrust_lbf')
COMPONENTS = ('wing-left', 'wing-right', 'tail-left', 'tail-right', 'body', 'propulsion')


def default_plant():
    from .launch import default_launch
    return dict(definition=None, atmosphere=None, propulsion=None,
                state=dict(height_agl_ft=500.0, airspeed_ft_s=150.0, alpha_deg=3.0, beta_deg=0.0, roll_deg=0.0,
                           pitch_deg=3.0, heading_deg=0.0, rates_B_deg_s=[0.0, 0.0, 0.0]),
                controls=dict(left_tail_deg=0.0, right_tail_deg=0.0, aileron_deg=0.0, thrust_lbf=3.0),
                run=dict(launch=default_launch(), duration_s=6.0, dt_s=0.01))


def build_plant(definition=None, atmosphere=None, propulsion=None, aero_dataset=None, wind_N_ft_s=None):
    """The production ControllerPlant for the workbench: default bench (actuator limits),
    default field case plus the optional atmosphere and propulsion from stations 4 and 5."""
    from .aircraft_controller_contract import default_bench, default_field_case, make_run_inputs
    from .aircraft_controller_plant import ControllerPlant
    from .aircraft_workspace import stable_example_definition
    case = default_field_case()
    if wind_N_ft_s is not None:
        case['wind_N_ft_s'] = deepcopy(wind_N_ft_s)
    if aero_dataset is not None:
        case['aero_dataset'] = deepcopy(aero_dataset)
    if atmosphere is not None:
        case['atmosphere'] = dict(atmosphere)
    if propulsion is not None:
        case['propulsion'] = dict(propulsion)
    return ControllerPlant(make_run_inputs(definition if definition is not None else stable_example_definition(),
                                           bench=default_bench(), field_case=case))


def state_from_flight(state):
    """RigidState (SI) from a flight description, zero wind assumed for the body velocity:
    v_B = V [cos(a) cos(b), sin(b), sin(a) cos(b)]; attitude from 3-2-1 heading, pitch, roll."""
    from .aircraft_release import quaternion_321
    from .state import RigidState
    _exact(state, default_plant()['state'], 'state')
    h = _number(state['height_agl_ft'], 0.01, 20000, 'state.height_agl_ft')
    v = _number(state['airspeed_ft_s'], 0, 400, 'state.airspeed_ft_s')
    a = math.radians(_number(state['alpha_deg'], -180, 180, 'state.alpha_deg'))
    b = math.radians(_number(state['beta_deg'], -90, 90, 'state.beta_deg'))
    angles = [math.radians(_number(state[k], -180, 180, 'state.'+k)) for k in ('roll_deg', 'pitch_deg', 'heading_deg')]
    rates = np.radians(_vector(state['rates_B_deg_s'], -2000, 2000, 'state.rates_B_deg_s'))
    v_B = v*np.array([math.cos(a)*math.cos(b), math.sin(b), math.sin(a)*math.cos(b)])
    return RigidState([0.0, 0.0, -h*FT_M], v_B*FT_M, quaternion_321(*angles), rates)


def _exact_aero(inputs, keys, name):
    keys = set(keys)
    if type(inputs) is dict and 'wind_N_ft_s' in inputs:
        keys.add('wind_N_ft_s')
        _vector(inputs['wind_N_ft_s'], -1000., 1000., 'wind_N_ft_s')
    if type(inputs) is dict and 'aero_dataset' in inputs:
        keys.add('aero_dataset')
        if inputs['aero_dataset'] is None:
            raise ValueError('omit aero_dataset to select the strip model; null is not a dataset snapshot')
    _exact(inputs, keys, name)


def _plant_inputs(inputs):
    _exact_aero(inputs, ('definition', 'atmosphere', 'propulsion', 'state', 'state_SI', 'time_s', 'controls'), 'plant inputs')
    _exact(inputs['controls'], CONTROL_KEYS, 'controls')
    return build_plant(inputs['definition'], inputs['atmosphere'], inputs['propulsion'], inputs.get('aero_dataset'), inputs.get('wind_N_ft_s'))


def plant_station(inputs):
    """Freeze the production plant at one state: every force/moment by component, gravity,
    totals, accelerations and load factor. The state is either a flight description
    (`state`) or a recorded SI state vector (`state_SI`, from a station 6 run) at `time_s`."""
    from .aero_strip_provider import component_of
    from .aircraft_controller_plant import PlantDomainError
    from .conventions import rotation_matrix
    from .state import RigidState
    plant = _plant_inputs(inputs)
    if (inputs['state'] is None) == (inputs['state_SI'] is None):
        raise ValueError('supply exactly one of state or state_SI')
    if inputs['state'] is not None:
        state = state_from_flight(inputs['state'])
    else:
        vector = inputs['state_SI']
        if not isinstance(vector, list) or len(vector) != 13 or not all(type(x) in (int, float) and math.isfinite(x) for x in vector):
            raise ValueError('state_SI requires the 13 finite numbers of a RigidState vector')
        state = RigidState.from_vector(np.array(vector, dtype=float))
    time_s = None if inputs['time_s'] is None else _number(inputs['time_s'], 0, 600, 'time_s')
    try:
        field, applied, derivative = plant.evaluate(state, inputs['controls'], time_s)
    except PlantDomainError as error:
        return dict(status='model-domain', error=str(error), aero_dataset=plant.aero_dataset)
    weight = plant.mass_properties['weight_lbf']
    gravity_B = rotation_matrix(state.q_NB).T @ np.array([0.0, 0.0, weight])
    cg = np.array(field['cg_B_in'])
    groups = {c: dict(force_B_lbf=np.zeros(3), moment_about_CG_B_in_lbf=np.zeros(3), elements=0) for c in COMPONENTS}
    ledger = []
    for row in field['ledger']:
        component = row.get('component') or component_of(row) or 'propulsion'
        g = groups[component]
        g['force_B_lbf'] += row['force_B_lbf']
        g['moment_about_CG_B_in_lbf'] += row['moment_about_CG_in_lbf']
        g['elements'] += 1
        ledger.append(dict(name=row['name'], component=component, kind=row['kind'], position_B_in=row['position_B_in'],
                           force_B_lbf=row['force_B_lbf'], moment_about_CG_B_in_lbf=row['moment_about_CG_in_lbf'],
                           alpha_deg=row.get('alpha_deg'), reynolds=row.get('reynolds')))
    total = np.array(field['non_gravity_force_B_lbf'])
    vdot = derivative.vdot_B_mps2/FT_M
    return plain(dict(
        status='ok', evidence_level=field['evidence_level'], aero_dataset=field['aero_dataset'],
        environment=field['environment'], propulsion=field.get('propulsion'),
        velocity_air_B_ft_s=field['velocity_air_B_ft_s'], omega_B_deg_s=np.degrees(field['omega_B_rad_s']),
        cg_B_in=field['cg_B_in'], weight_lbf=weight, components=groups, ledger=ledger,
        totals=dict(non_gravity_force_B_lbf=total, moment_about_CG_B_in_lbf=field['moment_about_CG_B_in_lbf'],
                    gravity_B_lbf=gravity_B, load_factor_B=total/weight),
        hand_check=dict(component_force_sum_B_lbf=sum(g['force_B_lbf'] for g in groups.values()),
                        component_moment_sum_B_in_lbf=sum(g['moment_about_CG_B_in_lbf'] for g in groups.values()),
                        gravity_magnitude_lbf=float(np.linalg.norm(gravity_B))),
        derivative=dict(vdot_B_ft_s2=vdot, omegadot_B_deg_s2=np.degrees(derivative.omegadot_B_radps2)),
        within_assumed_domain=field['within_assumed_domain'], domain_violations=field['domain_violations'],
        frame='body: x forward, y right, z down; moments about the CG; lbf, in-lbf',
        caveat='Same-model strip linearization is numerically verified (#210); the legacy different-aero reference is not an agreement gate. '
               'That verification does not validate a selected table or establish physical model validity. Treat dynamic results as estimates.'))


def plant_run(inputs):
    """Fixed-control free flight from tube exit through the production run_launch, with the
    SI state at every recorded instant so the station can freeze the plant at any time."""
    from .launch import run_launch
    _exact_aero(inputs, ('definition', 'atmosphere', 'propulsion', 'controls', 'run'), 'plant run inputs')
    _exact(inputs['controls'], CONTROL_KEYS, 'controls')
    _exact(inputs['run'], ('launch', 'duration_s', 'dt_s'), 'run')
    plant = build_plant(inputs['definition'], inputs['atmosphere'], inputs['propulsion'], inputs.get('aero_dataset'), inputs.get('wind_N_ft_s'))
    run = inputs['run']
    dt = _number(run['dt_s'], 0.002, 0.05, 'run.dt_s')
    duration = _number(run['duration_s'], dt, 30, 'run.duration_s')
    trace = run_launch(plant, run['launch'], dict(inputs['controls']), duration_s=duration, dt_s=dt,
                       stations=False, states=True)
    return plain(dict(trace, station_loads=None))


# ---------------------------------------------------------------- station 7

def default_launch_station():
    from .launch import default_launch
    return dict(definition=None, atmosphere=None, propulsion=None, launch=default_launch(),
                controls=dict(left_tail_deg=0.0, right_tail_deg=0.0, aileron_deg=0.0, thrust_lbf=3.0),
                duration_s=6.0, dt_s=0.01)


def launch_preview(inputs):
    """Kinematics only, including the production wind field at release time zero."""
    from .launch import exit_state, validate_launch, platform_kinematics
    from .aircraft_carrier_release import air_angles
    from .conventions import rotation_matrix
    _exact_aero(inputs, default_launch_station(), 'launch inputs')
    scenario = validate_launch(inputs['launch'])
    state = exit_state(scenario)
    plant = build_plant(inputs['definition'], inputs['atmosphere'], inputs['propulsion'], inputs.get('aero_dataset'), inputs.get('wind_N_ft_s'))
    R = rotation_matrix(state.q_NB)
    ground = R @ (state.v_CG_B_mps / 0.3048)
    wind = plant.wind_N_ft_s(state, 0.)
    air = R.T @ (ground-wind)
    k = platform_kinematics(scenario) if scenario['schema_version']==2 else dict(
        inherited_ground_N_ft_s=np.zeros(3), ejection_N_ft_s=ground)
    return plain(dict(schema='launch-kinematic-preview-v1', scenario=scenario,
        state_SI=state.to_vector(), q_NB=state.q_NB, position_N_ft=state.r_CG_N_m/0.3048,
        inherited_ground_N_ft_s=k['inherited_ground_N_ft_s'], ejection_N_ft_s=k['ejection_N_ft_s'],
        velocity_ground_N_ft_s=ground, wind_N_ft_s=wind, velocity_air_B_ft_s=air,
        **air_angles(air), scope='Fully separated initial kinematics only; no force-model or flight acceptance claim.'))


def launch_station(inputs):
    """Tube exit geometry and the fixed-control free flight from the production run_launch, with
    station loads at every recorded instant (the run record station 9 opens)."""
    from .conventions import rotation_matrix
    from .launch import exit_state, run_launch, tube_axis_N, validate_launch
    _exact_aero(inputs, default_launch_station(), 'launch inputs')
    _exact(inputs['controls'], CONTROL_KEYS, 'controls')
    launch = validate_launch(inputs['launch'])
    dt = _number(inputs['dt_s'], 0.002, 0.05, 'dt_s')
    duration = _number(inputs['duration_s'], dt, 30, 'duration_s')
    plant = build_plant(inputs['definition'], inputs['atmosphere'], inputs['propulsion'], inputs.get('aero_dataset'), inputs.get('wind_N_ft_s'))
    state = exit_state(launch)
    R = rotation_matrix(state.q_NB)
    axis = tube_axis_N(launch) if launch['schema_version']==1 else R[:,0]
    trace = run_launch(plant, launch, dict(inputs['controls']), duration_s=duration, dt_s=dt, stations=True, states=True)
    from .launch import _row
    from .aircraft_elastic import digest
    trace['definition'] = plant.inputs['definition']
    trace['aircraft_sha256'] = digest(trace['definition'])
    trace['inputs_sha256'] = digest(dict(plant=plant.inputs, launch=launch, controls=inputs['controls'], duration_s=duration, dt_s=dt))
    first = trace['truth'][0] if trace['truth'] else _row(0., state, {'velocity_air_B_ft_s': launch_preview(inputs)['velocity_air_B_ft_s']})
    segments = []
    for row in trace['truth']:
        if segments and segments[-1]['evidence_level'] == row['evidence_level']:
            segments[-1]['end_s'] = row['time_s']
        else:
            segments.append(dict(evidence_level=row['evidence_level'], start_s=row['time_s'], end_s=row['time_s']))
    if launch['schema_version'] == 2:
        from .launch import platform_kinematics
        k = platform_kinematics(launch)
        preview = launch_preview(inputs)
        velocity = k['velocity_ground_N_ft_s']
        expected = dict(groundspeed_ft_s=float(np.linalg.norm(velocity)),
                        height_agl_ft=launch['height_agl_ft'])
        return plain(dict(trace, evidence_segments=segments,
            exit=dict(k, body_x_axis_N=R[:,0], body_z_axis_N=R[:,2],
                      tip_off_rate_B_deg_s=launch['tip_off_rate_B_deg_s'],
                      velocity_N_ft_s=velocity,
                      velocity_air_B_ft_s=preview['velocity_air_B_ft_s']),
            hand_check=dict(expected=expected,
                observed=dict(groundspeed_ft_s=float(np.linalg.norm(first['velocity_ground_N_ft_s'])),
                              height_agl_ft=first['height_agl_ft']),
                note='Ground velocity = inherited platform ground velocity at release CG + rotated relative ejection. '
                     'The plant subtracts its local wind once to obtain air-relative velocity.'),
            frame='Local NED (north, east, down; ft), z=0 ground/water reference; body x forward, y right, z down'))
    result = dict(
        trace, evidence_segments=segments,
        exit=dict(tube_axis_N=axis, velocity_N_ft_s=launch['exit_speed_ft_s']*axis, body_x_axis_N=R[:, 0],
                  body_z_axis_N=R[:, 2], tip_off_rate_B_deg_s=launch['tip_off_rate_B_deg_s'],
                  position_N_ft=first['position_N_ft']),
        hand_check=dict(expected=dict(airspeed_ft_s=launch['exit_speed_ft_s'], flight_path_deg=launch['tube_elevation_deg'],
                                      alpha_deg=launch['pitch_offset_deg'] if launch['roll_deg'] == launch['yaw_offset_deg'] == 0 else None,
                                      height_agl_ft=launch['exit_height_agl_ft']),
                        observed=dict(airspeed_ft_s=first['airspeed_ft_s'], flight_path_deg=first['flight_path_deg'],
                                      alpha_deg=first['alpha_deg'], height_agl_ft=first['height_agl_ft']),
                        note='At tube exit with zero wind: airspeed = exit speed, flight path = tube elevation, '
                             'and with zero roll and yaw offset, alpha = pitch offset.'),
        frame='NED from the tube exit point (north, east, down; ft); body x forward, y right, z down')
    return plain(result)


# ---------------------------------------------------------------- station 9

def loads_station(inputs):
    """Concurrent station reactions at one recorded instant of a run (a station 7 launch):
    the production StationModel with its applied / gravity / inertia split, cross-checked
    against the balanced reference recovery (recover_stations) at the same instant."""
    from .aircraft_controller_plant import PlantDomainError
    from .state import RigidState
    from .station_loads import StationModel, default_stations, recover_stations
    _exact_aero(inputs, ('definition', 'atmosphere', 'propulsion', 'controls', 'state_SI', 'time_s'), 'loads inputs')
    _exact(inputs['controls'], CONTROL_KEYS, 'controls')
    vector = inputs['state_SI']
    if not isinstance(vector, list) or len(vector) != 13 or not all(type(x) in (int, float) and math.isfinite(x) for x in vector):
        raise ValueError('state_SI requires the 13 finite numbers of a RigidState vector')
    time_s = _number(inputs['time_s'], 0, 600, 'time_s')
    plant = build_plant(inputs['definition'], inputs['atmosphere'], inputs['propulsion'], inputs.get('aero_dataset'), inputs.get('wind_N_ft_s'))
    state = RigidState.from_vector(np.array(vector, dtype=float))
    return _loads_at_state(plant, state, inputs['controls'], time_s)


def controller_loads(report, tick):
    """Recover a saved controller tick using its exact aircraft, environment and controls.

    The HTTP adapter supplies the server-owned report, never editor inputs. This
    preserves gusts, installation and all field-case settings absent from Station 7.
    """
    from .aircraft_controller_plant import ControllerPlant
    from .state import RigidState
    if type(tick) is not int or tick < 0:
        raise ValueError('tick must be a nonnegative integer')
    row = next((r for r in report['truth'] if r['tick'] == tick), None)
    if row is None:
        raise ValueError('controller report has no recorded state at that tick')
    return _loads_at_state(ControllerPlant(report['inputs']), RigidState.from_vector(row['state_SI']),
                           row['actual_controls'], row['time_s'])


# Public compatibility alias; the core runtime shares this calculation.
from .flight_conditions import flight_condition


def _loads_at_state(plant, state, controls, time_s):
    from .aircraft_controller_plant import PlantDomainError
    from .station_loads import StationModel, default_stations, recover_stations
    try:
        field, _, derivative = plant.evaluate(state, controls, time_s)
    except PlantDomainError as error:
        return dict(status='model-domain', error=str(error), aero_dataset=plant.aero_dataset)
    fast = StationModel(plant).evaluate(state, field, derivative, time_s, contributions=True)
    reference = recover_stations(plant, state, field, derivative, time_s)
    definitions = {d['id']: d for d in default_stations(plant.inputs['definition'])}
    stations = []
    for entry, ref in zip(fast['stations'], reference['stations']):
        d = definitions[entry['id']]
        stations.append(dict(entry, description=d['description'], station_in=d.get('station_in'), retain=d.get('retain'),
                             reference_check=dict(force_B_lbf=ref['force_B_lbf'], moment_B_in_lbf=ref['moment_B_in_lbf'],
                                                  balanced=ref['balanced'])))
    g = plant.inputs['definition']['geometry']
    return plain(dict(
        status='ok', time_s=time_s, evidence_level=field['evidence_level'], aero_dataset=field['aero_dataset'], stations=stations,
        flight_condition=flight_condition(plant, state, field, derivative),
        aircraft=dict(name=plant.inputs['definition'].get('name'), definition=plant.inputs['definition']),
        whole_body=dict(balanced=reference['whole_body_balanced'], force_residual_lbf=reference['whole_force_residual_lbf'],
                        moment_residual_CG_in_lbf=reference['whole_moment_residual_CG_in_lbf']),
        cg_B_in=plant.mass_properties['cg_B_in'],
        geometry=dict(fuselage_length_in=g['fuselage_length_in'], wing_le_station_in=g['wing_le_station_in'],
                      wing_chord_in=g['wing_chord_in'], tail_le_station_in=g['tail_le_station_in'],
                      tail_chord_in=g['tail_chord_in']),
        convention=fast.get('convention') or reference['convention']))


# ---------------------------------------------------------------- station 10

def launch_capture_bench():
    """Capture bench started from tube exit (Station 8 and the default study). The trim-bench
    height floor (900 ft below a 1000 ft target) does not apply to a launch from the ground;
    ground contact stops the run instead, so minimum_height_ft is 0."""
    from .aircraft_controller_capture_contract import default_capture_bench, default_launch_phases
    bench = default_capture_bench()
    bench['disturbance'].update(airspeed_delta_ft_s=0.0)
    bench['timing'].update(duration_s=14.0)
    bench['criteria'].update(minimum_height_ft=0.0)
    launch = default_launch_phases()
    launch['scenario'].update(tube_elevation_deg=45.0, exit_speed_ft_s=150.0)
    bench['launch'] = launch
    return bench


def default_study():
    """A small closed-loop launch study the station starts from (edit anything)."""
    from .aircraft_controller_contract import default_field_case
    from .aircraft_workspace import stable_example_definition
    from .monte_carlo import SCHEMA
    bench = launch_capture_bench()
    variables = [
        dict(id='exit-speed', source='study input: tube tailoring range', distribution='uniform',
             params=dict(low=120.0, high=180.0),
             bindings=[dict(path=['bench', 'launch', 'scenario', 'exit_speed_ft_s'], transform='set')]),
        dict(id='tip-off-q', source='estimate: tube tip-off pitch rate', distribution='truncated-normal',
             params=dict(mean=0.0, std=15.0, low=-40.0, high=40.0),
             bindings=[dict(path=['bench', 'launch', 'scenario', 'tip_off_rate_B_deg_s', 1], transform='set')]),
        dict(id='battery-weight', source='estimate: +/-3% (1 sigma) battery weight', distribution='normal',
             params=dict(mean=1.0, std=0.03),
             bindings=[dict(path=['definition', 'components', 3, 'weight_lbf'], transform='scale')]),
    ]
    return dict(schema=SCHEMA, name='workbench launch study', source='workbench station 10 default', seed=1, count=16,
                base=dict(definition=stable_example_definition(), bench=bench, field_case=default_field_case()),
                variables=variables, budget=dict(max_workers=4, max_run_seconds=120))


def summary_matches(summary, stored):
    """A stored sample summary vouches only for the keys it recorded: compare those keys
    exactly (report_sha256 included, so implementation identity is still checked), so
    that fields added to summaries later do not make older studies mismatch forever."""
    if stored is None or not set(stored) <= set(summary):
        return False
    canonical = lambda v: json.dumps(v, sort_keys=True, allow_nan=False)
    return canonical({k: summary[k] for k in stored}) == canonical(stored)


def replay_study_sample(study, index, stored):
    """Replay one sample through the production replay_sample and compare its recomputed summary
    with the stored one. Returns the comparison and a trimmed history for display."""
    from .monte_carlo import replay_sample, sample_values, summarize
    report = replay_sample(study, index)
    summary = summarize(report, index, sample_values(study, index))
    snapshot = replay_snapshot(report)
    return plain(dict(index=index, report_sha256=report['report_sha256'],
                      stored_report_sha256=None if stored is None else stored.get('report_sha256'),
                      summary_matches=summary_matches(summary, stored),
                      summary=summary, status=report['status'], stop_reason=report['stop_reason'],
                      events=report.get('events'), truth=snapshot['truth'],
                      replay=snapshot,
                      evidence_level=(report.get('aero_dataset') or {}).get('evidence_level'), aero_dataset=report.get('aero_dataset')))


def replay_snapshot(report):
    """Display-only data from one production report, never from current editors.

    Motion uses SI body-to-NED states. Readouts and station fields retain exact
    recorded time/tick; no force reconstruction or display interpolation here.
    """
    from .aircraft_elastic import digest
    inputs = report['inputs']
    keys = ('tick', 'time_s', 'state_SI', 'flight_condition', 'height_ft', 'airspeed_ft_s',
            'alpha_deg', 'beta_deg', 'flight_path_deg', 'rate_max_deg_s', 'attitude_error_deg')
    return dict(definition=inputs['definition'], aircraft_sha256=digest(inputs['definition']),
                inputs_sha256=report['inputs_sha256'], report_sha256=report['report_sha256'],
                status=report['status'], stop_reason=report.get('stop_reason'),
                target=dict(inputs['bench'].get('target') or {}, height_agl_ft=(inputs['bench'].get('target') or {}).get('height_agl_ft')
                            if inputs['bench'].get('autopilot') is not None else None),
                commands=[{key: row[key] for key in ('tick','time_s','launch_phase','outer_state') if key in row}
                          for row in report.get('commands',[])],
                truth=[{key: row[key] for key in keys if key in row} for row in report['truth']],
                station_loads=report.get('station_loads',[]), aero_dataset=report.get('aero_dataset'))


# ---------------------------------------------------------------- station 8

def default_capture():
    return dict(definition=None, atmosphere=None, propulsion=None, bench=launch_capture_bench())


def designed_capture_example():
    """Explicit worked example selected on v4 development only; not new defaults."""
    from .gain_schedule_study import build_manifest, run_inputs
    manifest = build_manifest(4)
    candidate = next(c for c in manifest['candidates'] if c['id'] == 'unscheduled-K3-12-Ki5')
    case = next(c for c in manifest['development_cases'] if c['id'] == 'dev-v190-el45-tipoff')
    inputs = run_inputs(manifest, case, candidate)
    return dict(inputs=dict(definition=None, atmosphere=None, propulsion=deepcopy(inputs['field_case']['propulsion']),
                            bench=deepcopy(inputs['bench'])),
                candidate=candidate['id'], development_captures='5/12', reserved_captures='4/16',
                note='Explicit strip-model example; replaces capture and upstream settings only. Existing results and study drafts are unchanged. Numerical refinement/replay passed at frozen source f005f9a; most launch-envelope cases did not capture. Not physical validation or design acceptance.')


def staged_autopilot_example():
    """Separate numerical development example; not the historical reserved-case study."""
    from .aircraft_controller_capture_contract import default_autopilot
    example=designed_capture_example()
    bench=example['inputs']['bench']
    bench['name']='Staged AGL autopilot development example'
    bench['source']='Issue 304 paired altitude development cases; estimated aircraft, no reserved-envelope claim'
    bench['autopilot']=default_autopilot()
    bench['target']['height_agl_ft']=50.
    bench['timing']['duration_s']=90.
    # Retain the demonstrated pitch tuning; restore stronger default lateral feedback.
    bench['controller']['attitude_gain_per_s']=[6.,3.,6.]
    bench['controller']['rate_gain_per_s']=[30.,12.,30.]
    return dict(inputs=example['inputs'],candidate='staged-agl-autopilot-v1',
        note='Separate staged-autopilot numerical development example: 50 ft AGL command, 90 s run, stronger lateral gains. Estimated strip-model aircraft and ideal sensing; no reserved-case, physical-validation or flight-acceptance claim. Changes to aircraft, target or launch require a new run.')


def capture_prepare(inputs):
    """Complete controller run inputs for a launch-to-capture run. The page submits them to the
    existing controller bench API (/api/aircraft/controller-bench/runs), so the run is stored in
    the same catalog the controller learning, replay and comparison views (#153) read."""
    from .aircraft_controller_contract import default_field_case, make_run_inputs
    from .aircraft_workspace import stable_example_definition
    _exact_aero(inputs, default_capture(), 'capture inputs')
    if inputs['bench'].get('launch') is None:
        raise ValueError('station 8 runs start from a separated release: bench.launch is required')
    case = default_field_case()
    if 'wind_N_ft_s' in inputs:
        case['wind_N_ft_s'] = deepcopy(inputs['wind_N_ft_s'])
    if 'aero_dataset' in inputs:
        case['aero_dataset'] = deepcopy(inputs['aero_dataset'])
    if inputs['atmosphere'] is not None:
        case['atmosphere'] = dict(inputs['atmosphere'])
    if inputs['propulsion'] is not None:
        case['propulsion'] = dict(inputs['propulsion'])
    definition = inputs['definition'] if inputs['definition'] is not None else stable_example_definition()
    # Returned bare: the page forwards this exact text to the controller API, because the input
    # digests cover the canonical JSON (a browser round trip would turn 1.0 into 1).
    return make_run_inputs(definition, bench=inputs['bench'], field_case=case)


def capture_study_draft(study, inputs, source):
    """Explicit immutable handoff; preserve sampling choices, validate new bindings."""
    from .aircraft_controller_contract import make_run_inputs
    from .monte_carlo import validate_study
    rebuilt = make_run_inputs(inputs['definition'], inputs['bench'], inputs['field_case'])
    if inputs != rebuilt:
        raise ValueError('capture input envelope/digest mismatch')
    if rebuilt['bench'].get('launch') is None:
        raise ValueError('study handoff requires a launch-to-capture configuration')
    draft = deepcopy(study)
    draft['base'] = {key: deepcopy(rebuilt[key]) for key in ('definition', 'bench', 'field_case')}
    draft['source'] = source + '; imported inputs ' + rebuilt['inputs_sha256']
    draft = validate_study(draft)
    # Preserve canonical Python number representation across browser JSON parsing.
    return dict(study=draft, base_json=json.dumps(draft['base'], sort_keys=True, allow_nan=False),
                base_inputs_sha256=rebuilt['inputs_sha256'], source=draft['source'])


# ---------------------------------------------------------------- station 11

def envelopes_for_study(study, summaries):
    """Exact recorded-tick hulls from the production replay builder.

    Plot only retained governing vertices; interior recorded points were reduced,
    not omitted from the envelope calculation.
    """
    from .load_envelopes import build_complete_envelopes, export_csv, component_definitions
    envelopes = build_complete_envelopes(study, summaries)
    scatter = {sid: [dict(x=pair['x'], y=pair['y'], points=[
        {key: v[key] for key in ('x', 'y', 'sample', 'time_s', 'tick')} for v in pair['vertices']])
        for pair in station['pairs']] for sid, station in envelopes['stations'].items()}
    return plain(dict(envelopes=envelopes, points=scatter, csv=export_csv(envelopes),
                      aircraft=dict(name=study['base']['definition']['name'],definition=study['base']['definition']),
                      component_definitions=component_definitions()))


def resolve_vertex(study, stored_summary, time_s, governing):
    """Replay an actual retained governing tick and compare its exact concurrent field."""
    from .monte_carlo import replay_sample, sample_inputs
    from .station_loads import default_stations
    if governing['sample'] != stored_summary['index'] or governing['time_s'] != time_s:
        raise ValueError('governing point does not match requested sample/time')
    if governing['report_sha256'] != stored_summary.get('report_sha256'):
        raise ValueError('governing point does not match archived report hash')
    report = replay_sample(study, stored_summary['index'])
    if report['report_sha256'] != stored_summary.get('report_sha256'):
        raise ValueError('replay hash mismatch; reproduce with original inputs/code')
    row = next((r for r in report.get('station_loads') or [] if r['tick'] == governing['tick'] and r['time_s'] == time_s), None)
    if row is None:
        raise ValueError(f'the replayed run has no station loads at t = {time_s} s')
    inputs, _ = sample_inputs(study, stored_summary['index'])
    frames = {s['id']: s['panel_frame'] for s in default_stations(inputs['definition']) if s.get('panel_frame')}
    field = {s['id']: dict(s) for s in row['stations']}
    for sid, entry in field.items():
        if sid in frames:
            entry['panel_frame'] = frames[sid]
    stored = governing['concurrent_field']
    truth = next((r for r in report['truth'] if r['tick']==governing['tick'] and r['time_s']==time_s),None)
    conditions = None if truth is None else truth.get('flight_condition')
    condition_matches = 'flight_condition' not in governing or conditions == governing['flight_condition']
    return plain(dict(sample=stored_summary['index'], time_s=time_s, tick=governing['tick'], report_sha256=report['report_sha256'],
                      stored_report_sha256=stored_summary.get('report_sha256'), replayed_field=field, stored_field=stored,
                      resolves=stored is not None and field == stored and condition_matches, status=report['status'],
                      flight_condition=conditions, conditions_match=condition_matches, replay=replay_snapshot(report),
                      aircraft_sha256=governing.get('aircraft_sha256'), inputs_sha256=report.get('inputs_sha256'),
                      evidence_level=(report.get('aero_dataset') or {}).get('evidence_level'),
                      aero_dataset=report.get('aero_dataset'),
                      values=stored_summary.get('values')))


def run_station(station_id, inputs):
    """Dispatch a station request. `inputs` is the station's input dictionary."""
    if station_id == 'controller-design':
        from .controller_design import design_report
        return plain(design_report(capture_prepare(inputs)))
    if station_id == 'linear-check':
        from .strip_linearization import reference_crosscheck
        _exact(inputs, ('definition', 'airspeed_ft_s', 'field_case', 'include_avl'), 'linear cross-check inputs')
        speed = _number(inputs['airspeed_ft_s'], 100, 300, 'airspeed_ft_s')
        if type(inputs['include_avl']) is not bool:
            raise ValueError('include_avl must be boolean')
        return plain(reference_crosscheck(inputs['definition'], speed, inputs['field_case'], inputs['include_avl']))
    if station_id == 'sections':
        return sections_station(inputs)
    if station_id == 'aero-3d':
        return aero_3d_station(inputs)
    if station_id == 'environment':
        return environment_station(inputs)
    if station_id == 'propulsion':
        return propulsion_station(inputs)
    if station_id == 'plant':
        return plant_station(inputs)
    if station_id == 'plant-run':
        return plant_run(inputs)
    if station_id == 'launch-preview':
        return launch_preview(inputs)
    if station_id == 'launch':
        return launch_station(inputs)
    if station_id == 'loads':
        return loads_station(inputs)
    if station_id == 'capture':
        return capture_prepare(inputs)
    raise KeyError(station_id)


def defaults():
    """Default inputs for every available station (the page starts from these)."""
    plant = default_plant()
    return deepcopy(dict(sections=default_sections(), dataset=default_dataset_station(), **{'aero-3d': default_aero_3d()}, environment=default_environment(), propulsion=default_propulsion_station(), plant=plant,
                         launch=default_launch_station(), capture=default_capture()))
