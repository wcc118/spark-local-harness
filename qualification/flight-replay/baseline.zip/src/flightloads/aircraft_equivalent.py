"""Concurrent same-model wing transient-to-static reproduction, imperial boundary."""
from copy import deepcopy
import numpy as np
from .aircraft_structure import (WingBeam,from_aircraft,IN_M,LBF_N,MOMENT_NM,
    generalized_imperial)
from .aircraft_elastic import digest,SCREEN_LIMITS
from .aircraft_workspace import evaluate_aircraft

# Absolute plus relative*max(abs(reference)); fixed before implementation.
TOLERANCES={'w_in':1e-9,'slope_deg':1e-8,'root_Fz_lbf':1e-7,
    'root_Mx_in_lbf':1e-6,'root_stress_positive_z_psi':1e-4,
    'mid_stress_positive_z_psi':1e-4}
RTOL=1e-8


def numeric(value,shape,name):
    a=np.asarray(value)
    if (a.shape!=shape or a.dtype.kind not in 'iuf' or not np.all(np.isfinite(a)) or
        any(isinstance(v,(bool,np.bool_)) for v in np.asarray(value,dtype=object).flat)):
        raise ValueError('invalid finite numeric '+name)
    return a.astype(float)


def si_field(values):
    a=np.array(values,dtype=float,copy=True)
    a[...,::2]*=LBF_N;a[...,1::2]*=MOMENT_NM
    return a


def compare(reference,actual):
    checks={}
    for key,atol in TOLERANCES.items():
        r=np.asarray(reference[key]);a=np.asarray(actual[key])
        if r.shape!=a.shape:raise ValueError('response shape mismatch '+key)
        error=float(np.max(abs(r-a)));limit=atol+RTOL*float(np.max(abs(r)))
        checks[key]=dict(error=error,tolerance=limit,passed=bool(error<=limit))
    return dict(passed=all(c['passed'] for c in checks.values()),checks=checks)


def response_at(wing,u,reaction):
    r=wing.recover(u)
    return dict(w_in=r['w_in'],slope_deg=r['slope_deg'],nodes_in=r['eta_in'],
        root_Fz_lbf=float(reaction[0]/LBF_N),root_Mx_in_lbf=float(reaction[1]/MOMENT_NM),
        root_stress_positive_z_psi=r['stress_positive_z_psi'][0],
        mid_stress_positive_z_psi=wing.recover(u,[wing.length_in/2])['stress_positive_z_psi'][0],
        recovery=r)


def solve_static_field(wing,field_full):
    """Full alternating lbf/in-lbf field, including both prescribed root DOFs."""
    b=wing.beam;p=si_field(numeric(field_full,(len(b.mass_full),),'static field'))
    chol=np.linalg.cholesky(b.stiffness_free)
    u=np.linalg.solve(chol.T,np.linalg.solve(chol,p[2:]))
    reaction=(b.stiffness_full@np.r_[0.,0.,u]-p)[:2]
    return response_at(wing,u,reaction)


def _validated(p):
    if not isinstance(p,dict) or p.get('schema')!='aircraft-wing-history-v1':raise ValueError('invalid pilot schema')
    body=dict(p);identity=body.pop('history_sha256')
    if digest(body)!=identity:raise ValueError('pilot history hash mismatch')
    if digest(p['definition'])!=p['source_input_sha256']:raise ValueError('aircraft input identity mismatch')
    if p['source_status']!='completed' or p['scope_status']!='within-illustrative-pilot':
        raise ValueError('completed within-pilot source required')
    if p['source_event'] is not None or p['equation_verified'] is not True:raise ValueError('qualified completed equation record required')
    if p['residual_correction'] is not False:raise ValueError('residual correction unsupported')
    wing=WingBeam(**p['structural_config']);b=wing.beam;nf=len(b.mass_free)
    match=from_aircraft(p['definition'],young_psi=wing.young_psi,elements=wing.elements,damping_ratio=wing.damping_ratio)
    if wing.model_id!=p['structural_model_id'] or wing.model_id!=match.model_id:raise ValueError('model identity mismatch')
    if type(p['retained_modes']) is not int or p['retained_modes']!=nf:raise ValueError('all elastic modes required')
    n=len(p['times_s'])
    if not 2<=n<=1000:raise ValueError('invalid time count')
    t=numeric(p['times_s'],(n,),'times');dt=numeric([p['dt_s']],(1,),'dt')[0]
    if dt<=0 or t[0]!=0 or np.any(np.diff(t)<=0) or np.max(np.diff(t))>dt+1e-10:
        raise ValueError('invalid time grid')
    if not np.allclose(t[:-1],np.arange(n-1)*dt,atol=1e-10,rtol=0):raise ValueError('time samples disagree with declared step')
    if abs(t[-1]-p['definition']['transient_case']['duration_s'])>1e-10:raise ValueError('incomplete event window')
    nodes=numeric(p['nodes_in'],(wing.elements+1,),'nodes')
    if not np.allclose(nodes,b.nodes_m/IN_M,atol=1e-10,rtol=0):raise ValueError('node grid mismatch')
    states=[]
    for name in ('displacement','velocity','acceleration'):
        state=np.zeros((n,nf+2))
        state[:,2::2]=numeric(p['state'][name+'_transverse'],(n,wing.elements),name)*IN_M
        state[:,3::2]=np.radians(numeric(p['state'][name+'_slope'],(n,wing.elements),name+' slope'))
        states.append(state)
    u,v,a=states
    fields={key:si_field(numeric(value,(n,nf if key=='dynamic_residual_free' else nf+2),key))
            for key,value in p['fields'].items()}
    def require(actual,expected,name,atol=1e-7):
        if not np.allclose(actual,expected,rtol=1e-8,atol=atol):raise ValueError('inconsistent '+name)
    def require_field(actual,expected,name):
        ai=np.asarray(generalized_imperial(actual));ei=np.asarray(generalized_imperial(expected))
        require(ai[:,::2],ei[:,::2],name+' force',1e-7)
        require(ai[:,1::2],ei[:,1::2],name+' couple',1e-6)
    inp=p['inputs'];root_acc=numeric(inp['root_accel_z_in_s2'],(n,),'root acceleration')
    gravity=numeric(inp['gravity_z_in_s2'],(n,),'gravity');aero=numeric(inp['aero_lbf_per_in'],(n,),'aero')
    pitch=numeric(inp['pitch_rate_rad_s'],(n,),'pitch rate')
    root=numeric(inp['root_B_in'],(3,),'root');g=p['definition']['geometry']
    require(root,[-(g['wing_le_station_in']+g['wing_chord_in']/2),g['wing_root_spacing_in']/2,g['wing_z_in']],'attachment',1e-10)
    cg=np.asarray(evaluate_aircraft(p['definition'])['mass_properties']['cg_B_in']);rho=root-cg
    if len(p['concurrent_rigid_snapshots'])!=n:raise ValueError('snapshot count mismatch')
    for i,s in enumerate(p['concurrent_rigid_snapshots']):
        require(numeric([s['time_s']],(1,),'snapshot time'),[t[i]],'concurrent time',1e-10)
        omega=np.radians(numeric(s['angular_velocity_B_deg_s'],(3,),'angular rate'))
        alpha=np.radians(numeric(s['angular_acceleration_B_deg_s2'],(3,),'angular acceleration'))
        if max(abs(omega[[0,2]]))>1e-8 or max(abs(alpha[[0,2]]))>1e-8:raise ValueError('longitudinal scope required')
        acg=numeric(s['acceleration_CG_B_in_s2'],(3,),'CG acceleration')
        require(root_acc[i],(acg+np.cross(alpha,rho)+np.cross(omega,np.cross(omega,rho)))[2],'located root acceleration')
        require(pitch[i],omega[1],'pitch rate')
        require(gravity[i],numeric(s['gravity_B_in_s2'],(3,),'gravity vector')[2],'gravity')
        rows=[r for r in s['aerodynamic']['ledger'] if r['name']=='Wing aerodynamic resultant']
        if len(rows)!=1:raise ValueError('one wing aerodynamic source required')
        require(aero[i],numeric(rows[0]['force_B_lbf'],(3,),'wing force')[2]/(2*wing.length_in),'uniform aero')
        for key in ('cut_force_B_lbf','cut_moment_B_in_lbf'):numeric(s['loads'][key],(3,),key)
    expected_rigid=-(root_acc[:,None]*IN_M*b.rigid_map[:,0])@b.mass_full.T
    expected_elastic=-a@b.mass_full.T
    expected_damping=-v[:,2:]@b.damping_free.T@b.elastic_extractor
    expected_gravity=(gravity[:,None]*IN_M*b.rigid_map[:,0])@b.mass_full.T
    expected_aero=np.array([b.uniform_load(x*LBF_N/IN_M) for x in aero])
    for key,expected in [('negative_rigid_inertia_full',expected_rigid),('negative_elastic_inertia_full',expected_elastic),
        ('negative_damping_full',expected_damping),('aero_full',expected_aero),('gravity_full',expected_gravity),
        ('applied_full',expected_aero+expected_gravity)]:require_field(fields[key],expected,key)
    effective=fields['applied_full']+expected_rigid+expected_elastic+expected_damping
    residual=u@b.stiffness_full.T-effective
    require_field(fields['dynamic_residual_free'],residual[:,2:],'equilibrium archive')
    ri=np.asarray(generalized_imperial(residual[:,2:]))
    if abs(ri[:,::2]).max()>1e-7 or abs(ri[:,1::2]).max()>1e-6:raise ValueError('free equilibrium failed')
    metrics=dict(deflection_over_span=float(abs(u[:,::2]).max()/(wing.length_in*IN_M)),
        slope_rad=float(abs(u[:,1::2]).max()),pitch_rate_over_omega1=float(abs(pitch).max()/b.omega_radps[0]))
    if p['screening_limits']!=SCREEN_LIMITS or any(metrics[k]>limit for k,limit in SCREEN_LIMITS.items()):
        raise ValueError('approximation screening failed')
    for key,value in metrics.items():require(p['screening_metrics'][key],value,'screening metric')
    recovered=[response_at(wing,row[2:],rr[:2]) for row,rr in zip(u,residual)]
    for key in ('root_Fz_lbf','root_Mx_in_lbf','root_stress_positive_z_psi','mid_stress_positive_z_psi','tip_w_in'):
        values=numeric(p['response'][key],(n,),key)
        expected=np.array([r['w_in'][-1] if key=='tip_w_in' else r[key] for r in recovered])
        require(values,expected,'source response '+key,TOLERANCES.get(key,1e-9))
    return wing,t,fields,recovered,metrics


def _build_case(pilot,validated,i,rule):
    wing,t,fields,recovered,metrics=validated
    selected={key:deepcopy(values[i]) for key,values in pilot['state'].items()}
    terms={key:deepcopy(values[i]) for key,values in pilot['fields'].items()}
    p_eq=sum(np.array(terms[k]) for k in ('applied_full','negative_rigid_inertia_full','negative_elastic_inertia_full','negative_damping_full'))
    equivalent=solve_static_field(wing,p_eq.tolist());external=solve_static_field(wing,terms['applied_full'])
    checks=compare(recovered[i],equivalent);negative=compare(recovered[i],external)
    if not checks['passed']:raise ValueError('static reproduction failed')
    result=dict(schema='aircraft-equivalent-static-v1',selected_rule=rule,
        selected_index=i,selected_time=float(t[i]),window_boundary=i in (0,len(t)-1),
        source_history_identity=pilot['history_sha256'],source_rigid_identity=pilot['source_history_sha256'],
        source_input_identity=pilot['source_input_sha256'],source_event=deepcopy(pilot['source_event']),
        definition=deepcopy(pilot['definition']),structural_config=deepcopy(pilot['structural_config']),
        structural_model_id=wing.model_id,nodes_in=pilot['nodes_in'],full_exact_selected_state=selected,
        concurrent_fields=terms,p_eq_full=p_eq.tolist(),
        concurrent_rigid_fuselage_6loads=deepcopy(pilot['concurrent_rigid_snapshots'][i]['loads']),
        primary_tolerances=dict(absolute=TOLERANCES,relative=RTOL),comparisons=checks,
        external_only_comparisons=negative,primary_passed=checks['passed'],external_only_failed=not negative['passed'],
        transient_response=recovered[i],equivalent_response=equivalent,external_only_response=external,
        screening_metrics=metrics,limitations='Illustrative unloading-window reproduction only; no strength, buckling, fatigue, torsion, aircraft validation or design acceptance.')
    if rule=='first_maximum_root_bending_shear':result['selection_scales']=dict(INTERACTION_SCALES)
    result['canonical_case_sha256']=digest(result)
    return result



RESPONSES=('tip_w_in','root_Fz_lbf','root_Mx_in_lbf','root_stress_positive_z_psi','mid_stress_positive_z_psi')
INTERACTION_SCALES={'root_Fz_lbf':12.,'root_Mx_in_lbf':150.}
RULES={f'first_signed_{word}_{key}':(key,side) for key in RESPONSES
       for side,word in [('min','minimum'),('max','maximum')]}
RULES['first_maximum_root_bending_shear']=('root_bending_shear','max')


def response_histories(pilot):
    """Signed physical responses plus a demand index, never a strength criterion."""
    result={key:np.asarray(pilot['response'][key]) for key in RESPONSES}
    result['root_bending_shear']=sum((result[key]/scale)**2 for key,scale in INTERACTION_SCALES.items())
    return result


def _check(pilot):
    try:return _validated(pilot)
    except (KeyError,TypeError,IndexError,OverflowError) as error:raise ValueError('incomplete or invalid pilot') from error


def extract_extreme_case(pilot,response,side):
    """Select an explicitly declared signed response or the fixed demand index."""
    matches=[rule for rule,pair in RULES.items() if pair==(response,side)]
    if not matches:raise ValueError('unsupported selection criterion')
    validated=_check(pilot);values=response_histories(pilot)[response]
    index=int(np.argmin(values) if side=='min' else np.argmax(values))
    return _build_case(pilot,validated,index,matches[0])


def extract_case(pilot):
    """Preserve the #56 first signed minimum root +z stress selection and schema."""
    return extract_extreme_case(pilot,'root_stress_positive_z_psi','min')


def candidate_cases(pilot):
    """Union of actual concurrent instants; retain every selection reason."""
    validated=_check(pilot);histories=response_histories(pilot);selected={}
    for rule,(response,side) in RULES.items():
        values=histories[response];i=int(np.argmin(values) if side=='min' else np.argmax(values))
        if i not in selected:selected[i]=dict(case=_build_case(pilot,validated,i,rule),criteria=[])
        selected[i]['criteria'].append(dict(response=response,side=side,value=float(values[i])))
    return [selected[i] for i in sorted(selected)]


def replay_case(case,pilot):
    """Check every saved byte of case content before independently re-extracting."""
    body=dict(case);identity=body.pop('canonical_case_sha256')
    if digest(body)!=identity:raise ValueError('case hash mismatch')
    if case['selected_rule'] not in RULES:raise ValueError('unsupported saved selection rule')
    regenerated=extract_extreme_case(pilot,*RULES[case['selected_rule']])
    if regenerated['canonical_case_sha256']!=identity:raise ValueError('case replay mismatch')
    return regenerated
