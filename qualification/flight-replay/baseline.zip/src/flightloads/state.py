"""Rigid-body state and derivative structures."""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from ._arrays import readonly_copy


@dataclass(frozen=True)
class RigidState:
    """Rigid-body state: position, velocity, attitude, angular rate.

    State ordering: [r_CG_N, v_CG_B, q_NB, omega_B] = 13 components
    Frames: r in N, v and omega in B, attitude q_NB maps B->N.
    normalize_quaternion=False is reserved for internal RK-stage construction.
    """
    r_CG_N_m: np.ndarray
    v_CG_B_mps: np.ndarray
    q_NB: np.ndarray
    omega_B_radps: np.ndarray
    _original_norm: float
    _normalized: bool

    def __init__(
        self,
        r_CG_N_m: np.ndarray,
        v_CG_B_mps: np.ndarray,
        q_NB: np.ndarray,
        omega_B_radps: np.ndarray,
        *,
        normalize_quaternion: bool = True
    ) -> None:
        r = np.asarray(r_CG_N_m, dtype=np.float64)
        v = np.asarray(v_CG_B_mps, dtype=np.float64)
        q = np.asarray(q_NB, dtype=np.float64)
        omega = np.asarray(omega_B_radps, dtype=np.float64)

        # Validate shapes
        if r.shape != (3,):
            raise ValueError(f"r_CG_N_m must have shape (3,), got {r.shape}")
        if v.shape != (3,):
            raise ValueError(f"v_CG_B_mps must have shape (3,), got {v.shape}")
        if q.shape != (4,):
            raise ValueError(f"q_NB must have shape (4,), got {q.shape}")
        if omega.shape != (3,):
            raise ValueError(f"omega_B_radps must have shape (3,), got {omega.shape}")

        # Validate finite
        if not (np.all(np.isfinite(r)) and np.all(np.isfinite(v)) and
                np.all(np.isfinite(q)) and np.all(np.isfinite(omega))):
            raise ValueError("state components must be finite")

        # Check quaternion norm
        with np.errstate(over='ignore'):
            norm_q = np.linalg.norm(q)
        if norm_q <= 1e-12:
            raise ValueError(f"quaternion norm {norm_q:.3e} <= 1e-12")
        if not np.isfinite(norm_q):
            raise ValueError("quaternion norm is nonfinite")

        # Normalize if requested
        if normalize_quaternion:
            q_normalized = q / norm_q
            original_norm = float(norm_q)
            normalized = True
        else:
            q_normalized = q
            original_norm = float(norm_q)
            normalized = False

        # Store immutable copies
        object.__setattr__(self, 'r_CG_N_m', readonly_copy(r))
        object.__setattr__(self, 'v_CG_B_mps', readonly_copy(v))
        object.__setattr__(self, 'q_NB', readonly_copy(q_normalized))
        object.__setattr__(self, 'omega_B_radps', readonly_copy(omega))
        object.__setattr__(self, '_original_norm', original_norm)
        object.__setattr__(self, '_normalized', normalized)

    @classmethod
    def from_vector(cls, vec: np.ndarray, *, normalize_quaternion: bool = True) -> 'RigidState':
        """Construct from packed 13-element vector [r, v, q, omega]."""
        vec_arr = np.asarray(vec, dtype=np.float64)
        if vec_arr.shape != (13,):
            raise ValueError(f"vector must have shape (13,), got {vec_arr.shape}")
        if not np.all(np.isfinite(vec_arr)):
            raise ValueError("vector components must be finite")
        return cls(
            r_CG_N_m=vec_arr[0:3],
            v_CG_B_mps=vec_arr[3:6],
            q_NB=vec_arr[6:10],
            omega_B_radps=vec_arr[10:13],
            normalize_quaternion=normalize_quaternion
        )

    def to_vector(self) -> np.ndarray:
        """Pack state into 13-element vector [r, v, q, omega]."""
        return readonly_copy(np.concatenate([
            self.r_CG_N_m,
            self.v_CG_B_mps,
            self.q_NB,
            self.omega_B_radps
        ]))

    @property
    def original_norm(self) -> float:
        """Original quaternion norm before normalization."""
        return self._original_norm

    @property
    def was_normalized(self) -> bool:
        """Whether normalization was applied during construction."""
        return self._normalized


@dataclass(frozen=True)
class RigidDerivative:
    """Time derivative of rigid-body state.

    Ordering matches RigidState: [rdot_N, vdot_B, qdot_NB, omegadot_B]
    vdot_B is derivative of body-components, not inertial acceleration.
    """
    rdot_N_mps: np.ndarray
    vdot_B_mps2: np.ndarray
    qdot_NB_per_s: np.ndarray
    omegadot_B_radps2: np.ndarray

    def __init__(
        self,
        rdot_N_mps: np.ndarray,
        vdot_B_mps2: np.ndarray,
        qdot_NB_per_s: np.ndarray,
        omegadot_B_radps2: np.ndarray
    ) -> None:
        rdot = np.asarray(rdot_N_mps, dtype=np.float64)
        vdot = np.asarray(vdot_B_mps2, dtype=np.float64)
        qdot = np.asarray(qdot_NB_per_s, dtype=np.float64)
        omegadot = np.asarray(omegadot_B_radps2, dtype=np.float64)

        # Validate shapes
        if rdot.shape != (3,):
            raise ValueError(f"rdot_N_mps must have shape (3,), got {rdot.shape}")
        if vdot.shape != (3,):
            raise ValueError(f"vdot_B_mps2 must have shape (3,), got {vdot.shape}")
        if qdot.shape != (4,):
            raise ValueError(f"qdot_NB_per_s must have shape (4,), got {qdot.shape}")
        if omegadot.shape != (3,):
            raise ValueError(f"omegadot_B_radps2 must have shape (3,), got {omegadot.shape}")

        # Validate finite
        if not (np.all(np.isfinite(rdot)) and np.all(np.isfinite(vdot)) and
                np.all(np.isfinite(qdot)) and np.all(np.isfinite(omegadot))):
            raise ValueError("derivative components must be finite")

        object.__setattr__(self, 'rdot_N_mps', readonly_copy(rdot))
        object.__setattr__(self, 'vdot_B_mps2', readonly_copy(vdot))
        object.__setattr__(self, 'qdot_NB_per_s', readonly_copy(qdot))
        object.__setattr__(self, 'omegadot_B_radps2', readonly_copy(omegadot))

    @classmethod
    def from_vector(cls, vec: np.ndarray) -> 'RigidDerivative':
        """Construct from packed 13-element vector."""
        vec_arr = np.asarray(vec, dtype=np.float64)
        if vec_arr.shape != (13,):
            raise ValueError(f"vector must have shape (13,), got {vec_arr.shape}")
        if not np.all(np.isfinite(vec_arr)):
            raise ValueError("vector components must be finite")
        return cls(
            rdot_N_mps=vec_arr[0:3],
            vdot_B_mps2=vec_arr[3:6],
            qdot_NB_per_s=vec_arr[6:10],
            omegadot_B_radps2=vec_arr[10:13]
        )

    def to_vector(self) -> np.ndarray:
        """Pack derivative into 13-element vector."""
        return readonly_copy(np.concatenate([
            self.rdot_N_mps,
            self.vdot_B_mps2,
            self.qdot_NB_per_s,
            self.omegadot_B_radps2
        ]))
