"""Static engineering presentation; calculations remain in sil_verification."""
import html
import json
from matplotlib.figure import Figure
from matplotlib import rc_context


def render_plots(output, histories):
    panels = [('yaw_rad',None,'Truth yaw [rad]'), ('omega_B_radps',2,'Body yaw rate [rad/s]'),
        ('unlimited_torque_Nm',None,'Unlimited command [N m]'), ('actuator_torque_Nm',None,'Actuator torque [N m]'),
        ('section_force_B_N',0,'Cut Fx [N]'), ('section_force_B_N',1,'Cut Fy [N]'),
        ('section_moment_B_Nm',2,'Cut Mz [N m]'), ('measurement_age_s',None,'Measurement age [s]')]
    with rc_context({'svg.fonttype':'none', 'font.size':8}):
        fig = Figure(figsize=(12,16), layout='constrained')
        axes = fig.subplots(5,2).ravel()
        for case,color in [('nominal','#24618d'),('delayed','#bd542d'),('limited','#328051')]:
            for backend,style in [('mathematical','-'),('compiled','--')]:
                a = histories[case+'_'+backend].arrays
                for ax,(key,index,label) in zip(axes,panels):
                    y = a[key] if index is None else a[key][:,index]
                    ax.plot(a['time_s'],y,color=color,linestyle=style,label=case+' '+backend,lw=1)
                    ax.set(xlabel='Time [s]',ylabel=label)
        a = histories['delayed_mathematical'].arrays
        for key,style in [('yaw_rad','-'),('measured_yaw_rad','--')]:
            axes[8].plot(a['time_s'],a[key],linestyle=style,label=key)
        axes[8].set(xlabel='Time [s]',ylabel='Delayed case yaw [rad]')
        from .sil_verification import continuous_yaw
        for name in ('sampling_1','sampling_2','sampling_4'):
            a = histories[name].arrays
            axes[9].plot(a['time_s'],a['yaw_rad']-continuous_yaw(a['time_s']),label=name)
        axes[9].set(xlabel='Time [s]',ylabel='Sampled minus ideal yaw [rad]')
        for ax in axes:
            ax.grid(alpha=.2); ax.legend(fontsize=6,ncol=2)
        fig.savefig(output/'plots.svg',metadata={'Date':None})


def render_report(output, manifest):
    esc = html.escape
    def js(value):
        return esc(json.dumps(value,indent=2,allow_nan=False))
    status = ''.join(f'<li><b>{esc(k)}</b>: {esc(v)}</li>' for k,v in manifest['status'].items())
    links = ' · '.join(f'<a href="{name}">{name}</a>' for name in
        ('manifest.json','histories.npz','history.csv','controller.c','plots.svg'))
    groups = dict(manifest['checks'])
    if manifest['replay']:
        groups.update({'replay/'+k:v for k,v in manifest['replay']['checks'].items()})
    rows = ''.join(f'<tr><td>{esc(group)}</td><td>{esc(item["name"])}</td><td>{"PASS" if item["passed"] else "FAIL"}</td><td><pre>{js(item)}</pre></td></tr>'
                   for group,items in groups.items() for item in items)
    metadata = {k:v for k,v in manifest.items() if k not in ('checks','replay')}
    if manifest['replay']:
        metadata['replay_source'] = {k:v for k,v in manifest['replay'].items() if k != 'checks'}
    page = f'''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>SIL reference verification</title>
<style>body{{font:15px system-ui;max-width:1200px;margin:2rem auto;padding:0 1rem;color:#183044}}img{{width:100%;height:auto}}pre{{white-space:pre-wrap;overflow-wrap:anywhere}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #bbb;padding:.4rem;text-align:left;vertical-align:top}}.checks{{overflow-x:auto}}</style>
<h1>SIL reference verification</h1><ul>{status}</ul>
<p>4 kg manufactured reference, I=diag(4,4,8) kg m², zero gravity and a CG yaw couple.
Rigid-body RK4 is checked against scalar motion and cut loads at x=.5 m, retaining +x.</p>
<p>SIL checks host controller logic and numerical agreement. Processor execution time,
hardware I/O, physical sensor/actuator fidelity, aircraft behavior and structural design
acceptance require separate evidence. Pure-yaw branch: |yaw| &lt; 1 rad.</p>
<p>{links}</p><img src="plots.svg" alt="Python and C motion, actuator, cut-load and sensing comparisons, plus sampling convergence">
<details><summary>Inputs, units, tolerances, event order and source/compiler identities</summary><pre>{js(metadata)}</pre></details>
<h2>All verification and replay checks</h2><div class="checks"><table><tr><th>Group</th><th>Check</th><th>Result</th><th>Evidence</th></tr>{rows}</table></div></html>'''
    (output/'report.html').write_text(page,encoding='utf-8')
