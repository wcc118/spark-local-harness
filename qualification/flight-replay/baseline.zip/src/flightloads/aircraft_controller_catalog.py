"""Bounded controller subprocess jobs; HTTP/UI integration is a separate slice."""
from copy import deepcopy
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import threading
import time

from .aircraft_controller_store import ControllerStore, ACTIVE, _progress, write_artifact
from .aircraft_controller_trim import _identity
from .aircraft_elastic import digest
from ._aircraft_controller_job import MAX_MESSAGE

MEMORY_BYTES = 8*1024**3
WALL_SECONDS = 1800.


class ControllerCatalog:
    def __init__(self, root, execution_lock, *, _wall_seconds=WALL_SECONDS, _memory_bytes=MEMORY_BYTES):
        if not 0<_wall_seconds<=WALL_SECONDS or not 32*1024**2<=_memory_bytes<=MEMORY_BYTES:
            raise ValueError('Invalid controller worker resource ceiling')
        self.store = ControllerStore(root); self._execution = execution_lock
        self._lock = threading.RLock(); self._jobs = {}; self._closing = False; self._closed = threading.Event()
        self._wall = _wall_seconds; self._memory = _memory_bytes
        try:
            # A child inherits the same flock lease. Successful root acquisition
            # proves the prior owner AND its children have released that lease.
            for row in self.store.listing()['records']:
                if row['phase'] in ACTIVE:
                    self.store.update(row['id'],phase='interrupted',error='Previous process ended without durable result publication; no automatic resume')
        except BaseException:
            self.store.close(); raise

    def __enter__(self): return self
    def __exit__(self,*args): self.close()

    def _ensure_open(self):
        if self._closing: raise RuntimeError('Controller catalog is shutting down')

    def _view(self, row):
        row = deepcopy(row); job = self._jobs.get(row['id'])
        active = job is not None and not job['done'].is_set()
        row.update(active=active,cancellable=active and row['phase'] in ('preparing','running'),
                   cancel_requested=bool(job and job['cancel'].is_set()),
                   error=(job.get('error') if job else None) or row['error'],
                   resources=deepcopy(job.get('resources')) if job else None)
        return row

    def listing(self):
        with self._lock:
            result = self.store.listing(); result['records'] = [self._view(r) for r in result['records']]
            result['busy'] = self._execution.locked()
            result['limits'].update(worker_address_space_bytes=self._memory,worker_wall_seconds=self._wall,max_active_analyses=1)
            return result

    def snapshot(self, identifier):
        with self._lock: return self._view(self.store.snapshot(identifier))

    def configuration(self, inputs, parent_config_id=None):
        with self._lock:
            self._ensure_open()
            return self.store.create('configuration',inputs,parent_config_id=parent_config_id)

    def start(self, inputs, parent_config_id=None):
        return self._start('run',inputs,parent_config_id=parent_config_id)

    def replay(self, identifier):
        with self._lock:
            self._ensure_open()
            source = self.store.snapshot(identifier)
            if source['kind']!='run' or source['phase']!='finished': raise ValueError('Replay requires a finished saved run')
            if any(not job['done'].is_set() and job['id']==identifier for job in self._jobs.values()):
                raise RuntimeError('Source run is still active')
            inputs = self.store.artifact(identifier,'inputs.json')
            return self._start('replay',inputs,source_run_id=identifier)

    def _start(self, kind, inputs, **references):
        with self._lock:
            self._ensure_open()
            if not self._execution.acquire(blocking=False): raise RuntimeError('An aircraft analysis is already running')
            row = None; worker = None
            try:
                row = self.store.create(kind,inputs,**references); identifier = row['id']
                hashes,platform = _identity()
                job = dict(id=identifier,kind=kind,source=row['source_run_id'],cancel=threading.Event(),
                    done=threading.Event(),process=None,thread=None,error=None,resources=None,
                    identity=dict(hashes=hashes,platform=platform),last_progress=None)
                worker = threading.Thread(target=self._run,args=(job,),name='controller-'+identifier,daemon=True)
                job['thread'] = worker; self._jobs[identifier] = job
                try: worker.start()
                except BaseException:
                    if worker.ident is None:
                        job['done'].set(); job['thread'] = None
                    raise
                return self._view(row)
            except BaseException as error:
                # A late launch-call exception can leave a real supervisor alive.
                # It owns the lease until its terminal handling; admission is then
                # ambiguous to the caller, which must discover the saved job.
                if worker is not None and worker.ident is not None: raise
                if row is not None:
                    try: self.store.update(row['id'],phase='failed',error=('Could not start controller supervisor: '+str(error))[:2000])
                    except Exception as persistence: error.add_note('Terminal metadata write failed: '+str(persistence))
                self._execution.release(); raise

    @staticmethod
    def _stop(process):
        if process is None: return
        if process.poll() is None:
            try: process.terminate()
            except ProcessLookupError: pass
            try: process.wait(timeout=2.)
            except subprocess.TimeoutExpired:
                try: process.kill()
                except ProcessLookupError: pass
                process.wait()  # never release ownership while a child is alive

    def _run(self, job):
        identifier = job['id']; fds = []; process = None; error = None
        try:
            directory = self.store.open_writer(identifier); fds.append(directory)
            control_read,control_write = os.pipe(); progress_read,progress_write = os.pipe()
            fds.extend((control_read,control_write,progress_read,progress_write))
            os.set_blocking(progress_read,False)
            command = [sys.executable,str(Path(__file__).with_name('_aircraft_controller_job.py')),
                '--directory-fd',str(directory),'--lease-fd',str(self.store._lock_fd),
                '--control-fd',str(control_read),'--progress-fd',str(progress_write),
                '--memory-bytes',str(self._memory),'--kind',job['kind'],
                '--identity-sha',digest(job['identity'])]
            inherited = [directory,self.store._lock_fd,control_read,progress_write]
            if job['source'] is not None:
                with self.store._mutex, self.store._directory(job['source']) as fd:
                    source_fd = os.dup(fd); fds.append(source_fd); inherited.append(source_fd)
                    description = self.store.snapshot(job['source'])['artifacts']['report.json']
                command += ['--source-fd',str(source_fd),'--source-sha',description['sha256']]
            environment = dict(os.environ)
            source_path = str(Path(__file__).resolve().parent.parent)
            environment['PYTHONPATH'] = source_path+os.pathsep+environment.get('PYTHONPATH','')
            started = time.monotonic()
            process = subprocess.Popen(command,pass_fds=tuple(inherited),stdin=subprocess.DEVNULL,
                                       stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=environment)
            with self._lock: job['process'] = process
            for fd in (control_read,progress_write): os.close(fd); fds.remove(fd)
            result,error = self._monitor(job,process,progress_read,control_write,started)
            self._stop(process)  # reap before publishing or releasing the shared lock
            with self._lock:
                if self._closing: raise RuntimeError('Server shutdown interrupted controller execution')
                self.store.update(identifier,phase='verifying')
                if job['kind']=='replay' and job['cancel'].is_set():
                    source = self.store.artifact(job['source'],'report.json')
                    verdict = dict(schema='aircraft-controller-replay-v1',status='cancelled',
                        source_report_sha256=source['report_sha256'],replayed_report_sha256=None,
                        implementation_hashes=job['identity']['hashes'],platform=job['identity']['platform'],
                        error='Replay cancelled by user; no match is claimed')
                    write_artifact(directory,'replay.json',verdict)
                else:
                    if error: raise RuntimeError(error)
                    if process.returncode!=0: raise RuntimeError('Controller child exited '+str(process.returncode)+' without a verified result')
                    if result is None or result.get('kind')!=job['kind']: raise RuntimeError('Controller child returned no valid completion message')
                    if job['kind']=='replay': write_artifact(directory,'replay.json',result['verdict'])
                if result is not None: job['resources'] = result.get('resources')
                self.store.publish(identifier)
        except BaseException as caught:
            self._stop(process)
            error = (type(caught).__name__+': '+str(caught))[:2000] or 'Controller execution failed'
            with self._lock:
                job['error'] = error
                try:
                    phase = 'interrupted' if self._closing else 'failed'
                    self.store.update(identifier,phase=phase,error=error)
                except Exception as persistence:
                    job['error'] += '; failed to persist terminal status: '+str(persistence)[:500]
        finally:
            for fd in fds:
                try: os.close(fd)
                except OSError: pass
            with self._lock:
                job['done'].set()
                self._execution.release()

    def _monitor(self, job, process, read_fd, control_fd, started):
        buffer = b''; result = None; error = None; sent_cancel = False; persisted = 0.; exited = False
        inputs = self.store.artifact(job['id'],'inputs.json'); timing = inputs['bench']['timing']
        total = round(timing['duration_s']/timing['plant_dt_s'])
        while True:
            if self._closing: raise RuntimeError('Server shutdown interrupted controller execution')
            if time.monotonic()-started>self._wall: raise RuntimeError('Controller child exceeded wall-time limit; no verified trajectory was published')
            if job['cancel'].is_set() and not sent_cancel:
                if job['kind']=='replay': self._stop(process)
                else:
                    try: os.write(control_fd,b'C')
                    except BrokenPipeError: pass
                sent_cancel = True
            select.select([read_fd],[],[],.02)
            while True:
                try: chunk = os.read(read_fd,8192)
                except BlockingIOError: break
                if not chunk: break
                buffer += chunk
                while b'\n' in buffer:
                    raw,buffer = buffer.split(b'\n',1)
                    if len(raw)>MAX_MESSAGE: raise ValueError('Worker message exceeds limit')
                    message = json.loads(raw)
                    if type(message) is not dict: raise ValueError('Malformed worker message')
                    event = message.get('event')
                    if event=='progress':
                        p = message['progress']; _progress(p)
                        if p['total_ticks']!=total or (p['accepted_tick'] is not None and abs(p['time_s']-p['accepted_tick']*timing['plant_dt_s'])>1e-9):
                            raise ValueError('Worker progress disagrees with frozen clock')
                        old = job['last_progress']
                        if old is not None and old['accepted_tick'] is not None and (p['accepted_tick'] is None or p['accepted_tick']<old['accepted_tick']):
                            raise ValueError('Worker progress regressed')
                        job['last_progress'] = p
                        if time.monotonic()-persisted>=.1 or p['status']!='running':
                            self.store.update(job['id'],phase='running' if p['accepted_tick'] is not None else 'preparing',progress=p)
                            persisted = time.monotonic()
                    elif event=='done':
                        if result is not None: raise ValueError('Duplicate worker completion')
                        result = message
                    elif event=='error': error = str(message.get('error','Worker failure'))[:2000]
                    else: raise ValueError('Unknown worker event')
                if len(buffer)>MAX_MESSAGE: raise ValueError('Unterminated worker message exceeds limit')
            if process.poll() is not None:
                # Drain once after observing exit, covering a final write between
                # a nonblocking read and poll(). The parent's write end is closed.
                if not exited:
                    exited = True
                    continue
                # Child has closed its pipe; all remaining bytes must be complete.
                if buffer and not (job['kind']=='replay' and job['cancel'].is_set()):
                    raise ValueError('Truncated worker message')
                return result,error

    def cancel(self, identifier):
        with self._lock:
            row = self.snapshot(identifier)
            if not row['cancellable']: raise RuntimeError('No cancellable controller job')
            self._jobs[identifier]['cancel'].set()
            return self.snapshot(identifier)

    def delete(self, identifier, confirmation):
        with self._lock:
            self._ensure_open()
            if any(not j['done'].is_set() and identifier in (j['id'],j['source']) for j in self._jobs.values()):
                raise RuntimeError('Selected record is used by an active controller process')
            result = self.store.delete(identifier,confirmation); self._jobs.pop(identifier,None)
            return result

    def artifact(self, identifier, name):
        with self._lock:
            if name!='inputs.json' and any(not j['done'].is_set() and j['id']==identifier for j in self._jobs.values()):
                raise RuntimeError('Result is still being written or verified')
            return self.store.artifact(identifier,name)

    def download(self, identifier, name):
        with self._lock:
            if name!='inputs.json' and any(not j['done'].is_set() and j['id']==identifier for j in self._jobs.values()):
                raise RuntimeError('Result is still being written or verified')
            return self.store.verified_bytes(identifier,name)

    def close(self):
        with self._lock:
            already_closing = self._closing
            self._closing = True; workers = [j['thread'] for j in self._jobs.values() if j['thread'] is not None]
        if already_closing:
            self._closed.wait()
            return
        try:
            for worker in workers: worker.join()
            self.store.close()
        finally: self._closed.set()
