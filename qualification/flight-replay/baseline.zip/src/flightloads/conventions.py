"""Hamilton scalar-first quaternions; active rotations map body to inertial axes."""

import numpy as np


def finite_vector(value, size, name):
    result = np.asarray(value, dtype=np.float64)
    if result.shape != (size,) or not np.all(np.isfinite(result)):
        raise ValueError(f'{name} must be a finite vector of length {size}')
    return result


def unit_quaternion(value):
    q = finite_vector(value, 4, 'quaternion')
    with np.errstate(over='ignore'):
        norm = np.linalg.norm(q)
    if not np.isfinite(norm) or norm <= 1e-12:
        raise ValueError('quaternion norm must be finite and > 1e-12')
    return q / norm


def quaternion_multiply(a, b):
    """Raw a*b Hamilton product. Active rotations apply b, then a."""
    a = finite_vector(a, 4, 'a')
    b = finite_vector(b, 4, 'b')
    product = np.r_[a[0]*b[0] - a[1:]@b[1:],
                    a[0]*b[1:] + b[0]*a[1:] + np.cross(a[1:], b[1:])]
    return finite_vector(product, 4, 'quaternion product')


def rotation_matrix(q):
    s, x, y, z = unit_quaternion(q)
    u = np.array([x, y, z])
    cross = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]])
    return (s*s-u@u)*np.eye(3) + 2*np.outer(u, u) + 2*s*cross


def attitude_error(a, b):
    """Shortest orientation separation in radians, invariant to quaternion sign."""
    a, b = unit_quaternion(a), unit_quaternion(b)
    relative = quaternion_multiply(a * [1, -1, -1, -1], b)
    return float(2*np.arctan2(np.linalg.norm(relative[1:]), abs(relative[0])))
