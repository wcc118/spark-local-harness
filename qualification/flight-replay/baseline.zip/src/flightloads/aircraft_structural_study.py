"""Reproducible verification study for the illustrative moving-root wing pilot."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import numpy as np
from .aircraft_elastic import source_history, _solve, serialize_response
from .aircraft_structure import WingBeam, G_IN_S2, IN_M, LBF_N, MOMENT_NM, PSI_PA
from .beam import Excitation, integrate_modal

RESPONSE_LIMITS = dict(tip_w_in=.0001, root_Fz_lbf=.01, root_Mx_in_lbf=.1,
    root_stress_positive_z_psi=5., mid_stress_positive_z_psi=5.)
RTOL = .005


def responses(wing,h):
    a=h.arrays
    mid=np.array([wing.recover(u,[wing.length_in/2])['stress_positive_z_psi'][0]
        for u in a['displacement_free']])
    return dict(tip_w_in=a['displacement_free'][:,-2]/IN_M,
        root_Fz_lbf=a['root_reaction_z_N']/LBF_N,root_Mx_in_lbf=-a['root_reaction_y_Nm']/MOMENT_NM,
        root_stress_positive_z_psi=a['stress_positive_z_Pa'][:,0]/PSI_PA,mid_stress_positive_z_psi=mid)


def compare(coarse,fine):
    wc,hc,_=coarse;wf,hf,_=fine
    rc,rf=responses(wc,hc),responses(wf,hf)
    indices=np.array([np.argmin(abs(hf.times_s-t)) for t in hc.times_s])
    if max(abs(hf.times_s[indices]-hc.times_s))>1e-10:
        raise ValueError('comparison requires common physical times')
    checks={}
    for key,limit in RESPONSE_LIMITS.items():
        error=float(max(abs(rc[key]-rf[key][indices])))
        tolerance=limit+RTOL*float(max(abs(rf[key])))
        checks[key]=dict(error=error,tolerance=tolerance,passed=error<=tolerance)
    return dict(checks=checks,passed=all(c['passed'] for c in checks.values()))


def static_modal_checks():
    w=WingBeam(young_psi=2e6);b=w.beam;L=w.length_in;EI=w.EI_lbf_in2
    uniform=w.uniform_case(1.,gravity_z_in_s2=0.)
    tests={}
    for key,actual,expected,atol in [('tip_w_in',uniform['response']['w_in'][-1],L**4/(8*EI),1e-9),
        ('root_Fz_lbf',uniform['root_Fz_lbf'],-L,1e-9),
        ('root_Mx_in_lbf',uniform['root_Mx_in_lbf'],-L**2/2,1e-8)]:
        error=abs(actual-expected);tolerance=atol+1e-8*abs(expected)
        tests[key]=dict(actual=actual,expected=expected,error=error,tolerance=tolerance,passed=error<=tolerance)
    roots=np.array([1.875104068711961,4.694091132974175,7.854757438237613])
    exact=roots**2*np.sqrt(EI/w.mass_per_length_lbf_s2_in2)/L**2
    error=float(max(abs(b.omega_radps[:3]/exact-1)))
    tests['first_three_modes']=dict(frequency_hz=(b.omega_radps[:3]/(2*np.pi)).tolist(),
        exact_hz=(exact/(2*np.pi)).tolist(),relative_error=error,tolerance=.001,passed=error<=.001)
    mass_error=float(abs(b.modes.T@b.mass_free@b.modes-np.eye(len(b.modes))).max())
    stiffness_error=float(abs(b.modes.T@b.stiffness_free@b.modes-np.diag(b.omega_radps**2)).max()/max(b.omega_radps**2))
    tests['orthogonality']=dict(mass_error=mass_error,scaled_stiffness_error=stiffness_error,
        tolerance=1e-8,passed=max(mass_error,stiffness_error)<=1e-8)
    return dict(checks=tests,passed=all(t['passed'] for t in tests.values()))


def oscillator_check():
    b=WingBeam(young_psi=2e6).beam;omega=b.omega_radps[0];zeta=.02;wd=omega*np.sqrt(1-zeta*zeta)
    period=2*np.pi/omega;q0=1e-4;errors=[]
    for n in (100,200,400):
        h=integrate_modal(b,lambda t:Excitation(b,np.zeros(len(b.mass_full))),
            t_final_s=3*period,dt_s=period/n,retained_modes=1,residual_correction=False,initial_q=[q0])
        t=h.times_s
        exact=q0*np.exp(-zeta*omega*t)*(np.cos(wd*t)+zeta*omega/wd*np.sin(wd*t))
        errors.append(float(max(abs(h.arrays['modal_q'][:,0]-exact))/abs(q0)))
    ratios=[errors[i]/errors[i+1] for i in (0,1)]
    return dict(steps_per_period=[100,200,400],normalized_errors=errors,reduction_ratios=ratios,
        finest_limit=.0004,ratio_limits=[3.5,4.5],
        passed=errors[-1]<=.0004 and all(3.5<=v<=4.5 for v in ratios))


def run_study():
    source=source_history();cache={}
    def solve(n=32,modes=None,dt=.0005):
        key=(n,modes,dt)
        if key not in cache:cache[key]=_solve(source,elements=n,retained_modes=modes,dt_s=dt)
        return cache[key]
    spatial=[solve(n=n) for n in (8,16,32)]
    modal=[solve(modes=n) for n in (4,8,16,32,None)]
    temporal=[solve(dt=t) for t in (.002,.001,.0005)]
    coarse_source=source_history(rigid_dt_s=.0005)
    source_check=compare(_solve(coarse_source),solve())
    families={name:[compare(a,b) for a,b in zip(levels,levels[1:])]
        for name,levels in [('spatial',spatial),('modal',modal),('time',temporal)]}
    wing,h,inputs=solve()
    pilot=serialize_response(source,wing,h,inputs)
    rejected=serialize_response(source,*_solve(source,young_psi=1e6))
    static=static_modal_checks();oscillator=oscillator_check()
    transfer=dict(force_lbf=max(max(abs(np.asarray(v)[:3])) for tr in inputs['transfers'] for v in tr['transfer_residuals'].values()),
        moment_in_lbf=max(max(abs(np.asarray(v)[3:])) for tr in inputs['transfers'] for v in tr['transfer_residuals'].values()))
    passed=all(f[-1]['passed'] for f in families.values()) and source_check['passed'] and static['passed'] and oscillator['passed']
    passed=passed and pilot['scope_status']=='within-illustrative-pilot' and pilot['equation_verified']
    study=dict(schema='aircraft-wing-study-v1',verification_passed=bool(passed),static_modal=static,oscillator=oscillator,
        convergence=families,levels=dict(spatial_elements=[8,16,32],modal_counts=[4,8,16,32,64],time_dt_s=[.002,.001,.0005]),
        source_resolution=dict(coarse_dt_s=.0005,fine_dt_s=.00025,**source_check),
        response_absolute_tolerances=RESPONSE_LIMITS,response_relative_tolerance=RTOL,
        transfer_max_component_residual=transfer,
        rejected_baseline=dict(young_psi=1e6,structural_model_id=rejected['structural_model_id'],
            scope_status=rejected['scope_status'],screening_metrics=rejected['screening_metrics'],
            screening_limits=rejected['screening_limits'],initial_tip_w_in=rejected['response']['tip_w_in'][0]),
        pilot_summary=dict(young_psi=2e6,history_sha256=pilot['history_sha256'],structural_model_id=pilot['structural_model_id'],
            scope_status=pilot['scope_status'],screening_metrics=pilot['screening_metrics'],
            response_extrema={k:dict(min=float(min(v)),max=float(max(v))) for k,v in pilot['response'].items()}),
        interpretation='Numerical verification of an illustrative one-way wing-bending pilot; no actual-aircraft validation or design acceptance.')
    return study,pilot,source


def save_study(output):
    output=Path(output)
    if output.exists():raise ValueError('output exists; choose a new directory')
    study,pilot,source=run_study()
    root=Path(__file__).resolve().parents[2]
    try:
        revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
        dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip())
    except (subprocess.CalledProcessError,FileNotFoundError):revision='unavailable';dirty=None
    hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((root/'src'/'flightloads').glob('*.py'))}
    output.mkdir(parents=True,exist_ok=False)
    for name,data in [('pilot.json.gz',pilot),('rigid-source.json.gz',source)]:
        raw=json.dumps(data,sort_keys=True,allow_nan=False).encode()
        (output/name).write_bytes(gzip.compress(raw,mtime=0))
    study.update(artifacts=dict(pilot='pilot.json.gz',rigid_source='rigid-source.json.gz'),
        provenance=dict(commit=revision,dirty=dirty,source_sha256=hashes,
            artifact_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir()}))
    (output/'study.json').write_text(json.dumps(study,indent=2,allow_nan=False)+'\n')
    return study


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args(argv)
    study=save_study(args.output)
    print(f'{args.output}/study.json; numerical verification passed={study["verification_passed"]}')
    return 0 if study['verification_passed'] else 1


if __name__=='__main__':raise SystemExit(main())
