"""Standalone scientific plots and an inspectable benchmark report."""
import html
import io
import json
import numpy as np


def render_plots(result):
    try:
        from matplotlib import rc_context
        from matplotlib.figure import Figure
    except ImportError as error:
        raise RuntimeError('Install the reporting extra: pip install -e ".[reports]"') from error
    t=result.simulation.times_s; a=result.arrays; s=result.simulation.states
    with rc_context({'svg.fonttype':'none','font.size':9,'axes.grid':True,'grid.alpha':.25}):
        figure=Figure(figsize=(11,14),layout='constrained')
        axes=figure.subplots(4,2).ravel()
        def draw(index,title,unit,series):
            ax=axes[index]; ax.set(title=title,xlabel='Time [s]',ylabel=unit)
            for label,values,style in series:
                ax.plot(t,values,style,label=label,linewidth=1.4)
            ax.legend(fontsize=8);ax.ticklabel_format(axis='y',style='sci',scilimits=(-3,4))
        draw(0,'CG position in inertial axes','z_N [m]',
             [('computed',s[:,2],'-'),('analytic',a['reference_position_N_m'][:,2],'--')])
        draw(1,'Body angular rate','omega_z [rad/s]',
             [('computed',s[:,12],'-'),('analytic',a['reference_omega_B_radps'][:,2],'--')])
        draw(2,'Applied non-gravity loading','Couple z_B [N m]',
             [('prescribed',np.full(len(t),result.applied_loads.couples_B_Nm[0,2]),'-')])
        draw(3,'Mass point 0: separate force contributions','Body components [N]',
             [('negative inertia x',a['inertia_force_B_N'][:,0,0],'-'),
              ('negative inertia y',a['inertia_force_B_N'][:,0,1],'-'),
              ('negative inertia z',a['inertia_force_B_N'][:,0,2],'-'),
              ('gravity z',a['gravity_force_B_N'][:,0,2],'--')])
        draw(4,'Force on retained x > 0.5 m side','Body components [N]',
             [('Fx',a['section_force_B_N'][:,0],'-'),('Fy',a['section_force_B_N'][:,1],'-'),
              ('analytic Fx',a['reference_section_force_B_N'][:,0],'--'),
              ('analytic Fy',a['reference_section_force_B_N'][:,1],'--')])
        draw(5,'Section moment about (0.5, 0, 0) m','Mz_B [N m]',
             [('computed',a['section_moment_B_Nm'][:,2],'-'),
              ('analytic',a['reference_section_moment_B_Nm'][:,2],'--')])
        draw(6,'Whole-body force balance','Norm [N]',
             [('residual',np.linalg.norm(a['force_residual_B_N'],axis=1),'-'),
              ('limit',a['force_limit_N'],'--')])
        draw(7,'Whole-body CG moment balance','Norm [N m]',
             [('residual',np.linalg.norm(a['moment_residual_B_Nm'],axis=1),'-'),
              ('limit',a['moment_limit_Nm'],'--')])
        stream=io.StringIO();figure.savefig(stream,format='svg',metadata={'Date':None})
    text=stream.getvalue()
    return text[text.index('<svg'):]


def render_report(result,manifest,svg):
    esc=html.escape
    statuses=''.join(f'<div class="status"><b>{esc(k.replace("_"," "))}</b><br>{esc(v.replace("_"," "))}</div>'
                     for k,v in manifest['status'].items())
    def block(value):
        return '<pre>'+esc(json.dumps(value,indent=2,allow_nan=False))+'</pre>'
    final={name:result.arrays[name][-1].tolist() for name in (
        'reference_position_N_m','reference_velocity_B_mps','reference_omega_B_radps',
        'reference_section_force_B_N','reference_section_moment_B_Nm')}
    return f'''<!doctype html><html lang="en"><meta charset="utf-8">
<title>Mechanics-to-loads benchmark</title>
<style>body{{font:16px/1.5 system-ui,sans-serif;color:#182a3b;background:#f3f6f9;margin:0}}
main{{max-width:1120px;margin:auto;padding:32px}}h1{{font-size:32px;margin:0}}h2{{font-size:22px}}
section{{background:white;border:1px solid #d6e0e8;border-radius:8px;padding:22px;margin:22px 0}}
.statuses{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:22px 0}}
.status{{background:#e5edf5;padding:14px;border-radius:6px;font-size:14px}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f7fa;padding:14px;font-size:13px}}
svg{{width:100%;height:auto}}.muted{{color:#526579}}@media(max-width:700px){{.statuses{{grid-template-columns:1fr 1fr}}main{{padding:15px}}}}
</style><main><p class="muted">Generic reference model &middot; schema 1</p>
<h1>Mechanics to section loads</h1><p>A prescribed couple and uniform gravity,
with independent motion and load references.</p><div class="statuses">{statuses}</div>
<section><h2>Case and applicability</h2>{block(manifest['configuration'])}
<p>Four 1 kg masses at (+/-1, +/-1, 0) m; I = diag(4, 4, 8) kg m^2.
A constant z couple of 8*alpha N m acts at (2, 0, 0) m. Initial motion is zero,
attitude is identity, and gravity is (0, 0, g) m/s^2. Applied force is zero.
The cut at x=0.5 m retains the positive x side. All load vectors use body axes;
section moments act on the retained side about (0.5, 0, 0) m.</p>
<p>This is a fixed-geometry rigid-body verification case. It does not validate a
vehicle, aerodynamics, elastic response, launch dynamics, or a design envelope.</p></section>
<section><h2>Synchronized histories</h2><p>Every curve uses the same saved times.
Providers and accelerations are reevaluated at saved states before load recovery.
All samples enter the numerical checks.</p>{svg}</section>
<section><h2>Independent reference</h2><pre>omega_z = alpha*t; theta = 0.5*alpha*t^2
q_NB = [cos(theta/2), 0, 0, sin(theta/2)]
r_N_z = 0.5*g*t^2; v_B_z = g*t
mass gravity + negative inertia = [omega_z^2*x + alpha*y, omega_z^2*y - alpha*x, 0]
section F_B = [-2*omega_z^2, 2*alpha, 0] N
section M_B = [0, 0, -5*alpha] N m</pre>
<p>Gravity cancels translational inertia pointwise. Angular and centripetal inertia
remain. The two retained masses contribute Fy=-2*alpha N and Mz=-3*alpha N m;
the applied couple contributes +8*alpha N m. Negating the retained resultant gives
the section loads above.</p><p>Analytic values at the final saved time:</p>{block(final)}</section>
<section><h2>Numerical acceptance evidence</h2>{block(manifest['verification'])}
<p>Attitude tolerance is 1e-6 rad. Other reference-component errors use
1e-9 in the stated SI unit plus 1e-10 times the maximum absolute reference component.
Force and moment balance each use their own dimensional absolute-plus-relative
limits. Run completion does not imply these checks pass. Refine the timestep if
numerical verification fails; physical validation and design acceptance remain separate.</p></section>
<section><h2>Reproduce and inspect</h2><p>Keep manifest.json, histories.npz, history.csv,
plots.svg, and report.html together. NPZ holds full numeric arrays; CSV provides one row
per saved time. Model geometry and constant applied loads are recorded in the manifest.</p>
<pre>python -m flightloads.benchmark rerun --manifest PATH/manifest.json --output NEW_DIRECTORY</pre>
<p>Rerun comparison uses atol=1e-9 and rtol=1e-10 on every numeric array and recomputes
reference checks. Checksums detect artifact changes; they are not an authenticity signature.</p>
{block(manifest['comparison'])}</section><section><h2>Run provenance and numerical settings</h2>
<p>Run {esc(manifest['run_id'])} &middot; {esc(manifest['created_utc'])}</p>
{block(manifest['provenance'])}{block(manifest['numerics'])}</section></main></html>'''
