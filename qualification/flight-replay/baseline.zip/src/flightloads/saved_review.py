"""Fixed, read-only saved structural report served on the dashboard origin."""
import base64
import hashlib
from pathlib import Path
import re


class SavedStructuralReview:
    """Snapshot explicit report files at startup; never resolve request paths."""
    NAMES=('index.html','study.json','pilot.json.gz','rigid-source.json.gz')

    def __init__(self,directory):
        root=Path(directory).resolve()
        self.artifacts={}
        names=list(self.NAMES)
        optional=root/'equivalent-static.json'
        if optional.exists() or optional.is_symlink():names.append(optional.name)
        for name in names:
            path=root/name
            if path.is_symlink() or path.stat().st_size>64*1024*1024:
                raise ValueError('invalid saved structural review artifact')
            self.artifacts[name]=path.read_bytes()
        document=self.artifacts['index.html'].decode('utf-8')
        scripts=re.findall(r'<script>(.*?)</script>',document,re.DOTALL)
        if len(scripts)!=1:raise ValueError('expected one saved report script')
        digest=base64.b64encode(hashlib.sha256(scripts[0].encode()).digest()).decode()
        self.csp=(f"default-src 'none'; script-src 'sha256-{digest}'; "
                  "style-src 'unsafe-inline'; img-src data:; base-uri 'none'; frame-ancestors 'none'")

    def artifact(self,name):
        data=self.artifacts[name]
        kind=('text/html; charset=utf-8' if name=='index.html' else
              'application/json' if name.endswith('.json') else 'application/gzip')
        return data,kind
