"""Bounded envelope archives, independently replayed before dashboard publication."""
from datetime import datetime, timezone
import csv
import hashlib
import io
import json
from pathlib import Path
import zipfile
import numpy as np
from .beam import BeamModel, BeamHistory
from .benchmark import code_identity
from .envelope import EnvelopeSpec, EnvelopeStudy, SCHEMA, canonical
from .uncertainty import SamplingSpec, Trial, Ensemble, checked_basis

FILES = ('basis.npz', 'study.json', 'cases.csv')
MAX_BYTES = 128*1024*1024


def digest(data): return hashlib.sha256(data).hexdigest()


def read_file(root, name):
    path = root/name
    if root.is_symlink() or path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise ValueError('invalid envelope artifact path or size')
    with path.open('rb') as stream: data = stream.read(MAX_BYTES+1)
    if len(data) > MAX_BYTES: raise ValueError('envelope artifact too large')
    return data


def parse_json(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result: raise ValueError('duplicate JSON key')
            result[key] = value
        return result
    def invalid(value): raise ValueError('nonfinite JSON value')
    return json.loads(data, object_pairs_hook=unique, parse_constant=invalid)


def cases_csv(summary):
    stream = io.StringIO(newline=''); writer = csv.writer(stream)
    writer.writerow(['model_key','case_id','source_id','time_s','index','source_digest','reasons'])
    for model in summary['models']:
        for c in model['cases']:
            writer.writerow([model['model_key'],c['case_id'],c['source_id'],c['time_s'],c['index'],c['source_digest'],';'.join(c['reasons'])])
    return stream.getvalue().encode()


def export_envelope(study, directory):
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=False)
    summary = study.snapshot(); arrays = {}; models = []
    for number, (training, _) in enumerate(study.pairs):
        basis = training.basis; first = basis.histories[0]; prefixes = []
        for j, history in enumerate(basis.histories):
            prefix = f'm{number}_b{j}_'; prefixes.append(prefix)
            arrays.update({prefix+k:v for k,v in dict(times_s=history.times_s, **history.arrays).items()})
        models.append(dict(model=dict(basis.model.config), model_id=basis.model.model_id, basis_id=basis.basis_id,
            basis_digests=list(basis.digests), prefixes=prefixes, sampling=training.sampling.metadata(),
            integration=dict(dt_s=first.requested_dt_s, retained_modes=first.retained_modes,
                             residual_correction=first.residual_correction)))
    np.savez_compressed(root/'basis.npz', **arrays)
    (root/'study.json').write_bytes(canonical(summary))
    (root/'cases.csv').write_bytes(cases_csv(summary))
    manifest = dict(schema=SCHEMA, study_id=summary['study_id'], created_utc=datetime.now(timezone.utc).isoformat(),
        code=code_identity(), specification=study.spec.metadata(), models=models, status=summary['status'],
        artifacts={name:dict(bytes=(root/name).stat().st_size, sha256=digest((root/name).read_bytes())) for name in FILES})
    (root/'manifest.json').write_bytes(canonical(manifest))
    return manifest


def load_arrays(data):
    """Inspect compressed sizes AND NPY shapes before allowing array allocation."""
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries = archive.infolist()
        if not 1 <= len(entries) <= 162 or len({e.filename for e in entries}) != len(entries):
            raise ValueError('invalid or duplicate basis members')
        if sum(e.file_size for e in entries) > MAX_BYTES: raise ValueError('expanded basis archive too large')
        for entry in entries:
            if not entry.filename.endswith('.npy') or '/' in entry.filename or '\\' in entry.filename:
                raise ValueError('unexpected basis member')
            with archive.open(entry) as stream:
                version = np.lib.format.read_magic(stream)
                if version == (1, 0): shape, order, dtype = np.lib.format.read_array_header_1_0(stream)
                elif version == (2, 0): shape, order, dtype = np.lib.format.read_array_header_2_0(stream)
                else: raise ValueError('unsupported NPY version')
                if dtype != np.dtype('float64') or order or len(shape) not in (1, 2) or not 2 <= shape[0] <= 5001:
                    raise ValueError('unsupported basis dtype/layout/shape')
                if len(shape) == 2 and not 1 <= shape[1] <= 40: raise ValueError('basis column limit exceeded')
                if stream.tell()+int(np.prod(shape))*8 != entry.file_size: raise ValueError('basis shape/size mismatch')
    with np.load(io.BytesIO(data), allow_pickle=False) as archive:
        return {name:archive[name] for name in archive.files}


class EnvelopeCatalog:
    """One read-only study. Loading replays every event and recomputes all saved evidence."""
    def __init__(self, directory):
        self.root = Path(directory).absolute()
        try:
            raw = read_file(self.root, 'manifest.json'); manifest = parse_json(raw)
            if manifest['schema'] != SCHEMA or not 1 <= len(manifest['models']) <= 3:
                raise ValueError('unsupported envelope schema/model count')
            if manifest['code']['numpy'] != np.__version__: raise ValueError('NumPy changed; regenerate envelope')
            if set(manifest['artifacts']) != set(FILES): raise ValueError('unexpected envelope artifact set')
            data = {name:read_file(self.root, name) for name in FILES}
            for name, content in data.items():
                if manifest['artifacts'][name] != dict(bytes=len(content), sha256=digest(content)):
                    raise ValueError('envelope artifact hash/size mismatch')
            saved = parse_json(data['study.json']); arrays = load_arrays(data['basis.npz'])
            config = dict(manifest['specification'])
            for name in ('training_seed', 'calibration_seed'):
                if not isinstance(config[name], str) or str(int(config[name])) != config[name]:
                    raise ValueError('seed must be a canonical decimal string')
                config[name] = int(config[name])
            spec = EnvelopeSpec(**config); pairs = []; expected = set()
            if len(saved['models']) != len(manifest['models']): raise ValueError('model record count mismatch')
            for number, record in enumerate(manifest['models']):
                model_config = record['model']
                if not 1 <= model_config['elements'] <= 8: raise ValueError('archive beam element limit exceeded')
                model = BeamModel(**model_config); histories = []; settings = record['integration']
                if record['prefixes'] != [f'm{number}_b{j}_' for j in range(3)]: raise ValueError('basis prefix mismatch')
                for prefix in record['prefixes']:
                    names = {k[len(prefix):] for k in arrays if k.startswith(prefix)}
                    if 'times_s' not in names: raise ValueError('missing basis times')
                    expected.update(prefix+k for k in names)
                    histories.append(BeamHistory(model, settings['retained_modes'], settings['residual_correction'], settings['dt_s'],
                        arrays[prefix+'times_s'], {k:arrays[prefix+k] for k in names if k != 'times_s'}))
                basis = checked_basis(histories)
                if model.model_id != record['model_id'] or basis.basis_id != record['basis_id'] or list(basis.digests) != record['basis_digests']:
                    raise ValueError('model/basis changed; regenerate envelope')
                sampling = SamplingSpec(**{k:record['sampling'][k] for k in ('family','location','scale','correlation')})
                if canonical(sampling.metadata()) != canonical(record['sampling']): raise ValueError('sampling metadata mismatch')
                ensembles = []
                for kind, seed in (('training', spec.training_seed), ('calibration', spec.calibration_seed)):
                    records = [e['trial'] for e in saved['models'][number]['events'] if e['kind'] == kind]
                    trials = tuple(Trial(**r) for r in records)
                    ensembles.append(Ensemble(basis, sampling, seed, trials))
                pairs.append(tuple(ensembles))
            if set(arrays) != expected: raise ValueError('unexpected basis arrays')
            study = EnvelopeStudy(spec, pairs); actual = study.snapshot()
            if canonical(actual) != canonical(saved) or manifest['study_id'] != actual['study_id'] or manifest['status'] != actual['status']:
                raise ValueError('saved envelope evidence changed or is inconsistent; regenerate')
            if data['cases.csv'] != cases_csv(actual): raise ValueError('case CSV disagrees with replayed cases')
        except (KeyError, TypeError, IndexError, OverflowError, zipfile.BadZipFile) as exc:
            raise ValueError(f'invalid envelope archive: {exc}') from exc
        self._study = study; self._manifest = manifest
        self._hashes = {name:digest(content) for name,content in dict(data, **{'manifest.json':raw}).items()}

    def snapshot(self):
        value = self._study.snapshot()
        value['archive'] = dict(code=dict(self._manifest['code']), created_utc=self._manifest['created_utc'],
                                artifacts=['manifest.json', *FILES], replay_verified=True)
        return value

    def case_detail(self, case_id): return self._study.case_detail(case_id)

    def artifact(self, name):
        if name not in self._hashes: raise KeyError(name)
        content = read_file(self.root, name)
        if digest(content) != self._hashes[name]: raise ValueError('artifact changed since replay; reopen and verify')
        return content
