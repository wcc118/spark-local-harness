"""Explicit immutable PI-D interface and managed host-C implementation."""
from dataclasses import dataclass
import ctypes
import hashlib
import math
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile


def _finite(*values):
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x)
           for x in values):
        raise ValueError('controller scalars must be finite real numbers')


@dataclass(frozen=True)
class Measurement:
    yaw_rad: float
    rate_radps: float

    def __post_init__(self):
        _finite(self.yaw_rad, self.rate_radps)


@dataclass(frozen=True)
class Command:
    yaw_rad: float

    def __post_init__(self):
        _finite(self.yaw_rad)


@dataclass(frozen=True)
class ControllerState:
    integral_rad_s: float = 0.
    previous_error_rad: float = 0.

    def __post_init__(self):
        _finite(self.integral_rad_s, self.previous_error_rad)
        if abs(self.integral_rad_s) > .2:
            raise ValueError('integral state exceeds reference clamp')


@dataclass(frozen=True)
class ControllerOutput:
    state: ControllerState
    torque_Nm: float

    def __post_init__(self):
        if not isinstance(self.state, ControllerState):
            raise TypeError('ControllerState required')
        _finite(self.torque_Nm)


def _inputs(measurement, command, state, elapsed_s):
    if not (isinstance(measurement, Measurement) and isinstance(command, Command)
            and isinstance(state, ControllerState)):
        raise TypeError('explicit measurement, command and controller state required')
    _finite(elapsed_s)
    if elapsed_s < 0:
        raise ValueError('elapsed_s must be nonnegative')
    trial = state.integral_rad_s + state.previous_error_rad * elapsed_s
    error = command.yaw_rad - measurement.yaw_rad
    integral = max(-.2, min(.2, trial))
    _finite(trial, error, 24*error, 24*measurement.rate_radps,
            24*error + 8*integral - 24*measurement.rate_radps)


class MathematicalController:
    def step(self, measurement, command, state, elapsed_s):
        _inputs(measurement, command, state, elapsed_s)
        integral = max(-.2, min(.2, state.integral_rad_s + state.previous_error_rad*elapsed_s))
        error = command.yaw_rad - measurement.yaw_rad
        return ControllerOutput(ControllerState(integral, error),
                                24*error + 8*integral - 24*measurement.rate_radps)


class CompiledController:
    """Fixed packaged C on POSIX/cc; close releases files and forbids calls."""
    def __init__(self):
        self._closed = True
        self._temporary = None
        compiler = shutil.which('cc')
        if compiler is None:
            raise RuntimeError('SIL requires an existing host C compiler (cc)')
        source = Path(__file__).with_name('sil_controller.c')
        source_bytes = source.read_bytes()
        self._temporary = tempfile.TemporaryDirectory(prefix='flightloads-sil-')
        try:
            root = Path(self._temporary.name)
            copied = root/'controller.c'
            copied.write_bytes(source_bytes)
            binary = root/'controller.so'
            flags = ['-std=c11', '-Wall', '-Wextra', '-Werror', '-O2',
                     '-ffp-contract=off', '-shared', '-fPIC']
            invocation = [compiler, *flags, str(copied), '-o', str(binary)]
            built = subprocess.run(invocation, capture_output=True, text=True, timeout=30)
            if built.returncode:
                raise RuntimeError(f'C controller build failed: {built.stderr.strip()}')
            version = subprocess.run([compiler, '--version'], check=True,
                                     capture_output=True, text=True, timeout=10).stdout
            self._library = ctypes.CDLL(str(binary))
            self._step = self._library.flightloads_step
            self._step.argtypes = [ctypes.c_double]*4 + [ctypes.POINTER(ctypes.c_double)]*3
            self._step.restype = None
            self.provenance = dict(backend='host C via ctypes', source_sha256=hashlib.sha256(source_bytes).hexdigest(),
                binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(), compiler=compiler,
                compiler_version=version, flags=flags, invocation=invocation,
                platform=platform.platform(), machine=platform.machine(),
                build_stdout=built.stdout, build_stderr=built.stderr)
            self._closed = False
        except BaseException:
            self.close()
            raise

    def step(self, measurement, command, state, elapsed_s):
        if self._closed:
            raise RuntimeError('compiled controller is closed')
        _inputs(measurement, command, state, elapsed_s)
        integral = ctypes.c_double(state.integral_rad_s)
        previous = ctypes.c_double(state.previous_error_rad)
        torque = ctypes.c_double()
        self._step(command.yaw_rad, measurement.yaw_rad, measurement.rate_radps,
                   elapsed_s, ctypes.byref(integral), ctypes.byref(previous), ctypes.byref(torque))
        return ControllerOutput(ControllerState(integral.value, previous.value), torque.value)

    def close(self):
        self._closed = True
        self._step = None
        self._library = None
        if self._temporary is not None:
            self._temporary.cleanup()
            self._temporary = None

    def __enter__(self):
        if self._closed:
            raise RuntimeError('compiled controller is closed')
        return self

    def __exit__(self, *exc):
        self.close()
