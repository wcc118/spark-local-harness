"""Constant-mass rigid-body equations about the CG, with gravity separate."""

import numpy as np
from .conventions import finite_vector, quaternion_multiply, rotation_matrix
from .loads import integrate_loads
from .state import RigidDerivative


def rigid_derivative(state, mass_model, applied_loads, g_N):
    mass_model.require_rigid_inertia()
    g = finite_vector(g_N, 3, 'g_N')
    loads = integrate_loads(applied_loads)
    R = rotation_matrix(state.q_NB)
    w = state.omega_B_radps
    inertia = mass_model.inertia_CG_B_kg_m2
    return RigidDerivative(
        R @ state.v_CG_B_mps,
        loads.force_B_N / mass_model.mass_kg + R.T @ g - np.cross(w, state.v_CG_B_mps),
        0.5*quaternion_multiply(state.q_NB, np.r_[0, w]),
        np.linalg.solve(inertia, loads.moment_B_Nm - np.cross(w, inertia @ w)),
    )
