"""Plant-side aerodynamics: any aero dataset provider plus explicit propulsion.

Produces the report dictionary the controller plant and carrier trajectory
consume (ledger rows, totals about the CG, domain flags, coverage gaps), now
tagged with the active dataset's identity and evidence level (issue #206).

With the strip provider the report reproduces the historical full-angle field
report: the provider's field runs with zero thrust, and the propulsion row is
rebuilt here with the actual thrust and shaft torque, in the same ledger
position and with the same summation, so totals match bit for bit.
"""
from __future__ import annotations

import numpy as np

from .aero_dataset import AeroQuery, TabulatedDataset
from .aero_strip_provider import StripModelProvider
from .aircraft_elastic import digest


def _propulsion_row(position_B_in, thrust_lbf, shaft_torque_in_lbf, omega_B_rad_s, cg_B_in):
    force = np.array([float(thrust_lbf), 0.0, 0.0])
    couple = np.array([float(shaft_torque_in_lbf), 0.0, 0.0])
    omega = np.array(omega_B_rad_s, dtype=float)
    moment = np.cross(np.array(position_B_in, dtype=float) - np.array(cg_B_in, dtype=float), force) + couple
    return dict(name='fixed propulsion', kind='propulsion', position_B_in=list(position_B_in),
                force_B_lbf=force.tolist(), free_couple_B_in_lbf=couple.tolist(), moment_about_CG_in_lbf=moment.tolist(),
                drag_B_lbf=[0.0, 0.0, 0.0], drag_power_lbf_ft_s=0.0, couple_power_lbf_ft_s=float(couple@omega/12),
                local_mach=None, reynolds=None, reference_Re_range=None, within_reference_Re_range=None)


class PlantAero:
    """Evaluate aerodynamics through a provider and add the propulsion row."""

    def __init__(self, provider, prop_position_B_in):
        self.provider = provider
        self.prop_position_B_in = [float(x) for x in prop_position_B_in]
        self.identity = dict(provider.identity)
        if isinstance(provider, TabulatedDataset):
            self.identity['load_resolution'] = 'component-resultant'

    @classmethod
    def strip_model(cls, definition, *, parameters, settings, installation):
        g = definition['geometry']
        provider = StripModelProvider(definition, parameters=parameters, settings=settings, installation=installation)
        return cls(provider, [-g['prop_station_in'], 0.0, g['prop_z_in']])

    def evaluate(self, velocity_air_B_ft_s, omega_B_rad_s, cg_B_in, *, left_tail_deg, right_tail_deg, aileron_deg,
                 thrust_lbf, shaft_torque_in_lbf, environment):
        query = AeroQuery(velocity_air_B_ft_s, omega_B_rad_s, cg_B_in,
                          dict(left_tail_deg=left_tail_deg, right_tail_deg=right_tail_deg, aileron_deg=aileron_deg),
                          environment['density_slug_ft3'], environment['sound_speed_ft_s'], environment['viscosity_slug_ft_s'])
        propulsion = _propulsion_row(self.prop_position_B_in, thrust_lbf, shaft_torque_in_lbf, omega_B_rad_s, cg_B_in)
        if hasattr(self.provider, 'report'):
            # Fast path: the plant needs the field report, not per-strip LocatedLoad objects.
            report = self.provider.report(query)
            in_coverage, violations = report['within_assumed_domain'], list(report['domain_violations'])
            evidence = self.identity['evidence_level']
            ledger = [propulsion if row['kind'] == 'propulsion' else row for row in report['ledger']]
            extras = dict(model_id=report['model_id'], configuration_sha256=report['configuration_sha256'],
                          state_sha256=report['state_sha256'], reference_coverage_gaps=report['reference_coverage_gaps'],
                          limitations=report['limitations'], units=report['units'])
            empirical = sum(r['couple_power_lbf_ft_s'] for r in ledger if r['kind'] != 'propulsion')
            drag_power = sum(r['drag_power_lbf_ft_s'] for r in ledger)
        else:
            result = self.provider.evaluate(query)
            in_coverage, violations, evidence = result.in_coverage, list(result.coverage_violations), result.evidence_level
            cg = np.array(cg_B_in, dtype=float)
            ledger = [dict(name=l.element or l.component, kind=l.component, component=l.component, source=l.source,
                           position_B_in=list(l.position_B_in), force_B_lbf=list(l.force_B_lbf),
                           free_couple_B_in_lbf=list(l.couple_B_in_lbf),
                           moment_about_CG_in_lbf=(np.cross(np.array(l.position_B_in) - cg, l.force_B_lbf)
                                                   + np.array(l.couple_B_in_lbf)).tolist())
                      for l in result.loads] + [propulsion]
            extras = dict(model_id=result.provider_id, configuration_sha256=result.dataset_digest,
                          state_sha256=digest(dict(velocity_air_B_ft_s=list(query.velocity_air_B_ft_s),
                                                   omega_B_rad_s=list(query.omega_B_rad_s), cg_B_in=list(cg_B_in))),
                          reference_coverage_gaps=[],
                          limitations=['Component-resultant table: root/mount reactions only; distributed plane cuts are withheld from station envelopes and elastic forcing is unsupported.',
                                       'Table coverage and evidence are inherited; omitted body aerodynamics and linear rate assumptions remain model limitations.'],
                          units='ft/s, rad/s, in, lbf, in-lbf')
            empirical, drag_power = None, None  # not available from tabulated coefficients
        return dict(extras, cg_B_in=list(query.reference_point_B_in), velocity_air_B_ft_s=list(query.velocity_air_B_ft_s),
                    omega_B_rad_s=list(query.omega_B_rad_s), ledger=ledger,
                    non_gravity_force_B_lbf=np.sum([r['force_B_lbf'] for r in ledger], axis=0).tolist(),
                    moment_about_CG_B_in_lbf=np.sum([r['moment_about_CG_in_lbf'] for r in ledger], axis=0).tolist(),
                    drag_power_lbf_ft_s=drag_power, empirical_couple_power_lbf_ft_s=empirical,
                    within_assumed_domain=in_coverage, domain_violations=violations,
                    aero_dataset=dict(self.identity), evidence_level=evidence,
                    environment=dict(environment))
