"""Local HTTP adapter for the glass-box station workbench (host/origin checks stay in dashboard Handler).

    GET  /api/workbench/stations            registry and default inputs
    GET  /api/workbench/notes/NAME.md        concept note text (registry allowlist, docs/mechanics)
    POST /api/workbench/run/STATION          run a station on JSON inputs; nothing is saved
    POST /api/workbench/saved                {"station", "label", "inputs"}: run and save with provenance
    GET  /api/workbench/saved                saved runs, newest first
    GET  /api/workbench/saved/UUID           one saved run (inputs, result, provenance)
    POST /api/workbench/studies              {"label", "study"}: start a Monte Carlo study (one at a time)
    GET  /api/workbench/studies              studies with status and progress
    GET  /api/workbench/studies/UUID         study spec, status, progress and sample summaries
    POST /api/workbench/studies/UUID/cancel  stop after the samples in flight
    POST /api/workbench/studies/UUID/replay/N  replay sample N; compare with its stored summary
    GET  /api/workbench/baselines            list baseline revisions
    GET  /api/workbench/baselines/UUID       get one baseline revision
    POST /api/workbench/baselines            create a new baseline revision

Station results come from flightloads.workbench, which calls the production modules.
"""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path
import re
import threading
import uuid

from . import workbench
from . import bench_baseline

PREFIX = '/api/workbench'
UUID = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
MAX_INPUT = 4*1024**2  # includes canonical-base duplicate during explicit handoff
MAX_ACTIVE = 2
NOTES = Path(__file__).resolve().parents[2] / 'docs' / 'mechanics'
RUNNABLE = ('sections', 'aero-3d', 'dataset', 'environment', 'propulsion', 'plant', 'plant-run', 'linear-check', 'launch-preview', 'launch', 'loads', 'capture', 'controller-design')


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


class WorkbenchStore:
    """Saved station runs: one JSON file per run, written once, never modified."""

    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()

    def save(self, station, label, inputs, result, *, resolved_inputs=None):
        identifier = str(uuid.uuid4())
        record = dict(schema='workbench-run-v1', id=identifier, station=station, label=label,
                      created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
                      inputs=inputs, result=result,
                      provenance=dict(inputs_sha256=hashlib.sha256(_canonical(inputs).encode()).hexdigest(),
                                      result_sha256=hashlib.sha256(_canonical(result).encode()).hexdigest(),
                                      code='flightloads.workbench.run_station'))
        if resolved_inputs is not None:
            record['resolved_inputs'] = resolved_inputs
            record['provenance']['resolved_inputs_sha256'] = hashlib.sha256(_canonical(resolved_inputs).encode()).hexdigest()
        path = self.root / f'{identifier}.json'
        with self.lock:
            tmp = path.with_suffix('.tmp')
            tmp.write_text(_canonical(record))
            tmp.replace(path)
        return record

    def listing(self):
        rows = []
        for path in self.root.glob('*.json'):
            try:
                r = json.loads(path.read_text())
                rows.append({k: r[k] for k in ('id', 'station', 'label', 'created_utc')} | dict(provenance=r['provenance']))
            except (OSError, ValueError, KeyError):
                continue
        return sorted(rows, key=lambda r: r['created_utc'], reverse=True)

    def get(self, identifier):
        if not re.fullmatch(UUID, identifier):
            raise KeyError(identifier)
        return json.loads((self.root / f'{identifier}.json').read_text())


class StudyJobs:
    """Monte Carlo studies run by the production run_study in a background thread, one at a time.
    Each study lives in ROOT/studies/UUID (study.json, samples.jsonl, meta.json)."""

    def __init__(self, root):
        self.root = Path(root) / 'studies'
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        self.running = None          # (id, cancel Event, thread)
        self.progress = {}
        self.closing = False

    def _meta(self, identifier):
        meta = json.loads((self.root / identifier / 'meta.json').read_text())
        if meta['status'] == 'running' and not (self.running and self.running[0] == identifier and self.running[2].is_alive()):
            meta.update(status='unknown-owner', error='Study is not owned by this server; it may be interrupted or owned elsewhere. No automatic resume.')
        return meta

    def _write_meta(self, identifier, meta):
        path = self.root / identifier / 'meta.json'
        tmp = path.with_suffix('.tmp')
        tmp.write_text(_canonical(meta))
        tmp.replace(path)

    def start(self, label, study):
        from .aircraft_controller_contract import make_run_inputs
        from .monte_carlo import validate_study
        study = validate_study(study)
        base_inputs = make_run_inputs(study['base']['definition'], bench=study['base']['bench'],
                        field_case=study['base']['field_case'])   # base inputs must be runnable before any sample
        if not isinstance(label, str) or len(label) > 120:
            raise ValueError('label must be text of at most 120 characters')
        with self.lock:
            if self.closing:
                raise RuntimeError('Monte Carlo service is shutting down')
            if self.running is not None and self.running[2].is_alive():
                raise RuntimeError('a Monte Carlo study is already running; cancel it or wait')
            identifier = str(uuid.uuid4())
            (self.root / identifier).mkdir()
            meta = dict(id=identifier, label=label, name=study['name'], count=study['count'], seed=study['seed'],
                        status='running', created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
                        study_sha256=hashlib.sha256(_canonical(study).encode()).hexdigest(), error=None,
                        base_inputs_sha256=base_inputs['inputs_sha256'], source=study['source'])
            (self.root / identifier / 'study.json').write_text(_canonical(dict(study=study, study_sha256=meta['study_sha256'])))
            self._write_meta(identifier, meta)
            cancel = threading.Event()
            thread = threading.Thread(target=self._run, args=(identifier, study, cancel), daemon=True)
            self.running = (identifier, cancel, thread)
            self.progress[identifier] = dict(completed=0, total=study['count'])
            thread.start()
        return meta

    def _run(self, identifier, study, cancel):
        from .monte_carlo import run_study
        meta = json.loads((self.root / identifier / 'meta.json').read_text())
        try:
            summaries = run_study(study, self.root / identifier, workers=study['budget']['max_workers'],
                                  cancelled=cancel.is_set, progress=lambda p: self.progress.__setitem__(identifier, p))
            meta['status'] = 'cancelled' if len(summaries) < study['count'] else 'completed'
        except Exception as error:  # recorded, never raised into the server
            meta.update(status='failed', error=f'{type(error).__name__}: {error}')
        self._write_meta(identifier, meta)

    def close(self, timeout=60):
        """Server shutdown: cancel a running study and wait for its samples in flight."""
        with self.lock:
            self.closing = True
            running = self.running
        if running is not None and running[2].is_alive():
            running[1].set()
            running[2].join(timeout)

    def cancel(self, identifier):
        with self.lock:
            if self.running is None or self.running[0] != identifier or not self.running[2].is_alive():
                raise RuntimeError('that study is not running')
            self.running[1].set()
        return dict(id=identifier, cancelling=True)

    def listing(self):
        rows = []
        for path in self.root.glob('*/meta.json'):
            try:
                meta = self._meta(path.parent.name)
            except (OSError, ValueError):
                continue
            rows.append(dict(meta, progress=self._progress(meta)))
        return sorted(rows, key=lambda r: r['created_utc'], reverse=True)

    def _progress(self, meta):
        if meta['id'] in self.progress:
            return self.progress[meta['id']]
        done = len(self._samples(meta))
        return dict(completed=done, total=meta['count'])

    def _samples(self, meta):
        results = self.root / meta['id'] / 'samples.jsonl'
        lines = results.read_text().splitlines(keepends=True) if results.exists() else []
        if lines and not lines[-1].endswith('\n'):
            if meta['status'] in ('running', 'unknown-owner'):
                lines.pop()  # An append can be observed before its final newline arrives.
            else:
                raise ValueError('terminal study has an incomplete sample record')
        return [json.loads(line) for line in lines if line.strip()]

    def detail(self, identifier):
        if not re.fullmatch(UUID, identifier):
            raise KeyError(identifier)
        meta = self._meta(identifier)
        study = json.loads((self.root / identifier / 'study.json').read_text())['study']
        rows = self._samples(meta)
        return dict(meta=meta, progress=self._progress(meta), study=study, samples=sorted(rows, key=lambda r: r['index']))

    def replay(self, identifier, index):
        detail = self.detail(identifier)
        if not 0 <= index < detail['study']['count']:
            raise ValueError('sample index outside the study')
        stored = next((r for r in detail['samples'] if r['index'] == index), None)
        return workbench.replay_study_sample(detail['study'], index, stored)


class DatasetShelf:
    """Tabulated aero datasets for station 3: ROOT/datasets/ID (TabulatedDataset.save format).
    FlightStream CSV exports are imported through aero_dataset.read_flightstream_csv. The
    recorded active choice (active.json) is only a shelf preference. Explicit application
    returns an immutable self-contained snapshot for future plant inputs."""

    def __init__(self, root):
        self.root = Path(root) / 'datasets'
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()

    def listing(self):
        from .aero_dataset import TabulatedDataset
        rows = []
        for path in sorted(self.root.iterdir()):
            if path.name.startswith('.') or not (path / 'dataset.json').exists():
                continue
            try:
                d = TabulatedDataset.load(path)
            except (OSError, ValueError, KeyError) as error:
                rows.append(dict(id=path.name, error=str(error)))
                continue
            rows.append(dict(id=path.name, dataset_id=d.dataset_id, evidence_level=d.evidence_level, digest=d.digest,
                             source=dict(d.source), components=[t.component for t in d.components],
                             axes={a.name: [a.values[0], a.values[-1], len(a.values)] for a in d.axes},
                             validation_reference=d.validation_reference))
        active = json.loads((self.root / 'active.json').read_text()) if (self.root / 'active.json').exists() else None
        return dict(datasets=rows, active=active)

    def import_csv(self, identifier, text):
        from .aero_dataset import read_flightstream_csv
        if not isinstance(identifier, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}', identifier) or identifier.startswith('.'):
            raise ValueError('dataset id must be 1-80 letters, digits, dot, dash or underscore')
        if not isinstance(text, str) or not text.strip():
            raise ValueError('csv text is required')
        dataset = read_flightstream_csv(text, identifier)
        import tempfile
        with self.lock:
            if (self.root / identifier).exists():
                raise RuntimeError('a dataset with that id already exists; datasets are never overwritten')
            # Readers only see a complete immutable dataset, never metadata before arrays.
            with tempfile.TemporaryDirectory(prefix='.import-', dir=self.root) as staging:
                ready = Path(staging) / 'dataset'
                dataset.save(ready)
                ready.rename(self.root / identifier)
        return dict(id=identifier, digest=dataset.digest, evidence_level=dataset.evidence_level)

    def select(self, kind, identifier):
        if kind not in ('strip-model', 'dataset'):
            raise ValueError('provider kind must be strip-model or dataset')
        if kind == 'strip-model' and identifier is not None:
            raise ValueError('strip-model provider id must be null')
        if kind == 'dataset' and (not isinstance(identifier, str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}', identifier) or identifier.startswith('.')):
            raise ValueError('invalid dataset id')
        if kind == 'strip-model':
            from .workbench import _provider
            record = dict(kind=kind, id=None, digest=_provider(dict(kind=kind, id=None), self.root).identity['digest'])
        else:
            listing = {d['id']: d for d in self.listing()['datasets'] if 'digest' in d}
            if identifier not in listing:
                raise KeyError(identifier)
            record = dict(kind='dataset', id=identifier, digest=listing[identifier]['digest'],
                          evidence_level=listing[identifier]['evidence_level'])
        record['selected_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
        with self.lock:
            pending = self.root / ('.active-'+str(uuid.uuid4())+'.json')
            pending.write_text(_canonical(record))
            pending.replace(self.root / 'active.json')
        return record

    def snapshot(self, provider, expected_digest, definition):
        """Explicit application to future inputs; never consult active.json at runtime."""
        from .aero_snapshot import freeze_dataset
        from .aero_strip_provider import StripModelProvider
        from .aircraft_controller_contract import default_field_case
        from .aircraft_workspace import stable_example_definition, validate_definition
        definition = stable_example_definition() if definition is None else definition
        validate_definition(definition)
        workbench._exact(provider, ('kind', 'id'), 'provider')
        if provider == dict(kind='strip-model', id=None):
            if expected_digest is not None:
                raise ValueError('strip-model application requires null expected_digest')
            case = default_field_case()
            model = StripModelProvider(definition, parameters=case['parameters'], settings=case['discretization'],
                                       installation=case['installation'])
            return dict(aero_dataset=None, identity=dict(model.identity),
                        scope='Live strip model for future runs; existing snapshots remain unchanged.')
        if not isinstance(expected_digest, str) or not re.fullmatch('[0-9a-f]{64}', expected_digest):
            raise ValueError('dataset application requires its expected SHA-256 digest')
        dataset = workbench._provider(provider, self.root)
        if dataset.identity['digest'] != expected_digest:
            raise RuntimeError('dataset changed since selection; refresh and explicitly select the new digest')
        snapshot = freeze_dataset(dataset, definition)
        return dict(aero_dataset=snapshot, identity=dict(dataset.identity, load_resolution='component-resultant'),
                    scope='Immutable table snapshot bound to this geometry. Root/mount reactions use component resultants; distributed plane cuts are withheld and elastic forcing is unsupported. Coverage/evidence are inherited, not promoted.')


class WorkbenchAPI:
    def __init__(self, store, controllers=None):
        self.store = store
        self.controllers = controllers
        self.active = threading.BoundedSemaphore(MAX_ACTIVE)
        self.studies = StudyJobs(store.root)
        self.datasets = DatasetShelf(store.root)
        self.baselines = bench_baseline.BaselineStore(store.root)
        # Keep one explicit completed build. Downloads never initiate replay work.
        self.envelope_results = {}

    def _resolve_inputs(self, station, inputs):
        inputs = dict(inputs) if type(inputs) is dict else inputs
        bench = inputs.pop('bench_baseline', None) if type(inputs) is dict else None
        if bench is None:
            return inputs, None
        return bench_baseline.resolve_bench(bench, self.baselines, station, inputs)

    def _station_result(self, station, inputs):
        if station == 'loads' and type(inputs) is dict and 'controller_record' in inputs:
            workbench._exact(inputs, ('controller_record', 'tick'), 'controller loads source')
            identifier = inputs['controller_record']
            if not isinstance(identifier, str) or not re.fullmatch(UUID, identifier):
                raise ValueError('controller_record must be a UUID')
            if self.controllers is None:
                raise ValueError('controller catalog unavailable')
            report = json.loads(self.controllers.download(identifier, 'report.json'))
            result = workbench.controller_loads(report, inputs['tick'])
            result['source'] = dict(kind='controller', id=identifier, tick=inputs['tick'],
                                  inputs_sha256=report['inputs_sha256'], report_sha256=report['report_sha256'])
            return result
        return workbench.run_station(station, inputs)

    def _envelope_key(self, detail):
        return hashlib.sha256(_canonical(dict(study=detail['study'], samples=detail['samples'])).encode()).hexdigest()

    def _envelope_result(self, identifier, detail):
        cached = self.envelope_results.get(identifier)
        if cached is None or cached[0] != self._envelope_key(detail):
            raise RuntimeError('Build complete envelopes for this study first; cached result missing or archive changed')
        return cached[1]

    def get(self, handler, path):
        try:
            if path == PREFIX + '/autopilot-example':
                handler.reply(200, workbench.staged_autopilot_example())
                return True
            if path == PREFIX + '/controller-example':
                handler.reply(200, workbench.designed_capture_example())
            elif path == PREFIX + '/stations':
                from .launch import launch_sources
                handler.reply(200, dict(stations=workbench.stations(), defaults=workbench.defaults(), launch_sources=launch_sources()))
            elif match := re.fullmatch(PREFIX + '/notes/([A-Z0-9_]{1,60}\\.md)', path):
                allowed = {n for s in workbench.STATIONS for n in s['notes']}
                if match[1] not in allowed:
                    raise KeyError(match[1])
                handler.reply(200, (NOTES / match[1]).read_bytes(), 'text/markdown; charset=utf-8')
            elif path == PREFIX + '/saved':
                handler.reply(200, dict(runs=self.store.listing()))
            elif path == PREFIX + '/baselines':
                handler.reply(200, {'baselines': self.baselines.listing()})
            elif path == PREFIX + '/baselines/builtin':
                handler.reply(200, self.baselines.get('builtin'))
            elif match := re.fullmatch(PREFIX + '/baselines/(' + UUID + ')', path):
                handler.reply(200, self.baselines.get(match[1]))
            elif path == PREFIX + '/datasets':
                handler.reply(200, self.datasets.listing())
            elif path == PREFIX + '/studies':
                handler.reply(200, dict(studies=self.studies.listing(), default_study=workbench.default_study()))
            elif match := re.fullmatch(PREFIX + '/studies/(' + UUID + ')', path):
                handler.reply(200, self.studies.detail(match[1]))
            elif match := re.fullmatch(PREFIX + '/studies/(' + UUID + r')/envelopes\.(csv|json)', path):
                detail = self.studies.detail(match[1])
                result = self._envelope_result(match[1], detail)
                if match[2] == 'csv':
                    from urllib.parse import urlsplit, parse_qs
                    from .load_envelopes import export_csv
                    query = parse_qs(urlsplit(handler.path).query, keep_blank_values=True)
                    if query:
                        try:
                            if set(query) != {'station','x','y'} or any(len(v)!=1 for v in query.values()):
                                raise ValueError('projection CSV requires station, x and y exactly once')
                            csv = export_csv(result['envelopes'],query['station'][0],query['x'][0],query['y'][0])
                        except ValueError as error:
                            handler.reply(400,{'error':str(error)})
                            return
                    else:
                        csv = result['csv']
                    handler.reply(200, csv.encode(), 'text/csv; charset=utf-8', 'load-table-' + match[1] + '.csv')
                else:
                    from .load_envelopes import export_json
                    handler.reply(200, export_json(result['envelopes']).encode(), 'application/json', 'envelopes-' + match[1] + '.json')
            elif match := re.fullmatch(PREFIX + '/saved/(' + UUID + ')', path):
                handler.reply(200, self.store.get(match[1]))
            else:
                handler.reply(404, {'error': 'unknown workbench route'})
        except (KeyError, FileNotFoundError):
            handler.reply(404, {'error': 'workbench note or saved run not found'})
        except (ValueError, OSError):
            handler.reply(500, {'error': 'workbench storage could not be read'})
        except RuntimeError as error:
            handler.reply(409, {'error': str(error)})

    def _body(self, handler):
        if handler.headers.get('Content-Type', '').split(';')[0].strip() != 'application/json':
            raise PermissionError(415, 'application/json required')
        lengths = handler.headers.get_all('Content-Length', [])
        if len(lengths) != 1 or not re.fullmatch('[0-9]+', lengths[0]) or handler.headers.get('Transfer-Encoding'):
            raise PermissionError(413, 'One bounded Content-Length is required')
        length = int(lengths[0])
        if not 0 < length <= MAX_INPUT:
            raise PermissionError(413, f'JSON payload must be between 1 and {MAX_INPUT} bytes')
        raw = handler.rfile.read(length)
        if len(raw) != length:
            raise ValueError('Incomplete JSON request body')
        return json.loads(raw, parse_constant=lambda c: (_ for _ in ()).throw(ValueError('non-finite JSON number')))

    def post(self, handler, path):
        if path.startswith(PREFIX + '/studies'):
            self._post_study(handler, path)
            return
        if path in (PREFIX + '/datasets/import', PREFIX + '/datasets/active', PREFIX + '/datasets/snapshot'):
            try:
                body = self._body(handler)
                if path.endswith('/snapshot'):
                    body, identity = self._resolve_inputs('dataset-snapshot', body)
                    workbench._exact(body, ('provider', 'expected_digest', 'definition'), 'dataset snapshot request')
                    result = self.datasets.snapshot(body['provider'], body['expected_digest'], body['definition'])
                    if identity is not None: result['bench_baseline'] = identity
                    handler.reply(200, result)
                elif path.endswith('/import'):
                    if type(body) is not dict or set(body) != {'id', 'csv'}:
                        raise ValueError('import requires exactly id and csv')
                    handler.reply(201, self.datasets.import_csv(body['id'], body['csv']))
                else:
                    if type(body) is not dict or set(body) != {'kind', 'id'}:
                        raise ValueError('selection requires exactly kind and id')
                    handler.reply(200, self.datasets.select(body['kind'], body['id']))
            except PermissionError as error:
                handler.reply(error.args[0], {'error': error.args[1]})
            except KeyError:
                handler.reply(404, {'error': 'dataset not found'})
            except RuntimeError as error:
                handler.reply(409, {'error': str(error)})
            except (ValueError, TypeError, UnicodeError) as error:
                handler.reply(400, {'error': str(error)})
            except OSError:
                handler.reply(500, {'error': 'dataset storage failed'})
            return
        if path in (PREFIX + '/baselines/import-preview', PREFIX + '/baselines/import', PREFIX + '/baselines/effective'):
            try:
                body = self._body(handler)
                if path.endswith('/effective'):
                    inputs, identity = bench_baseline.resolve_bench(body, self.baselines, 'plant', {'definition': None, 'propulsion': None})
                    preview = bench_baseline.aircraft_import_preview(inputs['definition'])
                    handler.reply(200, dict(preview, bench_baseline=identity))
                elif path.endswith('/import-preview'):
                    workbench._exact(body, ('definition',), 'aircraft preview')
                    handler.reply(200, bench_baseline.aircraft_import_preview(body['definition']))
                else:
                    workbench._exact(body, ('parent', 'label', 'definition'), 'aircraft import')
                    if not isinstance(body['parent'], str):
                        raise ValueError('parent must be a baseline identifier')
                    handler.reply(201, self.baselines.import_aircraft(body['parent'], body['label'], body['definition']))
            except PermissionError as error:
                handler.reply(error.args[0], {'error': error.args[1]})
            except KeyError:
                handler.reply(404, {'error': 'parent baseline not found'})
            except (ValueError, TypeError, UnicodeError) as error:
                handler.reply(400, {'error': str(error)})
            except OSError:
                handler.reply(500, {'error': 'baseline import storage failed'})
            return
        if path == PREFIX + '/baselines':
            try:
                body = self._body(handler)
                if type(body) is not dict or set(body) != {'parent', 'label', 'overrides'}:
                    raise ValueError('baseline creation requires exactly parent, label, overrides')
                if not isinstance(body['parent'], str):
                    raise ValueError('parent must be a string')
                if not isinstance(body['label'], str):
                    raise ValueError('label must be a string')
                if not isinstance(body['overrides'], list):
                    raise ValueError('overrides must be a list')
                record = self.baselines.create(body['parent'], body['label'], body['overrides'])
                handler.reply(201, record)
            except KeyError:
                handler.reply(404, {'error': 'baseline not found'})
            except (ValueError, TypeError, UnicodeError) as error:
                handler.reply(400, {'error': str(error)})
            except OSError:
                handler.reply(500, {'error': 'baseline storage failed'})
            except RuntimeError as error:
                handler.reply(409, {'error': str(error)})
            return
        match = re.fullmatch(PREFIX + '/run/([a-z0-9-]{1,40})', path)
        if match is None and path != PREFIX + '/saved':
            handler.reply(404, {'error': 'unknown workbench route'})
            return
        if match is not None and match[1] not in RUNNABLE:
            handler.reply(404, {'error': 'station not available in the workbench yet'})
            return
        if not self.active.acquire(blocking=False):
            handler.reply(409, {'error': f'{MAX_ACTIVE} workbench runs are already active; retry when one finishes'})
            return
        try:
            body = self._body(handler)
            if match is not None:
                body, bench_identity = self._resolve_inputs(match[1], body)
                if match[1] == 'dataset':
                    result = workbench.dataset_slice(body, self.datasets.root)
                else:
                    result = self._station_result(match[1], body)
                # Capture is a canonical input envelope, not a result wrapper.
                if bench_identity is not None and match[1] != 'capture':
                    result['bench_baseline'] = bench_identity
                handler.reply(200, result)
                return
            if type(body) is not dict or set(body) != {'station', 'label', 'inputs'}:
                raise ValueError('saved run requires exactly station, label, inputs')
            if body['station'] not in RUNNABLE:
                raise ValueError('station not available in the workbench yet')
            if not isinstance(body['label'], str) or len(body['label']) > 120:
                raise ValueError('label must be text of at most 120 characters')

            # Saved bench runs: run the resolved (overridden) inputs, keep bench_baseline in the
            # saved inputs so inputs_sha256 covers it, and attach the identity to the result.
            bench = body['inputs'].get('bench_baseline') if type(body['inputs']) is dict else None
            run_inputs = body['inputs']
            if bench is not None:
                run_inputs = {k: v for k, v in body['inputs'].items() if k != 'bench_baseline'}
                run_inputs, bench_identity = bench_baseline.resolve_bench(bench, self.baselines, body['station'], run_inputs)
            result = (workbench.dataset_slice(run_inputs, self.datasets.root) if body['station'] == 'dataset'
                      else self._station_result(body['station'], run_inputs))
            if bench is not None and body['station'] != 'capture':
                result['bench_baseline'] = bench_identity
            handler.reply(201, self.store.save(body['station'], body['label'], body['inputs'], result,
                                              resolved_inputs=run_inputs if bench is not None else None))
        except PermissionError as error:
            handler.reply(error.args[0], {'error': error.args[1]})
        except (ValueError, TypeError, KeyError, UnicodeError) as error:
            handler.reply(400, {'error': str(error)})
        except OSError:
            handler.reply(500, {'error': 'workbench run could not be saved'})
        finally:
            self.active.release()

    def _post_study(self, handler, path):
        control = re.fullmatch(PREFIX + '/studies/(' + UUID + ')/(cancel|envelopes|vertex|replay/([0-9]{1,6}))', path)
        if path not in (PREFIX + '/studies', PREFIX + '/studies/draft') and control is None:
            handler.reply(404, {'error': 'unknown workbench route'})
            return
        try:
            if path == PREFIX + '/studies/draft':
                body = self._body(handler)
                workbench._exact(body, ('study', 'source'), 'study draft')
                source = body['source']
                if type(source) is not dict:
                    raise ValueError('draft source must be an object')
                if source.get('kind') == 'current-capture':
                    workbench._exact(source, ('kind', 'inputs'), 'current capture source')
                    resolved, _ = self._resolve_inputs('capture', source['inputs'])
                    inputs = workbench.capture_prepare(resolved)
                    label = 'current capture editors'
                elif source.get('kind') == 'saved-run':
                    workbench._exact(source, ('kind', 'id'), 'saved run source')
                    if self.controllers is None:
                        raise RuntimeError('controller catalog unavailable')
                    if not isinstance(source['id'], str) or not re.fullmatch(UUID, source['id']):
                        raise ValueError('saved run id must be a UUID')
                    inputs = json.loads(self.controllers.download(source['id'], 'inputs.json'))
                    label = 'saved controller run ' + source['id']
                else:
                    raise ValueError('source kind must be current-capture or saved-run')
                handler.reply(200, workbench.capture_study_draft(body['study'], inputs, label))
            elif path == PREFIX + '/studies':
                body = self._body(handler)
                if type(body) is not dict or set(body) not in ({'label', 'study'}, {'label', 'study', 'base_json'}):
                    raise ValueError('study request requires label, study and optional canonical base_json')
                if 'base_json' in body:
                    if not isinstance(body['base_json'], str):
                        raise ValueError('base_json must be a JSON string')
                    base = json.loads(body['base_json'])
                    if base != body['study']['base']:
                        raise ValueError('canonical base differs from edited study base; re-import or submit the edited base explicitly')
                    body['study']['base'] = base
                handler.reply(202, self.studies.start(body['label'], body['study']))
            elif control[2] == 'cancel':
                if self._body(handler) != {}:
                    raise ValueError('cancel requires an empty JSON object')
                handler.reply(200, self.studies.cancel(control[1]))
            elif control[2] == 'envelopes':
                if self._body(handler) != {}:
                    raise ValueError('envelope build requires an empty JSON object')
                detail = self.studies.detail(control[1])
                if detail['meta']['status'] not in ('completed', 'cancelled', 'failed'):
                    raise RuntimeError('the study has no confirmed terminal status; build envelopes when it finishes')
                if not self.active.acquire(blocking=False):
                    raise RuntimeError('workbench run capacity reached; retry after an active run finishes')
                try:
                    result = workbench.envelopes_for_study(detail['study'], detail['samples'])
                    self.envelope_results = {control[1]: (self._envelope_key(detail), result)}
                    handler.reply(200, dict(result, study_id=control[1]))
                finally:
                    self.active.release()
            elif control[2] == 'vertex':
                body = self._body(handler)
                if type(body) is not dict or set(body) != {'sample', 'time_s'} or type(body['sample']) is not int \
                        or type(body['time_s']) not in (int, float):
                    raise ValueError('vertex request requires exactly sample (integer) and time_s')
                detail = self.studies.detail(control[1])
                stored = next((r for r in detail['samples'] if r['index'] == body['sample']), None)
                if stored is None:
                    raise ValueError('sample not in this study')
                result = self._envelope_result(control[1], detail)
                governing = next((v for station in result['envelopes']['stations'].values()
                    for pair in station['pairs'] for v in pair['vertices']
                    if v['sample'] == body['sample'] and v['time_s'] == body['time_s']), None)
                if governing is None:
                    raise ValueError('requested sample/time is not a retained hull vertex')
                if not self.active.acquire(blocking=False):
                    handler.reply(409, {'error': f'{MAX_ACTIVE} workbench runs are already active; retry when one finishes'})
                    return
                try:
                    from .load_envelopes import governing_field
                    resolved = dict(governing,concurrent_field=governing_field(result['envelopes'],governing))
                    handler.reply(200, workbench.resolve_vertex(detail['study'], stored, float(body['time_s']), resolved))
                finally:
                    self.active.release()
            else:
                if self._body(handler) != {}:
                    raise ValueError('replay requires an empty JSON object')
                if not self.active.acquire(blocking=False):
                    handler.reply(409, {'error': f'{MAX_ACTIVE} workbench runs are already active; retry when one finishes'})
                    return
                try:
                    handler.reply(200, self.studies.replay(control[1], int(control[3])))
                finally:
                    self.active.release()
        except PermissionError as error:
            handler.reply(error.args[0], {'error': error.args[1]})
        except (KeyError, FileNotFoundError):
            handler.reply(404, {'error': 'study not found'})
        except RuntimeError as error:
            handler.reply(409, {'error': str(error)})
        except (ValueError, TypeError, UnicodeError) as error:
            handler.reply(400, {'error': str(error)})
        except OSError:
            handler.reply(500, {'error': 'study storage failed'})
