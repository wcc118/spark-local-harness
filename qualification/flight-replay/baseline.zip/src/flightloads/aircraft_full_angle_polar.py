"""Periodic exploratory section polar and traceable component comparisons.

No complete-aircraft force model or trajectory is provided by this module.
The low-angle coefficients, transition, and uncertainty bounds are assumptions;
published component comparisons retain disagreement rather than certify a fit.
"""
from copy import deepcopy
import hashlib
from importlib.resources import files
import math
from pathlib import Path
from .aircraft_elastic import digest

MODEL_ID = 'exploratory-full-angle-components-v1'
# Bounds are user-selectable exploratory ranges, not calibrated distributions.
PARAMETERS = {
    'section_cl45': (.5, 1.5, 1.05, 'High-angle sin(2 alpha) lift amplitude', 'SAND Figures 10/19 component comparison'),
    'section_cd90': (1., 2.4, 1.8, 'Broadside section drag coefficient', 'SAND Figure 19 component comparison'),
    'body_crossflow_cd': (.15, 1.3, .35, 'Constant body side-area drag coefficient', 'NASA Figure 5 comparison; drag crisis not modeled'),
    'body_axial_cd': (0., 1.5, .15, 'Body axial drag on maximum frontal area', 'Analyst assumption; no aircraft measurement'),
    'edge_cd': (0., 2.5, 1., 'Spanwise edge drag on chord times thickness', 'Analyst assumption; no aircraft measurement'),
    'wing_thickness_ratio': (.01, .3, .12, 'Wing thickness divided by chord', 'NACA4412 designation only; installation unmeasured'),
    'tail_thickness_ratio': (.01, .3, .12, 'Tail thickness divided by chord', 'Analyst assumption; section unspecified'),
    'wing_cl0': (-1., 1., .4, 'Wing low-angle lift at zero incidence', 'Analyst assumption; no measured NACA4412 polar'),
    'wing_cl_alpha_per_rad': (.1, 10., 5.5, 'Wing low-angle lift slope per radian', 'Analyst assumption'),
    'tail_cl0': (-1., 1., 0., 'Tail low-angle lift at zero incidence', 'Analyst symmetric-section assumption'),
    'tail_cl_alpha_per_rad': (.1, 10., 4., 'Tail low-angle lift slope per radian', 'Analyst assumption'),
    'wing_cd0': (0., .5, .02, 'Wing zero-lift profile drag coefficient', 'Analyst assumption'),
    'tail_cd0': (0., .5, .02, 'Tail zero-lift profile drag coefficient', 'Analyst assumption'),
    'wing_cm0': (-.5, .5, -.08, 'Wing low-angle quarter-chord moment coefficient', 'Analyst camber assumption'),
    'tail_cm0': (-.5, .5, 0., 'Tail low-angle quarter-chord moment coefficient', 'Analyst symmetric-section assumption'),
    'efficiency': (.2, 1., .8, 'Low-angle induced-drag efficiency', 'Analyst assumption'),
    'high_angle_cp_fraction': (.3, .7, .5, 'High-angle chordwise force center fraction', 'Analyst assumption; SAND Figure 28 moment discrepancy retained'),
}
BLEND_START_DEG = 12.
BLEND_END_DEG = 25.
SCOPE = ('Exploratory quasi-steady component surrogate, not a measured NACA4412 or complete-aircraft model. '
         'No validated large-angle capture, wake/contact, dynamic stall or design acceptance. '
         'Parameter bounds are assumed sensitivity ranges, not calibrated probability distributions.')


def default_parameters():
    return dict(schema_version=1, **{k:v[2] for k,v in PARAMETERS.items()})


def parameter_metadata():
    return dict(model_id=MODEL_ID, defaults=default_parameters(), scope=SCOPE,
        fields={k:dict(min=v[0], max=v[1], default=v[2], label=v[3], source=v[4],
            uncertainty_basis='Assumed exploratory range; no probability calibration') for k,v in PARAMETERS.items()},
        transition=dict(start_deg=BLEND_START_DEG,end_deg=BLEND_END_DEG,
            basis='Fixed smooth analyst transition, not measured stall angles'))


def validate_parameters(parameters):
    if not isinstance(parameters,dict) or set(parameters)!=set(default_parameters()):
        raise ValueError('Full-angle parameters require exactly the documented fields')
    if type(parameters['schema_version']) is not int or parameters['schema_version']!=1:
        raise ValueError('Full-angle parameter schema_version must be integer 1')
    for k,(lo,hi,*_) in PARAMETERS.items():
        v=parameters[k]
        if type(v) not in (int,float) or not math.isfinite(v) or not lo<=v<=hi:
            raise ValueError(f'{k} must be a finite number in [{lo},{hi}]')
    return deepcopy(parameters)


def _section_polar(alpha_deg, kind, p, aspect_ratio):
    """Internal fast path; caller validates scalar inputs and parameters once."""
    wrapped=(alpha_deg+180.)%360.-180.
    a=math.radians(wrapped)
    t=max(0.,min(1.,(abs(wrapped)-BLEND_START_DEG)/(BLEND_END_DEG-BLEND_START_DEG)))
    blend=t*t*(3.-2.*t)
    low_cl=p[kind+'_cl0']+p[kind+'_cl_alpha_per_rad']*a
    low_cd=p[kind+'_cd0']+low_cl*low_cl/(math.pi*aspect_ratio*p['efficiency'])
    high_cl=p['section_cl45']*math.sin(2*a)
    high_cd=p[kind+'_cd0']*math.cos(a)**2+p['section_cd90']*math.sin(a)**2
    high_cn=high_cl*math.cos(a)+high_cd*math.sin(a)
    high_cm=-(p['high_angle_cp_fraction']-.25)*high_cn
    return dict(alpha_deg=wrapped,high_angle_weight=blend,
        cl=(1-blend)*low_cl+blend*high_cl,
        cd=(1-blend)*low_cd+blend*high_cd,
        cm_quarter_chord=(1-blend)*p[kind+'_cm0']+blend*high_cm)


def section_polar(alpha_deg, parameters=None, *, kind='wing', aspect_ratio=12.):
    if type(alpha_deg) not in (int,float) or not math.isfinite(alpha_deg) or abs(alpha_deg)>1e6:
        raise ValueError('alpha_deg must be finite with magnitude <= 1e6 before periodic wrapping')
    if kind not in ('wing','tail'):raise ValueError('Section kind must be wing or tail')
    if type(aspect_ratio) not in (int,float) or not math.isfinite(aspect_ratio) or not .01<=aspect_ratio<=1000:
        raise ValueError('aspect_ratio must be finite in [.01,1000]')
    p=validate_parameters(default_parameters() if parameters is None else parameters)
    return _section_polar(alpha_deg,kind,p,aspect_ratio)


def comparison_source():
    import json
    return json.loads(files('flightloads').joinpath('data/aero/full_angle_comparisons.json').read_text())


def _comparison(value,interval):
    lo,hi=interval
    return dict(predicted=value,reference_visual_range=list(interval),
        signed_distance_to_range=value-lo if value<lo else value-hi if value>hi else 0.,
        residual_from_range_midpoint=value-(lo+hi)/2,
        interpretation='Visual reading/scatter range, not a confidence interval or validation tolerance')


def component_comparison(parameters=None):
    p=validate_parameters(default_parameters() if parameters is None else parameters)
    source=comparison_source();sections=[]
    # Only high-angle coefficients are compared; these points have blend=1.
    # Do not compare unmeasured cambered low-angle assumptions to symmetric data.
    for row in source['section']['readings']:
        polar=_section_polar(row['alpha_deg'],'wing',p,12.)
        sections.append(dict(alpha_deg=row['alpha_deg'],high_angle_weight=polar['high_angle_weight'],
            **{name:_comparison(polar[key],row[name+'_visual_range']) for name,key in
                [('CL','cl'),('CD','cd'),('CM','cm_quarter_chord')]}))
    bodies=[dict(Re=row['Re'],CD=_comparison(p['body_crossflow_cd'],row['Cd_visual_range'])) for row in source['body']['readings']]
    out=dict(schema='full-angle-component-evidence-v1',model_id=MODEL_ID,parameters=p,scope=SCOPE,
        source=source,section_comparisons=sections,body_comparisons=bodies,
        evidence_status='Component discrepancies reported; aircraft validation not established',
        missing_evidence=['Measured complete-aircraft full-angle force and moment data',
            'NACA4412/actual tail section data at relevant Reynolds and angles',
            'Finite-wing spanwise flow, body taper, surface/body interference and wake',
            'Dynamic stall, release/contact forces and carrier wake',
            'Calibrated joint parameter distributions and correlations'],
        parameter_sha256=digest(p),source_sha256=digest(source),
        implementation_sha256={name:hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()
            for name in ['aircraft_full_angle_polar.py','aircraft_elastic.py']})
    out['evidence_sha256']=digest(out)
    return out


def main(argv=None):
    import argparse,json
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parameters',type=Path,help='Explicit full-angle parameter JSON; otherwise illustrative defaults')
    parser.add_argument('--output',type=Path,required=True,help='New evidence JSON file; existing files are not overwritten')
    args=parser.parse_args(argv)
    parameters=None if args.parameters is None else json.loads(args.parameters.read_text())
    result=component_comparison(parameters)
    with args.output.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(f'Component comparison written: {args.output}; aircraft validation not established')


if __name__=='__main__':main()
