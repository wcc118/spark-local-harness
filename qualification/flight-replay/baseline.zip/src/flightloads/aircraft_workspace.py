"""Imperial mass properties and an explicitly illustrative static load balance.

Geometry/stations are inches; body axes x forward, y right, z down. Station
s=-x is positive aft from the nose datum. All moments use right-hand signs.
This module is independent of the legacy SI dynamics interfaces.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from importlib.resources import files
import json
from pathlib import Path

import numpy as np

from .aircraft_input_limits import POSITION_BOUNDS, WEIGHT_BOUNDS

G_IN_S2 = 386.08858267716535  # exact standard gravity 9.80665 / 0.0254
FORCE_TOL_LBF = 1e-8
MOMENT_TOL_IN_LBF = 1e-7


def default_definition():
    return json.loads(files('flightloads').joinpath('aircraft-default.json').read_text())


def example_definition():
    """Invented distribution for learning; never a measured aircraft model."""
    d = default_definition()
    d['name'] = 'Illustrative 28-lbf layout — invented mass distribution'
    d['mode'] = 'illustrative'
    # weight, station, y, z. Box/line dimensions remain the stated idealizations.
    values = [(6,15,0,0),(3,12,-15,-3),(3,12,15,-3),(6,7,0,0),
              (3,29,0,0),(5,6,0,0),(1,27,-4.828,2.828),(1,27,4.828,2.828)]
    for c, row in zip(d['components'], values):
        c.update(zip(('weight_lbf','station_in','y_in','z_in'), row))
    d['assumptions'].append('Every component weight, location and mass shape in this example is invented for demonstration. Editing geometry does not automatically relocate component CGs or applied loads; reconcile them explicitly.')
    return d



def stable_example_definition():
    """Invented forward mass placement, not an installation recommendation."""
    from .aircraft_flight import default_condition
    from .aircraft_transient import default_settings
    d=example_definition()
    d['name']='Illustrative statically stable comparison — invented forward mass placement'
    for component in d['components']:
        if component['id']=='battery':component['station_in']=3
        if component['id']=='payload':component['station_in']=0
    d['assumptions'].append('Comparison only: 6-lbf battery box at station3in spans0..6in; 5-lbf point payload at nose station0in. All weights and other placements unchanged. Recompute CG/inertia from components. This is not a packaging or flight acceptance recommendation.')
    d['flight_condition']=default_condition()
    # This canonical reference seeds schema-v1 ensemble identities. Preserve its
    # historical omitted travel field; validation supplies the same 10-deg limit.
    d['flight_condition'].pop('ruddervator_limit_deg',None)
    d['transient_case']=default_settings()
    return d


def _object(value, name):
    if not isinstance(value, dict):
        raise ValueError(f'{name} must be an object')
    return value


def _number(value, name, low=POSITION_BOUNDS[0], high=POSITION_BOUNDS[1], nullable=False):
    if value is None and nullable:
        return
    if type(value) not in (int, float) or not low <= value <= high:
        raise ValueError(f'{name} must be finite and between {low} and {high}')


def _string(value, name, maximum=200):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f'{name} must be a nonempty string of at most {maximum} characters')


def validate_definition(d):
    _object(d, 'definition')
    if type(d.get('schema_version')) is not int or d['schema_version'] != 1:
        raise ValueError('schema_version must be 1')
    _string(d.get('name'), 'name')
    if d.get('mode') not in ('working', 'illustrative'):
        raise ValueError('mode must be working or illustrative')
    _number(d.get('target_weight_lbf'), 'target_weight_lbf', *WEIGHT_BOUNDS)
    g = _object(d.get('geometry'), 'geometry')
    expected = default_definition()['geometry']
    if set(g) != set(expected):
        raise ValueError('geometry must contain exactly the documented geometry fields')
    for key, value in g.items():
        _number(value, key)
    from .aircraft_input_limits import (GEOMETRY_POSITIVE, GEOMETRY_NONNEGATIVE,
        GEOMETRY_POSITIVE_BOUNDS, GEOMETRY_NONNEGATIVE_BOUNDS, CANT_BOUNDS,
        MIN_LOAD_STATION_SEPARATION_IN, DIMENSION_BOUNDS, ACCELERATION_BOUNDS)
    for key in GEOMETRY_POSITIVE:
        _number(g[key], key, *GEOMETRY_POSITIVE_BOUNDS)
    for key in GEOMETRY_NONNEGATIVE:
        _number(g[key], key, *GEOMETRY_NONNEGATIVE_BOUNDS)
    _number(g['tail_down_cant_deg'], 'tail_down_cant_deg', *CANT_BOUNDS)
    for key in ('wing_le_station_in','tail_le_station_in'):
        _number(g[key], key, 0, g['fuselage_length_in'])
    if g['aileron_inboard_from_root_in'] + g['aileron_span_in'] > g['wing_exposed_span_in']/2:
        raise ValueError('aileron must fit within each exposed semispan')
    if abs(g['tail_load_station_in']-g['wing_load_station_in']) < MIN_LOAD_STATION_SEPARATION_IN:
        raise ValueError('wing and tail load stations must differ by at least 0.001 in')
    assumptions = d.get('assumptions')
    if not isinstance(assumptions, list) or len(assumptions) > 30:
        raise ValueError('assumptions must be a list of at most 30 strings')
    for a in assumptions:
        _string(a, 'assumption', 1000)
    cs = d.get('components')
    if not isinstance(cs, list) or len(cs) > 100:
        raise ValueError('components must be a list of at most 100 entries')
    ids = set()
    fields = {'id','name','model','weight_lbf','station_in','y_in','z_in','length_in','width_in','height_in'}
    for c in cs:
        _object(c, 'component')
        if not fields <= set(c) or set(c)-fields-{'cg_source','placement'}:
            raise ValueError('component fields must match documented required and optional fields')
        source=c.get('cg_source','manual')
        if source not in ('manual','geometry'):
            raise ValueError('cg_source must be manual or geometry')
        if source=='geometry' and c.get('model')=='point':
            raise ValueError('point components require a manual CG location')
        if 'placement' in c:
            p=_object(c['placement'],'placement')
            if set(p)!={'forward_station_in','left_y_in','top_z_in'}:
                raise ValueError('placement requires forward_station_in, left_y_in and top_z_in')
            for key,value in p.items():
                _number(value,f'placement {key}',nullable=True)
        for key in ('id','name'):
            _string(c.get(key), f'component {key}')
        if c['id'] in ids:
            raise ValueError('component ids must be unique')
        ids.add(c['id'])
        if c['model'] not in ('point','line','box'):
            raise ValueError('component model must be point, line or box')
        _number(c['weight_lbf'], f"{c['name']} weight_lbf", *WEIGHT_BOUNDS, nullable=True)
        for key in ('station_in','y_in','z_in'):
            _number(c[key], f"{c['name']} {key}", nullable=True)
        for key in ('length_in','width_in','height_in'):
            _number(c[key], f"{c['name']} {key}", *DIMENSION_BOUNDS, nullable=True)
        needed = [] if c['model']=='point' else ['length_in']
        if c['model']=='box':
            needed += ['width_in','height_in']
        for key in needed:
            if c[key] is not None and c[key] <= 0:
                raise ValueError(f"{c['name']} {key} must be positive for {c['model']}")
    cut = _object(d.get('cut'), 'cut')
    _number(cut.get('station_in'), 'cut station', 0, g['fuselage_length_in'])
    if cut.get('retain') not in ('fore','aft'):
        raise ValueError('cut retain must be fore or aft')
    if 'load_case' in d:
        case=_object(d['load_case'],'load_case')
        if set(case)!={'kind','a_up_g'} or case['kind']!='vertical-translation':
            raise ValueError('load_case requires kind vertical-translation and a_up_g only')
        _number(case['a_up_g'],'a_up_g',*ACCELERATION_BOUNDS)
    if 'flight_condition' in d:
        from .aircraft_flight import validate_condition
        validate_condition(d['flight_condition'])
    if 'transient_case' in d:
        from .aircraft_transient import validate_settings
        validate_settings(d['transient_case'])
    return d


def _missing(c):
    needed = ['weight_lbf','station_in','y_in','z_in']
    if c['model'] != 'point':
        needed.append('length_in')
    if c['model'] == 'box':
        needed += ['width_in','height_in']
    return [key for key in needed if c[key] is None]


def resolve_components(definition):
    """Resolve centroid estimates without changing the stored manual CG fields.

    The caller validates the definition first. A line has zero transverse
    extent; its left/top placement denotes its y/z location, not a box corner.
    Unknown placement/dimensions produce unknown coordinates independently of
    weight. These resolved copies are shared by drawing and load calculations.
    """
    resolved=[]
    for raw in definition['components']:
        c=deepcopy(raw)
        c['cg_source']=raw.get('cg_source','manual')
        if c['cg_source']=='geometry':
            p=raw.get('placement',{})
            dimensions=[c['length_in'],c['width_in'],c['height_in']] if c['model']=='box' else [c['length_in'],0,0]
            for key,origin,dimension in zip(('station_in','y_in','z_in'),
                    ('forward_station_in','left_y_in','top_z_in'),dimensions):
                value=p.get(origin)
                c[key]=None if value is None or dimension is None else value+dimension/2
            c['cg_description']='Estimated geometric centroid; uniform density and axis-aligned mass idealization'
        else:
            c['cg_description']='Manual component CG; user-entered location'
        resolved.append(c)
    return resolved


def _intrinsic(c):
    m = c['weight_lbf']/G_IN_S2
    if c['model'] == 'point':
        return np.zeros((3,3))
    l = c['length_in']
    w, h = (c['width_in'],c['height_in']) if c['model']=='box' else (0,0)
    return m/12 * np.diag([w*w+h*h, l*l+h*h, l*l+w*w])


def _position(c):
    return np.array([-c['station_in'],c['y_in'],c['z_in']], dtype=float)


def _retained(c, cut):
    """Weight fraction and station centroid after exact axial clipping."""
    s, k, aft = c['station_in'], cut['station_in'], cut['retain']=='aft'
    if c['model']=='point':
        return (1.0 if (s>=k)==aft else 0.0), s
    a,b = s-c['length_in']/2, s+c['length_in']/2
    lo,hi = (max(a,k),b) if aft else (a,min(b,k))
    if hi <= lo:
        return 0.0, s
    return (hi-lo)/(b-a), (lo+hi)/2


def evaluate_aircraft(definition):
    d = validate_definition(definition)
    cs, g, cut = resolve_components(d), d['geometry'], d['cut']
    a_up_g=d.get('load_case',{}).get('a_up_g',0.0)
    n=1.0+a_up_g
    missing = [{'id':c['id'],'name':c['name'],'fields':_missing(c)} for c in cs if _missing(c)]
    out = dict(schema_version=1, mode=d['mode'], g_in_s2=G_IN_S2,
               reference_area_in2=g['wing_exposed_span_in']*g['wing_chord_in'],
               overall_wing_span_in=g['wing_exposed_span_in']+g['wing_root_spacing_in'],
               missing=missing, resolved_components=cs, mass_properties=None, loads=None,
               load_case=dict(kind='vertical-translation' if a_up_g else 'steady-level-support',
                   name='Prescribed vertical translation' if a_up_g else 'Steady level support',
                   a_up_g=a_up_g, a_up_in_s2=a_up_g*G_IN_S2,
                   load_factor=n, acceleration_B_in_s2=[0.0,0.0,-a_up_g*G_IN_S2],
                   angular_velocity_B_rad_s=[0.0,0.0,0.0],
                   angular_acceleration_B_rad_s2=[0.0,0.0,0.0],
                   inertia_pseudo_force_B_lbf=None if a_up_g else [0.0,0.0,0.0],
                   attitude='Fixed wings-level; body z down aligned with gravity',
                   force_origin='Required equilibrium forces; aerodynamic capability is not modeled',
                   definition=f'n=1+a_up/g={n:.8g}; a_up={a_up_g*G_IN_S2:.8g} in/s^2',
                   scope='Pure common translation; angular rate and acceleration zero. Input bounds +/-10 g are numerical limits, not a design envelope.'),
               status='incomplete', notes=[
                   'Body x=-station, y right, z down. Moments follow the right-hand rule.',
                   'Weights are lbf. Mass=weight/386.08858267716535; inertia is lbf*s^2*in.',
                   'Point intrinsic inertia is idealized zero; lines run along body x; boxes align with body axes.',
                   'Geometry changes do not move component coordinates or applied load stations automatically.',
                   'Vertical equilibrium example only: no aerodynamic trim, propulsion, transient or sizing prediction.'
               ])
    from .aircraft_flight import default_condition, evaluate_condition
    out['flight_condition_template']=default_condition()
    from .aircraft_transient import default_settings
    out['transient_case_template']=default_settings()
    out['flight_condition']=None
    if missing or not cs:
        if 'flight_condition' in d:out['flight_condition']=evaluate_condition(d,out)
        return out
    weights = np.array([c['weight_lbf'] for c in cs])
    positions = np.array([_position(c) for c in cs])
    weight = float(weights.sum())
    cg = weights @ positions / weight
    tensor = np.zeros((3,3))
    contributions = []
    for c,p in zip(cs,positions):
        rho = p-cg
        intrinsic = _intrinsic(c)
        shift = c['weight_lbf']/G_IN_S2*(np.dot(rho,rho)*np.eye(3)-np.outer(rho,rho))
        tensor += intrinsic+shift
        contributions.append(dict(id=c['id'],name=c['name'],mass_lbf_s2_per_in=c['weight_lbf']/G_IN_S2,
                                  intrinsic=intrinsic.tolist(),parallel_axis=shift.tolist(),
                                  total=(intrinsic+shift).tolist()))
    values, axes = np.linalg.eigh(tensor)
    out['mass_properties'] = dict(weight_lbf=weight,mass_lbf_s2_per_in=weight/G_IN_S2,
        target_difference_lbf=weight-d['target_weight_lbf'],cg_B_in=cg.tolist(),cg_station_in=float(-cg[0]),
        inertia_CG=tensor.tolist(),principal_inertias=values.tolist(),principal_axes_columns_B=axes.tolist(),
        contributions=contributions,
        principal_note='Eigenvectors are body-coordinate columns. Signs are arbitrary; repeated eigenvalues have nonunique axes.')
    sw,st = g['wing_load_station_in'],g['tail_load_station_in']
    tail = n*weight*(-cg[0]-sw)/(st-sw)
    wing = n*weight-tail
    out['load_case']['inertia_pseudo_force_B_lbf']=[0.0,0.0,weight*a_up_g]
    ledger = []
    def entry(identifier,name,kind,force,pos,fraction=1):
        derivation=(f'Input component weight x retained fraction = {force[2]/fraction:.8g} x {fraction:.8g} = {force[2]:.8g} lbf along +z'
                    if kind=='weight' else
                    f'Pseudo inertia = -m*a_B; Fz = retained weight * a_up/g = {force[2]:.8g} lbf. This is not an external force.'
                    if kind=='inertia' else
                    'Required force from total vertical and pitch equilibrium; see numerical substitution. Upward L acts along body -z; no aerodynamic prediction.')
        return dict(id=identifier,name=name,kind=kind,force_B_lbf=list(force),position_B_in=list(pos),fraction=fraction,
                    source={'weight':'input-weight','inertia':'prescribed-acceleration','applied':'solved-equilibrium'}[kind],derivation=derivation)
    for c,p in zip(cs,positions):
        ledger.append(entry(c['id'],c['name'],'weight',[0,0,c['weight_lbf']],p))
        if a_up_g:
            ledger.append(entry('inertia-'+c['id'],c['name']+' inertia','inertia',[0,0,c['weight_lbf']*a_up_g],p))
    ledger += [entry('applied-wing','Wing vertical force','applied',[0,0,-wing],[-sw,g['wing_load_y_in'],g['wing_z_in']]),
               entry('applied-tail','Tail vertical force','applied',[0,0,-tail],[-st,g['tail_load_y_in'],g['tail_root_z_in']])]
    def sums(items, origin):
        f,m = np.zeros(3),np.zeros(3)
        for item in items:
            force = np.array(item['force_B_lbf'])
            f += force
            m += np.cross(np.array(item['position_B_in'])-origin,force)
        return f,m
    f,m = sums(ledger,np.zeros(3))
    balanced = bool(np.max(np.abs(f))<=FORCE_TOL_LBF and np.max(np.abs(m))<=MOMENT_TOL_IN_LBF)
    retained = []
    for c in cs:
        fraction,s = _retained(c,cut)
        if fraction:
            retained.append(entry(c['id'],c['name'],'weight',[0,0,c['weight_lbf']*fraction],[-s,c['y_in'],c['z_in']],fraction))
            if a_up_g:
                retained.append(entry('inertia-'+c['id'],c['name']+' inertia','inertia',
                    [0,0,c['weight_lbf']*fraction*a_up_g],[-s,c['y_in'],c['z_in']],fraction))
    for item in ledger[-2:]:
        if ((-item['position_B_in'][0]>=cut['station_in']) == (cut['retain']=='aft')):
            retained.append(item)
    origin = np.array([-cut['station_in'],0,0])
    for item in ledger + retained:
        item['moment_about_cut_in_lbf'] = np.cross(np.array(item['position_B_in'])-origin,
                                                  item['force_B_lbf']).tolist()
    rf,rm = sums(retained,origin)
    external_f,external_m=sums([item for item in ledger if item['kind']!='inertia'],np.zeros(3))
    retained_external_f,retained_external_m=sums([item for item in retained if item['kind']!='inertia'],origin)
    inertia_f,inertia_m=sums([item for item in retained if item['kind']=='inertia'],origin)
    out['status'] = 'equilibrium-example' if balanced else 'unbalanced'
    out['loads'] = dict(wing_up_lbf=float(wing),tail_up_lbf=float(tail),ledger=ledger,
        balance_convention='D Alembert: external + pseudo inertia = 0',
        external_force_B_lbf=external_f.tolist(), external_moment_about_nose_in_lbf=external_m.tolist(),
        mass_times_acceleration_B_lbf=[0.0,0.0,-weight*a_up_g],
        retained_external_force_B_lbf=retained_external_f.tolist(),
        retained_external_moment_about_cut_in_lbf=retained_external_m.tolist(),
        retained_mass_times_acceleration_B_lbf=(-inertia_f).tolist(),
        retained_inertial_moment_about_cut_in_lbf=(-inertia_m).tolist(),
        whole_force_residual_lbf=f.tolist(),whole_moment_residual_in_lbf=m.tolist(),balanced=balanced,
        force_tolerance_lbf=FORCE_TOL_LBF,moment_tolerance_in_lbf=MOMENT_TOL_IN_LBF,
        retained_ledger=retained,cut_origin_B_in=origin.tolist(),
        cut_force_B_lbf=(-rf).tolist() if balanced else None,
        cut_moment_B_in_lbf=(-rm).tolist() if balanced else None,
        cut_force_residual_lbf=(rf-rf).tolist() if balanced else None,
        cut_moment_residual_in_lbf=(rm-rm).tolist() if balanced else None,
        note='Point forces exactly on the cut belong to aft. Fore and aft distributed fractions complement. Cut reactions act ON retained body BY discarded body. Uniform line/box clipping is along station.',
        equations=['m_i=W_i/g; CG=sum(W_i*r_i)/sum(W_i)',
                   'I_CG=sum(I_intrinsic_i + m_i*((rho_i dot rho_i)*identity - outer(rho_i,rho_i)))',
                   'I_box=(m/12)*diag(width^2+height^2, length^2+height^2, length^2+width^2)',
                   f'Lt = n*W*(s_CG-sw)/(st-sw) = {n:.8g}*{weight:.8g}*({-cg[0]:.8g}-{sw:.8g})/({st:.8g}-{sw:.8g}) = {tail:.8g} lbf upward',
                   f'Lw = n*W-Lt = {wing:.8g} lbf upward; actual body Fz=-L',
                   'F_cut + sum(F_external_retained) = m_ret*a_B; pseudo inertia = -m_ret*a_B',
                   'F_cut=-sum(F_external_retained+F_inertia_retained); M_cut=-sum((r-r_cut) cross (F_external+F_inertia))',
                   f'a_up/g={a_up_g:.8g}; n=1+a_up/g={n:.8g}; inertia Fz_i=W_i*a_up/g. Zero acceleration gives zero pseudo inertia. Do not pass pseudo inertia to a dynamics external-force input.',
                   'Whole-aircraft residual must pass before cut resultants are available. An asymmetric lateral CG may require an additional roll-balancing load model.'])
    if 'flight_condition' in d:out['flight_condition']=evaluate_condition(d,out)
    return out


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('definition',type=Path,help='exported aircraft JSON')
    args = parser.parse_args(argv)
    try:
        if args.definition.stat().st_size>131072:
            raise ValueError('definition exceeds 128 KiB')
        result=evaluate_aircraft(json.loads(args.definition.read_text()))
        print(json.dumps(result,indent=2,allow_nan=False))
    except (ValueError,OSError,TypeError,KeyError) as error:
        parser.exit(2,f'aircraft evaluation failed: {error}\n')


if __name__=='__main__':
    main()
