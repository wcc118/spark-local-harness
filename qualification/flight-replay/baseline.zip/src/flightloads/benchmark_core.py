"""Prescribed-couple benchmark with independent analytic motion/load references."""
from collections.abc import Mapping
from dataclasses import dataclass
import numbers
from types import MappingProxyType
import numpy as np
from ._arrays import readonly_copy
from .mass import MassModel
from .loads import AppliedLoads
from .state import RigidState
from .integration import integrate
from .dynamics import rigid_derivative
from .recovery import CutDefinition, recover_balance, recover_section
from .conventions import attitude_error


@dataclass(frozen=True)
class BenchmarkConfig:
    duration_s: float = 2.
    dt_s: float = .01
    alpha_radps2: float = 1.
    g_mps2: float = 9.81
    schema_version: int = 1

    def __post_init__(self):
        if type(self.schema_version) is not int or self.schema_version != 1:
            raise ValueError('schema_version must be plain integer 1')
        for name in ('duration_s','dt_s','alpha_radps2','g_mps2'):
            value=getattr(self,name)
            if isinstance(value,bool) or not isinstance(value,numbers.Real) or not np.isfinite(value):
                raise ValueError(f'{name} must be a finite real number, not bool or text')
            object.__setattr__(self,name,float(value))
        if not 0 < self.duration_s <= 5 or not 0 < self.dt_s <= .05:
            raise ValueError('duration_s must be in (0,5], dt_s in (0,.05]')
        if abs(self.alpha_radps2)>2 or abs(self.g_mps2)>20:
            raise ValueError('abs(alpha_radps2)<=2 and abs(g_mps2)<=20 required')
        if self.dt_s*20000 < self.duration_s:
            raise ValueError('configuration exceeds 20000 steps')

    def to_dict(self):
        return {name:getattr(self,name) for name in self.__dataclass_fields__}

    @classmethod
    def from_dict(cls,data):
        if not isinstance(data,Mapping) or set(data)!=set(cls.__dataclass_fields__):
            raise ValueError('configuration requires exactly the schema fields')
        return cls(**data)


@dataclass(frozen=True,init=False)
class BenchmarkResult:
    """Construction executes the case; verification cannot be externally supplied."""
    config: BenchmarkConfig
    mass_model: MassModel
    applied_loads: AppliedLoads
    cut: CutDefinition
    simulation: object
    arrays: Mapping
    verification: Mapping

    @property
    def numerically_verified(self):
        return all(metric['passed'] for metric in self.verification.values())

    def __init__(self,config):
        if not isinstance(config,BenchmarkConfig):
            raise TypeError('config must be BenchmarkConfig')
        mass=MassModel(np.ones(4),[[1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0]],'prescribed-couple')
        alpha,g=config.alpha_radps2,config.g_mps2
        loads=AppliedLoads([[2,0,0]],[[0,0,0]],[[0,0,8*alpha]],('prescribed-couple',))
        cut=CutDefinition('x-half',[.5,0,0],[1,0,0])
        load_provider=lambda t,s,c:loads
        gravity_provider=lambda t,r,c:[0,0,g]
        sim=integrate(RigidState([0]*3,[0]*3,[1,0,0,0],[0]*3),mass,config.duration_s,
                      config.dt_s,load_provider,gravity_provider,max_steps=20000)
        field_keys=('point_accel_B_mps2','gravity_force_B_N','inertia_force_B_N',
                    'force_residual_B_N','moment_residual_B_Nm','force_limit_N','moment_limit_Nm',
                    'force_scale_N','moment_scale_Nm')
        data={name:[] for name in (*field_keys,'section_force_B_N','section_moment_B_Nm')}
        for i,t in enumerate(sim.times_s):
            state=sim.state_at(i)
            applied=load_provider(t,state,None)
            gravity=gravity_provider(t,state.r_CG_N_m,None)
            derivative=rigid_derivative(state,mass,applied,gravity)
            field=recover_balance(state,derivative,mass,applied,gravity)
            section=recover_section(field,cut,time_s=t)
            for name in field_keys:
                data[name].append(getattr(field,name))
            data['section_force_B_N'].append(section.force_on_retained_B_N)
            data['section_moment_B_Nm'].append(section.moment_on_retained_B_Nm)
        t=sim.times_s;zero=np.zeros_like(t);constant=lambda x:np.full_like(t,x)
        data.update(reference_position_N_m=np.column_stack([zero,zero,.5*g*t*t]),
                    reference_velocity_B_mps=np.column_stack([zero,zero,g*t]),
                    reference_quaternion_NB=np.column_stack([np.cos(alpha*t*t/4),zero,zero,np.sin(alpha*t*t/4)]),
                    reference_omega_B_radps=np.column_stack([zero,zero,alpha*t]),
                    reference_section_force_B_N=np.column_stack([-2*(alpha*t)**2,constant(2*alpha),zero]),
                    reference_section_moment_B_Nm=np.column_stack([zero,zero,constant(-5*alpha)]))
        data={name:readonly_copy(value) for name,value in data.items()}
        if not all(np.all(np.isfinite(a)) for a in data.values()):
            raise ValueError('nonfinite benchmark history')
        for name,value in dict(config=config,mass_model=mass,applied_loads=loads,cut=cut,simulation=sim,
                               arrays=MappingProxyType(data),verification=self._verify_histories(sim.states,data)).items():
            object.__setattr__(self,name,value)

    @staticmethod
    def _verify_histories(states,data):
        metrics={}
        def metric(name,error,limit,unit):
            if not np.isfinite(error) or not np.isfinite(limit) or limit<=0:
                raise ValueError('invalid verification metric')
            metrics[name]=MappingProxyType(dict(max_error=float(error),limit=float(limit),
                                                unit=unit,passed=bool(error<=limit)))
        metric('attitude',max(attitude_error(q,r) for q,r in zip(states[:,6:10],data['reference_quaternion_NB'])),1e-6,'rad')
        comparisons=[('position',states[:,:3],'reference_position_N_m','m'),
                     ('velocity',states[:,3:6],'reference_velocity_B_mps','m/s'),
                     ('omega',states[:,10:13],'reference_omega_B_radps','rad/s'),
                     ('section_force',data['section_force_B_N'],'reference_section_force_B_N','N'),
                     ('section_moment',data['section_moment_B_Nm'],'reference_section_moment_B_Nm','N m')]
        for name,computed,key,unit in comparisons:
            reference=data[key]
            metric(name,np.max(np.abs(computed-reference)),1e-9+1e-10*np.max(np.abs(reference)),unit)
        metric('force_balance',np.max(np.linalg.norm(data['force_residual_B_N'],axis=1)/data['force_limit_N']),1,'residual/limit')
        metric('moment_balance',np.max(np.linalg.norm(data['moment_residual_B_Nm'],axis=1)/data['moment_limit_Nm']),1,'residual/limit')
        return MappingProxyType(metrics)


def run_benchmark(config):
    return BenchmarkResult(config)
