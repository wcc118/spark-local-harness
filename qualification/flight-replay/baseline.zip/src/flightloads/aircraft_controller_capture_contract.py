"""Explicit v2 extension; v1 inputs retain their original shape and meaning."""
from copy import deepcopy
from .aircraft_controller_contract import _object, _number, _ticks, default_bench


def default_outer_loop():
    return dict(mode='capture',speed_kp_lbf_per_ft_s=.15,speed_ki_lbf_per_ft=.04,
        speed_integral_limit_ft=30.,flight_path_target_deg=0.,flight_path_kp=.8,
        flight_path_ki_per_s=.2,flight_path_integral_limit_deg_s=10.,
        pitch_min_deg=-15.,pitch_max_deg=15.,pitch_rate_deg_s=20.,
        thrust_rate_lbf_s=1.,thrust_delay_s=.1)


def default_autopilot():
    """Optional second stage: AGL height hold after measured stable-flight capture."""
    return dict(mode='altitude-hold',altitude_kp_per_s=.15,max_climb_ft_s=15.,
        max_descent_ft_s=15.,flight_path_min_deg=-8.,flight_path_max_deg=8.,
        engagement_dwell_s=2.,height_tolerance_ft=5.,dwell_s=3.)


def _validate_autopilot(value,bench):
    _object(value,default_autopilot(),'autopilot')
    if value['mode']!='altitude-hold':raise ValueError('autopilot.mode must be altitude-hold')
    if bench['outer_loop']['mode']!='capture':raise ValueError('autopilot requires capture outer loop')
    for key,high in (('altitude_kp_per_s',2),('max_climb_ft_s',100),('max_descent_ft_s',100),
                     ('height_tolerance_ft',1000),('engagement_dwell_s',3600),('dwell_s',3600)):
        _number(value[key],0,high,'autopilot.'+key,True)
    _number(value['flight_path_min_deg'],-30,0,'autopilot.flight_path_min_deg')
    _number(value['flight_path_max_deg'],0,30,'autopilot.flight_path_max_deg')
    if value['flight_path_min_deg']>=value['flight_path_max_deg']:
        raise ValueError('autopilot flight path limits require min < max')


def default_capture_bench():
    b=default_bench()
    b.update(schema_version=2,name='Exploratory sustained capture',
             source='E2 fixed numerical demonstration; estimated hardware; not physical validation',
             outer_loop=default_outer_loop())
    b['controller']['mode']='rate-attitude'
    b['controller']['attitude_gain_per_s']=[6.,6.,6.]
    b['controller']['rate_gain_per_s']=[30.,30.,30.]
    b['target'].update(trim_thrust_min_lbf=0.,trim_thrust_max_lbf=5.,fixed_thrust_lbf=0.)
    b['timing'].update(duration_s=20.,plant_dt_s=.01,sensor_period_s=.02,controller_period_s=.02)
    b['criteria'].update(speed_error_ft_s=2.,flight_path_error_deg=1.,heading_error_deg=2.,
                         rate_error_deg_s=1.,attitude_error_deg=1.,minimum_height_ft=900.,dwell_s=5.)
    b['target'].update(airspeed_ft_s=150.,height_agl_ft=1000.,heading_deg=0.)
    b['disturbance'].update(attitude_body_deg=[0.,0.,0.],rate_body_deg_s=[0.,0.,0.],
                            airspeed_delta_ft_s=-15.,flight_path_delta_deg=0.)
    for a in b['actuators'].values():
        a.update(min_deg=-20.,max_deg=20.,rate_deg_s=90.,delay_s=.02)
    return b


def default_launch_phases():
    """Launch-to-capture mode logic (#220): rate damping, attitude recovery, then capture."""
    from .launch import default_launch
    return dict(scenario=default_launch(),
                rate_damp=dict(threshold_deg_s=10.,dwell_s=.2,max_s=2.),
                attitude=dict(threshold_deg=5.,dwell_s=.2,max_s=4.))


def default_schedule():
    """Dynamic-pressure scheduling of the allocation effectiveness (#221):
    B(q) = B_trim * clip((q/q_trim)^exponent, min_scale, max_scale). Exponent 1 matches
    surface moments proportional to dynamic pressure; 0 is the unscheduled controller."""
    return dict(mode='dynamic-pressure',exponent=1.,min_scale=.25,max_scale=4.)


def _validate_schedule(value):
    _object(value,default_schedule(),'schedule')
    if value['mode']!='dynamic-pressure':raise ValueError('schedule.mode must be dynamic-pressure')
    _number(value['exponent'],0,2,'schedule.exponent')
    _number(value['min_scale'],0,1,'schedule.min_scale',True)
    _number(value['max_scale'],1,10,'schedule.max_scale')


def default_speed_recovery():
    """Optional launch phase (#221): after attitude recovery, if airspeed is below the floor, hold
    a nose-down pitch at maximum thrust (trading height for speed) until the floor is regained."""
    return dict(min_airspeed_ft_s=125.,pitch_deg=-15.,dwell_s=.2,max_s=6.)


def _validate_launch_phases(value,timing):
    from .launch import validate_launch
    _object(value,(*default_launch_phases(),)+(('speed_recovery',) if type(value) is dict and 'speed_recovery' in value else ()),'launch')
    validate_launch(value['scenario'])
    _object(value['rate_damp'],default_launch_phases()['rate_damp'],'launch.rate_damp')
    _object(value['attitude'],default_launch_phases()['attitude'],'launch.attitude')
    _number(value['rate_damp']['threshold_deg_s'],0,360,'launch.rate_damp.threshold_deg_s',True)
    _number(value['attitude']['threshold_deg'],0,180,'launch.attitude.threshold_deg',True)
    for phase in ('rate_damp','attitude'):
        _number(value[phase]['dwell_s'],0,timing['duration_s'],f'launch.{phase}.dwell_s')
        _number(value[phase]['max_s'],0,timing['duration_s'],f'launch.{phase}.max_s',True)
    if 'speed_recovery' in value:
        r=value['speed_recovery']
        _object(r,default_speed_recovery(),'launch.speed_recovery')
        _number(r['min_airspeed_ft_s'],1,400,'launch.speed_recovery.min_airspeed_ft_s',True)
        _number(r['pitch_deg'],-45,0,'launch.speed_recovery.pitch_deg')
        _number(r['dwell_s'],0,timing['duration_s'],'launch.speed_recovery.dwell_s')
        _number(r['max_s'],0,timing['duration_s'],'launch.speed_recovery.max_s',True)


def validate_capture_extension(bench):
    """Validate v2 extension then return a v1-shaped copy for base validation."""
    keys=(*default_bench(),'outer_loop')+tuple(k for k in ('launch','schedule','autopilot') if type(bench) is dict and k in bench)
    _object(bench,keys,'v2 bench')
    disturbance=bench['disturbance']
    _object(disturbance,(*default_bench()['disturbance'],'airspeed_delta_ft_s','flight_path_delta_deg'),'v2 disturbance')
    base=deepcopy(bench); base.pop('outer_loop'); base.pop('launch',None); base.pop('schedule',None); base.pop('autopilot',None); base['schema_version']=1
    base['disturbance'].pop('airspeed_delta_ft_s');base['disturbance'].pop('flight_path_delta_deg')
    from .aircraft_controller_contract import validate_bench
    validate_bench(base)
    c=bench['outer_loop']
    _object(c,default_outer_loop(),'outer_loop')
    if c['mode'] not in ('off','capture'):
        raise ValueError('outer_loop.mode must be off or capture')
    for key,maximum in (('speed_kp_lbf_per_ft_s',10),('speed_ki_lbf_per_ft',10),
            ('speed_integral_limit_ft',1000),('flight_path_kp',10),('flight_path_ki_per_s',10),
            ('flight_path_integral_limit_deg_s',1000)):
        _number(c[key],0,maximum,'outer_loop.'+key)
    _number(c['flight_path_target_deg'],-10,10,'outer_loop.flight_path_target_deg')
    for key in ('pitch_min_deg','pitch_max_deg'):
        _number(c[key],-45,45,'outer_loop.'+key)
    if c['pitch_min_deg']>=c['pitch_max_deg']:
        raise ValueError('Outer pitch limits require min < max')
    _number(c['pitch_rate_deg_s'],0,90,'outer_loop.pitch_rate_deg_s',True)
    _number(c['thrust_rate_lbf_s'],0,100,'outer_loop.thrust_rate_lbf_s',True)
    _number(c['thrust_delay_s'],0,1,'outer_loop.thrust_delay_s')
    _ticks(c['thrust_delay_s'],bench['timing']['plant_dt_s'],'outer_loop.thrust_delay_s')
    if c['mode']=='capture' and (bench['controller']['mode']!='rate-attitude' or bench['target']['thrust_mode']!='trim'):
        raise ValueError('Capture requires rate-attitude inner control and trim thrust policy')
    disturbance=bench['disturbance']
    _object(disturbance,(*default_bench()['disturbance'],'airspeed_delta_ft_s','flight_path_delta_deg'),'v2 disturbance')
    _number(disturbance['airspeed_delta_ft_s'],-100,100,'disturbance.airspeed_delta_ft_s')
    _number(disturbance['flight_path_delta_deg'],-30,30,'disturbance.flight_path_delta_deg')
    if bench['target']['airspeed_ft_s']+disturbance['airspeed_delta_ft_s']<=1:
        raise ValueError('Disturbed airspeed must exceed 1ft/s')
    if 'launch' in bench:
        if c['mode']!='capture':raise ValueError('launch requires outer_loop.mode capture')
        if any(disturbance[k] for k in ('airspeed_delta_ft_s','flight_path_delta_deg')) or any(
                any(disturbance[k]) for k in ('attitude_body_deg','rate_body_deg_s')):
            raise ValueError('launch runs start from the tube exit or separated platform release state; set disturbances to zero')
        _validate_launch_phases(bench['launch'],bench['timing'])
    if 'schedule' in bench:
        if c['mode']!='capture':raise ValueError('schedule requires outer_loop.mode capture')
        _validate_schedule(bench['schedule'])
    if 'autopilot' in bench:_validate_autopilot(bench['autopilot'],bench)
    return base
