"""Strip-model provider: the existing full-angle field behind the aero dataset interface.

Evidence level `estimate`, source `strip-model-v1`. Propulsion rows are excluded:
thrust and shaft torque are not aerodynamics and enter the plant separately
(issue #209). See docs/mechanics/AERO_DATASET.md and FULL_ANGLE_FORCE_FIELD.md.
"""
from __future__ import annotations

from copy import deepcopy

from .aero_dataset import LocatedLoad, assemble
from .aircraft_elastic import digest
from .aircraft_full_angle_field import FullAngleField, default_controls, default_settings
from .aircraft_full_angle_polar import default_parameters

SOURCE = 'strip-model-v1'
# (kind, side) -> component; side from the ledger name ("wing -1 strip 3").
_COMPONENTS = {('wing', '-1'): 'wing-left', ('wing', '+1'): 'wing-right',
               ('tail', '-1'): 'tail-left', ('tail', '+1'): 'tail-right'}
_BODY_KINDS = ('body-crossflow', 'body-axial')


def component_of(element):
    """Map a full-angle ledger element to its component name, or None for propulsion."""
    kind = element['kind']
    if kind in _BODY_KINDS:
        return 'body'
    if kind == 'propulsion':
        return None
    parts = element['name'].split()
    component = _COMPONENTS.get((kind, parts[1] if len(parts) > 1 else ''))
    if component is None:
        raise ValueError(f'unmapped full-angle ledger element: {element["name"]!r} ({kind})')
    return component


class StripModelProvider:
    """Live-evaluation provider delegating to FullAngleField.

    Controls: left/right tail panel incidence and aileron in repository convention;
    common = (left + right)/2 and differential = (left - right)/2, as in
    ControllerPlant. Atmosphere comes from each query. Fields are cached by
    (controls, atmosphere) so repeated evaluations reuse the same instance.
    """

    def __init__(self, definition, *, parameters=None, settings=None, installation=None):
        self._definition = deepcopy(definition)
        self._parameters = deepcopy(parameters) if parameters is not None else default_parameters()
        self._settings = deepcopy(settings) if settings is not None else default_settings()
        self._installation = {'wing_incidence_deg': 0.0, 'tail_incidence_deg': 0.0, **(installation or {})}
        self.identity = {'id': SOURCE, 'evidence_level': 'estimate',
                         'digest': digest(dict(definition=self._definition, parameters=self._parameters,
                                               settings=self._settings, installation=self._installation))}
        self._cache_key, self._field = None, None

    def field(self, query):
        """The FullAngleField instance used for this query (for stations and tests)."""
        controls = query.controls_deg
        key = (tuple(controls[k] for k in ('left_tail_deg', 'right_tail_deg', 'aileron_deg')),
               query.density_slug_ft3, query.viscosity_slug_ft_s, query.sound_speed_ft_s)
        if key != self._cache_key:
            actual = dict(default_controls(), **self._installation)
            actual.update(common_tail_deg=(controls['left_tail_deg'] + controls['right_tail_deg'])/2,
                          differential_tail_deg=(controls['left_tail_deg'] - controls['right_tail_deg'])/2,
                          aileron_deg=controls['aileron_deg'], thrust_lbf=0.0, prop_torque_in_lbf=0.0)
            environment = dict(density_slug_ft3=query.density_slug_ft3, viscosity_slug_ft_s=query.viscosity_slug_ft_s,
                               sound_speed_ft_s=query.sound_speed_ft_s, source='aero query atmosphere')
            self._field = FullAngleField(self._definition, parameters=self._parameters, environment=environment,
                                         controls=actual, settings=self._settings)
            self._cache_key = key
        return self._field

    def evaluate(self, query):
        return self.evaluate_with_report(query)[0]

    def report(self, query):
        """The full-angle report only (thrust and shaft torque zero); the plant's fast path."""
        return self.field(query).evaluate(query.velocity_air_B_ft_s, query.omega_B_rad_s, query.reference_point_B_in)

    def evaluate_with_report(self, query):
        """AeroResult plus the underlying full-angle report (thrust and shaft torque zero).

        The report keeps per-strip detail (polars, drag power, Reynolds coverage) that
        stations and the plant's energy bookkeeping use. Its propulsion row carries zero load.
        """
        report = self.report(query)
        loads = []
        for element in report['ledger']:
            component = component_of(element)
            if component is None:
                continue
            loads.append(LocatedLoad(component, element['position_B_in'], element['force_B_lbf'],
                                     element['free_couple_B_in_lbf'], SOURCE, 'estimate', element['name']))
        result = assemble(loads, query.reference_point_B_in, provider_id=SOURCE, dataset_digest=self.identity['digest'],
                          violations=tuple(report['domain_violations']))
        return result, report
