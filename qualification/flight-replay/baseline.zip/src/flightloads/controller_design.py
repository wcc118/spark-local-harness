"""Small-signal pitch-rate design diagnostic for the actual sampled plant.

This is a local linear diagnostic, not a nonlinear stability certificate. The
production servo is a delayed slew limiter: its infinitesimal gain is one, not
an invented first-order lag. Finite-amplitude limits are reported separately.
"""
from copy import deepcopy
import math
import numpy as np
from .aircraft_controller_plant import ControllerPlant
from .aircraft_controller_trim import trim_bench
from .aircraft_release import quaternion_321
from .state import RigidState


def matrix_exp(matrix):
    """Scaling/squaring Taylor exponential, bounded to small dense matrices."""
    a = np.asarray(matrix, dtype=float)
    if a.ndim != 2 or a.shape[0] != a.shape[1] or a.shape[0] > 32 or not np.isfinite(a).all():
        raise ValueError('finite square matrix of order <=32 required')
    scale = max(0, math.ceil(math.log2(max(1., float(np.linalg.norm(a, np.inf))*2))))
    if scale > 30:
        raise ValueError('matrix exponential scale budget exceeded')
    a = a/(2**scale)
    result = term = np.eye(len(a))
    for k in range(1, 80):
        term = term@a/k
        result = result+term
        if np.linalg.norm(term, np.inf) < 1e-16:
            break
    else:
        raise ValueError('matrix exponential failed to converge')
    for _ in range(scale):
        result = result@result
    if not np.isfinite(result).all():
        raise ValueError('nonfinite matrix exponential')
    return result


def zoh(a, b, period):
    n = len(a)
    augmented = np.zeros((n+1, n+1))
    augmented[:n, :n], augmented[:n, n] = a, b
    value = matrix_exp(augmented*period)
    return value[:n, :n], value[:n, n]


def delayed_zoh(a, b, period, delay):
    """Exact held-input interval split, including fractional controller delays."""
    quotient = delay/period
    whole = int(math.floor(quotient+1e-12))
    remainder = max(0., delay-whole*period)
    ad, _ = zoh(a, b, period)
    tail, new = zoh(a, b, period-remainder)
    _, early = zoh(a, b, remainder)
    return ad, new, tail@early, whole


def pitch_linearization(inputs, step_factor=1.):
    if not math.isfinite(step_factor) or step_factor <= 0:
        raise ValueError('positive finite step factor required')
    plant = ControllerPlant(inputs)
    bench, case = inputs['bench'], inputs['field_case']
    if any(case['wind_N_ft_s']) or case.get('gusts') or bench['target']['heading_deg'] != 0:
        raise ValueError('pitch design requires zero wind/gusts and heading zero')
    trim = trim_bench(inputs, verify_hold=False)
    if trim['status'] != 'feasible' or trim['effectiveness']['status'] != 'available':
        raise ValueError('pitch design requires feasible trim and available effectiveness')
    candidate = trim['candidate']
    controls = candidate['controls']
    roll = math.radians(candidate['roll_deg'])
    reference = RigidState.from_vector(candidate['state_SI'])
    x0 = np.array([reference.v_CG_B_mps[0]/.3048, reference.v_CG_B_mps[2]/.3048,
                   0., math.radians(candidate['pitch_deg'])])
    allocation = np.linalg.pinv(np.asarray(trim['effectiveness']['matrix']), rcond=1e-8)[:, 1]

    def rhs(x, acceleration):
        u, w, q, theta = x
        state = RigidState(reference.r_CG_N_m, [u*.3048, reference.v_CG_B_mps[1], w*.3048],
                           quaternion_321(roll, theta, 0.), [0., q, 0.])
        changed = dict(controls)
        for name, gain in zip(('left_tail_deg', 'right_tail_deg', 'aileron_deg'), allocation):
            changed[name] = float(changed[name]+gain*acceleration)
        derivative = plant.evaluate(state, changed)[2]
        return np.array([derivative.vdot_B_mps2[0]/.3048, derivative.vdot_B_mps2[2]/.3048,
                         derivative.omegadot_B_radps2[1], q*math.cos(roll)])

    steps = np.array([.001, .001, 1e-5, 1e-5])*step_factor
    a = np.column_stack([(rhs(x0+np.eye(4)[i]*h, 0)-rhs(x0-np.eye(4)[i]*h, 0))/(2*h)
                         for i, h in enumerate(steps)])
    h = .01*step_factor
    b = (rhs(x0, h)-rhs(x0, -h))/(2*h)
    return a, b, allocation, trim


def sampled_loop(a, b, period, delay, kp, ki, attitude_gain=0.):
    if not math.isfinite(period) or period <= 0 or not math.isfinite(delay) or not 0 <= delay <= 50*period:
        raise ValueError('pitch diagnostic requires positive period and delay <=50 controller periods')
    ad, new, old, whole = delayed_zoh(a, b, period, delay)
    # Queue holds u[k-1],u[k-2],... . I is the previous accepted error integral.
    n = len(a)
    c = np.array([0., 0., 180/math.pi, attitude_gain*180/math.pi])
    size = n+1+whole+1

    def step(x):
        error = -float(c@x[:n])
        integral = x[n]+period*error if ki else 0.
        command = kp*error+ki*integral
        history = np.r_[command, x[n+1:]]
        return np.r_[ad@x[:n]+new*history[whole]+old*history[whole+1], integral, history[:-1]]

    matrix = np.column_stack([step(np.eye(size)[i]) for i in range(size)])
    frequencies = np.geomspace(.001, math.pi/period*(1-1e-7), 2400)
    values = []
    for omega in frequencies:
        z = np.exp(1j*omega*period)
        response = c@np.linalg.solve(z*np.eye(n)-ad, (new+old/z)/z**whole)
        values.append(response*(kp+ki*period/(1-1/z)))
    values = np.asarray(values)
    gain = 20*np.log10(np.maximum(np.abs(values), 1e-300))
    phase = np.degrees(np.unwrap(np.angle(values)))
    crossings = []
    for k in np.flatnonzero(gain[:-1]*gain[1:] < 0):
        f = -gain[k]/(gain[k+1]-gain[k])
        crossings.append(dict(frequency_rad_s=float(np.exp(np.log(frequencies[k])*(1-f)+np.log(frequencies[k+1])*f)),
                              phase_margin_deg=float((180+phase[k]+f*(phase[k+1]-phase[k])+180)%360-180),
                              gain_direction='descending' if gain[k+1] < gain[k] else 'ascending'))
    gain_margins = []
    for target in range(-180, int(math.floor(min(phase)))-361, -360):
        for k in np.flatnonzero((phase[:-1]-target)*(phase[1:]-target) < 0):
            f = (target-phase[k])/(phase[k+1]-phase[k])
            gain_margins.append(float(-(gain[k]+f*(gain[k+1]-gain[k]))))
    poles = np.linalg.eigvals(matrix)
    return dict(closed_loop_poles=[[float(v.real), float(v.imag)] for v in poles],
                spectral_radius=float(max(abs(poles))), stable=bool(max(abs(poles)) < 1-1e-9),
                pole_classification='stable' if max(abs(poles)) < 1-1e-9 else 'marginal' if max(abs(poles)) <= 1+1e-9 else 'unstable',
                gain_crossings=crossings, gain_margins_db=gain_margins,
                frequency_rad_s=frequencies.tolist(), gain_db=gain.tolist(), phase_deg=phase.tolist())


def design_report(inputs):
    """Editable bench gains feed both production runs and this diagnostic."""
    a, b, allocation, trim = pitch_linearization(inputs)
    fine_a, fine_b, _, _ = pitch_linearization(inputs, .5)
    bench = inputs['bench']
    timing, actuators, settings = bench['timing'], bench['actuators'], bench['controller']
    if timing['sensor_period_s'] != timing['controller_period_s']:
        raise ValueError('pitch design currently requires coincident sensor/controller clocks')
    if len({actuators[name]['delay_s'] for name in actuators}) != 1:
        raise ValueError('pitch design requires equal surface delays')
    if settings['mode'] != 'rate-attitude':
        raise ValueError('pitch design requires rate-attitude mode')
    period, delay = timing['controller_period_s'], actuators['left_tail']['delay_s']
    kp, ki = settings['rate_gain_per_s'][1], settings['rate_integral_gain_per_s2'][1]
    rate = sampled_loop(a, b, period, delay, kp, ki)
    attitude = sampled_loop(a, b, period, delay, kp, ki,
                            settings['attitude_gain_per_s'][1]*math.cos(math.radians(trim['candidate']['roll_deg'])))
    limits = [dict(surface=name, rate_deg_s=actuators[name]['rate_deg_s'],
                   travel_min_deg=actuators[name]['min_deg'], travel_max_deg=actuators[name]['max_deg'],
                   allocation_deg_per_deg_s2=float(gain))
              for name, gain in zip(('left_tail', 'right_tail', 'aileron'), allocation)]
    return dict(schema='sampled-pitch-design-v1', inputs=deepcopy(inputs), inputs_sha256=inputs['inputs_sha256'],
        implementation_hashes=trim['implementation_hashes'], trim=trim['candidate'],
        states=['u_ft_s', 'w_ft_s', 'q_rad_s', 'theta_rad'], input='allocated pitch acceleration deg/s^2',
        A=a.tolist(), B=b.tolist(), refined_A=fine_a.tolist(), refined_B=fine_b.tolist(),
        max_derivative_refinement_error=float(max(np.max(abs(a-fine_a)), np.max(abs(b-fine_b)))),
        controller_period_s=period, servo_delay_s=delay, inner_rate_loop=rate, attitude_loop=attitude,
        servo_limits=limits, commanded_rate_limit_deg_s=settings['rate_limit_deg_s'][1],
        evidence_level='estimate', limitations=[
            'Frozen-lateral longitudinal projection at actual trim roll and controls; lateral dynamics and outer speed/flight-path loops excluded. Not full-aircraft stability.',
            'Slew limiter infinitesimal gain is unity after delay; no invented first-order servo lag.',
            'Finite sinusoidal deflection amplitude D at omega requires D*omega <= surface rate; travel and allocation saturation invalidate linear margins.',
            'Zero-order hold and fractional-period actuator delay included; no extra computation delay is present in production.',
            'Margins are frequency-grid diagnostics; closed-loop poles are reported separately. Neither certifies nonlinear launch stability or physical validation.'])
