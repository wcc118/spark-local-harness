"""Managed controller artifacts; local Linux filesystem, one owning catalog.

No jobs, HTTP, simulation or automatic replay. See CONTROLLER_DASHBOARD_CONTRACT.
Catalog callers must additionally prohibit deletion while a child is alive.
"""
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import hashlib
from itertools import islice
import json
import math
import os
from pathlib import Path
import re
import stat
import threading
import uuid

from .aircraft_controller_contract import make_run_inputs, _json_values
from .aircraft_elastic import digest

SCHEMA = 'aircraft-controller-record-v1'
MAX_INPUT = 4*1024**2  # bounded self-contained aero table snapshots (#257)
MAX_METADATA = 64*1024
MAX_REPORT = 256*1024**2
MAX_CONFIGS = 32
MAX_RUNS = 16
MAX_ENTRIES = 128
LIMITS = {'inputs.json': MAX_INPUT, 'record.json': MAX_METADATA,
          'report.json': MAX_REPORT, 'replay.json': MAX_METADATA}
KINDS = ('configuration', 'run', 'replay')
ACTIVE = ('preparing', 'running', 'verifying')
TERMINAL = ('finished', 'failed', 'interrupted')
REPORT_STATUSES = ('completed', 'cancelled', 'not-run-trim', 'not-run-authority',
                   'ground', 'model-domain', 'numerical-error')


def _id(value):
    if type(value) is not str or re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', value) is None:
        raise ValueError('Canonical UUID required')
    return value


def _identity(info):
    return info.st_dev, info.st_ino


def _now():
    return datetime.now(timezone.utc).isoformat()


def _text(value, maximum):
    if type(value) is not str or not value.strip() or len(value)>maximum:
        raise ValueError('Invalid metadata text')


def _pairs(pairs):
    result = {}
    for key,value in pairs:
        if key in result: raise ValueError('Duplicate JSON key: '+key)
        result[key] = value
    return result


def _decode(raw):
    def invalid(value): raise ValueError('Nonfinite JSON: '+value)
    value = json.loads(raw, parse_constant=invalid, object_pairs_hook=_pairs)
    _json_values(value, 'artifact')
    return value


def _read(fd, name):
    if name not in LIMITS: raise ValueError('Unknown artifact basename')
    child = os.open(name, os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK, dir_fd=fd)
    with os.fdopen(child, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size>LIMITS[name]:
            raise ValueError('Artifact must be a bounded regular file')
        raw = stream.read(LIMITS[name]+1)
        if len(raw)>LIMITS[name]: raise ValueError('Artifact grew beyond byte limit')
    return raw


def _descriptor(name, raw):
    return dict(name=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def _write(fd, name, value, limit):
    """Exclusive incremental encoding; remove only our own failed creation."""
    child = os.open(name, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, 0o600, dir_fd=fd)
    identity = _identity(os.fstat(child)); total = 0; sha = hashlib.sha256()
    try:
        with os.fdopen(child, 'wb') as stream:
            for chunk in json.JSONEncoder(sort_keys=True,separators=(',',':'),allow_nan=False).iterencode(value):
                raw = chunk.encode(); total += len(raw)
                if total>limit: raise ValueError(name+' exceeds byte limit')
                stream.write(raw); sha.update(raw)
            stream.flush(); os.fsync(stream.fileno())
        os.fsync(fd)
    except BaseException:
        try:
            if _identity(os.stat(name,dir_fd=fd,follow_symlinks=False))==identity:
                os.unlink(name,dir_fd=fd)
        except OSError: pass
        raise
    return dict(name=name,bytes=total,sha256=sha.hexdigest())


def write_artifact(directory_fd, name, value):
    """Child writer boundary: caller supplies a pinned directory FD, never a path.

    This stages an exclusive artifact. Parent verification/publication is separate.
    """
    if name not in ('report.json','replay.json'): raise ValueError('Not a result artifact')
    _json_values(value, 'artifact')
    return _write(directory_fd,name,value,LIMITS[name])


def _inputs(value, *, admission=False):
    keys = {'schema','model_id','definition','bench','field_case','definition_sha256',
            'bench_sha256','field_case_sha256','inputs_sha256'}
    if type(value) is not dict or set(value)!=keys:
        raise ValueError('Invalid input envelope fields')
    bench=value.get('bench')
    version=bench.get('schema_version') if type(bench) is dict else None
    if type(version) is not int or version not in (1,2) or value['schema']!='aircraft-controller-inputs-v'+str(version) or value['model_id']!='aircraft-controller-contract-v'+str(version):
        raise ValueError('Input schema mismatch')
    for name in ('definition','bench','field_case'):
        if digest(value[name])!=value[name+'_sha256']: raise ValueError('Input component checksum mismatch')
    if digest({k:value[k+'_sha256'] for k in ('definition','bench','field_case')})!=value['inputs_sha256']:
        raise ValueError('Input envelope checksum mismatch')
    _text(value['bench']['name'],200)
    if admission and make_run_inputs(value['definition'],value['bench'],value['field_case'])!=value:
        raise ValueError('Input envelope differs from reconstructed inputs')


def _progress(value):
    if value is None: return
    if type(value) is not dict or set(value)!={'accepted_tick','total_ticks','time_s','status'}:
        raise ValueError('Invalid progress fields')
    total,tick,time = value['total_ticks'],value['accepted_tick'],value['time_s']
    if type(total) is not int or not 1<=total<=24000: raise ValueError('Invalid total ticks')
    if tick is None:
        if time is not None: raise ValueError('Unaccepted progress must have null time')
    elif type(tick) is not int or not 0<=tick<=total or type(time) not in (int,float) or not math.isfinite(time) or time<0:
        raise ValueError('Invalid accepted progress')
    if value['status'] not in ('running',)+REPORT_STATUSES: raise ValueError('Invalid progress status')


def _result(name, value, inputs):
    if type(value) is not dict: raise ValueError('Result object required')
    hashes,platform = value.get('implementation_hashes'),value.get('platform')
    if type(hashes) is not dict or not hashes or any(type(k) is not str or type(v) is not str or re.fullmatch('[0-9a-f]{64}',v) is None for k,v in hashes.items()):
        raise ValueError('Result implementation identity missing or invalid')
    if type(platform) is not dict or set(platform)!={'system','release','machine','python','numpy'}:
        raise ValueError('Result platform identity missing or invalid')
    for part in platform.values(): _text(part,1000)
    if name=='report.json':
        saved = dict(value); expected = saved.pop('report_sha256',None)
        if digest(saved)!=expected: raise ValueError('Report checksum mismatch')
        expected_model='aircraft-controller-run-v'+str(inputs['bench']['schema_version'])
        if value.get('schema')!=expected_model or value.get('model_id')!=expected_model:
            raise ValueError('Report schema mismatch')
        if value.get('inputs')!=inputs or value.get('inputs_sha256')!=inputs['inputs_sha256']:
            raise ValueError('Report inputs mismatch')
        if value.get('status') not in REPORT_STATUSES: raise ValueError('Report is not terminal')
    else:
        keys = {'schema','status','source_report_sha256','replayed_report_sha256','implementation_hashes','platform','error'}
        if set(value)!=keys or value['schema']!='aircraft-controller-replay-v1': raise ValueError('Replay schema mismatch')
        if value['status'] not in ('matched','mismatched','cancelled','failed'): raise ValueError('Replay status invalid')
        if not re.fullmatch('[0-9a-f]{64}',str(value['source_report_sha256'])): raise ValueError('Source checksum invalid')
        replayed = value['replayed_report_sha256']
        if replayed is not None and not re.fullmatch('[0-9a-f]{64}',str(replayed)): raise ValueError('Replay checksum invalid')
        if value['status']=='matched':
            if replayed!=value['source_report_sha256'] or value['error'] is not None: raise ValueError('Invalid match verdict')
        else: _text(value['error'],2000)


class ControllerStore:
    """Single-owner artifact store. All public operations serialize on one lock."""
    def __init__(self, root):
        self.root = Path(root).absolute(); self._mutex = threading.RLock()
        self._fd = self._lock_fd = None; self._records = {}; self._unavailable = {}
        self.root.mkdir(parents=True,exist_ok=True)
        try:
            self._fd = os.open(self.root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
            self._root_identity = _identity(os.fstat(self._fd))
            self._lock_fd = os.open('catalog.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=self._fd)
            info = os.fstat(self._lock_fd)
            if not stat.S_ISREG(info.st_mode): raise ValueError('Catalog lock must be regular')
            self._lock_identity = _identity(info)
            try: fcntl.flock(self._lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError as error: raise RuntimeError('Controller catalog already owned') from error
            for name in self._names():
                try:
                    _id(name)
                    info = os.stat(name,dir_fd=self._fd,follow_symlinks=False)
                    if not stat.S_ISDIR(info.st_mode): raise ValueError('Record must be a real directory')
                    self._records[name] = _identity(info)
                    with self._directory(name) as fd: self._record(fd,name)
                except (ValueError,TypeError,KeyError,OSError) as error:
                    self._records.pop(name,None); self._unavailable[name] = str(error)
        except BaseException:
            self.close(); raise

    def close(self):
        with self._mutex:
            for name in ('_lock_fd','_fd'):
                fd = getattr(self,name)
                if fd is not None: os.close(fd); setattr(self,name,None)

    def __enter__(self): return self
    def __exit__(self,*args): self.close()

    def _check(self):
        if self._fd is None: raise RuntimeError('Controller store is closed')
        if _identity(os.stat(self.root,follow_symlinks=False))!=self._root_identity:
            raise RuntimeError('Controller root changed')
        if _identity(os.stat('catalog.lock',dir_fd=self._fd,follow_symlinks=False))!=self._lock_identity:
            raise RuntimeError('Controller ownership lock changed')

    def _names(self):
        self._check()
        with os.scandir(self._fd) as entries:
            names = [entry.name for entry in islice(entries,MAX_ENTRIES+1)]
        if len(names)>MAX_ENTRIES: raise ValueError('Controller catalog scan limit exceeded')
        return sorted(name for name in names if name!='catalog.lock')

    @contextmanager
    def _directory(self, identifier):
        self._check(); _id(identifier)
        identity = self._records[identifier]
        fd = os.open(identifier,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=self._fd)
        try:
            if _identity(os.fstat(fd))!=identity: raise RuntimeError('Controller record directory changed')
            yield fd
        finally: os.close(fd)

    def _record(self, fd, identifier, *, full=False):
        with os.scandir(fd) as entries: names = [e.name for e in islice(entries,6)]
        if set(names)-set(LIMITS): raise ValueError('Unknown record files; manual inspection required')
        for name in names:
            info = os.stat(name,dir_fd=fd,follow_symlinks=False)
            if not stat.S_ISREG(info.st_mode) or info.st_size>LIMITS[name]: raise ValueError('Unsafe record artifact')
        record = _decode(_read(fd,'record.json')); saved = dict(record)
        signature = saved.pop('record_sha256',None)
        keys = {'schema','id','kind','name','created_utc','updated_utc','parent_config_id',
                'source_run_id','phase','progress','error','artifacts'}
        if set(saved)!=keys or digest(saved)!=signature or record['schema']!=SCHEMA or record['id']!=identifier:
            raise ValueError('Record metadata identity mismatch')
        kind,phase = record['kind'],record['phase']
        if kind not in KINDS or phase not in ACTIVE+TERMINAL: raise ValueError('Record kind/phase invalid')
        _text(record['name'],200)
        for key in ('created_utc','updated_utc'):
            stamp = datetime.fromisoformat(record[key])
            if stamp.tzinfo is None or stamp.utcoffset().total_seconds()!=0: raise ValueError('UTC timestamp required')
        for key in ('parent_config_id','source_run_id'):
            if record[key] is not None: _id(record[key])
        if (kind=='replay')!=(record['source_run_id'] is not None): raise ValueError('Replay source required only for replay')
        if record['error'] is not None: _text(record['error'],2000)
        if phase in ('failed','interrupted') and record['error'] is None: raise ValueError('Failure reason required')
        _progress(record['progress'])
        artifacts = record['artifacts']
        allowed = {'inputs.json'} | ({'report.json'} if kind=='run' else {'replay.json'} if kind=='replay' else set())
        if type(artifacts) is not dict or 'inputs.json' not in artifacts or set(artifacts)-allowed:
            raise ValueError('Record artifacts invalid')
        if set(names)-({'record.json'}|allowed): raise ValueError('Artifact does not belong to record kind')
        values = {}
        for name,description in artifacts.items():
            if type(description) is not dict or set(description)!={'name','bytes','sha256'} or description['name']!=name:
                raise ValueError('Artifact descriptor invalid')
            if type(description['bytes']) is not int or not 0<=description['bytes']<=LIMITS[name]:
                raise ValueError('Artifact descriptor byte limit invalid')
            if type(description['sha256']) is not str or re.fullmatch('[0-9a-f]{64}',description['sha256']) is None:
                raise ValueError('Artifact descriptor checksum invalid')
            info = os.stat(name,dir_fd=fd,follow_symlinks=False)
            if info.st_size!=description['bytes']: raise ValueError('Artifact size mismatch')
            # Compact polling never decodes entire histories. Full reads verify
            # bytes/checksum/result identity before exposing a result artifact.
            if name=='inputs.json' or full:
                raw = _read(fd,name)
                if description!=_descriptor(name,raw): raise ValueError('Artifact checksum/size mismatch')
                values[name] = _decode(raw)
        inputs = values['inputs.json']; _inputs(inputs)
        if record['name']!=inputs['bench']['name']: raise ValueError('Record name differs from frozen inputs')
        if record['progress'] is not None:
            timing = inputs['bench']['timing']; p = record['progress']
            if p['total_ticks']!=round(timing['duration_s']/timing['plant_dt_s']): raise ValueError('Progress horizon mismatch')
            if p['accepted_tick'] is not None and abs(p['time_s']-p['accepted_tick']*timing['plant_dt_s'])>1e-9:
                raise ValueError('Progress accepted time mismatch')
        if kind=='configuration' and (phase!='finished' or record['progress'] is not None): raise ValueError('Configuration must be finished')
        result_name = 'report.json' if kind=='run' else 'replay.json'
        if kind!='configuration' and phase=='finished' and result_name not in artifacts: raise ValueError('Finished record has no verified result')
        for name,value in values.items():
            if name!='inputs.json': _result(name,value,inputs)
        return record,values

    def _metadata(self, fd, record):
        saved = deepcopy(record); saved.pop('record_sha256',None); saved['updated_utc'] = _now()
        saved['record_sha256'] = digest(saved)
        name = '.record-'+str(uuid.uuid4())+'.tmp'
        try:
            _write(fd,name,saved,MAX_METADATA)
            os.replace(name,'record.json',src_dir_fd=fd,dst_dir_fd=fd); os.fsync(fd)
        finally:
            try: os.unlink(name,dir_fd=fd)
            except FileNotFoundError: pass
        return saved

    def listing(self):
        with self._mutex:
            names = self._names(); unavailable = {}; rows = []
            for name in names:
                if name not in self._records:
                    unavailable[name] = self._unavailable.get(name,'Unregistered entry; reopen catalog to inspect')
                    continue
                try:
                    with self._directory(name) as fd: record,_ = self._record(fd,name)
                    rows.append(record)
                except (ValueError,TypeError,KeyError,OSError,RuntimeError) as error: unavailable[name] = str(error)
            return dict(records=rows,unavailable=[dict(name=k,error=v) for k,v in unavailable.items()],
                        limits=dict(max_configurations=MAX_CONFIGS,max_runs=MAX_RUNS,max_input_bytes=MAX_INPUT,max_report_bytes=MAX_REPORT))

    def snapshot(self, identifier):
        with self._mutex, self._directory(identifier) as fd:
            return self._record(fd,identifier)[0]

    def artifact(self, identifier, name):
        if name not in ('inputs.json','report.json','replay.json'): raise ValueError('Unknown public artifact')
        with self._mutex, self._directory(identifier) as fd:
            record,values = self._record(fd,identifier,full=name!='inputs.json')
            if name not in record['artifacts']: raise RuntimeError('Artifact not published')
            return values[name]

    def verified_bytes(self, identifier, name):
        """Bounded exact download bytes; verification precedes any HTTP headers."""
        if name not in ('inputs.json','report.json','replay.json'): raise ValueError('Unknown public artifact')
        with self._mutex, self._directory(identifier) as fd:
            record,values = self._record(fd,identifier,full=name!='inputs.json')
            if name not in record['artifacts']: raise RuntimeError('Artifact not published')
            del values
            raw = _read(fd,name)
            if _descriptor(name,raw)!=record['artifacts'][name]: raise ValueError('Artifact changed during download verification')
            return raw

    def create(self, kind, inputs, *, parent_config_id=None, source_run_id=None):
        if kind not in KINDS: raise ValueError('Unknown record kind')
        inputs = deepcopy(inputs); _json_values(inputs,'inputs'); _inputs(inputs,admission=True)
        if len(json.dumps(inputs,sort_keys=True,separators=(',',':'),allow_nan=False).encode())>MAX_INPUT:
            raise ValueError('Input byte limit exceeded')
        with self._mutex:
            listing = self.listing(); unknown = len(listing['unavailable'])
            count = sum((r['kind']=='configuration')==(kind=='configuration') for r in listing['records'])
            if count+unknown >= (MAX_CONFIGS if kind=='configuration' else MAX_RUNS): raise RuntimeError('Controller record capacity reached')
            if parent_config_id is not None:
                parent = self.snapshot(parent_config_id)
                if parent['kind']!='configuration': raise ValueError('Parent must be a saved configuration')
            if kind=='replay':
                if source_run_id is None: raise ValueError('Replay source required')
                source = self.snapshot(source_run_id)
                if source['kind']!='run' or source['phase']!='finished' or 'report.json' not in source['artifacts']:
                    raise ValueError('Replay source must be a finished run')
                if self.artifact(source_run_id,'inputs.json')!=inputs: raise ValueError('Replay inputs differ from source')
            elif source_run_id is not None: raise ValueError('Source run only applies to replay')
            identifier = str(uuid.uuid4()); os.mkdir(identifier,0o700,dir_fd=self._fd)
            self._records[identifier] = _identity(os.stat(identifier,dir_fd=self._fd,follow_symlinks=False))
            with self._directory(identifier) as fd:
                description = _write(fd,'inputs.json',inputs,MAX_INPUT)
                record = dict(schema=SCHEMA,id=identifier,kind=kind,name=inputs['bench']['name'],
                    created_utc=_now(),updated_utc=_now(),parent_config_id=parent_config_id,
                    source_run_id=source_run_id,phase='finished' if kind=='configuration' else 'preparing',
                    progress=None,error=None,artifacts={'inputs.json':description})
                result = self._metadata(fd,record)
            os.fsync(self._fd)
            return result

    def update(self, identifier, *, phase, progress=None, error=None):
        if phase not in ACTIVE+('failed','interrupted'): raise ValueError('Use publish for finished results')
        _progress(progress)
        if error is not None: _text(error,2000)
        if phase in ('failed','interrupted') and error is None: raise ValueError('Failure reason required')
        with self._mutex, self._directory(identifier) as fd:
            record,values = self._record(fd,identifier)
            if record['phase'] in TERMINAL: raise RuntimeError('Terminal records are immutable')
            if record['phase']=='verifying' and phase in ('preparing','running') or record['phase']=='running' and phase=='preparing':
                raise ValueError('Job lifecycle cannot move backwards')
            if progress is not None:
                timing = values['inputs.json']['bench']['timing']
                if progress['total_ticks']!=round(timing['duration_s']/timing['plant_dt_s']): raise ValueError('Progress horizon mismatch')
                if progress['accepted_tick'] is not None and abs(progress['time_s']-progress['accepted_tick']*timing['plant_dt_s'])>1e-9:
                    raise ValueError('Progress accepted time mismatch')
                old = record['progress']
                if old is not None and old['accepted_tick'] is not None and (progress['accepted_tick'] is None or progress['accepted_tick']<old['accepted_tick']):
                    raise ValueError('Accepted progress cannot move backwards')
            record.update(phase=phase,error=error)
            if progress is not None: record['progress'] = deepcopy(progress)
            return self._metadata(fd,record)

    def open_writer(self, identifier):
        """Return owned FD for a child; caller closes it and guards child lifetime."""
        with self._mutex, self._directory(identifier) as fd:
            record,_ = self._record(fd,identifier)
            if record['phase'] not in ACTIVE: raise RuntimeError('Record is not writable')
            return os.dup(fd)

    def publish(self, identifier):
        with self._mutex, self._directory(identifier) as fd:
            record,values = self._record(fd,identifier)
            if record['phase'] not in ACTIVE: raise RuntimeError('Terminal records are immutable')
            name = 'report.json' if record['kind']=='run' else 'replay.json'
            raw = _read(fd,name); result = _decode(raw); _result(name,result,values['inputs.json'])
            if name=='replay.json':
                source = self.artifact(record['source_run_id'],'report.json')
                if result['source_report_sha256']!=source['report_sha256']: raise ValueError('Replay source identity mismatch')
                if result['status']=='matched' and any(result[k]!=source[k] for k in ('implementation_hashes','platform')):
                    raise ValueError('Matched replay implementation/platform differs from source')
            if name=='report.json':
                last = result['truth'][-1] if result['truth'] else None
                timing = values['inputs.json']['bench']['timing']
                progress = dict(accepted_tick=None if last is None else last['tick'],
                    total_ticks=round(timing['duration_s']/timing['plant_dt_s']),
                    time_s=None if last is None else last['time_s'],status=result['status'])
                _progress(progress)
                if last is not None and abs(progress['time_s']-progress['accepted_tick']*timing['plant_dt_s'])>1e-9:
                    raise ValueError('Report accepted time disagrees with frozen clock')
                previous = record['progress']
                if previous is not None and previous['accepted_tick'] is not None and (last is None or progress['accepted_tick']<previous['accepted_tick']):
                    raise ValueError('Report accepted progress regressed')
                record['progress'] = progress
            record['artifacts'][name] = _descriptor(name,raw)
            record.update(phase='finished',error=None)
            return self._metadata(fd,record)

    def delete(self, identifier, confirmation):
        if confirmation!=_id(identifier): raise ValueError('Confirmation must match selected UUID')
        with self._mutex, self._directory(identifier) as fd:
            record,_ = self._record(fd,identifier)
            if record['phase'] not in TERMINAL: raise RuntimeError('Active record cannot be deleted')
            # Only known regular files in the pinned directory; never traverse.
            # Catalog must additionally guard against a still-live result writer.
            names = os.listdir(fd)
            if set(names)-set(LIMITS): raise ValueError('Unknown files prevent deletion')
            for name in names:
                if not stat.S_ISREG(os.stat(name,dir_fd=fd,follow_symlinks=False).st_mode):
                    raise ValueError('Unsafe file prevents deletion')
            for name in names: os.unlink(name,dir_fd=fd)
            os.fsync(fd)
            if _identity(os.stat(identifier,dir_fd=self._fd,follow_symlinks=False))!=self._records[identifier]:
                raise RuntimeError('Record changed during deletion')
            os.rmdir(identifier,dir_fd=self._fd); os.fsync(self._fd)
            del self._records[identifier]
            return dict(deleted=identifier)
