"""Public deterministic report/replay and CLI; see mechanics/CONTROLLER_RUN.md."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
from ._aircraft_controller_runtime import simulate_bench
from .aircraft_controller import CONTROL_KEYS, SURFACES
from .aircraft_controller_contract import _json_values
from .aircraft_controller_trim import _identity
from .aircraft_controller_plant import ControllerPlant
from .aircraft_elastic import digest

MODEL_ID = 'aircraft-controller-run-v1'


def _build_metrics(trace):
    truth = trace['truth']
    scalar_keys = ('accepted_duration_s','peak_attitude_error_deg','peak_rate_deg_s',
        'min_airspeed_ft_s','max_airspeed_ft_s','min_height_ft','max_height_ft',
        'min_flight_path_deg','max_flight_path_deg','air_angle_unavailable_samples')
    vector_keys = ('surface_travel_deg','travel_limit_duration_s','rate_limit_duration_s',
        'command_travel_limit_duration_s','command_accel_limit_duration_s')
    metrics = dict.fromkeys(scalar_keys+vector_keys)
    metrics.update(selected_cut_extrema=deepcopy(trace['governing_loads']['extrema']),
                   reason='No accepted samples' if not truth else None)
    if not truth: return metrics
    for key in vector_keys: metrics[key] = [0.,0.,0.]
    metrics['accepted_duration_s'] = truth[-1]['time_s']-truth[0]['time_s']
    for key in ('attitude_error_deg','rate_max_deg_s'):
        metrics['peak_attitude_error_deg' if key=='attitude_error_deg' else 'peak_rate_deg_s'] = max(row[key] for row in truth)
    for key in ('airspeed_ft_s','height_ft','flight_path_deg'):
        values = [row[key] for row in truth if row[key] is not None]
        metrics['min_'+key] = min(values) if values else None
        metrics['max_'+key] = max(values) if values else None
    metrics['air_angle_unavailable_samples'] = sum(row['air_angles_reason'] is not None for row in truth)
    for previous,current in zip(truth,truth[1:]):
        for j,key in enumerate(CONTROL_KEYS[:3]):
            metrics['surface_travel_deg'][j] += abs(current['actual_controls'][key]-previous['actual_controls'][key])
    for segment in trace['segments']:
        if not segment['completed']: continue
        for j,name in enumerate(SURFACES):
            moving = min(segment['duration_s'],abs(segment['target_deg'][j]-segment['start_deg'][j])/segment['rate_deg_s'][j])
            metrics['rate_limit_duration_s'][j] += moving
            limits = trace['inputs']['bench']['actuators'][name]
            if any(abs(segment['target_deg'][j]-limits[key])<=1e-12 for key in ('min_deg','max_deg')):
                metrics['travel_limit_duration_s'][j] += segment['duration_s']-moving
    commands = trace['commands']
    for index,command in enumerate(commands):
        end = min(truth[-1]['time_s'],commands[index+1]['time_s'] if index+1<len(commands) else truth[-1]['time_s'])
        held = max(0.,end-command['time_s'])
        for metric,flag in (('command_travel_limit_duration_s','travel_limited'),('command_accel_limit_duration_s','accel_limited')):
            for j,limited in enumerate(command[flag]):
                if limited: metrics[metric][j] += held
    if trace['inputs']['bench']['schema_version']==2:
        metrics['thrust_travel_lbf']=sum(abs(b['actual_controls']['thrust_lbf']-a['actual_controls']['thrust_lbf']) for a,b in zip(truth,truth[1:]))
        metrics['thrust_rate_limit_duration_s']=0.
        metrics['thrust_stop_duration_s']=0.
        limits=trace['inputs']['bench']['target']
        for segment in trace['thrust_segments']:
            if not segment['completed']:continue
            moving=min(segment['duration_s'],abs(segment['target_lbf']-segment['start_lbf'])/segment['rate_lbf_s'])
            metrics['thrust_rate_limit_duration_s']+=moving
            if any(abs(segment['target_lbf']-limits[key])<=1e-12 for key in ('trim_thrust_min_lbf','trim_thrust_max_lbf')):
                metrics['thrust_stop_duration_s']+=segment['duration_s']-moving
    return metrics


def _build_outcomes(trace):
    truth = trace['truth']; criteria = trace['inputs']['bench']['criteria']
    outcomes = {'sustained_capture':dict(status='unavailable',reason='Speed/flight-path outer loops are not implemented')}
    for name in ('rate_damping','attitude_recovery'):
        first = start = None
        for row in truth:
            inside = row['rate_max_deg_s']<=criteria['rate_error_deg_s'] and (name=='rate_damping' or row['attitude_error_deg']<=criteria['attitude_error_deg'])
            if inside:
                if first is None: first = row['time_s']
                if start is None: start = row['time_s']
            else: start = None
        duration = None if not truth else (0. if start is None else truth[-1]['time_s']-start)
        if not truth: reason = 'No accepted samples'
        elif trace['status']!='completed': reason = 'Simulation did not complete: '+trace['status']
        elif any(row['height_ft']<criteria['minimum_height_ft'] for row in truth): reason = 'Height below minimum during simulation'
        elif any(row['airspeed_ft_s']>criteria['max_airspeed_ft_s'] for row in truth): reason = 'Airspeed above maximum during simulation'
        elif start is None or duration+1e-12<criteria['dwell_s']: reason = 'Final uninterrupted dwell insufficient'
        else: reason = None
        outcomes[name] = dict(met=reason is None,first_entry_time_s=first,final_dwell_start_s=start,
                              final_dwell_duration_s=duration,reason=reason)
    if trace['inputs']['bench']['schema_version']==2:
        bench=trace['inputs']['bench']; target=bench['target']; outer=bench['outer_loop']
        first=start=None
        for row in truth:
            gamma,heading=row['flight_path_deg'],row['heading_deg']
            inside=(gamma is not None and heading is not None
                and abs(row['airspeed_ft_s']-target['airspeed_ft_s'])<=criteria['speed_error_ft_s']
                and abs(gamma-outer['flight_path_target_deg'])<=criteria['flight_path_error_deg']
                and abs((heading-target['heading_deg']+180)%360-180)<=criteria['heading_error_deg']
                and row['rate_max_deg_s']<=criteria['rate_error_deg_s'])
            if inside:
                if first is None: first=row['time_s']
                if start is None: start=row['time_s']
            else: start=None
        duration=None if not truth else (0. if start is None else truth[-1]['time_s']-start)
        if not truth: reason='No accepted samples'
        elif trace['status']!='completed': reason='Simulation did not complete: '+trace['status']
        elif any(row['height_ft']<criteria['minimum_height_ft'] for row in truth): reason='Height below minimum during simulation'
        elif any(row['airspeed_ft_s']>criteria['max_airspeed_ft_s'] for row in truth): reason='Airspeed above maximum during simulation'
        elif start is None or duration+1e-12<criteria['dwell_s']: reason='Final simultaneous capture dwell insufficient'
        else: reason=None
        outcomes['sustained_capture']=dict(status='available',met=reason is None,
            first_entry_time_s=first,final_dwell_start_s=start,final_dwell_duration_s=duration,reason=reason,
            objectives='airspeed, air-relative flight path, body heading and body rates; altitude is clearance only')
    if 'autopilot' in trace['inputs']['bench']:
        import math
        bench=trace['inputs']['bench']; ap=bench['autopilot']; target=bench['target']
        events=[e for e in trace.get('events',[]) if e['kind']=='autopilot-engaged']
        engagement=events[0]['time_s'] if events else None
        stable_start=events[0].get('stabilization_start_s') if events else None
        outcomes['stabilization']=dict(status='available',met=engagement is not None,
            first_entry_time_s=stable_start,
            engagement_time_s=engagement,final_dwell_duration_s=(engagement-stable_start if stable_start is not None else None) if engagement is not None else 0.,
            reason=None if engagement is not None else 'Stable-flight engagement dwell not achieved')
        start=first=None; unmet=[]
        wind_down=trace['inputs']['field_case']['wind_N_ft_s'][2]
        for row in truth:
            speed=row['airspeed_ft_s'];gamma=row['flight_path_deg'];heading=row['heading_deg']
            hold_gamma=math.degrees(math.asin(max(-1.,min(1.,wind_down/max(speed,1e-12)))))
            checks=dict(height=abs(row['height_ft']-target['height_agl_ft'])<=ap['height_tolerance_ft'],
                speed=abs(speed-target['airspeed_ft_s'])<=criteria['speed_error_ft_s'],
                flight_path=gamma is not None and abs(gamma-hold_gamma)<=criteria['flight_path_error_deg'],
                heading=heading is not None and abs((heading-target['heading_deg']+180)%360-180)<=criteria['heading_error_deg'],
                rates=row['rate_max_deg_s']<=criteria['rate_error_deg_s'])
            unmet=[k for k,v in checks.items() if not v]
            if engagement is not None and row['time_s']>=engagement and not unmet:
                if first is None:first=row['time_s']
                if start is None:start=row['time_s']
            else:start=None
        duration=0. if start is None else truth[-1]['time_s']-start
        reason=None
        if not truth:reason='No accepted samples'
        elif trace['status']!='completed':reason='Simulation did not complete: '+trace['status']
        elif any(r['height_ft']<criteria['minimum_height_ft'] for r in truth):reason='Height below minimum during simulation'
        elif any(r['airspeed_ft_s']>criteria['max_airspeed_ft_s'] for r in truth):reason='Airspeed above maximum during simulation'
        elif engagement is None:reason='Stable-flight engagement dwell not achieved'
        elif unmet:reason='Commanded-flight criteria unmet: '+', '.join(unmet)
        elif duration+1e-12<ap['dwell_s']:reason='Final uninterrupted commanded-flight dwell insufficient'
        outcomes['autopilot']=dict(status='available',met=reason is None,reason=reason,
            engagement_time_s=engagement,first_entry_time_s=first,final_dwell_start_s=start,
            final_dwell_duration_s=duration,unmet_criteria=unmet,target_height_agl_ft=target['height_agl_ft'],
            actual_height_agl_ft=truth[-1]['height_ft'] if truth else None,height_tolerance_ft=ap['height_tolerance_ft'],
            objectives='AGL height, airspeed, level ground-relative flight path, body heading and body rates')
    return outcomes


def run_bench(inputs, *, progress=None, cancelled=None):
    report = simulate_bench(inputs,progress=progress,cancelled=cancelled)
    hashes,platform = _identity()
    model='aircraft-controller-run-v'+str(inputs['bench']['schema_version'])
    report.update(schema=model,model_id=model,implementation_hashes=hashes,platform=platform,
                  aero_dataset=ControllerPlant(inputs).aero_dataset,
                  metrics=_build_metrics(report),outcomes=_build_outcomes(report))
    report['report_sha256'] = digest(report)
    return report


def replay_bench(report):
    _json_values(report,'report')
    if type(report) is not dict or report.get('schema') not in (MODEL_ID,'aircraft-controller-run-v2') or report.get('model_id')!=report.get('schema'):
        raise ValueError('Report schema mismatch')
    saved = deepcopy(report); expected = saved.pop('report_sha256',None)
    if digest(saved)!=expected: raise ValueError('Report checksum mismatch')
    hashes,platform = _identity()
    if saved.get('implementation_hashes')!=hashes: raise ValueError('Replay requires identical implementation')
    if saved.get('platform')!=platform: raise ValueError('Replay requires identical platform')
    if 'inputs' not in saved: raise ValueError('Report missing inputs')
    tick = saved.get('cancel_tick')
    if tick is not None and (type(tick) is not int or tick<0): raise ValueError('Invalid cancel tick')
    replayed = run_bench(saved['inputs'],cancelled=None if tick is None else lambda p:p['accepted_tick']==tick)
    if replayed['report_sha256']!=expected: raise ValueError('Replayed full report differs from saved')
    return replayed


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input_json'); parser.add_argument('--output',required=True)
    args = parser.parse_args(argv)
    try:
        inputs = json.loads(Path(args.input_json).read_text())
        report = run_bench(inputs)
        Path(args.output).write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    except (OSError,ValueError) as error:
        print(str(error),file=sys.stderr)
        return 1
    print(report['status']+' '+report['report_sha256'])
    return 0


if __name__=='__main__':
    raise SystemExit(main())
