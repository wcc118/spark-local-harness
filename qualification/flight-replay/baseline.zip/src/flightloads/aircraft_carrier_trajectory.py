"""Exploratory separated carrier release; ground-state RK4, air-relative loads."""
from copy import deepcopy
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from .aircraft_carrier_release import preview_release, air_angles
from .aircraft_full_angle_field import (FullAngleField, default_controls, default_environment,
    default_settings, field_metadata)
from .aircraft_full_angle_polar import default_parameters
from .aircraft_workspace import evaluate_aircraft
from .aircraft_transient import (mass_quadrature, recover_imperial, IN_M, FT_M, LBF_N, IN_LBF_NM, G_N)
from .aircraft_elastic import digest
from .conventions import rotation_matrix
from .state import RigidState
from .loads import AppliedLoads
from .dynamics import rigid_derivative
from .integration import integrate
from .plant_aero import PlantAero

MODEL_ID='exploratory-carrier-free-flight-v1'
INTEGRATION={'duration_s':(.001,5.,.5),'dt_s':(.0001,.05,.005)}
MAX_INTERVALS=1000
CONTROL_KEYS=['common_tail_deg','differential_tail_deg','aileron_deg','thrust_lbf','prop_torque_in_lbf']
IMPLEMENTATION=['aircraft_carrier_trajectory.py','aircraft_carrier_release.py','aircraft_release.py',
    'aircraft_full_angle_field.py','aircraft_full_angle_polar.py','aircraft_workspace.py',
    'aircraft_input_limits.py','aircraft_transient.py','aircraft_elastic.py','integration.py',
    'dynamics.py','state.py','mass.py','loads.py','conventions.py','_arrays.py']
LIMITATIONS=[
    'Exploratory constant-mass rigid free flight after full separation; no trim prerequisite or capture/stability/strength acceptance.',
    'Uniform atmosphere and wind; AGL height does not infer atmospheric density. Controls and propulsion are held fixed from the release scenario.',
    'No tube/contact, carrier wake/rotation-offset, deployment, flexible wing/tail response, gyroscopic rotor or ground-contact dynamics.',
    'Ground stop uses the CG crossing a flat z_N=0 plane, not the earliest geometry contact.',
    'Any invalid RK stage rejects its whole step. Event brackets are numerical step brackets, not exact physical event times; refine dt.',
    'Cut recovery clips mass analytically and treats body side force as uniform over each midpoint bin. Wing/tail, axial drag and propulsion remain located resultants; refine aerodynamic discretization.',
    'Run completion and numerical verification do not validate aircraft coefficients or define a successful recovery. Capture criteria are unspecified.',
]


def default_case():
    return dict(schema_version=1,environment=default_environment(),parameters=default_parameters(),
        discretization=default_settings(),installation=dict(wing_incidence_deg=0.,tail_incidence_deg=0.),
        integration={k:v[2] for k,v in INTEGRATION.items()})


def trajectory_metadata():
    return dict(model_id=MODEL_ID,defaults=default_case(),field=field_metadata(),
        integration={k:dict(min=v[0],max=v[1],default=v[2],unit='s') for k,v in INTEGRATION.items()},
        max_intervals=MAX_INTERVALS,held_scenario_controls=list(CONTROL_KEYS),limitations=list(LIMITATIONS))


def _case(value):
    c=deepcopy(default_case() if value is None else value)
    if not isinstance(c,dict) or set(c)!=set(default_case()) or type(c['schema_version']) is not int or c['schema_version']!=1:
        raise ValueError('Trajectory case requires exactly the schema_version=1 documented fields')
    for key in ['environment','parameters','discretization']:
        if not isinstance(c[key],dict):raise ValueError(key+' requires its complete documented object')
    if not isinstance(c['integration'],dict) or set(c['integration'])!=set(INTEGRATION):
        raise ValueError('Trajectory integration requires duration_s and dt_s')
    for key,(lo,hi,_) in INTEGRATION.items():
        v=c['integration'][key]
        if type(v) not in (int,float) or not math.isfinite(v) or not lo<=v<=hi:
            raise ValueError(f'integration.{key} must be finite in [{lo},{hi}] s')
    if c['integration']['duration_s']/c['integration']['dt_s']>MAX_INTERVALS:
        raise ValueError(f'Trajectory is limited to {MAX_INTERVALS} integration intervals; increase dt or reduce duration')
    if not isinstance(c['installation'],dict) or set(c['installation'])!={'wing_incidence_deg','tail_incidence_deg'}:
        raise ValueError('Installation requires exactly wing_incidence_deg and tail_incidence_deg')
    return c


def _implementation():
    root=Path(__file__).parent
    return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in IMPLEMENTATION}


class TrajectoryStop(ValueError):
    def __init__(self,kind,reason,time_s):
        super().__init__(reason);self.kind=kind;self.time_s=float(time_s)


class _Context:
    def __init__(self,definition,scenario,case):
        self.preview=preview_release(definition,scenario);self.case=_case(case)
        self.definition=self.preview['definition'];self.scenario=self.preview['scenario']
        # Compute only the aircraft mass projection; saved legacy flight/load cases are retained in inputs but do not drive release.
        mass_definition=deepcopy(self.definition)
        for key in ['flight_condition','transient_case','load_case']:mass_definition.pop(key,None)
        workspace=evaluate_aircraft(mass_definition);self.mp=workspace['mass_properties'];self.components=workspace['resolved_components']
        if self.mp is None:raise ValueError('Carrier trajectory requires complete component mass inputs')
        try:
            self.mass=mass_quadrature(self.components);self.mass.require_rigid_inertia()
        except (RuntimeError,ValueError) as error:raise ValueError('Carrier trajectory requires positive-definite usable inertia: '+str(error)) from error
        if not (np.allclose(self.mass.cg_from_datum_B_m,np.array(self.mp['cg_B_in'])*IN_M,rtol=1e-10,atol=1e-12)
            and np.allclose(self.mass.inertia_CG_B_kg_m2,np.array(self.mp['inertia_CG'])*IN_LBF_NM,rtol=1e-10,atol=1e-12)
            and math.isclose(self.mass.mass_kg,self.mp['weight_lbf']*LBF_N/G_N[2],rel_tol=1e-12)):
            raise ValueError('Mass quadrature and component mass/CG/inertia disagree')
        controls=dict(default_controls(),**self.case['installation']);controls.update({k:self.scenario[k] for k in CONTROL_KEYS})
        self.field=FullAngleField(self.definition,parameters=self.case['parameters'],environment=self.case['environment'],
            controls=controls,settings=self.case['discretization'])
        # Forces come through the aero dataset interface (#206); self.field keeps the recorded configuration/evidence.
        self.aero=PlantAero.strip_model(self.definition,parameters=self.case['parameters'],
            settings=self.case['discretization'],installation=self.case['installation'])
        self.aero_controls=dict(left_tail_deg=controls['common_tail_deg']+controls['differential_tail_deg'],
            right_tail_deg=controls['common_tail_deg']-controls['differential_tail_deg'],aileron_deg=controls['aileron_deg'],
            thrust_lbf=controls['thrust_lbf'],shaft_torque_in_lbf=controls['prop_torque_in_lbf'])
        initial=self.preview['initial'];self.wind=np.array(initial['vectors_ft_s']['wind_N'])
        self.initial=RigidState(np.array(initial['position_N_ft'])*FT_M,np.array(initial['vectors_ft_s']['ground_B'])*FT_M,
            initial['q_NB'],np.radians(initial['omega_B_deg_s']))
        self.max_stage_norm_error=0.

    def field_at(self,state):
        air=state.v_CG_B_mps/FT_M-rotation_matrix(state.q_NB).T@self.wind
        return self.aero.evaluate(air,state.omega_B_radps,self.mp['cg_B_in'],environment=self.case['environment'],**self.aero_controls)

    def checked(self,time,state):
        if state.r_CG_N_m[2]>=0:raise TrajectoryStop('ground','CG reached flat ground plane',time)
        field=self.field_at(state)
        if not field['within_assumed_domain']:
            raise TrajectoryStop('model-limit','; '.join(field['domain_violations']),time)
        return field

    def applied(self,field):
        rows=field['ledger']
        return AppliedLoads(np.array([np.array(r['position_B_in'])-self.mp['cg_B_in'] for r in rows])*IN_M,
            np.array([r['force_B_lbf'] for r in rows])*LBF_N,np.array([r['free_couple_B_in_lbf'] for r in rows])*IN_LBF_NM,
            tuple(r['name'] for r in rows))

    def provider(self,time,state,context):
        self.max_stage_norm_error=max(self.max_stage_norm_error,abs(state.original_norm-1))
        return self.applied(self.checked(time,state))

    def recovery_ledger(self,field):
        # A body midpoint bin represents uniform force per length. Split the intersected bin
        # at the cut without changing its total force or first moment; trajectory stays cut-independent.
        rows=[];cut=self.definition['cut']['station_in'];ds=self.definition['geometry']['fuselage_length_in']/self.case['discretization']['body_strips']
        for source in field['ledger']:
            station=-source['position_B_in'][0];lo,hi=station-ds/2,station+ds/2
            if source['kind']=='body-crossflow' and lo<cut<hi:
                for a,b,label in [(lo,cut,'fore'),(cut,hi,'aft')]:
                    row=deepcopy(source);row.update(name=source['name']+' '+label+' cut-bin portion',
                        position_B_in=[-(a+b)/2,0.,0.],force_B_lbf=(np.array(source['force_B_lbf'])*(b-a)/ds).tolist())
                    rows.append(row)
            else:rows.append(source)
        return rows

    def snapshot(self,time,state,field):
        derivative=rigid_derivative(state,self.mass,self.applied(field),G_N);R=rotation_matrix(state.q_NB)
        acceleration=(derivative.vdot_B_mps2+np.cross(state.omega_B_radps,state.v_CG_B_mps))/IN_M
        gravity=R.T@G_N/IN_M
        recovery=recover_imperial(self.definition,self.components,self.mp['cg_B_in'],acceleration,
            derivative.omegadot_B_radps2,state.omega_B_radps,gravity,self.recovery_ledger(field),time)
        if not recovery['balanced']:raise TrajectoryStop('load-recovery','Whole-body force/moment residual exceeded recovery tolerance',time)
        air=np.array(field['velocity_air_B_ft_s']);ground=state.v_CG_B_mps/FT_M
        # Energy is inertial ground-frame mechanical energy, not a passivity criterion in moving air or with propulsive/couple work.
        energy=.5*self.mass.mass_kg*np.dot(state.v_CG_B_mps,state.v_CG_B_mps)+.5*state.omega_B_radps@self.mass.inertia_CG_B_kg_m2@state.omega_B_radps-self.mass.mass_kg*G_N[2]*state.r_CG_N_m[2]
        power=(np.dot(field['non_gravity_force_B_lbf'],ground)+np.dot(field['moment_about_CG_B_in_lbf'],state.omega_B_radps)/12)*LBF_N*FT_M
        row=dict(time_s=time,state_SI=state.to_vector().tolist(),position_N_ft=(state.r_CG_N_m/FT_M).tolist(),q_NB=state.q_NB.tolist(),
            ground_velocity_B_ft_s=ground.tolist(),ground_velocity_N_ft_s=(R@ground).tolist(),air_velocity_B_ft_s=air.tolist(),
            relative_wind_B_ft_s=(-air).tolist(),**air_angles(air),angular_velocity_B_deg_s=np.degrees(state.omega_B_radps).tolist(),
            angular_acceleration_B_deg_s2=np.degrees(derivative.omegadot_B_radps2).tolist(),acceleration_CG_B_in_s2=acceleration.tolist(),
            gravity_B_in_s2=gravity.tolist(),non_gravity_force_B_lbf=field['non_gravity_force_B_lbf'],moment_about_CG_B_in_lbf=field['moment_about_CG_B_in_lbf'],
            drag_power_lbf_ft_s=field['drag_power_lbf_ft_s'],empirical_couple_power_lbf_ft_s=field['empirical_couple_power_lbf_ft_s'],
            mechanical_energy_J=float(energy),non_gravity_power_W=float(power),field_state_sha256=field['state_sha256'],
            reference_coverage_gaps=field['reference_coverage_gaps'],loads={k:v for k,v in recovery.items() if k not in ['ledger','retained_ledger']})
        row['sample_sha256']=digest(row)
        return row,dict(aerodynamic=field,loads=recovery)


def run_release(definition,scenario,case=None):
    ctx=_Context(definition,scenario,case);settings=ctx.case['integration'];duration=settings['duration_s'];dt=settings['dt_s']
    snapshots=[];event=None;audit=None;peak=-1.;peak_index=None
    def accept(time,state,field):
        nonlocal audit,peak,peak_index
        row,details=ctx.snapshot(time,state,field);score=float(np.linalg.norm(row['loads']['cut_moment_B_in_lbf']))
        if score>peak:peak=score;peak_index=len(snapshots);audit=details
        snapshots.append(row)
    def stopped(error,begin,end):
        return dict(kind=error.kind,reason=str(error),last_accepted_time_s=begin,rejected_step_end_s=end,
            detected_stage_time_s=error.time_s,time_resolution_s=end-begin)
    state=ctx.initial
    initial_field=ctx.field_at(state)
    try:accept(0.,state,ctx.checked(0.,state))
    except TrajectoryStop as error:event=stopped(error,0.,0.)
    if event is None:
        count=math.ceil(duration/dt)
        for i in range(count):
            t=snapshots[-1]['time_s']
            if t>=duration:break
            target=min((i+1)*dt,duration)
            try:
                with np.errstate(over='raise',invalid='raise',divide='raise'):
                    result=integrate(state,ctx.mass,target,target-t,ctx.provider,lambda *args:G_N,t0=t,max_steps=1)
                    candidate=result.state_at(-1);field=ctx.checked(target,candidate);accept(target,candidate,field)
            except TrajectoryStop as error:
                event=stopped(error,t,target);break
            except (ValueError,FloatingPointError,OverflowError,np.linalg.LinAlgError) as error:
                event=stopped(TrajectoryStop('numerical-failure',str(error),t),t,target);event['detected_stage_time_s']=None;break
            state=candidate
    inputs=dict(definition=deepcopy(ctx.definition),scenario=deepcopy(ctx.scenario),case=deepcopy(ctx.case))
    out=dict(schema='carrier-trajectory-v1',model_id=MODEL_ID,inputs=inputs,input_sha256=digest(inputs),initial_preview=ctx.preview,
        initial_state_SI=ctx.initial.to_vector().tolist(),initial_field=initial_field,mass_properties=ctx.mp,
        field_configuration=ctx.field.configuration,field_configuration_sha256=ctx.field.configuration_sha256,
        aero_dataset=dict(ctx.aero.identity),
        field_evidence=ctx.field.report(initial_field['velocity_air_B_ft_s'],ctx.initial.omega_B_radps,ctx.mp['cg_B_in']),
        status='initial-rejected' if not snapshots else 'completed' if event is None else 'stopped',event=event,
        requested_duration_s=duration,accepted_duration_s=snapshots[-1]['time_s'] if snapshots else 0.,
        accepted_sample_count=len(snapshots),snapshots=snapshots,audit_sample_index=peak_index,audit_sample=audit,
        audit_selection='Largest Euclidean cut-moment norm among accepted samples, first tie; concurrent six components, not an allowable or combined failure criterion.',
        max_evaluated_stage_quaternion_norm_error=ctx.max_stage_norm_error,
        outcomes=dict(capture='unknown',stability='not-assessed',strength='not-assessed',reason='No owner-defined capture criterion or validated acceptance model'),
        history_storage='All accepted states and concurrent load summaries; full aerodynamic/mass ledger at audit_sample_index. replay_sample reconstructs any accepted sample against identical implementation.',
        limitations=list(LIMITATIONS),implementation_sha256=_implementation(),units='ft, ft/s, in, in/s^2, s, deg, deg/s, lbf, in-lbf; state_SI is m,m/s,quaternion,rad/s; energy J, power W')
    out['report_sha256']=digest(out)
    return out


def replay_sample(report,index):
    """Offline exact-sample audit, verifying the complete report and implementation."""
    if not isinstance(report,dict) or report.get('schema')!='carrier-trajectory-v1':raise ValueError('Carrier trajectory report required')
    unsigned={k:v for k,v in report.items() if k!='report_sha256'}
    if report.get('report_sha256')!=digest(unsigned):raise ValueError('Report checksum mismatch')
    if report['implementation_sha256']!=_implementation():raise ValueError('Report implementation differs; replay requires the recorded code version')
    if type(index) is not int or not 0<=index<len(report['snapshots']):raise ValueError('Accepted sample index out of range')
    ctx=_Context(**report['inputs']);saved=report['snapshots'][index]
    state=RigidState.from_vector(saved['state_SI'],normalize_quaternion=False)
    row,details=ctx.snapshot(saved['time_s'],state,ctx.checked(saved['time_s'],state))
    if row!=saved:raise ValueError('Reconstructed sample differs from saved evidence')
    return dict(index=index,sample=row,details=details,input_sha256=report['input_sha256'],report_sha256=report['report_sha256'])


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('inputs',type=Path);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args(argv)
    try:
        if args.inputs.stat().st_size>131072:raise ValueError('Trajectory input exceeds128 KiB')
        if args.output.exists():raise ValueError('Output exists; choose a new file')
        inputs=json.loads(args.inputs.read_text())
        if not isinstance(inputs,dict) or set(inputs)!={'definition','scenario','case'}:raise ValueError('Input requires exactly definition, scenario, case')
        result=run_release(**inputs)
        with args.output.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
    except (ValueError,OSError) as error:parser.error(str(error))
    print(f"{result['status']}: accepted {result['accepted_duration_s']:g}/{result['requested_duration_s']:g} s; {args.output}")


if __name__=='__main__':main()
