"""Estimated symmetric longitudinal capability, entirely in imperial units.

No coefficient here is a measured NACA 4412 or inverted-V-tail dataset. Model
limits are assumed domains, not established aircraft validity or acceptance.
"""
from copy import deepcopy
import math
import numpy as np

KNOT_FT_S = 1852 / 0.3048 / 3600
SOURCES = [
    'https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/lift-equation/',
    'https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/induced-drag-coefficient/',
    'https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/earth-atmosphere-equation-english/',
]


def default_condition():
    return dict(speed_ft_s=200., altitude_ft=0., density_override_slug_ft3=None,
        viscosity_slug_ft_s=3.737e-7, alpha_deg=3., wing_incidence_deg=0.,
        tail_incidence_deg=0., ruddervator_deg=6., ruddervator_limit_deg=10., thrust_lbf=3., max_thrust_lbf=10.,
        coefficient_source='Illustrative engineering assumptions; no measured aircraft aerodynamic or propulsion data',
        wing_cl0=.2, wing_cl_alpha_per_rad=4.8, wing_cd0=.025, wing_cm0=-.05,
        wing_efficiency=.8, wing_cl_limit=1.2, wing_alpha_limit_deg=12.,
        tail_cl_alpha_per_rad=3., tail_cd0=.02, tail_efficiency=.8,
        tail_cl_limit=1., tail_alpha_limit_deg=15., downwash_gradient=.3,
        reynolds_min=50000., reynolds_max=1000000.)


def validate_condition(c):
    if not isinstance(c,dict) or set(c) not in (set(default_condition()), set(default_condition())-{'ruddervator_limit_deg'}):
        raise ValueError('flight_condition must contain exactly the documented fields')
    # Schema-v1 compatibility: omitted travel retains the historical assumption.
    # Normalize a copy; validation must not rewrite imported/saved definitions.
    c={**c, 'ruddervator_limit_deg': c.get('ruddervator_limit_deg',10.)}
    from .aircraft_input_limits import FLIGHT_BOUNDS
    bounds=FLIGHT_BOUNDS
    for key,(lo,hi) in bounds.items():
        value=c[key]
        if key=='density_override_slug_ft3' and value is None:continue
        if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:
            raise ValueError(f'flight_condition {key} must be finite in [{lo}, {hi}]')
    if c['reynolds_min']>=c['reynolds_max']:
        raise ValueError('flight_condition Reynolds bounds must be ordered')
    source=c['coefficient_source']
    if not isinstance(source,str) or not source.strip() or len(source)>1000:
        raise ValueError('coefficient_source must describe data provenance in 1..1000 characters')
    return c


def atmosphere(altitude_ft):
    """NASA historical English troposphere curve fit, not measured weather."""
    if not 0<=altitude_ft<=30000:raise ValueError('atmosphere altitude outside 0..30000 ft scope')
    temperature=59-.00356*altitude_ft
    pressure=2116*((temperature+459.7)/518.6)**5.256
    return dict(temperature_F=temperature,pressure_psf=pressure,
                density_slug_ft3=pressure/(1718*(temperature+459.7)))


def _field(d,mp,c,alpha,delta,thrust,*,flow_B_ft_s=None,omega_B_rad_s=None):
    """Evaluate located wind forces; gravity and inertia are never included."""
    g=d['geometry'];a=math.radians(alpha);ca,sa=math.cos(a),math.sin(a)
    wing_pos=[-g['wing_load_station_in'],g['wing_load_y_in'],g['wing_z_in']]
    tail_pos=[-g['tail_load_station_in'],g['tail_load_y_in'],g['tail_root_z_in']]
    prop_pos=[-g['prop_station_in'],0,g['prop_z_in']]
    flow=np.array(flow_B_ft_s if flow_B_ft_s is not None else [c['speed_ft_s']*ca,0,c['speed_ft_s']*sa])
    omega=np.array(omega_B_rad_s if omega_B_rad_s is not None else [0.,0.,0.])
    local=[]
    for pos in [wing_pos,tail_pos]:
        v=flow+np.cross(omega,(np.array(pos)-mp['cg_B_in'])/12)
        if v[0]<=0 or abs(v[1])>1e-7:raise ValueError('Local reverse flow or lateral flow outside longitudinal model')
        local.append((math.degrees(math.atan2(v[2],v[0])),float(np.linalg.norm(v))))
    (alpha_w,vw),(alpha_t,vt)=local
    rho=c['density_override_slug_ft3']
    atm=atmosphere(c['altitude_ft'])
    if rho is None:rho=atm['density_slug_ft3']
    q=.5*rho*c['speed_ft_s']**2/144  # psi; area below is in^2
    qw,qt=.5*rho*vw**2/144,.5*rho*vt**2/144
    sw=g['wing_exposed_span_in']*g['wing_chord_in']
    st=g['tail_panel_length_in']*g['tail_chord_in'] # one physical panel
    arw=g['wing_exposed_span_in']**2/sw
    art=g['tail_panel_length_in']**2/st
    cant=math.radians(g['tail_down_cant_deg']);cc=math.cos(cant)
    aw=alpha_w+c['wing_incidence_deg']
    # Small-angle local incidence and symmetric panel-normal projection.
    at=(alpha_t-c['downwash_gradient']*aw)*cc+c['tail_incidence_deg']+delta
    clw=c['wing_cl0']+c['wing_cl_alpha_per_rad']*math.radians(aw)
    clt=c['tail_cl_alpha_per_rad']*math.radians(at)
    cdw=c['wing_cd0']+clw**2/(math.pi*arw*c['wing_efficiency'])
    cdt=c['tail_cd0']+clt**2/(math.pi*art*c['tail_efficiency'])
    lw,lt=qw*sw*clw,2*qt*st*clt*cc
    dw,dt=qw*sw*cdw,2*qt*st*cdt
    def wind_force(lift,drag,angle):
        a=math.radians(angle)
        return np.array([lift*math.sin(a)-drag*math.cos(a),0,-lift*math.cos(a)-drag*math.sin(a)])
    cm=qw*sw*g['wing_chord_in']*c['wing_cm0']
    ledger=[]
    for name,pos,force,couple in [
        ('Wing aerodynamic resultant',wing_pos,wind_force(lw,dw,alpha_w),[0,cm,0]),
        ('Symmetric tail aerodynamic resultant',tail_pos,wind_force(lt,dt,alpha_t),[0,0,0]),
        ('Propulsive thrust',prop_pos,[thrust,0,0],[0,0,0])]:
        moment=np.cross(np.array(pos)-mp['cg_B_in'],force)+couple
        ledger.append(dict(name=name,position_B_in=list(pos),force_B_lbf=list(force),
            free_couple_B_in_lbf=couple,moment_about_CG_in_lbf=moment.tolist()))
    total_f=np.sum([x['force_B_lbf'] for x in ledger],axis=0)
    total_m=np.sum([x['moment_about_CG_in_lbf'] for x in ledger],axis=0)
    reynolds_w=rho*vw*(g['wing_chord_in']/12)/c['viscosity_slug_ft_s']
    reynolds_t=rho*vt*(g['tail_chord_in']/12)/c['viscosity_slug_ft_s']
    violations=[]
    if not 30<=vw<=300 or not 30<=vt<=300:violations.append('Local surface airspeed outside 30..300 ft/s model scope')
    for name,value,limit in [('wing incidence',aw,c['wing_alpha_limit_deg']),
            ('tail local incidence',at,c['tail_alpha_limit_deg']),('wing CL',clw,c['wing_cl_limit']),
            ('tail CL',clt,c['tail_cl_limit']),('ruddervator travel',delta,c.get('ruddervator_limit_deg',10.))]:
        if abs(value)>limit+1e-10:violations.append(f'{name}: {value:.6g} exceeds assumed +/-{limit:.6g}')
    for name,re in [('wing',reynolds_w),('tail',reynolds_t)]:
        if not c['reynolds_min']<=re<=c['reynolds_max']:violations.append(f'{name} Reynolds number {re:.6g} outside assumed domain')
    if thrust<0 or thrust>c['max_thrust_lbf']+1e-10:violations.append('Thrust outside assumed available range')
    return dict(alpha_deg=alpha,ruddervator_deg=delta,thrust_lbf=thrust,
        density_slug_ft3=rho,density_source='User override' if c['density_override_slug_ft3'] is not None else 'NASA historical altitude curve fit',
        speed_ft_s=c['speed_ft_s'],speed_knots=c['speed_ft_s']/KNOT_FT_S,dynamic_pressure_psi=q,
        wing_dynamic_pressure_psi=qw,tail_dynamic_pressure_psi=qt,
        wing_flow_alpha_deg=alpha_w,tail_flow_alpha_deg=alpha_t,
        wing_area_in2=sw,tail_panel_area_in2=st,wing_aspect_ratio=arw,tail_panel_aspect_ratio=art,
        wing_reynolds=reynolds_w,tail_reynolds=reynolds_t,wing_cl=clw,tail_panel_cl=clt,
        wing_cd=cdw,tail_panel_cd=cdt,wing_incidence_deg=aw,tail_local_incidence_deg=at,
        wing_lift_lbf=lw,tail_vertical_wind_lift_lbf=lt,total_drag_lbf=dw+dt,
        ledger=ledger,non_gravity_force_B_lbf=total_f.tolist(),moment_about_CG_B_in_lbf=total_m.tolist(),
        domain_violations=violations,within_assumed_domain=not violations)


def _residual(field,weight,n):
    a=math.radians(field['alpha_deg'])
    gravity=weight*np.array([-math.sin(a),0,math.cos(a)])
    # Inertial UP maps to [+sin(theta),0,-cos(theta)] in body coordinates.
    ma=-(n-1)*gravity
    field['gravity_force_B_lbf']=gravity.tolist()
    field['mass_times_acceleration_B_lbf']=ma.tolist()
    field['external_force_B_lbf']=(np.array(field['non_gravity_force_B_lbf'])+gravity).tolist()
    effective_gravity=gravity-ma
    return np.array(field['non_gravity_force_B_lbf'])+effective_gravity,np.array(field['moment_about_CG_B_in_lbf'])


def evaluate_condition(d,workspace):
    """Compare one input condition, then find required longitudinal balance."""
    c=validate_condition(d['flight_condition']);mp=workspace['mass_properties']
    base=dict(status='incomplete-mass',coefficient_source=c['coefficient_source'],sources=SOURCES,
        validation='Unvalidated estimated model; numerical trim is not aircraft or design acceptance',
        input=deepcopy(c),predicted=None,required=None,trim=None)
    if mp is None:return base
    if abs(mp['cg_B_in'][1])>1e-8 or any(abs(d['geometry'][k])>1e-8 for k in ['wing_load_y_in','tail_load_y_in']):
        base['status']='unsupported-asymmetry';return base
    weight=mp['weight_lbf'];n=workspace['load_case']['load_factor']
    predicted=_field(d,mp,c,c['alpha_deg'],c['ruddervator_deg'],c['thrust_lbf'])
    f,m=_residual(predicted,weight,n)
    predicted.update(force_residual_B_lbf=f.tolist(),moment_residual_B_in_lbf=m.tolist())
    base.update(status='estimated-condition',predicted=predicted)
    # Required lift/thrust at this alpha, holding the predicted drag/free couple
    # fixed. This is a linear equilibrium comparison, not another aero prediction.
    a=math.radians(c['alpha_deg']);lift=np.array([math.sin(a),0,-math.cos(a)])
    positions=[np.array(x['position_B_in'])-mp['cg_B_in'] for x in predicted['ledger']]
    columns=[]
    for pos,unit in zip(positions,[lift,lift,np.array([1.,0,0])]):
        columns.append([unit[0],unit[2],np.cross(pos,unit)[1]])
    matrix=np.array(columns).T
    actual=np.array([predicted['wing_lift_lbf'],predicted['tail_vertical_wind_lift_lbf'],c['thrust_lbf']])
    if np.linalg.cond(matrix)<1e10:
        required=actual-np.linalg.solve(matrix,[f[0],f[2],m[1]])
        base['required']=dict(wing_lift_lbf=float(required[0]),tail_vertical_wind_lift_lbf=float(required[1]),
            thrust_lbf=float(required[2]),note='At input alpha with predicted drag and wing free couple held fixed; pure vertical inertial acceleration, theta=alpha and horizontal flight path')
    # Search required balance independently of available travel. Numerical search
    # guards (+/-20 alpha, +/-45 deflection) are not aircraft capability. Report
    # convergence separately from travel/aerodynamic validity; never extrapolate
    # a failed search into a claimed required deflection.
    x=np.array([c['alpha_deg'],c['ruddervator_deg']],dtype=float)
    scale=np.array([weight,weight*d['geometry']['wing_chord_in']])
    def trial(x):
        field=_field(d,mp,c,float(x[0]),float(x[1]),0.)
        thrust=field['total_drag_lbf']/math.cos(math.radians(x[0]))
        field=_field(d,mp,c,float(x[0]),float(x[1]),thrust)
        f,m=_residual(field,weight,n)
        return np.array([f[2],m[1]])/scale,field,f,m
    for iteration in range(40):
        res,field,f,m=trial(x)
        if np.linalg.norm(res)<1e-10:break
        step=1e-4
        jac=np.column_stack([(trial(x+np.eye(2)[i]*step)[0]-res)/step for i in range(2)])
        try:dx=np.linalg.solve(jac,-res)
        except np.linalg.LinAlgError:break
        moved=False
        for factor in [1,.5,.25,.125,.0625,.03125]:
            candidate=np.clip(x+factor*dx,[-20,-45],[20,45])
            if np.linalg.norm(trial(candidate)[0])<np.linalg.norm(res)-1e-14:
                x=candidate;moved=True;break
        if not moved:break
    res,field,f,m=trial(x)
    converged=bool(np.max(np.abs(f))<1e-6 and np.max(np.abs(m))<1e-5)
    feasible=converged and field['within_assumed_domain']
    base['trim']=dict(status='balanced-within-assumed-model' if feasible else 'balance-outside-assumed-limits' if converged else 'no-feasible-trim-found',
        feasible=feasible,converged=converged,iterations=iteration+1,
        alpha_deg=float(x[0]),ruddervator_deg=float(x[1]),thrust_lbf=field['thrust_lbf'],
        control_at_limit=bool(abs(x[1])>=c['ruddervator_limit_deg']-1e-6),
        available_ruddervator_deg=c['ruddervator_limit_deg'],
        within_control_travel=bool(abs(x[1])<=c['ruddervator_limit_deg']+1e-10),
        required_ruddervator_deg=float(x[1]) if converged else None,
        search_bounds_deg=dict(alpha=[-20,20],ruddervator=[-45,45]),
        force_residual_B_lbf=f.tolist(),moment_residual_B_in_lbf=m.tolist(),
        domain_violations=field['domain_violations'],predicted=field)
    work={**workspace,'flight_condition':base}
    base['static_stability']={
        'trial':static_stability_diagnostic(d,work,trial_alpha_deg=c['alpha_deg'],
            trial_delta_deg=c['ruddervator_deg'],trial_thrust_lbf=c['thrust_lbf']),
        'trim':static_stability_diagnostic(d,work)}
    return base


def static_stability_diagnostic(d, workspace, *, trial_alpha_deg=None,
                                trial_delta_deg=None, trial_thrust_lbf=None):
    """Local controls-fixed derivative at an explicit trial or feasible trim.

    s=-x increases aft; My is positive nose-up, Fz positive down. Holding CG
    height fixed, moving the moment reference aft by ds changes M_alpha by
    -ds*Z_alpha. Thus s_np=s_cg+M_alpha/Z_alpha. This does not move any mass.
    Derivatives use degrees; all other inputs remain fixed, angular rate zero.
    """
    unavailable=lambda status, **extra: dict(status=status, classification=None,
        neutral_point_station_in=None, static_margin_percent=None,
        static_margin_dimensionless=None, **extra)
    mp=workspace['mass_properties'];g=d['geometry'];c=d.get('flight_condition')
    if mp is None:return unavailable('incomplete-mass')
    if c is None:return unavailable('missing-flight-condition')
    if abs(mp['cg_B_in'][1])>1e-8 or any(abs(g[k])>1e-8 for k in ('wing_load_y_in','tail_load_y_in')):
        return unavailable('unsupported-asymmetry')
    trim=(workspace.get('flight_condition') or {}).get('trim') or {}
    values=(trial_alpha_deg,trial_delta_deg,trial_thrust_lbf)
    if all(v is None for v in values):
        if not trim.get('feasible'):return unavailable('trim-infeasible')
        values=tuple(trim[k] for k in ('alpha_deg','ruddervator_deg','thrust_lbf'))
        basis='feasible-trim'
    elif any(v is None for v in values):return unavailable('incomplete-trial-state')
    else:basis='trial-input'
    if any(not math.isfinite(v) for v in values):return unavailable('nonfinite')
    alpha,delta,thrust=values
    base=dict(basis=basis,alpha_deg=alpha,ruddervator_deg=delta,thrust_lbf=thrust,
        speed_ft_s=c['speed_ft_s'],angular_velocity_B_rad_s=[0.,0.,0.])
    info=dict(base_state=base,cg_station_in=-mp['cg_B_in'][0],
        cg_z_in=mp['cg_B_in'][2],wing_le_station_in=g['wing_le_station_in'],
        wing_chord_in=g['wing_chord_in'],near_neutral_margin=0.001,
        note='Local estimated controls-fixed longitudinal static tendency only; not dynamic stability, measured aircraft validation or an operational CG limit. My is whole-aircraft moment about CG, not section-cut My.')
    def sample(a):
        f=_field(d,mp,c,a,delta,thrust)
        if not f['within_assumed_domain']:raise ValueError('; '.join(f['domain_violations']))
        pair=np.array([f['moment_about_CG_B_in_lbf'][1],f['non_gravity_force_B_lbf'][2]])
        if not np.isfinite(pair).all():raise ValueError('Nonfinite force or moment')
        return pair
    try:
        sample(alpha)
        slopes=[(sample(alpha+h)-sample(alpha-h))/(2*h) for h in (0.001,0.0005)]
    except ValueError as error:return unavailable('invalid-stencil',reason=str(error),**info)
    if not np.isfinite(slopes).all():return unavailable('nonfinite',**info)
    difference=np.abs(slopes[0]-slopes[1])
    tolerance=1e-8+1e-6*np.maximum(np.abs(slopes[0]),np.abs(slopes[1]))
    convergence=dict(steps_deg=[0.001,0.0005],M_alpha_per_deg=[float(s[0]) for s in slopes],
        Z_alpha_per_deg=[float(s[1]) for s in slopes],difference=difference.tolist(),
        allowed_difference=tolerance.tolist(),passed=bool(np.all(difference<=tolerance)))
    info['convergence_check']=convergence
    if not convergence['passed']:return unavailable('step-sensitive',**info)
    M,Z=map(float,slopes[1])
    info.update(M_alpha=M,Z_alpha=Z,derivative_units=['in-lbf/deg','lbf/deg'])
    if abs(Z)<1e-8:return unavailable('ill-conditioned',**info)
    # Conventional margin classification requires increasing upward force with alpha.
    if Z>=0:return unavailable('unsupported-force-slope',**info)
    np_station=info['cg_station_in']+M/Z
    margin=(np_station-info['cg_station_in'])/g['wing_chord_in']
    tendency='neutral' if abs(margin)<=0.001 else 'stable' if M<0 else 'unstable'
    return dict(status='valid',classification=tendency,neutral_point_station_in=np_station,
        static_margin_dimensionless=margin,static_margin_percent=100*margin,**info)
