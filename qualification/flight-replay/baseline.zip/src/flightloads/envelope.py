"""Concurrent case reduction and independently calibrated, conditional event coverage."""
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import numpy as np
from .benchmark import plain
from .equivalent_static import (extract_cases, reference_responses, reference_interaction,
                               validate_history)
from .uncertainty import (SamplingSpec, make_basis, run_ensemble, integer, probability,
                          order_confidences, checked_basis)

MANDATORY = ((1.5, .5, 1.), (.5, 1.5, 1.))
SCHEMA = 'concurrent-envelope-v1'


def canonical(value):
    return json.dumps(plain(value), sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def fingerprint(value):
    return hashlib.sha256(canonical(value)).hexdigest()


@dataclass(frozen=True)
class EnvelopeSpec:
    training_count: int = 512
    calibration_count: int = 256
    training_seed: int = 20260907
    calibration_seed: int = 20260908
    coverage: float = .95
    confidence: float = .95

    def __post_init__(self):
        for name in ('training_count', 'calibration_count'):
            object.__setattr__(self, name, integer(getattr(self, name), name, 1, 1024))
        for name in ('training_seed', 'calibration_seed'):
            object.__setattr__(self, name, integer(getattr(self, name), name, 0, 2**64-1))
        if self.training_seed == self.calibration_seed:
            raise ValueError('training and calibration require distinct random sequences')
        for name in ('coverage', 'confidence'):
            object.__setattr__(self, name, probability(getattr(self, name), name))

    def metadata(self):
        return dict(asdict(self), training_seed=str(self.training_seed), calibration_seed=str(self.calibration_seed))


def binomial_upper(k, n, alpha):
    """One-sided exact upper probability bound; invert CDF(k;n,q)=alpha."""
    n = integer(n, 'n', 1, 10000); k = integer(k, 'k', 0, n); alpha = probability(alpha, 'alpha')
    if k == n: return 1.
    if k == 0: return -math.expm1(math.log(alpha)/n)
    lo, hi = 0., 1.
    for _ in range(80):
        mid = (lo+hi)/2
        if mid in (lo, hi): break
        if order_confidences(n, mid)[k] > alpha: lo = mid
        else: hi = mid
    return hi


def response_histories(history):
    root = np.column_stack([history.arrays['root_reaction_z_N'], history.arrays['root_reaction_y_Nm']])
    values = {r.name:r.values(history.model, history.arrays['displacement_free'], root)
              for r in reference_responses(history.model)}
    values[reference_interaction().name] = reference_interaction().values(values)
    return values


def extrema(history, source_id):
    result = {}
    for name, values in response_histories(history).items():
        signs = ('max',) if name == reference_interaction().name else ('min', 'max')
        result[name] = {}
        for sign in signs:
            i = int(np.argmin(values) if sign == 'min' else np.argmax(values))
            result[name][sign] = dict(value=float(values[i]), source_id=source_id, index=i,
                                       time_s=float(history.times_s[i]))
    return result


def combine_bounds(events):
    bounds = {}
    for event in events:
        for name, signs in event.get('extrema', {}).items():
            for sign, point in signs.items():
                old = bounds.setdefault(name, {}).get(sign)
                if old is None or (point['value'] < old['value'] if sign == 'min' else point['value'] > old['value']):
                    bounds[name][sign] = dict(point)
    return bounds


def outside(extremes, bounds):
    if not bounds: return True
    return any(point['value'] < bounds[name][sign]['value'] if sign == 'min'
               else point['value'] > bounds[name][sign]['value']
               for name, signs in extremes.items() for sign, point in signs.items())


class EnvelopeStudy:
    """Computed evidence; snapshots are copies. All selected cases replay their source."""
    def __init__(self, spec, pairs):
        if not isinstance(spec, EnvelopeSpec): raise ValueError('expected EnvelopeSpec')
        pairs = tuple(pairs)
        if not 1 <= len(pairs) <= 3: raise ValueError('one to three unweighted alternatives required')
        self.spec, self.pairs = spec, pairs
        self._sources, self._cases = {}, {}
        models = [self._reduce(i, *pair) for i, pair in enumerate(pairs)]
        if len({m['model_id'] for m in models}) != len(models): raise ValueError('duplicate model alternative')
        complete = all(m['population_complete'] for m in models)
        verified = complete and all(m['coverage']['finite_ensemble_covered'] and m['coverage']['final_contains_training'] and m['static_verified'] for m in models)
        qualified = verified and all(m['qualification']['qualified'] for m in models)
        self._summary = plain(dict(schema=SCHEMA, specification=spec.metadata(), models=models,
            status=dict(run_completion='completed', numerical_verification='passed' if verified else 'failed',
                statistical_qualification='qualified' if qualified else 'unqualified',
                model_validation='not_performed', design_acceptance='not_performed'),
            scope='Joint declared responses over saved event times, conditional on each unweighted synthetic model. Not physical validation, capacity, or failure probability.',
            confidence_method='Independent calibration against frozen training bounds; exact one-sided binomial upper violation probability; Bonferroni across models. Final expansion inherits original bound.',
            invalidation='Regenerate after changing model, forcing, sampling, time grid, modes, response definitions, interaction, or selection/qualification procedure.',
            marginal_counterexample=dict(vectors=[[1,0],[0,1],[.8,.8]],marginal_selected_Q=1.,actual_Q_max=1.28,fictitious_componentwise_Q=2.)))
        self._summary['study_id'] = fingerprint(self._summary)

    def _reduce(self, number, training, calibration):
        spec = self.spec; basis = training.basis; prefix = f'm{number}'
        verified_basis = checked_basis(basis.histories)
        if verified_basis.basis_id != basis.basis_id or verified_basis.digests != basis.digests:
            raise ValueError('training basis identity mismatch')
        cb = checked_basis(calibration.basis.histories)
        if cb.basis_id != basis.basis_id or cb.basis_id != calibration.basis.basis_id:
            raise ValueError('calibration basis differs from frozen training model')
        if canonical(training.sampling.metadata()) != canonical(calibration.sampling.metadata()):
            raise ValueError('calibration population differs from training')
        events = []
        for kind, ensemble, count, seed in (('training', training, spec.training_count, spec.training_seed),
                                           ('calibration', calibration, spec.calibration_count, spec.calibration_seed)):
            if len(ensemble.trials) != count or ensemble.master_seed != seed:
                raise ValueError('requested population count or seed mismatch')
            for index, trial in enumerate(ensemble.trials):
                if trial.index != index or trial.status not in ('completed', 'failed', 'invalid'):
                    raise ValueError('missing, reordered, or invalid trial record')
                source_id = f'{prefix}-{kind}-{index:04d}'
                event = dict(source_id=source_id, kind=kind, trial=trial.metadata(), master_seed=str(seed))
                if trial.status == 'completed':
                    history = ensemble.replay(index)
                    event['extrema'] = extrema(history, source_id)
                    self._sources[source_id] = (ensemble, index, None)
                events.append(event)
        for index, amp in enumerate(MANDATORY):
            source_id = f'{prefix}-mandatory-{index:04d}'; history = basis.reconstruct(amp)
            digest = validate_history(history)
            events.append(dict(source_id=source_id, kind='mandatory', amplitudes=list(amp), history_digest=digest,
                               extrema=extrema(history, source_id), provenance='illustrative deterministic case, not a random sample'))
            self._sources[source_id] = (training, None, amp)
        train_events = [e for e in events if e['kind'] == 'training']
        calibration_events = [e for e in events if e['kind'] == 'calibration']
        complete = training.complete and calibration.complete
        frozen = combine_bounds(train_events); final = combine_bounds(events)
        violations = [e['source_id'] for e in calibration_events if 'extrema' not in e or outside(e['extrema'], frozen)]
        alpha = (1-spec.confidence)/len(self.pairs)
        lower = 1-binomial_upper(len(violations), spec.calibration_count, alpha) if complete else None
        qualification = dict(calibration_events=spec.calibration_count, violating_source_ids=violations,
            violations=len(violations), alpha=alpha, per_model_confidence=1-alpha,
            familywise_confidence_at_least=spec.confidence, target_coverage=spec.coverage,
            coverage_lower=lower, qualified=lower is not None and lower >= spec.coverage,
            denominator_excludes_mandatory=True, evaluated_against='training_bounds')
        selected = {}
        def retain(bounds, scope):
            for name, signs in bounds.items():
                for sign, p in signs.items():
                    selected.setdefault((p['source_id'], p['index']), []).append(f'{scope}:{name}:{sign}')
        retain(frozen, 'training'); retain(final, 'final')
        for e in events:
            if e['kind'] == 'mandatory': retain(e['extrema'], 'mandatory')
        case_records = []; extracted = {}
        for (source_id, index), reasons in sorted(selected.items()):
            if source_id not in extracted:
                h = self.source(source_id)
                extracted[source_id] = {c.index:c for c in extract_cases(h, run_id=source_id,
                    interactions=(reference_interaction(),)).cases}
            case = extracted[source_id][index]; case_id = f'{source_id}-t{index:05d}'
            self._cases[case_id] = case
            record = self._case_record(case_id, case, reasons)
            case_records.append(record)
        # Static values independently replay all final support cases within field tolerances.
        static_verified = bool(case_records) and all(c['verified'] for c in case_records)
        covered = all('extrema' in e and not outside(e['extrema'], final) for e in events)
        contains = bool(frozen) and not outside(frozen, final)
        defs = [dict(asdict(r), unit=r.unit) for r in reference_responses(basis.model)]
        return dict(model_key=prefix, model=dict(basis.model.config), model_id=basis.model.model_id,
            basis_id=basis.basis_id, responses=defs, interaction=asdict(reference_interaction()),
            population_complete=complete, events=events, training_bounds=frozen, final_bounds=final,
            qualification=qualification, coverage=dict(finite_ensemble_covered=covered,
                final_contains_training=contains, requested_random_events=spec.training_count+spec.calibration_count,
                mandatory_events=len(MANDATORY), saved_time_samples=len(basis.histories[0].times_s)),
            static_verified=static_verified, cases=case_records)

    def source(self, source_id):
        ensemble, index, amp = self._sources[source_id]
        return ensemble.replay(index) if amp is None else ensemble.basis.reconstruct(amp)

    def _case_record(self, case_id, case, reasons):
        h = self.source(case.run_id); model = h.model
        definitions = reference_responses(model)
        source = {name:float(values[case.index]) for name,values in response_histories(h).items()}
        static = {r.name:float(r.values(model, case.static_displacement, case.static_root_reaction)) for r in definitions}
        static[reference_interaction().name] = float(reference_interaction().values(static))
        return plain(dict(case_id=case_id, source_id=case.run_id, source_digest=case.source_digest,
            model_id=case.model_id, index=case.index, time_s=case.time_s, reasons=reasons,
            components=case.components, source_displacement=case.source_displacement,
            static_displacement=case.static_displacement, source_root_reaction=case.source_root_reaction,
            static_root_reaction=case.static_root_reaction, source_responses=source, static_responses=static,
            checks=case.checks, verified=case.verified, nodes_m=model.nodes_m,
            source_stress_Pa=model.recover(case.source_displacement, model.nodes_m)['stress_positive_z_Pa'],
            static_stress_Pa=model.recover(case.static_displacement, model.nodes_m)['stress_positive_z_Pa']))

    def snapshot(self):
        return json.loads(canonical(self._summary))

    def case_detail(self, case_id):
        case = self._cases[case_id]; h = self.source(case.run_id)
        if validate_history(h) != case.source_digest: raise ValueError('case source identity changed')
        record = next(c for m in self._summary['models'] for c in m['cases'] if c['case_id'] == case_id)
        event = next(e for m in self._summary['models'] for e in m['events'] if e['source_id'] == case.run_id)
        return plain(dict(case=record, event=event, times_s=h.times_s, histories=response_histories(h)))


def reference_envelope(spec=None, *, progress=None):
    spec = EnvelopeSpec() if spec is None else spec
    sampling = SamplingSpec(correlation=((1.,.4,0.),(.4,1.,0.),(0.,0.,1.)))
    pairs = []
    for z in (.01, .02, .04):
        if progress: progress(f'Integrating basis and sampling damping {z:g}')
        basis = make_basis(damping_ratio=z)
        pairs.append((run_ensemble(basis, sampling, count=spec.training_count, master_seed=spec.training_seed),
                      run_ensemble(basis, sampling, count=spec.calibration_count, master_seed=spec.calibration_seed)))
    if progress: progress('Replaying populations, reducing cases, and calibrating coverage')
    return EnvelopeStudy(spec, pairs)
