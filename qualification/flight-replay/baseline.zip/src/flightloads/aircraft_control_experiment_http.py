"""Exact local learning-study routes; dashboard owns host/origin enforcement."""
import re
from .aircraft_controller_http import UUID,_exact
from .aircraft_controller_store import _decode,_id,MAX_INPUT
from .aircraft_control_experiments import plan,VARIABLES

PREFIX='/api/aircraft/control-experiments'

class ExperimentAPI:
    def __init__(self,catalog,controllers,downloads):self.catalog=catalog;self.controllers=controllers;self.downloads=downloads

    def source(self,spec):
        if type(spec) is not dict:raise ValueError('Study specification required')
        identifier=spec.get('reference_id');_id(identifier);row=self.controllers.snapshot(identifier)
        if row['kind'] not in ('configuration','run') or row['active']:raise ValueError('Choose an inactive saved configuration or run reference')
        return self.controllers.artifact(identifier,'inputs.json')

    def get(self,handler,path):
        try:
            if path==PREFIX:
                handler.reply(200,self.catalog.listing());return
            if path==PREFIX+'/metadata':
                from .aircraft_control_experiment_metrics import METRICS
                handler.reply(200,dict(variables=VARIABLES,metrics=METRICS,limits=self.catalog.listing()['limits']));return
            match=re.fullmatch(PREFIX+'/('+UUID+')(?:/(reference|plan)|/points/([0-7])/(inputs|report))?',path)
            if not match:handler.reply(404,{'error':'Unknown study route'});return
            identifier,action,index,name=match.groups()
            if index is not None:
                if not self.downloads.acquire(blocking=False):raise RuntimeError('Two report downloads active; retry after one finishes')
                try:handler.reply(200,self.catalog.download(identifier,int(index),name+'.json'),'application/json','study-'+identifier+'-'+index+'-'+name+'.json',stream=True)
                finally:self.downloads.release()
            elif action=='reference':handler.reply(200,self.catalog.reference(identifier))
            elif action=='plan':handler.reply(200,self.catalog.snapshot(identifier)['plan'],'application/json','study-'+identifier+'-plan.json')
            else:handler.reply(200,self.catalog.snapshot(identifier))
        except (KeyError,FileNotFoundError):handler.reply(404,{'error':'Study or reference not found'})
        except (ValueError,RuntimeError,TypeError) as e:handler.reply(409,{'error':str(e)})
        except OSError:handler.reply(500,{'error':'Study storage could not be read'})

    def post(self,handler,path):
        match=re.fullmatch(PREFIX+'/('+UUID+')/(cancel|delete)',path)
        if path not in (PREFIX,PREFIX+'/preview') and not match:handler.reply(404,{'error':'Unknown study route'});return
        if handler.headers.get('Content-Type','').split(';')[0].strip()!='application/json':handler.reply(415,{'error':'application/json required'});return
        try:
            lengths=handler.headers.get_all('Content-Length',[])
            if len(lengths)!=1 or not re.fullmatch('[0-9]+',lengths[0]) or handler.headers.get('Transfer-Encoding'):raise ValueError('One bounded Content-Length required')
            length=int(lengths[0])
            if not 0<length<=MAX_INPUT:handler.reply(413,{'error':'Study request exceeds input budget'});return
            raw=handler.rfile.read(length)
            if len(raw)!=length:raise ValueError('Incomplete request body')
            body=_decode(raw)
            if path==PREFIX+'/preview':
                reference=self.source(body);handler.reply(200,plan(reference,body))
            elif path==PREFIX:
                _exact(body,('spec','plan_sha256'));reference=self.source(body['spec']);handler.reply(202,self.catalog.start(reference,body['spec'],body['plan_sha256']))
            else:
                identifier,action=match.groups();_exact(body,('confirmation',) if action=='delete' else ())
                handler.reply(200 if action=='delete' else 202,self.catalog.delete(identifier,body['confirmation']) if action=='delete' else self.catalog.cancel(identifier))
        except (KeyError,FileNotFoundError):handler.reply(404,{'error':'Study or saved reference unavailable'})
        except (ValueError,TypeError,UnicodeError,OverflowError,RecursionError) as e:handler.reply(400,{'error':str(e)})
        except RuntimeError as e:handler.reply(409,{'error':str(e)})
        except OSError:handler.reply(500,{'error':'Study storage operation failed; refresh before retrying'})
