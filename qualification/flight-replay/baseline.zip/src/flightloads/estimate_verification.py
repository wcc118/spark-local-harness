"""Frozen section and aircraft assembly checks shared by CLI and tests."""
import math
import numpy as np
from .aero_dataset import AeroQuery
from .aero_estimate_provider import XfoilAvlEstimate
from .aircraft_workspace import evaluate_aircraft
from .avl_model import run_avl


def verify_estimate_snapshot(snapshot):
    model = XfoilAvlEstimate(snapshot)
    e, g = snapshot['environment'], model.g
    cg = evaluate_aircraft(snapshot['definition'])['mass_properties']['cg_B_in']
    checks = []
    for kind, records in model.sections.items():
        for re, section in records:
            error = max(abs(model.section(kind, re, a)[k]-values[i])
                        for a, values in zip(section.alpha, section.values)
                        for i, k in enumerate(('CL', 'CD', 'CM')))
            jump = max(abs(section.evaluate(a-d)[k]-section.evaluate(a+d)[k])
                       for a in (section.alpha[0], section.alpha[-1]) for k in ('CL', 'CD') for d in (1e-8,))
            endpoints = all(section.evaluate(a)['CL'] == 0 for a in (-180, 180))
            drag_error = abs(section.evaluate(90)['CD']-section.cdmax)
            checks.append(dict(kind=kind, reynolds=re, attached_error=error, match_jump=jump,
                               drag90_error=drag_error, zero_endpoint_lift=endpoints,
                               passed=bool(error <= 1e-9 and jump <= 1e-6 and endpoints and drag_error <= 1e-12)))

    def coefficients(alpha, speed, controls=(0., 0., 0.)):
        a = math.radians(alpha)
        result = model.evaluate(AeroQuery((speed*math.cos(a), 0., speed*math.sin(a)), (0., 0., 0.), cg,
            dict(zip(('left_tail_deg', 'right_tail_deg', 'aileron_deg'), controls)),
            e['density_slug_ft3'], e['sound_speed_ft_s'], e['viscosity_slug_ft_s']))
        if not result.in_coverage:
            raise ValueError('verification query outside coverage: '+str(result.coverage_violations))
        qS = .5*e['density_slug_ft3']*speed**2*g['wing_exposed_span_in']*g['wing_chord_in']/144
        return np.array([(result.force_B_lbf[0]*math.sin(a)-result.force_B_lbf[2]*math.cos(a))/qS,
                         result.moment_B_in_lbf[1]/(qS*g['wing_chord_in']),
                         result.moment_B_in_lbf[0]/(qS*g['wing_exposed_span_in'])])

    modes = []
    for step in (1., 2., 4.):
        avl = run_avl(snapshot['definition'], [[a, 0, 0, 0, 0, 0, 0, 0, 0] for a in (-step, step)])
        expected = np.array([(avl.total_forces[1][k]-avl.total_forces[0][k])/math.radians(2*step) for k in ('CL', 'Cm')])
        for speed in (100., 150., 200.):
            actual = (coefficients(step, speed)-coefficients(-step, speed))[:2]/math.radians(2*step)
            error = np.abs(actual/expected-1)
            modes.append(dict(speed_ft_s=speed, step_deg=step, actual_slopes_per_rad=actual.tolist(),
                avl_slopes_per_rad=expected.tolist(), relative_errors=error.tolist(), avl_input_sha256=avl.input_sha256,
                passed=bool(error[0] <= .10 and error[1] <= .20 and actual[1]*expected[1] > 0)))
    controls = []
    for index, name in enumerate(('left_tail', 'right_tail', 'aileron')):
        cases, perturbations = [], []
        for sign in (-1., 1.):
            control = np.eye(3)[index]*sign
            cases.append([0, 0, 0, 0, 0, *control.tolist(), 0])
            perturbations.append(coefficients(0., 150., control))
        avl = run_avl(snapshot['definition'], cases)
        component, output = ('Cl', 2) if name == 'aileron' else ('Cm', 1)
        expected = (avl.total_forces[1][component]-avl.total_forces[0][component])/2
        actual = (perturbations[1][output]-perturbations[0][output])/2
        controls.append(dict(control=name, coefficient=component, actual_per_deg=float(actual), avl_per_deg=expected,
                             avl_input_sha256=avl.input_sha256, passed=bool(actual*expected > 0)))
    # This is deliberately a comparison of different angle meanings, not an agreement gate.
    avl = run_avl(snapshot['definition'], [[4, 0, 0, 0, 0, 0, 0, 0, 0]])
    total = avl.total_forces[0]
    ar = g['wing_exposed_span_in']/g['wing_chord_in']
    re = e['density_slug_ft3']*150*g['wing_chord_in']/12/e['viscosity_slug_ft_s']
    corrections, areas = [], []
    for i, row in enumerate(model.rows):
        if row['name'].startswith('Wing'):
            cl = row['cl_normal']+model.jac[i, 0]*4
            corrections.append(math.radians(4-model.attached_angle('wing', re, cl)))
            areas.append(row['area_ft2'])
    handcheck = dict(alpha_deg=4., speed_ft_s=150., equivalent_wing_angle_correction_rad=float(np.average(corrections, weights=areas)),
                    idealized_aircraft_reference_angle_rad=total['CL']/(math.pi*ar*total['e']),
                    scope='Equivalent wing correction includes viscous/camber correspondence; CL/(pi AR e) uses aircraft references. Neither is measured wing-only downwash; equality is not asserted.')
    return dict(schema='xfoil-avl-verification-v1', snapshot_sha256=model.identity['digest'],
                sections=checks, aircraft_slopes=modes, control_signs=controls, handcheck=handcheck,
                tolerances=dict(attached=1e-9, match_jump=1e-6, lift_slope=.10, pitch_slope=.20),
                passed=all(row['passed'] for row in checks+modes+controls), evidence_level='estimate',
                note='Numerical assembly verification against its AVL loading anchor, not independent physical validation or design acceptance.')
