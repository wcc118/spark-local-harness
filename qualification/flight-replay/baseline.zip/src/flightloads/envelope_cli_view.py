"""Terminal review of computed envelope evidence; no inference from display values."""


def format_summary(snapshot):
    spec = snapshot['specification']
    lines = [f'{name}: {value}' for name,value in snapshot['status'].items()]
    lines += [f"coverage target: {spec['coverage']}; familywise confidence: {spec['confidence']}",
              f"training count: {spec['training_count']}; calibration count: {spec['calibration_count']}"]
    for model in snapshot['models']:
        q, c = model['qualification'], model['coverage']
        lower = 'unavailable' if q['coverage_lower'] is None else f"{q['coverage_lower']:.10g}"
        lines += ['', f"=== Model {model['model_key']} ===", f"damping_ratio: {model['model']['damping_ratio']}",
            f"actual retained cases: {len(model['cases'])}",
            f"training events: {spec['training_count']}; calibration events: {q['calibration_events']}; mandatory events: {c['mandatory_events']}",
            f"original calibration violations: {q['violations']}/{q['calibration_events']} (mandatory excluded)",
            f"evaluated against: {q['evaluated_against']}",
            f"coverage lower bound: {lower}; target coverage: {q['target_coverage']}",
            f"model qualification: {'qualified' if q['qualified'] else 'unqualified'}",
            f"per-model confidence: {q['per_model_confidence']:.10g}; familywise confidence at least: {q['familywise_confidence_at_least']}",
            f"finite-ensemble verified: {c['finite_ensemble_covered']}; final contains training: {c['final_contains_training']}",
            f"static replay verified: {model['static_verified']}; population complete: {model['population_complete']}"]
    lines += ['', 'Confidence is conditional on each unweighted model; mandatory events are not probability samples.',
              'Final expansion retains the original frozen-training calibration count.',
              'Archive artifacts: study.json, basis.npz, cases.csv, manifest.json',
              'Dashboard review: python -m flightloads.dashboard --results RESULTS --envelope ENVELOPE']
    return '\n'.join(lines)
