"""Fixed-step RK4 with raw stage quaternions and accepted-state normalization."""

from dataclasses import dataclass
import numbers
import numpy as np
from ._arrays import readonly_copy
from .dynamics import rigid_derivative
from .state import RigidState


@dataclass(frozen=True)
class SimulationResult:
    times_s: np.ndarray
    states: np.ndarray
    initial_quaternion_norm: float
    initial_was_normalized: bool
    requested_dt_s: float

    def __post_init__(self):
        times, states = np.asarray(self.times_s), np.asarray(self.states)
        if (times.ndim != 1 or len(times) == 0 or states.shape != (len(times), 13)
                or not np.all(np.isfinite(times)) or not np.all(np.isfinite(states))
                or np.any(np.diff(times) <= 0)):
            raise ValueError('result requires finite ordered times and matching states')
        for row in states:
            if not np.isclose(np.linalg.norm(row[6:10]), 1, rtol=0, atol=1e-12):
                raise ValueError('saved quaternion must have unit norm')
        if (not np.isfinite(self.initial_quaternion_norm) or self.initial_quaternion_norm <= 1e-12
                or not np.isfinite(self.requested_dt_s) or self.requested_dt_s <= 0):
            raise ValueError('invalid initialization norm or requested dt')
        object.__setattr__(self, 'times_s', readonly_copy(times))
        object.__setattr__(self, 'states', readonly_copy(states))

    def state_at(self, index):
        return RigidState.from_vector(self.states[index])


def integrate(initial_state, mass_model, t_final, dt, load_provider,
              gravity_provider, *, t0=0, context=None, max_steps=1000000):
    """Providers are evaluated at all four stages, including duplicate times.

    Providers must be deterministic and cannot mutate state or position inputs.
    dt is nominal; the last step may be shorter. All times are float64 seconds.
    """
    t0, t_final, dt = float(t0), float(t_final), float(dt)
    if not all(np.isfinite(x) for x in (t0, t_final, dt)) or dt <= 0 or t_final < t0:
        raise ValueError('finite times, positive dt and t_final >= t0 required')
    if isinstance(max_steps, bool) or not isinstance(max_steps, numbers.Integral) or max_steps < 1:
        raise ValueError('max_steps must be a positive integer')
    if not callable(load_provider) or not callable(gravity_provider):
        raise TypeError('both providers must be callable')
    mass_model.require_rigid_inertia()
    y = RigidState.from_vector(initial_state.to_vector()).to_vector()
    times, states = [t0], [y]

    def rhs(t, vector):
        state = RigidState.from_vector(vector, normalize_quaternion=False)
        return rigid_derivative(state, mass_model, load_provider(t, state, context),
                                gravity_provider(t, state.r_CG_N_m, context)).to_vector()

    t, step = t0, 0
    while t < t_final:
        if step >= max_steps:
            raise ValueError('max_steps exceeded')
        # Anchoring to t0 avoids accumulated time drift and spurious final steps.
        target = min(t0 + (step + 1)*dt, t_final)
        h = target - t
        mid = t + h/2
        if not np.isfinite(h) or h <= 0 or not t < mid < target:
            raise ValueError('time step cannot advance RK stages in float64')
        k1 = rhs(t, y)
        k2 = rhs(mid, y + h/2*k1)
        k3 = rhs(mid, y + h/2*k2)
        k4 = rhs(target, y + h*k3)
        y = RigidState.from_vector(y + h/6*(k1 + 2*k2 + 2*k3 + k4)).to_vector()
        t, step = target, step + 1
        times.append(t)
        states.append(y)
    return SimulationResult(times, states, initial_state.original_norm, True, dt)
