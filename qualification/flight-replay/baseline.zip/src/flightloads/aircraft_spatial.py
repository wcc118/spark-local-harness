"""Illustrative four-panel force law, with its own symmetric 1-g trim.

This is an explicitly separate model from aircraft_flight. No measured lateral
coefficients, fuselage side force, wake delay or launch-contact model is implied.
All boundary quantities are imperial, with angles/rates in rad internally.
"""
from copy import deepcopy
import math
import numpy as np
from .aircraft_flight import atmosphere, validate_condition
from .aircraft_workspace import evaluate_aircraft, validate_definition

MODEL_ID = 'illustrative-four-panel-v1'
AILERON_EFFECTIVENESS = .35
LIMITATIONS = ('Illustrative quasi-steady four-panel sensitivity model; no measured aircraft '
    'lateral/rate/control data. Fuselage side force, delayed wake, stall, contact and deployment '
    'are omitted. Propeller shaft torque is a separately declared input. Numerical verification '
    'does not establish aircraft stability, capture, strength or operational acceptance.')


def _finite(value, name):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError(name + ' must be a finite number')
    return float(value)


def panel_geometry(geometry):
    """Physical panel centroids at quarter chord; datum nose, s=-body x."""
    g = geometry
    if abs(g['wing_load_y_in']) > 1e-10 or abs(g['tail_load_y_in']) > 1e-10:
        raise ValueError('Four-panel geometry does not support eccentric longitudinal resultants')
    panels = []
    for kind in ('wing', 'tail'):
        wing = kind == 'wing'
        length = g['wing_exposed_span_in']/2 if wing else g['tail_panel_length_in']
        chord = g[kind+'_chord_in']
        cant = 0. if wing else math.radians(g['tail_down_cant_deg'])
        for side in (-1, 1):
            position = [-g[kind+'_le_station_in']-chord/4,
                side*(g[kind+'_root_spacing_in']/2+length*math.cos(cant)/2),
                (g['wing_z_in'] if wing else g['tail_root_z_in'])+length*math.sin(cant)/2]
            panels.append(dict(kind=kind, side=side, name=('Left ' if side < 0 else 'Right ')+kind,
                position_B_in=position, area_in2=length*chord, chord_in=chord, length_in=length,
                aspect_ratio=(2*length/chord if wing else length/chord), cant_rad=cant,
                span_unit_B=[0., side*math.cos(cant), math.sin(cant)],
                up_unit_B=[0., side*math.sin(cant), -math.cos(cant)]))
    return panels


def field(definition, mass_properties, velocity_B_ft_s, omega_B_rad_s, *,
          common_tail_deg, differential_tail_deg=0., aileron_deg=0., thrust_lbf=0., prop_torque_in_lbf=0.):
    """Located aerodynamic/propulsive forces only; gravity/inertia are separate."""
    validate_definition(definition)
    c = validate_condition(definition['flight_condition']);g = definition['geometry']
    velocity, omega = np.asarray(velocity_B_ft_s, dtype=float), np.asarray(omega_B_rad_s, dtype=float)
    if velocity.shape != (3,) or omega.shape != (3,) or not np.all(np.isfinite([velocity, omega])):
        raise ValueError('Finite three-component body velocity and rate required')
    common = _finite(common_tail_deg, 'common tail incidence')
    differential = _finite(differential_tail_deg, 'tail differential')
    aileron = _finite(aileron_deg, 'aileron');thrust = _finite(thrust_lbf, 'thrust')
    torque = _finite(prop_torque_in_lbf, 'propeller torque')
    cg = np.asarray(mass_properties['cg_B_in'])
    rho = c['density_override_slug_ft3']
    if rho is None:rho = atmosphere(c['altitude_ft'])['density_slug_ft3']
    panels = panel_geometry(g);violations = [];ledger = []
    cg_speed = float(np.linalg.norm(velocity))
    if not 30<=cg_speed<=300:violations.append('CG speed outside30..300ft/s')
    if cg_speed>0 and abs(math.degrees(math.asin(float(np.clip(velocity[1]/cg_speed,-1,1)))))>10+1e-10:
        violations.append('CG sideslip outside assumed +/-10 deg')
    if abs(torque)>100:violations.append('Declared propeller torque outside +/-100 in-lbf sanity bound')
    for p in panels:
        v = velocity + np.cross(omega, (np.asarray(p['position_B_in'])-cg)/12)
        speed = float(np.linalg.norm(v))
        if speed <= 1e-9 or v[0] <= 0:raise ValueError('Local zero/reverse flow outside four-panel model')
        unit = v/speed;cross = np.cross(unit, p['span_unit_B']);norm = float(np.linalg.norm(cross))
        if norm < 1e-6:raise ValueError('Near-spanwise flow outside four-panel model')
        p.update(local_velocity_B_ft_s=v.tolist(), speed_ft_s=speed, flow_unit_B=unit.tolist(),
            lift_unit_B=(-p['side']*cross/norm).tolist(),
            flow_incidence_deg=math.degrees(math.atan2(-float(v @ p['up_unit_B']), v[0])))
    mean_wing = sum(p['flow_incidence_deg']+c['wing_incidence_deg'] for p in panels if p['kind']=='wing')/2
    for p in panels:
        kind = p['kind'];wing = kind == 'wing';side = p['side']
        delta = -side*AILERON_EFFECTIVENESS*g['aileron_span_in']/p['length_in']*aileron if wing else common-side*differential
        incidence = p['flow_incidence_deg']+c[kind+'_incidence_deg']+delta
        if not wing:incidence -= c['downwash_gradient']*mean_wing*math.cos(p['cant_rad'])
        cl = (c['wing_cl0'] if wing else 0.)+c[kind+'_cl_alpha_per_rad']*math.radians(incidence)
        cd = c[kind+'_cd0']+cl*cl/(math.pi*p['aspect_ratio']*c[kind+'_efficiency'])
        q = .5*rho*p['speed_ft_s']**2/144
        lift = q*p['area_in2']*cl*np.asarray(p['lift_unit_B'])
        drag = -q*p['area_in2']*cd*np.asarray(p['flow_unit_B'])
        force = lift+drag
        couple = np.array([0., q*p['area_in2']*p['chord_in']*c['wing_cm0'] if wing else 0., 0.])
        moment = np.cross(np.asarray(p['position_B_in'])-cg, force)+couple
        reynolds = rho*p['speed_ft_s']*p['chord_in']/12/c['viscosity_slug_ft_s']
        p.update(effective_incidence_deg=incidence, control_incidence_deg=delta, cl=cl, cd=cd,
            dynamic_pressure_psi=q, reynolds=reynolds, lift_B_lbf=lift.tolist(), drag_B_lbf=drag.tolist())
        for name, value, limit in [('incidence',incidence,c[kind+'_alpha_limit_deg']),('CL',cl,c[kind+'_cl_limit'])]:
            if abs(value)>limit+1e-10:violations.append(f"{p['name']} {name} outside assumed +/-{limit:g}")
        if not wing and abs(delta)>10+1e-10:violations.append(p['name']+' control outside +/-10 deg travel')
        if not 30<=p['speed_ft_s']<=300:violations.append(p['name']+' speed outside 30..300 ft/s')
        if not c['reynolds_min']<=reynolds<=c['reynolds_max']:violations.append(p['name']+' Reynolds outside assumed domain')
        ledger.append(dict(name=p['name']+' aerodynamic resultant', position_B_in=p['position_B_in'],
            force_B_lbf=force.tolist(), free_couple_B_in_lbf=couple.tolist(), moment_about_CG_in_lbf=moment.tolist()))
    position=np.array([-g['prop_station_in'],0.,g['prop_z_in']]);force=np.array([thrust,0.,0.]);couple=np.array([torque,0.,0.])
    ledger.append(dict(name='Propulsive thrust and declared shaft torque',position_B_in=position.tolist(),
        force_B_lbf=force.tolist(),free_couple_B_in_lbf=couple.tolist(),
        moment_about_CG_in_lbf=(np.cross(position-cg,force)+couple).tolist()))
    if abs(aileron)>10+1e-10:violations.append('Aileron command outside +/-10 deg')
    if not 0<=thrust<=c['max_thrust_lbf']+1e-10:violations.append('Thrust outside assumed availability')
    return dict(model_id=MODEL_ID,panels=panels,ledger=ledger,density_slug_ft3=rho,
        non_gravity_force_B_lbf=np.sum([r['force_B_lbf'] for r in ledger],axis=0).tolist(),
        moment_about_CG_B_in_lbf=np.sum([r['moment_about_CG_in_lbf'] for r in ledger],axis=0).tolist(),
        within_assumed_domain=not violations,domain_violations=violations,limitations=LIMITATIONS)


def symmetric_trim(definition):
    """Find this force law's own level, steady, controls-fixed 1-g trim."""
    d = deepcopy(definition);workspace = evaluate_aircraft(d);mp = workspace['mass_properties']
    if mp is None:raise ValueError('Complete mass properties required for spatial trim')
    from .aircraft_transient import mass_quadrature
    mass_quadrature(workspace['resolved_components']).require_rigid_inertia()
    if abs(workspace['load_case']['a_up_g'])>1e-12:
        raise ValueError('Spatial steady initialization requires a_up_g=0')
    inertia = np.asarray(mp['inertia_CG'])
    if abs(mp['cg_B_in'][1])>1e-8 or max(abs(inertia[0,1]),abs(inertia[1,2]))>1e-8:
        raise ValueError('Symmetric trim requires centered mass and zero xy/yz inertia coupling')
    c = validate_condition(d['flight_condition']);weight = mp['weight_lbf']
    scale = np.array([weight,weight,weight*d['geometry']['wing_chord_in']])
    x = np.array([c['alpha_deg'],c['ruddervator_deg'],c['thrust_lbf']],dtype=float)
    def trial(values):
        alpha,tail,thrust = map(float,values);a = math.radians(alpha)
        result = field(d,mp,c['speed_ft_s']*np.array([math.cos(a),0.,math.sin(a)]),np.zeros(3),
            common_tail_deg=tail,thrust_lbf=thrust)
        f = np.asarray(result['non_gravity_force_B_lbf'])+weight*np.array([-math.sin(a),0.,math.cos(a)])
        m = np.asarray(result['moment_about_CG_B_in_lbf'])
        return np.array([f[0],f[2],m[1]])/scale,result,f,m
    for iteration in range(40):
        res,result,f,m = trial(x)
        if max(abs(f))<=1e-6 and max(abs(m))<=1e-5:break
        steps = np.array([1e-4,1e-4,1e-5])
        jac = np.column_stack([(trial(x+np.eye(3)[j]*steps[j])[0]-trial(x-np.eye(3)[j]*steps[j])[0])/(2*steps[j]) for j in range(3)])
        try:change = np.linalg.solve(jac,-res)
        except np.linalg.LinAlgError:break
        moved = False
        for factor in (1.,.5,.25,.125,.0625,.03125):
            candidate = np.clip(x+factor*change,[-20.,-10.,0.],[20.,10.,c['max_thrust_lbf']])
            if np.linalg.norm(trial(candidate)[0]) < np.linalg.norm(res)-1e-14:
                x=candidate;moved=True;break
        if not moved:break
    res,result,f,m = trial(x)
    converged = bool(max(abs(f))<=1e-6 and max(abs(m))<=1e-5)
    feasible = converged and result['within_assumed_domain']
    return dict(model_id=MODEL_ID,feasible=feasible,converged=converged,
        status='balanced-within-assumed-model' if feasible else 'no-feasible-trim-found',iterations=iteration+1,
        alpha_deg=float(x[0]),common_tail_deg=float(x[1]),thrust_lbf=float(x[2]),
        force_residual_B_lbf=f.tolist(),moment_residual_B_in_lbf=m.tolist(),field=result,
        mass_properties=mp,limitations=LIMITATIONS)
