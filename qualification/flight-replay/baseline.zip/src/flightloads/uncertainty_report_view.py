"""Offline views of verified conditional event statistics."""
import html
import json


def render_report(output,manifest,ensembles):
    import numpy as np
    from matplotlib.figure import Figure
    from matplotlib import rc_context
    records=manifest['ensembles'];colors=('#24618d','#bd542d','#328051')
    with rc_context({'svg.fonttype':'none','font.size':9}):
        fig=Figure(figsize=(12,9),layout='constrained');axes=fig.subplots(2,2).ravel()
        for ax,name,scale,label in ((axes[0],'root_bending_shear',1.,'Q [dimensionless]'),
                                    (axes[1],'root_stress_max',1000.,'Positive root-stress maximum [kPa]')):
            for i,(record,ensemble) in enumerate(zip(records,ensembles)):
                if not ensemble.complete:continue
                values=np.sort([t.maxima[name] for t in ensemble.trials])
                ax.step(values/scale,np.arange(1,len(values)+1)/len(values),where='post',color=colors[i%3],
                    label=f'damping {record["model"]["damping_ratio"]:g}, n={len(values)} events')
            ax.set(xlabel=label,ylabel='Empirical CDF',ylim=(0,1.02),title='Conditional event distribution')
            if ax.lines:ax.legend(fontsize=7)
            else:ax.text(.5,.5,'Population curves withheld\n(incomplete ensembles)',ha='center',transform=ax.transAxes)
        ax=axes[2]
        for i,(record,ensemble) in enumerate(zip(records,ensembles)):
            if not ensemble.complete:continue
            counts=[];empirical=[];upper=[]
            for row in record['convergence']:
                counts.append(row['prefix']);stats=row['statistics']
                s=None if stats is None else stats['root_bending_shear']
                empirical.append(np.nan if s is None else s['empirical_quantile'])
                upper.append(np.nan if s is None or s['tolerance_upper'] is None else s['tolerance_upper'])
            label=f'damping {record["model"]["damping_ratio"]:g}'
            ax.plot(counts,empirical,'o-',color=colors[i%3],label=label+' percentile',markersize=4)
            if np.any(np.isfinite(upper)):ax.plot(counts,upper,'s--',color=colors[i%3],label=label+' tolerance upper',markersize=4)
        ax.set(xlabel='Original-prefix event count',ylabel='Q [dimensionless]',title='95th percentile and available 95/95 upper bound')
        if ax.lines:ax.legend(fontsize=6)
        else:ax.text(.5,.5,'Convergence withheld\n(incomplete ensembles)',ha='center',transform=ax.transAxes)
        ax=axes[3];draws=np.array([t.amplitudes[:2] for t in ensembles[0].trials if t.amplitudes is not None])
        if len(draws):ax.scatter(draws[:,0],draws[:,1],s=15,alpha=.65,color=colors[0])
        ax.axvline(ensembles[0].sampling.location[0],ls=':',color='#888')
        ax.axhline(ensembles[0].sampling.location[1],ls=':',color='#888')
        ax.set(xlabel='Tip multiplier',ylabel='Mid multiplier',title='Input draws once per realization (common across models)')
        for ax in axes:ax.grid(alpha=.25)
        fig.savefig(output/'response.svg',metadata={'Date':None})
    esc=lambda x:html.escape(str(x))
    number=lambda x:'unavailable' if x is None else f'{x:.7g}'
    statuses=''.join(f'<tr><td>{esc(k.replace("_"," "))}</td><td>{esc(v.replace("_"," "))}</td></tr>' for k,v in manifest['status'].items())
    summary='';rows='';demand=[]
    for record in records:
        eid=esc(record['ensemble_id']);z=record['model']['damping_ratio']
        summary+=f'<tr><td>{eid}</td><td>{z:g}</td><td>{record["requested_trials"]}</td><td>{record["completed_trials"]}</td><td>{len(record["failed_trials"])}</td></tr>'
        stats=record['statistics']
        if stats is None:
            rows+=f'<tr><td>{eid}</td><td colspan="7">Withheld: incomplete ensemble; no success-only population inference</td></tr>'
            demand.append(eid+': withheld');continue
        for name,s in stats.items():
            upper=number(s['tolerance_upper']) if s['tolerance_status']=='available' else 'insufficient sample size'
            rows+=f'<tr><td>{eid}</td><td>{esc(name)}</td><td>{esc(manifest["event_units"][name])}</td><td>{number(s["empirical_quantile"])}</td><td>{upper}</td><td>{number(s["tolerance_rank"])}</td><td>{number(s["achieved_confidence"])}</td><td>{s["sample_count"]}</td></tr>'
        q=stats['root_bending_shear']
        demand.append(f'{eid}: {q["exceedances"]}/{q["sample_count"]} ({number(q["exceedance_fraction"])})')
    downloads=' · '.join(f'<a href="{name}">{name}</a>' for name in ('basis.npz','trials.json','events.csv','response.svg','manifest.json'))
    page=f'''<!doctype html><meta charset="utf-8"><title>Conditional event uncertainty</title>
<style>body{{font:15px system-ui;max-width:1200px;margin:2rem auto;padding:0 1rem}}table{{border-collapse:collapse}}td,th{{border:1px solid #aaa;padding:.35rem}}img{{width:100%}}pre{{white-space:pre-wrap}}</style>
<h1>Conditional event uncertainty</h1><table><tr><th>Claim</th><th>Status</th></tr>{statuses}</table>
<img src="response.svg" alt="Conditional event distributions, sampling convergence and input correlation">
<p>Each observation is a complete event maximum. Damping alternatives are unweighted; their common input draws are not extra independent samples.</p>
<table><tr><th>Ensemble</th><th>Damping</th><th>Requested</th><th>Completed</th><th>Failed/invalid</th></tr>{summary}</table>
<p>Empirical 95th percentiles and upper tolerance bounds with 95% population coverage and 95% requested confidence are separate quantities.
Insufficient sample sizes remain unavailable. Curves are withheld for incomplete ensembles; failed/invalid records remain in the downloads.</p>
<table><tr><th>Model</th><th>Event</th><th>Unit</th><th>Empirical percentile</th><th>Tolerance upper</th><th>Rank</th><th>Achieved confidence</th><th>Events</th></tr>{rows}</table>
<p>Confidence scope: {esc(manifest['confidence_scope'])}. Sampling convergence does not establish time, mesh or modal accuracy.</p>
<p>Q&gt;2 demand exceedances: {'; '.join(demand)}. {esc(manifest['demand_threshold_meaning'])}.</p>
<p>Basis arrays and recorded amplitudes reconstruct every full history. Seeds, model/basis identities, whole-history digests and event indices/times support replay.
All completed trials were replayed; direct integrations and an exact small-binomial reference are checked in the manifest.</p>
<p>These are synthetic input laws, not vehicle uncertainty evidence. Numerical verification, physical model validation and design acceptance remain separate.</p>
<p>Downloads: {downloads}</p><details><summary>Inputs, conditional statistics and numerical checks</summary><pre>{esc(json.dumps(manifest,indent=2,allow_nan=False))}</pre></details>'''
    (output/'report.html').write_text(page,encoding='utf-8')
