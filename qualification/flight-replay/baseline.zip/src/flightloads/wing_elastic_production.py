"""Illustrative elastic wing driven by unified-plant histories (issue #214, P4b).

The existing moving-root Euler-Bernoulli wing (aircraft_structure.WingBeam,
aircraft_elastic) was driven only by the legacy longitudinal chain. This adapter
drives the same beam from a production run (controller bench report, or any
history with SI states and controls):

    applied_full(t) = sum over right-wing strips of point loads  N^T Fz_i + N'^T C_i
                      + uniform wing weight  mu * g_z,B(t)
    base_accel(t)   = [ a_z,B at the wing root,  roll acceleration alpha_x ]
    a_root = a_CG + alpha x rho + omega x (omega x rho),   rho = r_root - r_CG

Beam axis: eta outward along the right panel from its root, w along body +z, slope
conjugate to rotation about +x (as in aircraft_elastic). Only vertical bending is
modelled: chordwise forces, torsion and spanwise (centrifugal) axial load are omitted
and reported as screening quantities, never folded in silently.

The generic solver (solve_forcing) is shared with an adapter for the legacy
longitudinal history, so both paths use identical code after forcing assembly.
See docs/mechanics/ELASTIC_PRODUCTION.md.
"""
from __future__ import annotations

from dataclasses import replace
import numpy as np

from .aero_strip_provider import component_of
from .aircraft_structure import IN_M, LBF_N, MOMENT_NM, PSI_PA, from_aircraft
from .beam import Excitation, integrate_modal

G_IN_S2 = 386.08858267716535


def solve_forcing(wing, times_s, applied_full, base_accel, *, dt_s, retained_modes=None):
    """Integrate the moving-root beam for tabulated forcing (linear interpolation in time).

    applied_full: [n_t, n_dof] SI generalized loads (N, N m); base_accel: [n_t, 2] (m/s^2, rad/s^2).
    Starts from the static deflection of the first sample (as aircraft_elastic does)."""
    b = wing.beam
    ts = np.asarray(times_s, dtype=float)
    loads = np.asarray(applied_full, dtype=float)
    base = np.asarray(base_accel, dtype=float)
    if ts.ndim != 1 or len(ts) < 2 or loads.shape != (len(ts), len(b.mass_full)) or base.shape != (len(ts), 2):
        raise ValueError('forcing arrays must share the time grid and the beam DOF count')
    if not (np.all(np.isfinite(ts)) and np.all(np.diff(ts) > 0)
            and np.all(np.isfinite(loads)) and np.all(np.isfinite(base))):
        raise ValueError('forcing values must be finite and times strictly increasing')
    origin = float(ts[0])
    relative_times = ts - origin

    def forcing(t):
        if t < -1e-12 or t > relative_times[-1] + 1e-12:
            raise ValueError('cannot extrapolate beyond the source history')
        i = int(np.clip(np.searchsorted(relative_times, t, side='right') - 1, 0, len(ts) - 2))
        w = (t - relative_times[i])/(relative_times[i + 1] - relative_times[i])
        return Excitation(b, (1 - w)*loads[i] + w*loads[i + 1], base_accel=(1 - w)*base[i] + w*base[i + 1])

    count = len(b.omega_radps) if retained_modes is None else retained_modes
    b.residual_flexibility(count)  # Validate count without silently truncating fractional modes.
    static = b.static_displacement(forcing(0.0).effective_free)
    q0 = b.modes[:, :count].T @ b.mass_free @ static
    history = integrate_modal(b, forcing, t_final_s=float(ts[-1] - ts[0]), dt_s=dt_s, retained_modes=count,
                              initial_q=q0, residual_correction=False)
    history = replace(history, times_s=origin + history.times_s)
    a = history.arrays
    return history, dict(times_s=history.times_s.tolist(),
                         root_Fz_lbf=(a['root_reaction_z_N']/LBF_N).tolist(),
                         root_Mx_in_lbf=(-a['root_reaction_y_Nm']/MOMENT_NM).tolist(),
                         root_stress_positive_z_psi=(a['stress_positive_z_Pa'][:, 0]/PSI_PA).tolist(),
                         tip_w_in=(a['displacement_free'][:, -2]/IN_M).tolist())


def production_forcing(plant, rows, *, young_psi=2e6, elements=32):
    """Forcing arrays from production states. rows: [(time_s, RigidState, controls)].

    Returns (wing, times, applied_full, base_accel, screens). Each state is re-evaluated
    with the same plant (the loads the integrator used at that instant)."""
    if plant.aero_dataset.get('load_resolution') == 'component-resultant':
        raise ValueError('elastic forcing requires distributed wing loads; component-resultant tables are unsupported')
    definition = plant.inputs['definition']
    g = definition['geometry']
    wing = from_aircraft(definition, young_psi=young_psi, elements=elements)
    b = wing.beam
    cg = np.asarray(plant.mass_properties['cg_B_in'], dtype=float)
    root = np.array([-(g['wing_le_station_in'] + g['wing_chord_in']/2), g['wing_root_spacing_in']/2, g['wing_z_in']])
    rho = (root - cg)*IN_M
    mu = b.mass_per_length_kgpm
    times, applied, base, screens = [], [], [], dict(max_abs_Fy_over_Fz=0.0, max_abs_roll_rate_deg_s=0.0,
                                                     max_left_right_Fz_difference_lbf=0.0)
    from .conventions import rotation_matrix
    from .aircraft_transient import G_N
    for time_s, state, controls in rows:
        field, _, derivative = plant.evaluate(state, controls, time_s)
        omega, alpha = np.asarray(state.omega_B_radps), np.asarray(derivative.omegadot_B_radps2)
        a_cg = derivative.vdot_B_mps2 + np.cross(omega, state.v_CG_B_mps)
        a_root = a_cg + np.cross(alpha, rho) + np.cross(omega, np.cross(omega, rho))
        g_B = rotation_matrix(state.q_NB).T @ G_N
        load = b.uniform_load(mu*g_B[2])
        right_fz = left_fz = 0.0
        max_fy = max_fz = 0.0
        for row in field['ledger']:
            if row['kind'] != 'wing':
                continue
            side = component_of(row)
            f = np.asarray(row['force_B_lbf'])
            if side == 'wing-left':
                left_fz += f[2]
                continue
            right_fz += f[2]
            eta_in = row['position_B_in'][1] - g['wing_root_spacing_in']/2
            couple_x = row['free_couple_B_in_lbf'][0] - (row['position_B_in'][2] - root[2])*f[1]
            load = load + b.point_load(float(np.clip(eta_in*IN_M, 0.0, b.nodes_m[-1])), force_N=f[2]*LBF_N,
                                       couple_slope_Nm=couple_x*MOMENT_NM)
            max_fy, max_fz = max(max_fy, abs(f[1])), max(max_fz, abs(f[2]))
        screens['max_abs_Fy_over_Fz'] = max(screens['max_abs_Fy_over_Fz'], max_fy/max_fz if max_fz else 0.0)
        screens['max_abs_roll_rate_deg_s'] = max(screens['max_abs_roll_rate_deg_s'], abs(float(np.degrees(omega[0]))))
        screens['max_left_right_Fz_difference_lbf'] = max(screens['max_left_right_Fz_difference_lbf'], abs(right_fz - left_fz))
        times.append(float(time_s))
        applied.append(np.asarray(load))
        base.append([float(a_root[2]), float(alpha[0])])
    return wing, np.array(times), np.array(applied), np.array(base), screens


def from_controller_report(report, *, young_psi=2e6, elements=32, dt_s=None, retained_modes=None):
    """Elastic right-wing response for a controller bench report (run_bench), from its truth
    states and actual controls, plus the rigid station recovery for comparison."""
    from .aircraft_controller_plant import ControllerPlant
    from .state import RigidState
    plant = ControllerPlant(report['inputs'])
    truth = report['truth']
    if len(truth) < 2:
        raise ValueError('elastic response requires at least two recorded truth samples')
    rows = [(r['time_s'], RigidState.from_vector(np.array(r['state_SI'])), dict(r['actual_controls'])) for r in truth]
    wing, times, applied, base, screens = production_forcing(plant, rows, young_psi=young_psi, elements=elements)
    step = float(times[1] - times[0]) if dt_s is None else dt_s
    history, response = solve_forcing(wing, times, applied, base, dt_s=step, retained_modes=retained_modes)
    stations = {row['tick']: {s['id']: s for s in row['stations']} for row in report.get('station_loads') or []}
    rigid = [stations[r['tick']]['wing-root-right']['moment_B_in_lbf'][0] if r['tick'] in stations else None for r in truth]
    return dict(wing=wing, history=history, response=response, rigid_root_Mx_in_lbf=rigid, screens=screens,
                first_mode_hz=float(wing.beam.omega_radps[0]/(2*np.pi)), evidence_level=report['aero_dataset']['evidence_level'])


def legacy_forcing(source, *, young_psi=2e6, elements=32):
    """The legacy longitudinal source history (aircraft_elastic.source_history) as forcing
    arrays for solve_forcing: uniform aero load, uniform weight, root z acceleration."""
    wing = from_aircraft(source['definition'], young_psi=young_psi, elements=elements)
    b = wing.beam
    snapshots = source['snapshots']
    times = np.array([s['time_s'] for s in snapshots])
    g = source['definition']['geometry']
    cg = np.asarray(source['mass_properties']['cg_B_in'])
    root = np.array([-(g['wing_le_station_in'] + g['wing_chord_in']/2), g['wing_root_spacing_in']/2, g['wing_z_in']])
    rho = root - cg
    from .aircraft_structure import transfer_wing_load
    applied, base = [], []
    for s in snapshots:
        omega = np.radians(s['angular_velocity_B_deg_s'])
        alpha = np.radians(s['angular_acceleration_B_deg_s2'])
        tr = transfer_wing_load(s['aerodynamic']['ledger'][0], panel_span_in=wing.length_in,
                                root_spacing_in=g['wing_root_spacing_in'], beam_station_in=-root[0],
                                beam_z_in=root[2], cg_B_in=cg)
        p = tr['right_uniform_Fz_lbf_per_in']*LBF_N/IN_M
        gz = s['gravity_B_in_s2'][2]*IN_M
        az = (np.asarray(s['acceleration_CG_B_in_s2']) + np.cross(alpha, rho) + np.cross(omega, np.cross(omega, rho)))[2]*IN_M
        applied.append(np.asarray(b.uniform_load(p + b.mass_per_length_kgpm*gz)))
        base.append([az, 0.0])
    return wing, times, np.array(applied), np.array(base)


def equivalent_static_at(wing, history, index):
    """The #56 transient-to-static reproduction at one instant of a production history, with
    the existing aircraft_equivalent formulas and tolerances:

        p_eq = f_applied - M R a_root - M a - C v
        K_ff u_static = p_eq_free,   reaction = (K u_static - p_eq)_root
    """
    from .aircraft_equivalent import compare, response_at, solve_static_field
    from .aircraft_structure import generalized_imperial
    b = wing.beam
    a = history.arrays
    n = len(b.mass_full)
    u = np.r_[0.0, 0.0, a['displacement_free'][index]]
    v_free = a['velocity_free'][index]
    acc = np.r_[0.0, 0.0, a['acceleration_free'][index]]
    rigid = -b.mass_full @ b.rigid_map @ a['base_accel'][index]
    elastic = -b.mass_full @ acc
    damping = -(v_free @ b.damping_free.T @ b.elastic_extractor)
    p_eq = a['applied_full'][index] + rigid + elastic + damping
    residual = b.stiffness_full @ u - p_eq
    free = np.asarray(generalized_imperial(residual[2:]))
    transient = response_at(wing, u[2:], residual[:2])
    static = solve_static_field(wing, np.asarray(generalized_imperial(p_eq)).tolist())
    checks = compare(transient, static)
    external = compare(transient, solve_static_field(wing, np.asarray(generalized_imperial(a['applied_full'][index])).tolist()))
    return dict(index=int(index), time_s=float(history.times_s[index]), passed=checks['passed'], comparisons=checks,
                free_residual_lbf=float(abs(free[::2]).max()), free_residual_in_lbf=float(abs(free[1::2]).max()),
                external_only_failed=not external['passed'], transient=transient, equivalent=static)
