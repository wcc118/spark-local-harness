"""AVL adapter: geometry in feet, coefficients in declared body/stability axes."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import tempfile
import numpy as np

SCHEMA = 'avl-adapter-v3'
NUMBER = r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[EeDd][-+]?\d+)?'


def _hash(data):
    return hashlib.sha256(data).hexdigest()


def _json(value):
    return json.dumps(value, sort_keys=True, allow_nan=False)


def avl_to_body(vector):
    """Rotate a GEOMETRY-axis vector to body axes; units unchanged."""
    return np.asarray(vector, dtype=float) * [-1, 1, -1]


avl_to_body_force = avl_to_body
avl_to_body_moment = avl_to_body


@dataclass(frozen=True)
class AvlResult:
    schema: str
    definition_sha256: str
    input_sha256: str
    cases: list
    discretization: dict
    engine_manifest: dict
    total_forces: list
    surface_forces: list
    strip_forces: list
    derivatives: list
    downwash_at_tail: list
    run_timestamp: str
    reference: dict
    raw_outputs: list


def build_avl_geometry(definition, *, n_chord=8, n_span=24,
                       reference_B_in=None, wing_section='4412', tail_section='0009'):
    """Generate exposed rectangular wing and down-canted tails, nose origin.

    Moment reference defaults to resolved CG. Incomplete mass data require an
    explicit reference. Positive tail control means positive incidence.
    """
    from .aircraft_workspace import evaluate_aircraft
    if any(type(n) is not int or not 2 <= n <= 256 for n in (n_chord, n_span)):
        raise ValueError('mesh counts must be integers in [2,256]')
    if 4*n_chord*n_span > 3072:
        raise ValueError('aircraft mesh exceeds verified pinned-engine budget of 3072 vortices')
    resolved = evaluate_aircraft(definition)
    if reference_B_in is None:
        if resolved['mass_properties'] is None:
            raise ValueError('complete mass data or explicit reference_B_in required')
        reference_B_in = resolved['mass_properties']['cg_B_in']
    ref = np.asarray(reference_B_in, dtype=float)
    if ref.shape != (3,) or not np.isfinite(ref).all():
        raise ValueError('reference_B_in must be a finite 3-vector')
    if not all(re.fullmatch(r'\d{4}', s) for s in (wing_section, tail_section)):
        raise ValueError('sections must be four-digit NACA designations')
    g = definition['geometry']
    chord, span = g['wing_chord_in']/12, g['wing_exposed_span_in']/12
    lines = ['Flightloads aircraft', '0', '0 0 0', f'{span*chord:.12g} {chord:.12g} {span:.12g}',
             ' '.join(f'{x:.12g}' for x in avl_to_body(ref)/12)]

    def section(x, y, z, c, foil, control=None):
        lines.extend(['SECTION', f'{x:.12g} {y:.12g} {z:.12g} {c:.12g} 0', 'NACA', foil])
        if control:
            lines.extend(['CONTROL', control])

    lines.extend(['SURFACE', 'Wing', f'{n_chord} 1 {n_span} 1', 'YDUPLICATE', '0'])
    lo = g['aileron_inboard_from_root_in']/12
    hi = lo + g['aileron_span_in']/12
    ctrl = f'Aileron -1 {1-g["aileron_chord_in"]/g["wing_chord_in"]:.12g} 0 1 0 -1'
    for y in sorted({0., lo, hi, span/2}):
        section(g['wing_le_station_in']/12, g['wing_root_spacing_in']/24+y,
                -g['wing_z_in']/12, chord, wing_section, ctrl if lo <= y <= hi else None)
    cant = math.radians(g['tail_down_cant_deg'])
    for side, name in [(-1, 'LeftTail'), (1, 'RightTail')]:
        lines.extend(['SURFACE', name, f'{n_chord} 1 {n_span} 1'])
        control = f'{name} 1 0 0 {math.cos(cant):.12g} {-side*math.sin(cant):.12g} 1'
        for distance in ([g['tail_panel_length_in'], 0] if side < 0 else [0, g['tail_panel_length_in']]):
            section(g['tail_le_station_in']/12,
                    side*(g['tail_root_spacing_in']/2+distance*math.cos(cant))/12,
                    -(g['tail_root_z_in']+distance*math.sin(cant))/12,
                    g['tail_chord_in']/12, tail_section, control)
    return '\n'.join(lines)+'\n'


def _numbers(text):
    values = {k: float(v.replace('D', 'E').replace('d', 'e'))
              for k, v in re.findall(r"([A-Za-z][A-Za-z0-9_'/]*)\s*=\s*("+NUMBER+r')', text)}
    if not all(math.isfinite(v) for v in values.values()):
        raise ValueError('nonfinite AVL output')
    return values


def _parse_outputs(raw):
    ft, fn, fs, st = (raw[k] for k in ('FT', 'FN', 'FS', 'ST'))
    if any('Standard axis orientation,  X fwd, Z down' not in t for t in (ft, fn, st)):
        raise ValueError('unsupported AVL output axes')
    total = _numbers(ft)
    required = ('CXtot', 'CYtot', 'CZtot', 'Cltot', 'Cmtot', 'Cntot', 'CLtot', 'CDtot', 'CDind',
                'Sref', 'Cref', 'Bref', 'Xref', 'Yref', 'Zref')
    if not all(k in total for k in required):
        raise ValueError('missing AVL total coefficient/reference')
    total.update({k: total[v] for k, v in dict(CL='CLtot', CD='CDtot', CY='CYtot', Cl='Cltot', Cm='Cmtot', Cn='Cntot').items()})
    total['force_coeff_B'] = [total[k] for k in ('CXtot', 'CYtot', 'CZtot')]
    total['moment_coeff_B'] = [total[k] for k in ('Cltot', 'Cmtot', 'Cntot')]
    surfaces = []
    for line in fn.split('Surface Forces (referred to Ssurf')[0].splitlines():
        parts = line.split()
        if len(parts) >= 11 and parts[0].isdigit():
            row = dict(zip(('area_ft2', 'CL', 'CD', 'Cm', 'CY', 'Cn', 'Cl', 'CDi', 'CDv'), map(float, parts[1:10])))
            row.update(surface=int(parts[0]), name=' '.join(parts[10:]))
            surfaces.append(row)
    strips, surface, name = [], None, None
    for line in fs.splitlines():
        found = re.search(r'Surface #\s*(\d+)\s+(.*)', line)
        if found:
            surface, name = int(found[1]), found[2].strip()
        parts = line.split()
        if surface is not None and len(parts) == 15 and parts[0].isdigit():
            row = dict(zip(('x_le_ft', 'y_le_ft', 'z_le_ft', 'chord_ft', 'area_ft2', 'c_cl_ft',
                            'far_wake_downwash_over_v', 'cl_normal', 'cl', 'cd', 'cdv', 'cm_quarter', 'cm_le', 'cp_x_c'), map(float, parts[1:])))
            row.update(strip=int(parts[0]), surface=surface, name=name,
                       position_LE_B_ft=avl_to_body([float(x) for x in parts[1:4]]).tolist())
            strips.append(row)
    derivatives = _numbers(st.split('Stability-axis derivatives...')[-1])
    if not surfaces or not strips or not all(k in derivatives for k in ('CLa', 'Cma', 'CLq', 'Cmq')):
        raise ValueError('missing AVL surface, strip or derivative output')
    if len(strips) != int(total.get('Strips', -1)) or len(surfaces) != int(total.get('Surfaces', -1)):
        raise ValueError('incomplete AVL surface/strip output')
    if any(not math.isfinite(v) for rows in (surfaces, strips) for row in rows for v in row.values() if isinstance(v, float)):
        raise ValueError('nonfinite AVL table')
    return total, surfaces, strips, derivatives


def run_geometry(geometry, cases, *, cache_dir=None, timeout_s=120, attachments=None,
                 definition_sha256='', discretization=None, survey=None):
    """Run reference or aircraft geometry in feet through common written outputs.

    Cases: alpha, beta (degrees), body pb/2V, qc/2V, rb/2V, controls in
    declaration order (degrees), Mach. Forces and moments are coefficients,
    not dimensional loads. ST derivatives retain AVL stability-axis labels.
    """
    from .aero_engines import locate
    if not math.isfinite(timeout_s) or timeout_s <= 0:
        raise ValueError('positive finite timeout required')
    cases = [list(map(float, c)) for c in cases]
    if not cases or any(len(c) < 6 or not all(map(math.isfinite, c)) or not 0 <= c[-1] < .7 for c in cases):
        raise ValueError('finite cases required; 0<=Mach<0.7')
    controls = list(dict.fromkeys(re.findall(r'(?im)^CONTROL\s*\n\s*(\S+)', geometry)))
    if any(len(c) != 6+len(controls) for c in cases):
        raise ValueError('case control count differs from geometry')
    attachments = attachments or {}
    survey = survey or {}
    if len(survey) > 32:
        raise ValueError('at most 32 survey points')
    for point in survey.values():
        for key in ('position_geometry_ft', 'normal_geometry'):
            vec = np.asarray(point[key], dtype=float)
            if vec.shape != (3,) or not np.isfinite(vec).all():
                raise ValueError('finite survey point/normal required')
        if not np.isclose(np.linalg.norm(point['normal_geometry']), 1):
            raise ValueError('unit survey normal required')
    if any(Path(k).name != k or k in ('.', '..', 'aircraft.avl') for k in attachments):
        raise ValueError('attachment requires a safe distinct basename')
    binary, manifest = locate('avl')
    binary_hash = _hash(binary.read_bytes())
    packet = dict(schema=SCHEMA, geometry=geometry, cases=cases, attachments=attachments, survey=survey,
                  binary_sha256=binary_hash, definition_sha256=definition_sha256, discretization=discretization or {})
    key = _hash(_json(packet).encode())
    cache = Path(cache_dir or os.environ.get('FLIGHTLOADS_AVL_CACHE_DIR', Path.home()/'.cache/flight-loads/avl'))
    cache.mkdir(parents=True, exist_ok=True)
    target = cache/(key+'.json')
    if target.exists():
        saved = json.loads(target.read_text())
        if saved['schema'] != SCHEMA or saved['input_sha256'] != key:
            raise ValueError('invalid AVL cache provenance')
        return AvlResult(**saved)
    outputs, totals, surfaces, strips, derivs, wash = [], [], [], [], [], []
    for case in cases:
        alpha, beta, p, q, r = case[:5]
        angle = math.radians(alpha)
        ps, rs = p*math.cos(angle)+r*math.sin(angle), -p*math.sin(angle)+r*math.cos(angle)
        commands = ['load aircraft.avl', 'oper', f'a a {alpha}', f'b b {beta}',
                    f'r r {ps}', f'p p {q}', f'y y {rs}', 'm', f'mn {case[-1]}', '']
        commands += [f'd{i} d{i} {value}' for i, value in enumerate(case[5:-1], 1)]
        commands += ['x']
        for kind in ('FT', 'FN', 'FS', 'ST'):
            commands += [kind, kind+'.txt']
        if survey:
            commands += ['ob', 'i']
            commands += [' '.join(map(str, p['position_geometry_ft'])) for p in survey.values()]
            commands += ['', 'x', 'f', 'OB.txt', '']
        commands += ['', 'quit', '']
        with tempfile.TemporaryDirectory(prefix='flightloads-avl-') as directory:
            root = Path(directory)
            (root/'aircraft.avl').write_text(geometry)
            for name, content in attachments.items():
                (root/name).write_text(content)
            try:
                run = subprocess.run([str(binary)], cwd=root, input='\n'.join(commands),
                                     capture_output=True, text=True, timeout=timeout_s)
            except subprocess.TimeoutExpired as exc:
                raise RuntimeError('AVL execution timed out') from exc
            if run.returncode or 'not recognized' in run.stdout.lower():
                raise RuntimeError(f'AVL command failed (exit {run.returncode}): {run.stdout[-1500:]}')
            try:
                raw = {k: (root/(k+'.txt')).read_text() for k in ('FT', 'FN', 'FS', 'ST')}
                total, surface, strip, derivative = _parse_outputs(raw)
                downwash = {}
                if survey:
                    raw['OB'] = (root/'OB.txt').read_text()
                    rows = [line.split() for line in raw['OB'].splitlines()
                            if len(line.split()) == 12 and line.split()[0].isdigit()]
                    if len(rows) != len(survey):
                        raise ValueError('incomplete off-body survey')
                    aa, bb = math.radians(alpha), math.radians(beta)
                    freestream = np.array([math.cos(aa)*math.cos(bb), -math.sin(bb), math.sin(aa)*math.cos(bb)])
                    for (name, point), row in zip(survey.items(), rows):
                        values = np.array(list(map(float, row[1:])))
                        if not np.isfinite(values).all() or not np.allclose(values[:3], point['position_geometry_ft'], atol=1e-6):
                            raise ValueError('invalid off-body coordinates/velocity')
                        velocity = values[3:6]
                        normal = point['normal_geometry']
                        free_angle = math.atan2(float(freestream @ normal), freestream[0])
                        local_angle = math.atan2(float(velocity @ normal), velocity[0])
                        downwash[name] = dict(position_geometry_ft=point['position_geometry_ft'],
                                              normal_geometry=normal, velocity_over_v_geometry=velocity.tolist(),
                                              downwash_rad=free_angle-local_angle)
            except (OSError, ValueError) as exc:
                raise RuntimeError(f'Invalid AVL written output: {exc}') from exc
        totals.append(total); surfaces.append(surface); strips.append(strip); derivs.append(derivative); wash.append(downwash)
        outputs.append(raw)
    result = AvlResult(SCHEMA, definition_sha256, key, cases, discretization or {},
                       dict(manifest, binary_sha256=binary_hash), totals, surfaces, strips, derivs, wash,
                       datetime.now(timezone.utc).isoformat(),
                       dict(length_unit='ft', coefficients='dimensionless', force_axes='body', moment_axes='body',
                            derivative_axes='stability', derivative_angles='radian; controls per degree',
                            eigenmodes='unverified/not exposed', downwash='OB freestream-minus-local angle in panel plane; includes self induction and body-rate flow',
                            point_geometry_ft=[totals[0][k] for k in ('Xref','Yref','Zref')]), outputs)
    target.write_text(_json(asdict(result)))
    return result


def run_avl(definition, cases, *, cache_dir=None, timeout_s=120, n_chord=8, n_span=24,
            reference_B_in=None, wing_section='4412', tail_section='0009'):
    geometry = build_avl_geometry(definition, n_chord=n_chord, n_span=n_span,
                                  reference_B_in=reference_B_in, wing_section=wing_section, tail_section=tail_section)
    # Public aircraft order: left tail, right tail, aileron. Deck order: aileron, left, right.
    ordered = []
    for case in cases:
        if len(case) != 9:
            raise ValueError('aircraft case requires nine values')
        ordered.append([*case[:5], case[7], case[5], case[6], case[8]])
    g = definition['geometry']
    cant = math.radians(g['tail_down_cant_deg'])
    survey = {}
    for side, name in [(-1, 'LeftTail'), (1, 'RightTail')]:
        survey[name] = dict(position_geometry_ft=[(g['tail_le_station_in']-.25*g['tail_chord_in'])/12,
                            side*(g['tail_root_spacing_in']/2+.5*g['tail_panel_length_in']*math.cos(cant))/12,
                            -(g['tail_root_z_in']+.5*g['tail_panel_length_in']*math.sin(cant))/12],
                            normal_geometry=[0., side*math.sin(cant), math.cos(cant)])
    return run_geometry(geometry, ordered, cache_dir=cache_dir, timeout_s=timeout_s,
                        definition_sha256=_hash(_json(definition).encode()),
                        discretization=dict(n_chord=n_chord, n_span=n_span), survey=survey)
