"""Run a frozen E1 plan into a new, bounded archive; no live dashboard writes."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import signal
import sys
import time
from .aircraft_controller_study import run_study, validate_plan
from .aircraft_elastic import digest

MAX_REPORT_BYTES = 16 * 1024 * 1024
MAX_ARCHIVE_BYTES = 256 * 1024 * 1024


def _encode(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'),
                       allow_nan=False)+'\n').encode()


def _new_file(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def _markdown(result):
    selection=result.get('selection')
    lines=['# E1 controller experiment', '', 'Exploratory estimated aircraft and ideal sensing. Not physical validation or sustained capture.', '',
           'Execution status: '+result['status'], 'Plan SHA256: '+result['plan_sha256'],
           'Selected candidate: '+str(selection.get('candidate_id',selection.get('id')) if selection else 'none'),
           'Reserved set consumed: '+str(result['holdout_consumed']), '',
           'The full summary records gates, scores, input/report hashes and refinement. Each report-NNN.json preserves its complete inputs and concurrent load fields.', '',
           '| Run | Phase | Candidate | Case | Status | Gates |',
           '|---|---|---|---|---|---|']
    def cell(value): return str(value).replace('|','/').replace('\n',' ')
    for row in result['runs']:
        summary=row.get('summary',row)
        gates=summary.get('failed_gates',summary.get('failures',[]))
        lines.append('| '+' | '.join(cell(v) for v in [row['index'],row['phase'],row['candidate_id'],row['case_id'],summary.get('status'),gates])+' |')
    lines += ['', '## Interpretation', '',
              'Selection uses tuning cases only; reserved failures never change the winner. A completed study may contain failed or unstable runs. Every variant is retrimmed with its own ideal effectiveness: this is known-model sensitivity, not evidence of robustness to unknown plant mismatch.', '',
              'Any tuning informed by this reserved set consumes it. Use a fresh versioned evaluation set for a new selection.', '',
              'Inspect signed loads at their own saved governing event; do not combine independent extrema. E2 adds separate speed/flight-path regulation and sustained-capture criteria.', '']
    return '\n'.join(lines)


def execute(plan, output, *, cancelled=None, stream=None):
    """Create a fresh archive. Any failure leaves a manifest naming its saved prefix."""
    plan=validate_plan(plan)
    output=Path(output)
    output.mkdir(mode=0o700,parents=False,exist_ok=False)
    stream=sys.stdout if stream is None else stream
    _new_file(output/'plan.json',_encode(plan))
    entries=[]; total_bytes=0; last_time=0.; last_phase=None
    def record(index, report):
        nonlocal total_bytes
        if type(index) is not int or index!=len(entries):
            raise ValueError('Archive record index is not sequential')
        raw=_encode(report)
        if len(raw)>MAX_REPORT_BYTES or total_bytes+len(raw)>MAX_ARCHIVE_BYTES:
            raise ValueError('Study archive byte budget exceeded; no report was silently truncated')
        name=f'report-{index:03d}.json'
        _new_file(output/name,raw)
        entries.append(dict(index=index,file=name,bytes=len(raw),report_sha256=report['report_sha256']))
        total_bytes+=len(raw)
    def progress(value):
        nonlocal last_time,last_phase
        phase=value['phase']
        if phase=='selection-frozen':
            _new_file(output/'selection.json',_encode(value['selection']))
        now=time.monotonic()
        if phase!=last_phase or now-last_time>=.5:
            print(json.dumps(value,allow_nan=False),file=stream,flush=True)
            last_time=now;last_phase=phase
    try:
        result=run_study(deepcopy(plan),progress=progress,cancelled=cancelled,record=record)
        _new_file(output/'summary.json',_encode(result))
        _new_file(output/'report.md',_markdown(result).encode())
        _new_file(output/'manifest.json',_encode(dict(schema='aircraft-controller-study-archive-v1',
            plan_sha256=digest(plan),study_sha256=result['study_sha256'],status=result['status'],
            reports=entries,report_bytes=total_bytes)))
        return result
    except BaseException as error:
        _new_file(output/'failure.json',_encode(dict(schema='aircraft-controller-study-failure-v1',
            plan_sha256=digest(plan),error_type=type(error).__name__,reason=str(error),
            reports=entries,report_bytes=total_bytes)))
        raise


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan_json');parser.add_argument('--output',required=True)
    args=parser.parse_args(argv)
    stopped=False
    def stop(signum,frame):
        nonlocal stopped
        stopped=True
    previous={sig:signal.signal(sig,stop) for sig in (signal.SIGINT,signal.SIGTERM)}
    try:
        path=Path(args.plan_json)
        if path.stat().st_size>2*1024*1024: raise ValueError('Study plan exceeds2MiB')
        plan=json.loads(path.read_text())
        result=execute(plan,args.output,cancelled=lambda:stopped)
        print(json.dumps(dict(status=result['status'],study_sha256=result['study_sha256']),allow_nan=False))
        return 130 if result['status']=='cancelled' else 0
    except (ValueError,OSError,KeyError,TypeError) as error:
        print(type(error).__name__+': '+str(error),file=sys.stderr)
        return 2
    finally:
        for sig,handler in previous.items():signal.signal(sig,handler)


if __name__=='__main__':
    raise SystemExit(main())
