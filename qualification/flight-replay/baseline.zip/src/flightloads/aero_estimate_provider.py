"""Located XFOIL/Viterna loads with AVL strip-response induction estimates.

Construction explicitly runs the engines; evaluating an existing snapshot does not.
No use of FS far-wake velocity as an angle or OB as wing-only downwash.
"""
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from .aero_dataset import LocatedLoad, assemble, flow_state
from .aircraft_elastic import digest
from .estimate_polars import ExtendedSection

CODE_FILES = ('aero_estimate_provider.py', 'estimate_polars.py', 'aero_dataset.py')


def implementation_hashes():
    return {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in CODE_FILES}


def build_estimate_snapshot(definition, environment, speeds=(100., 150., 200.)):
    from .avl_model import run_avl, build_avl_geometry
    from .xfoil_polars import run_polar
    g = definition['geometry']
    build_avl_geometry(definition)  # Validate geometry before any engine execution.
    if any(not math.isfinite(environment[k]) or environment[k] <= 0 for k in
           ('density_slug_ft3', 'viscosity_slug_ft_s', 'sound_speed_ft_s')):
        raise ValueError('positive finite atmosphere required for section generation')
    if len(speeds) < 2 or any(not math.isfinite(s) or s <= 0 for s in speeds) or any(b <= a for a, b in zip(speeds, speeds[1:])):
        raise ValueError('at least two finite positive increasing section speeds required')
    sections = {}
    for kind, designation in (('wing', 'NACA 4412'), ('tail', 'NACA 0009')):
        ar = g['wing_exposed_span_in']/g['wing_chord_in'] if kind == 'wing' else g['tail_panel_length_in']/g['tail_chord_in']
        sections[kind] = []
        for speed in speeds:
            re = environment['density_slug_ft3']*speed*g[kind+'_chord_in']/12/environment['viscosity_slug_ft_s']
            record = run_polar(designation, re, list(range(-12, 19)), mach=0.)
            section = ExtendedSection(record, ar)
            if not section.alpha[0] <= -4 < 4 <= section.alpha[-1]:
                raise ValueError('XFOIL attached record does not cover frozen +/-4deg comparison')
            sections[kind].append(dict(reynolds=re, section=section.manifest()))
    # Central response cases, independently compared later with direct +/-4deg cases.
    steps = [1., 1., .01, .01, .01, 1., 1., 1.]
    cases = [[0.]*9]
    for index, step in enumerate(steps):
        for sign in (-1, 1):
            case = [0.]*9
            case[index] = sign*step
            cases.append(case)
    avl = run_avl(definition, cases)
    rows = avl.strip_forces[0]
    jac = np.array([[(plus['cl_normal']-minus['cl_normal'])/(2*step)
        for minus, plus in zip(avl.strip_forces[2*k+1], avl.strip_forces[2*k+2])]
        for k, step in enumerate(steps)]).T
    snapshot = dict(schema='xfoil-avl-estimate-v1', definition=deepcopy(definition),
        implementation_hashes=implementation_hashes(),
        environment=deepcopy(environment), sections=sections, avl=asdict(avl),
        strip_cl_jacobian=jac.tolist(), assumptions=dict(section_coupling='invert positive-slope XFOIL attached segment to AVL strip loading',
        induction_anchor_limits='alpha/beta/controls +/-4deg; dimensionless rates +/-0.01',
        correction_full_until_deg=12., correction_zero_at_deg=25., high_angle_aileron_effectiveness=.5,
        body_aerodynamics='omitted', compressibility='incompressible, Mach<=0.3'))
    return snapshot


class XfoilAvlEstimate:
    """Immutable input snapshot; per-load source identifies the section and correction."""
    def __init__(self, snapshot):
        self.snapshot = deepcopy(snapshot)
        if snapshot.get('schema') != 'xfoil-avl-estimate-v1':
            raise ValueError('unsupported estimate snapshot schema')
        if snapshot.get('implementation_hashes') != implementation_hashes():
            raise ValueError('estimate implementation hash mismatch; regenerate or use original code')
        self.identity = dict(id='xfoil-avl-estimate', digest=digest(self.snapshot), evidence_level='estimate')
        self.g = self.snapshot['definition']['geometry']
        self.rows = self.snapshot['avl']['strip_forces'][0]
        self.jac = np.asarray(self.snapshot['strip_cl_jacobian'])
        self.sections = {kind: [(r['reynolds'], ExtendedSection(r['section']['attached_record'], r['section']['aspect_ratio']))
            for r in records] for kind, records in self.snapshot['sections'].items()}
        self._inverse_cache = {}

    def section(self, kind, reynolds, angle):
        records = self.sections[kind]
        grid = np.array([r[0] for r in records])
        if not grid[0]*(1-1e-12) <= reynolds <= grid[-1]*(1+1e-12):
            raise ValueError(f'{kind} Reynolds outside [{grid[0]:g},{grid[-1]:g}]')
        i = min(len(grid)-2, max(0, int(np.searchsorted(grid, reynolds)-1)))
        f = min(1., max(0., (reynolds-grid[i])/(grid[i+1]-grid[i])))
        a, b = records[i][1].evaluate(angle), records[i+1][1].evaluate(angle)
        if f == 0:
            return a
        if f == 1:
            return b
        sources = sorted({a['source'], b['source']})
        return {**{k: (1-f)*a[k]+f*b[k] for k in ('CL', 'CD', 'CM')}, 'source': '+'.join(sources)}

    def evaluate(self, query):
        g = self.g
        flow = flow_state(query, g['wing_exposed_span_in'], g['wing_chord_in'])
        violations = []
        if flow is None:
            violations.append('flow angles undefined below 1e-6ft/s')
        elif flow['mach'] > .3:
            violations.append('incompressible estimate limited to Mach<=0.3')
        if violations:
            return assemble([], query.reference_point_B_in, provider_id=self.identity['id'],
                            dataset_digest=self.identity['digest'], violations=violations)
        vector = np.array([flow[k] for k in ('alpha_deg', 'beta_deg', 'p_hat', 'q_hat', 'r_hat')]
                          +[query.controls_deg[k] for k in ('left_tail_deg', 'right_tail_deg', 'aileron_deg')])
        weight = min(1., max(0., (abs(flow['alpha_deg'])-12)/13))
        weight = 1-weight*weight*(3-2*weight)
        loads = []
        for index, row in enumerate(self.rows):
            kind = 'wing' if row['name'].startswith('Wing') else 'tail'
            side = -1 if row['y_le_ft'] < 0 else 1
            cant = 0. if kind == 'wing' else math.radians(g['tail_down_cant_deg'])
            span = np.array([0., math.cos(cant), side*math.sin(cant)])
            normal = np.cross([1., 0., 0.], span)
            position = np.array(row['position_LE_B_ft'])*12
            position[0] -= g[kind+'_chord_in']/4
            delta = query.controls_deg['left_tail_deg' if side < 0 else 'right_tail_deg'] if kind == 'tail' else 0.
            if kind == 'wing' and g['aileron_inboard_from_root_in'] <= abs(position[1])-g['wing_root_spacing_in']/2 <= g['aileron_inboard_from_root_in']+g['aileron_span_in']:
                delta = -side*.5*query.controls_deg['aileron_deg']
            angle = math.radians(delta)
            chord = math.cos(angle)*np.array([1., 0., 0.])-math.sin(angle)*normal
            n = math.sin(angle)*np.array([1., 0., 0.])+math.cos(angle)*normal
            local = np.asarray(query.velocity_air_B_ft_s)+np.cross(query.omega_B_rad_s, (position-query.reference_point_B_in)/12)
            vc, vn = local@chord, local@n
            speed = math.hypot(vc, vn)
            geometric = math.atan2(vn, vc)
            reynolds = query.density_slug_ft3*flow['speed_ft_s']*g[kind+'_chord_in']/12/query.viscosity_slug_ft_s
            try:
                effective = geometric
                if weight:
                    anchor = np.clip(vector, [-4, -4, -.01, -.01, -.01, -4, -4, -4],
                                     [4, 4, .01, .01, .01, 4, 4, 4])
                    target_cl = row['cl_normal']+self.jac[index]@anchor
                    target_angle = math.radians(self.attached_angle(kind, reynolds, target_cl))
                    # Reconcile local viscous section and attached loading, not aircraft totals.
                    anchored_delta = anchor[5 if side < 0 else 6] if kind == 'tail' else (-side*.5*anchor[7] if delta else 0.)
                    da, aa, bb = map(math.radians, (anchored_delta, anchor[0], anchor[1]))
                    ac = math.cos(da)*np.array([1., 0., 0.])-math.sin(da)*normal
                    an = math.sin(da)*np.array([1., 0., 0.])+math.cos(da)*normal
                    velocity = flow['speed_ft_s']*np.array([math.cos(aa)*math.cos(bb), math.sin(bb), math.sin(aa)*math.cos(bb)])
                    omega = anchor[2:5]*2*flow['speed_ft_s']/np.array([g['wing_exposed_span_in']/12, g['wing_chord_in']/12, g['wing_exposed_span_in']/12])
                    local_anchor = velocity+np.cross(omega, (position-query.reference_point_B_in)/12)
                    anchor_angle = math.atan2(local_anchor@an, local_anchor@ac)
                    effective += weight*(target_angle-anchor_angle)
                effective = max(-math.pi, min(math.pi, effective))
                polar = self.section(kind, reynolds, math.degrees(effective))
            except ValueError as error:
                violations.append(str(error))
                continue
            direction = math.sin(effective)*chord-math.cos(effective)*n
            drag = math.cos(effective)*chord+math.sin(effective)*n
            scale = .5*query.density_slug_ft3*speed**2*row['area_ft2']
            force = scale*(polar['CL']*direction-polar['CD']*drag)
            couple = scale*g[kind+'_chord_in']*polar['CM']*span
            component = kind+('-left' if side < 0 else '-right')
            source = polar['source']+('+avl-correction' if weight else '')
            loads.append(LocatedLoad(component, tuple(position), tuple(force), tuple(couple), source, 'estimate', str(row['strip'])))
        # Missing sections invalidate the entire query, not a partial aircraft force.
        return assemble([] if violations else loads, query.reference_point_B_in,
                        provider_id=self.identity['id'], dataset_digest=self.identity['digest'], violations=tuple(sorted(set(violations))))

    def attached_angle(self, kind, reynolds, target_cl):
        """Invert a positive-slope attached section segment, nearest zero angle.

        This is a local loading correspondence, not an independent validation of
        AVL. Different/Re-dependent viscous slopes cannot be replaced by 2*pi.
        """
        key = (kind, reynolds)
        if key not in self._inverse_cache:
            records = self.sections[kind]
            lower = max(p.alpha[0] for _, p in records)
            upper = min(p.alpha[-1] for _, p in records)
            angles = sorted({float(a) for _, p in records for a in p.alpha if lower <= a <= upper})
            lifts = [self.section(kind, reynolds, a)['CL'] for a in angles]
            if len(self._inverse_cache) >= 128:
                self._inverse_cache.clear()
            self._inverse_cache[key] = angles, lifts
        angles, lifts = self._inverse_cache[key]
        roots = [a+(target_cl-ca)*(b-a)/(cb-ca) for a, b, ca, cb in zip(angles, angles[1:], lifts, lifts[1:])
                 if cb > ca and ca <= target_cl <= cb]
        if not roots:
            raise ValueError('AVL strip loading outside invertible attached XFOIL coverage')
        return min(roots, key=abs)


def tabulate_estimate(snapshot, axes=None, dataset_id='xfoil-avl-estimate'):
    """Serialize located component loads, rate derivatives and per-cell source tags.

    Tables use the declared reference atmosphere. A changed atmosphere cannot be
    treated as the same Reynolds/Mach relation; the dataset records that constraint.
    """
    from .aero_dataset import AXES, AeroQuery, ComponentTable, GridAxis, TabulatedDataset
    from .aircraft_workspace import evaluate_aircraft
    model = XfoilAvlEstimate(snapshot)
    g, e = model.g, snapshot['environment']
    if axes is None:
        alpha = [-180, -150, -120, -90, -60, -45, -30, -25, -20, -15, -12, -10, -8, -6, -4, -2,
                 0, 2, 4, 6, 8, 10, 12, 15, 20, 25, 30, 45, 60, 90, 120, 150, 180]
        axes = tuple(GridAxis(name, tuple(values)) for name, values in zip(AXES,
            [alpha, [-4, 0, 4], [s/e['sound_speed_ft_s'] for s in (100, 150, 200)], [-20, 0, 20], [-20, 0, 20], [-20, 0, 20]]))
    if [a.name for a in axes] != list(AXES):
        raise ValueError('estimate axes must use the canonical order')
    shape = tuple(len(a.values) for a in axes)
    if math.prod(shape) > 100_000:
        raise ValueError('estimate generation limited to 100000 grid cells')
    cg = evaluate_aircraft(snapshot['definition'])['mass_properties']['cg_B_in']
    components = ('wing-left', 'wing-right', 'tail-left', 'tail-right')
    refs = {}
    for component in components:
        kind, side = component.split('-')
        rows = [r for r in model.rows if r['name'].startswith('Wing') == (kind == 'wing') and (r['y_le_ft'] < 0) == (side == 'left')]
        position = np.average([r['position_LE_B_ft'] for r in rows], axis=0, weights=[r['area_ft2'] for r in rows])*12
        position[0] -= g[kind+'_chord_in']/4
        refs[component] = position
    arrays = {c: np.empty(shape+(6,)) for c in components}
    tags = {c: np.empty(shape, dtype=object) for c in components}
    rates = {c: np.empty(shape[:3]+(6, 3)) for c in components}
    area = g['wing_exposed_span_in']*g['wing_chord_in']
    scales = np.array([1, 1, 1, g['wing_exposed_span_in'], g['wing_chord_in'], g['wing_exposed_span_in']])

    def sample(values, rate=(0., 0., 0.)):
        a, b = map(math.radians, values[:2])
        speed = values[2]*e['sound_speed_ft_s']
        omega = np.array(rate)*2*speed/np.array([g['wing_exposed_span_in']/12, g['wing_chord_in']/12, g['wing_exposed_span_in']/12])
        query = AeroQuery((speed*math.cos(a)*math.cos(b), speed*math.sin(b), speed*math.sin(a)*math.cos(b)),
                         omega, cg, dict(zip(('left_tail_deg', 'right_tail_deg', 'aileron_deg'), values[3:])),
                         e['density_slug_ft3'], e['sound_speed_ft_s'], e['viscosity_slug_ft_s'])
        result = model.evaluate(query)
        if not result.in_coverage:
            raise ValueError(f'cannot tabulate {values}: {result.coverage_violations}')
        sums = {c: np.zeros(6) for c in components}
        sources = {c: set() for c in components}
        for load in result.loads:
            c = load.component
            sums[c][:3] += load.force_B_lbf
            sums[c][3:] += np.cross(np.asarray(load.position_B_in)-refs[c], load.force_B_lbf)+load.couple_B_in_lbf
            sources[c].update(load.source.split('+'))
        qS = .5*e['density_slug_ft3']*speed**2*area/144
        return {c: sums[c]/(qS*scales) for c in components}, {c: '+'.join(sorted(sources[c])) for c in components}

    for index in np.ndindex(shape):
        values = [axis.values[i] for axis, i in zip(axes, index)]
        coefficients, sources = sample(values)
        for c in components:
            arrays[c][index], tags[c][index] = coefficients[c], sources[c]
    for index in np.ndindex(shape[:3]):
        values = [axes[k].values[i] for k, i in enumerate(index)]+[0., 0., 0.]
        for k in range(3):
            delta = np.eye(3)[k]*.001
            plus, _ = sample(values, delta)
            minus, _ = sample(values, -delta)
            for c in components:
                rates[c][index+(slice(None), k)] = (plus[c]-minus[c])/.002
    source = dict(kind='xfoil-avl-estimate-v1', snapshot_sha256=model.identity['digest'],
                  velocity_reference_point_B_in_json=json.dumps(cg),
                  estimate_snapshot_json=json.dumps(snapshot, sort_keys=True),
                  cell_sources_json=json.dumps({c: tags[c].tolist() for c in components}),
                  reference_atmosphere_json=json.dumps({k: e[k] for k in ('density_slug_ft3', 'sound_speed_ft_s', 'viscosity_slug_ft_s')}))
    return TabulatedDataset(dataset_id, 'estimate', source, area, g['wing_exposed_span_in'], g['wing_chord_in'], axes,
        tuple(ComponentTable(c, tuple(refs[c]), arrays[c], rates[c], 'xfoil-avl-estimate; per-cell tags in metadata') for c in components),
        notes='Estimate only; fixed atmosphere/Re-Mach relation; linear rate derivatives at neutral controls; post-stall low confidence. No body aerodynamic model.')
