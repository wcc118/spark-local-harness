"""Local controller API adapter; host/origin checks remain in dashboard Handler."""
import json
import re
import threading

from .aircraft_controller_contract import default_bench, default_field_case, bench_metadata, make_run_inputs
from .aircraft_controller_capture_contract import default_capture_bench
from .aircraft_controller_store import MAX_INPUT, _decode, _id

PREFIX = '/api/aircraft/controller-bench'
UUID = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
MAX_DOWNLOADS = 2


class RecordNotFound(Exception):
    pass


def _exact(value, keys):
    if type(value) is not dict or set(value)!=set(keys):
        raise ValueError('Request requires exactly '+', '.join(keys))


def _validation_error(error):
    result = {'error':str(error)}
    match = re.match(r'^((?:target|timing|controller|actuators|disturbance|criteria|provenance|outer_loop|autopilot)(?:\.[A-Za-z_][A-Za-z0-9_]*(?:\[\d+\])?)*)(?:\s|:)',str(error))
    if match: result['path'] = 'bench.'+match[1]
    return result


class ControllerAPI:
    def __init__(self, catalog):
        self.catalog = catalog
        self.downloads = threading.BoundedSemaphore(MAX_DOWNLOADS)

    def listing(self):
        result = self.catalog.listing(); result['limits']['max_downloads'] = MAX_DOWNLOADS
        return result

    def _lookup(self, identifier):
        _id(identifier)
        try: return self.catalog.snapshot(identifier)
        except KeyError as error:
            if error.args==(identifier,): raise RecordNotFound from error
            raise RuntimeError('Saved controller record is unavailable: '+str(error)) from error
        except (ValueError,TypeError,OSError) as error:
            raise RuntimeError('Saved controller record is unavailable: '+str(error)) from error

    def get(self, handler, path):
        identifier = None
        try:
            if path==PREFIX+'/metadata':
                handler.reply(200,dict(default_bench=default_bench(),default_capture_bench=default_capture_bench(),default_field_case=default_field_case(),
                    interfaces=bench_metadata(),limits=self.listing()['limits']))
            elif path==PREFIX+'/records': handler.reply(200,self.listing())
            elif match:=re.fullmatch(PREFIX+'/records/('+UUID+')(?:/(inputs|report|replay))?',path):
                identifier,name = match.groups()
                row = self._lookup(identifier)
                if name is None: handler.reply(200,row)
                else: self._download(handler,identifier,name+'.json')
            else: handler.reply(404,{'error':'unknown controller route'})
        except RecordNotFound: handler.reply(404,{'error':'Controller record not found'})
        except KeyError as error:
            handler.reply(404 if identifier is not None and error.args==(identifier,) else 409,{'error':'Controller record or artifact unavailable'})
        except FileNotFoundError: handler.reply(409,{'error':'Saved controller artifact is unavailable'})
        except (ValueError,RuntimeError) as error: handler.reply(409,{'error':str(error)})
        except OSError: handler.reply(500,{'error':'Controller storage could not be read'})

    def _download(self, handler, identifier, name):
        if not self.downloads.acquire(blocking=False):
            handler.reply(409,{'error':'Two controller downloads are already active; retry after one finishes'})
            return
        try:
            raw = self.catalog.download(identifier,name)
            handler.reply(200,raw,'application/json','controller-'+identifier+'-'+name,stream=True)
        finally: self.downloads.release()

    def post(self, handler, path):
        match = re.fullmatch(PREFIX+'/records/('+UUID+')/(cancel|replay|delete)',path)
        if match is None and path not in (PREFIX+'/prepare',PREFIX+'/configurations',PREFIX+'/runs'):
            handler.reply(404,{'error':'unknown controller route'}); return
        if handler.headers.get('Content-Type','').split(';')[0].strip()!='application/json':
            handler.reply(415,{'error':'application/json required'}); return
        references = []
        try:
            lengths = handler.headers.get_all('Content-Length',[])
            if len(lengths)!=1 or not re.fullmatch('[0-9]+',lengths[0]):
                handler.reply(413,{'error':'One bounded Content-Length is required'}); return
            length = int(lengths[0])
            if handler.headers.get('Transfer-Encoding') or not 0<length<=MAX_INPUT:
                handler.reply(413,{'error':f'JSON payload must be between 1 and {MAX_INPUT} bytes'}); return
            raw = handler.rfile.read(length)
            if len(raw)!=length: raise ValueError('Incomplete JSON request body')
            body = _decode(raw)
            if path==PREFIX+'/prepare':
                _exact(body,('definition','bench','field_case'))
                prepared = make_run_inputs(**body)
                raw_inputs = json.dumps(prepared,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
                worst_wrapper = b'{"inputs":'+raw_inputs+b',"parent_config_id":"00000000-0000-0000-0000-000000000000"}'
                if len(worst_wrapper)>MAX_INPUT:
                    raise ValueError(f'Prepared inputs cannot fit the {MAX_INPUT}-byte submission budget')
                handler.reply(200,raw_inputs)
            elif path in (PREFIX+'/configurations',PREFIX+'/runs'):
                _exact(body,('inputs','parent_config_id'))
                if body['parent_config_id'] is not None:
                    references.append(body['parent_config_id'])
                    self._lookup(body['parent_config_id'])
                if path.endswith('/configurations'):
                    result = self.catalog.configuration(body['inputs'],body['parent_config_id']); status = 201
                else:
                    result = self.catalog.start(body['inputs'],body['parent_config_id']); status = 202
                handler.reply(status,result)
            else:
                identifier,action = match.groups()
                _exact(body,('confirmation',) if action=='delete' else ())
                references.append(identifier)
                self._lookup(identifier)
                if action=='delete': result = self.catalog.delete(identifier,body['confirmation']); status = 200
                elif action=='cancel': result = self.catalog.cancel(identifier); status = 202
                else: result = self.catalog.replay(identifier); status = 202
                handler.reply(status,result)
        except KeyError as error:
            # Only explicit reference lookups are 404; nested malformed input is 400.
            if error.args and any(error.args==(identifier,) for identifier in references):
                handler.reply(404,{'error':'Controller record not found'})
            else: handler.reply(400,_validation_error(error))
        except RecordNotFound: handler.reply(404,{'error':'Controller record not found'})
        except (ValueError,TypeError,UnicodeError) as error: handler.reply(400,_validation_error(error))
        except RecursionError: handler.reply(400,{'error':'JSON nesting exceeds the supported input depth'})
        except RuntimeError as error: handler.reply(409,{'error':str(error)})
        except OSError: handler.reply(500,{'error':'Controller operation failed; refresh saved records before retrying. Some files may have been written or removed.'})
