"""Fixed-input, one-variable learning studies. No retuning or acceptance search."""
from copy import deepcopy
import math
from .aircraft_controller_contract import make_run_inputs, MAX_ELEMENT_INTERVALS
from .aircraft_controller_store import MAX_REPORT, MAX_INPUT
from .aircraft_workspace import resolve_components
from .aircraft_elastic import digest
from .aircraft_controller_trim import _identity

MAX_POINTS=8
MAX_INTERVALS=32000
MAX_BYTES=MAX_POINTS*(MAX_REPORT+2*MAX_INPUT)+2*MAX_INPUT
MAX_WALL=7200
VARIABLES=[dict(key='battery_station_in',label='Battery station',unit='in aft of nose',path=None)]
for field,label,unit in [('attitude_gain_per_s','Attitude gain','1/s'),('rate_gain_per_s','Rate gain','1/s')]:
    for axis,name in enumerate(('roll','pitch','yaw')):
        VARIABLES.append(dict(key=field+'.'+str(axis),label=name.title()+' '+label.lower(),unit=unit,path=['bench','controller',field,axis]))
for surface in ('left_tail','right_tail','aileron'):
    for field,unit in [('rate_deg_s','deg/s'),('delay_s','s'),('min_deg','deg'),('max_deg','deg')]:
        VARIABLES.append(dict(key=surface+'.'+field,label=surface.replace('_',' ').title()+' '+{'rate_deg_s':'slew rate','delay_s':'command delay','min_deg':'lower travel stop','max_deg':'upper travel stop'}[field],unit=unit,path=['bench','actuators',surface,field]))
for field,unit in [('attitude_body_deg','deg'),('rate_body_deg_s','deg/s')]:
    for axis,name in enumerate(('roll','pitch','yaw')):
        VARIABLES.append(dict(key=field+'.'+str(axis),label='Initial '+name+' '+('angle' if field=='attitude_body_deg' else 'rate')+' offset',unit=unit,path=['bench','disturbance',field,axis]))
for field,unit in [('airspeed_delta_ft_s','ft/s'),('flight_path_delta_deg','deg')]:
    VARIABLES.append(dict(key=field,label='Initial '+('airspeed offset' if field=='airspeed_delta_ft_s' else 'flight-path offset'),unit=unit,path=['bench','disturbance',field]))
BY_KEY={v['key']:v for v in VARIABLES}


def _finite(v):
    try:return type(v) in (int,float) and math.isfinite(v)
    except OverflowError:return False

def aircraft(inputs):
    cs=resolve_components(inputs['definition']);weight=sum(c['weight_lbf'] for c in cs)
    if weight<=0 or any(not _finite(c['station_in']) for c in cs):raise ValueError('Resolved mass stations required')
    battery=next((c for c in cs if c['id']=='battery'),None)
    return dict(cg_station_in=sum(c['station_in']*c['weight_lbf'] for c in cs)/weight,battery_station_in=None if battery is None else battery['station_in'])


def variant(reference,key,value):
    """Only the selected physical setting changes; regenerate envelope hashes."""
    if not isinstance(key,str) or key not in BY_KEY:raise ValueError('Unknown study variable')
    if not _finite(value):raise ValueError('Study values must be finite numbers')
    parts={k:deepcopy(reference[k]) for k in ('definition','bench','field_case')}
    if key=='battery_station_in':
        battery=next((c for c in parts['definition']['components'] if c['id']=='battery'),None)
        if battery is None:raise ValueError('Saved aircraft has no battery component')
        if battery.get('cg_source')=='geometry':
            if not _finite(battery.get('length_in')):raise ValueError('Battery length required for geometric station')
            battery['placement']['forward_station_in']=value-battery['length_in']/2
        else:battery['station_in']=value
    else:
        path=BY_KEY[key]['path'];parent=parts
        try:
            for item in path[:-1]:parent=parent[item]
            if (isinstance(parent,dict) and path[-1] not in parent) or (isinstance(parent,list) and not 0<=path[-1]<len(parent)):
                raise ValueError('Selected variable unavailable in this saved input version')
            parent[path[-1]]=value
        except (KeyError,IndexError,TypeError) as error:raise ValueError('Selected variable unavailable in this saved input version') from error
    return make_run_inputs(**parts)


def plan(reference,spec):
    if type(spec) is not dict or set(spec)!={'name','reference_id','variable','values','budget'}:raise ValueError('Study requires name, reference_id, variable, values and budget')
    if not isinstance(spec['name'],str) or not spec['name'].strip() or len(spec['name'])>120:raise ValueError('Study name must contain 1..120 characters')
    values=spec['values'];budget=spec['budget'];key=spec['variable']
    if type(values) is not list or not 1<=len(values)<=MAX_POINTS or any(not _finite(v) for v in values) or len(set(values))!=len(values):raise ValueError('Provide 1..8 distinct finite study values')
    limits=dict(max_runs=MAX_POINTS,max_intervals=MAX_INTERVALS,max_storage_bytes=MAX_BYTES,wall_seconds=MAX_WALL)
    if type(budget) is not dict or set(budget)!=set(limits):raise ValueError('Explicit run, interval, storage and wall-time budgets required')
    for field,maximum in limits.items():
        if type(budget[field]) is not int or not 1<=budget[field]<=maximum:raise ValueError(field+' budget outside supported bounds')
    timing=reference['bench']['timing'];intervals=round(timing['duration_s']/timing['plant_dt_s'])*len(values)
    storage=len(values)*(MAX_REPORT+2*MAX_INPUT)+2*MAX_INPUT
    if len(values)>budget['max_runs'] or intervals>budget['max_intervals'] or storage>budget['max_storage_bytes']:raise ValueError('Planned study exceeds declared run, interval or storage budget')
    points=[]
    for i,value in enumerate(values):
        sample=variant(reference,key,value)
        points.append(dict(index=i,value=value,inputs_sha256=sample['inputs_sha256'],**aircraft(sample)))
    if len({p['inputs_sha256'] for p in points})!=len(points):raise ValueError('Study values collapse to identical saved inputs at numerical precision')
    result=dict(schema='aircraft-control-experiment-plan-v1',spec=deepcopy(spec),reference_inputs_sha256=reference['inputs_sha256'],variable=deepcopy(BY_KEY[key]),points=points,planned_runs=len(values),planned_intervals=intervals,reserved_storage_bytes=storage,max_element_intervals=len(values)*MAX_ELEMENT_INTERVALS)
    hashes,platform=_identity();result['implementation_identity']=dict(hashes=hashes,platform=platform)
    result['plan_sha256']=digest(result)
    return result
