"""Bounded longitudinal maneuver and distributed cut recovery; imperial boundary."""
from copy import deepcopy
import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import numpy as np
from .aircraft_workspace import evaluate_aircraft, G_IN_S2, _intrinsic, _position, _retained
from .aircraft_flight import _field
from .conventions import rotation_matrix
from .dynamics import rigid_derivative
from .integration import integrate
from .loads import AppliedLoads
from .mass import MassModel
from .state import RigidState

IN_M=.0254
FT_M=.3048
LBF_N=4.4482216152605
IN_LBF_NM=IN_M*LBF_N
G_N=np.array([0.,0.,9.80665])


def default_settings():
    return dict(duration_s=.2,dt_s=.005,pulse_start_s=.03,pulse_end_s=.07,
                ruddervator_pulse_deg=.25,initial_height_agl_ft=1000.)


def validate_settings(c):
    if not isinstance(c,dict) or set(c)!=set(default_settings()):
        raise ValueError('transient_case requires exactly the documented fields')
    from .aircraft_input_limits import TRANSIENT_BOUNDS, TRANSIENT_MAX_INTERVALS
    bounds=TRANSIENT_BOUNDS
    for key,(lo,hi) in bounds.items():
        v=c[key]
        if type(v) not in (int,float) or not math.isfinite(v) or not lo<=v<=hi:
            raise ValueError(f'transient_case {key} must be finite in [{lo}, {hi}]')
    if not c['pulse_start_s']<c['pulse_end_s']<=c['duration_s']:
        raise ValueError('Pulse must start before ending, within run duration')
    if c['duration_s']/c['dt_s']>TRANSIENT_MAX_INTERVALS:
        raise ValueError('Transient is limited to 1000 accepted steps including pulse breakpoints')
    return c


def mass_quadrature(components):
    """Two-point Gauss nodes reproduce uniform CG and inertia exactly."""
    masses,points=[],[]
    for c in components:
        dims=[0,0,0] if c['model']=='point' else [c['length_in'],0,0]
        if c['model']=='box':dims=[c['length_in'],c['width_in'],c['height_in']]
        offsets=list(itertools.product(*[[-v/(2*math.sqrt(3)),v/(2*math.sqrt(3))] if v else [0.] for v in dims]))
        for offset in offsets:
            masses.append(c['weight_lbf']*LBF_N/9.80665/len(offsets))
            points.append((_position(c)+offset)*IN_M)
    return MassModel(np.array(masses),np.array(points),'nose-datum')


def recover_imperial(d,components,cg,a_cg,alpha,omega,gravity,applied,time_s):
    """Analytically clip uniform mass and include its intrinsic inertia couple.

    Inputs: inches, lbf, in/s², rad/s² and rad/s. Applied rows contain actual
    non-gravity forces and free couples only. All vectors are body coordinates.
    """
    cg,a_cg,alpha,omega,gravity=map(lambda x:np.asarray(x,dtype=float),(cg,a_cg,alpha,omega,gravity))
    origin=np.array([-d['cut']['station_in'],0.,0.]);full=[];retained=[]
    def row(identifier,name,kind,r,f,couple,fraction=1.,acceleration=None):
        return dict(id=identifier,name=name,kind=kind,position_B_in=list(r),force_B_lbf=list(f),
            free_couple_B_in_lbf=list(couple),fraction=fraction,
            moment_about_cut_in_lbf=(np.cross(np.array(r)-origin,f)+couple).tolist(),
            acceleration_B_in_s2=None if acceleration is None else list(acceleration))
    def mass_rows(c,fraction,station):
        piece=deepcopy(c);piece['weight_lbf']*=fraction;piece['station_in']=station
        if piece['model']!='point':piece['length_in']*=fraction
        r=_position(piece);rho=r-cg;m=piece['weight_lbf']/G_IN_S2
        acceleration=a_cg+np.cross(alpha,rho)+np.cross(omega,np.cross(omega,rho))
        inertia=_intrinsic(piece)
        couple=-inertia@alpha-np.cross(omega,inertia@omega)
        return [row(c['id'],c['name']+' gravity','weight',r,m*gravity,np.zeros(3),fraction,acceleration),
                row('inertia-'+c['id'],c['name']+' inertia','inertia',r,-m*acceleration,couple,fraction,acceleration)]
    for c in components:
        full.extend(mass_rows(c,1.,c['station_in']))
        fraction,s=_retained(c,d['cut'])
        if fraction:retained.extend(mass_rows(c,fraction,s))
    for i,item in enumerate(applied):
        entry=row('applied-'+str(i),item['name'],'applied',item['position_B_in'],
                  item['force_B_lbf'],item['free_couple_B_in_lbf'])
        full.append(entry)
        if ((-item['position_B_in'][0]>=d['cut']['station_in'])==(d['cut']['retain']=='aft')):retained.append(entry)
    def sums(rows,about):
        f,m=np.zeros(3),np.zeros(3)
        for item in rows:
            f+=item['force_B_lbf']
            m+=np.cross(np.array(item['position_B_in'])-about,item['force_B_lbf'])+item['free_couple_B_in_lbf']
        return f,m
    wf,wm=sums(full,cg);rf,rm=sums(retained,origin)
    fscale=sum(np.linalg.norm(x['force_B_lbf']) for x in full)
    mscale=sum(np.linalg.norm(np.cross(np.array(x['position_B_in'])-cg,x['force_B_lbf']))+
               np.linalg.norm(x['free_couple_B_in_lbf']) for x in full)
    ftol,mtol=1e-7+1e-10*fscale,1e-6+1e-10*mscale
    balanced=bool(np.max(np.abs(wf))<=ftol and np.max(np.abs(wm))<=mtol)
    external_f,external_m=sums([x for x in retained if x['kind']!='inertia'],origin)
    inertia_f,inertia_m=sums([x for x in retained if x['kind']=='inertia'],origin)
    return dict(time_s=time_s,ledger=full,retained_ledger=retained,cut_origin_B_in=origin.tolist(),
        balanced=balanced,force_tolerance_lbf=ftol,moment_tolerance_in_lbf=mtol,
        whole_force_residual_lbf=wf.tolist(),whole_moment_residual_CG_in_lbf=wm.tolist(),
        cut_force_B_lbf=(-rf).tolist() if balanced else None,
        cut_moment_B_in_lbf=(-rm).tolist() if balanced else None,
        retained_external_force_B_lbf=external_f.tolist(),retained_external_moment_B_in_lbf=external_m.tolist(),
        retained_mass_times_acceleration_B_lbf=(-inertia_f).tolist(),
        retained_inertial_moment_B_in_lbf=(-inertia_m).tolist(),
        note='Concurrent rigid-body recovery; inertia rows include intrinsic free couples. Reactions act on retained material. Point loads exactly on the cut belong to aft.')


class DomainStop(ValueError):
    pass


def propagate_bounded(initial,mass,settings,provider,gravity_provider):
    """Reuse verified RK4, with exact time breakpoints and no invalid accepted step.

    A provider DomainStop rejects the whole step. The returned bracket is the
    rejected numerical step, not an exact event root. Stage constraints may
    conservatively stop early; decrease dt to assess event convergence.
    """
    times=[0.];states=[initial];event=None
    breaks=sorted(set([0.,settings['pulse_start_s'],settings['pulse_end_s'],settings['duration_s']]))
    provider(0.,initial,None) # reject an invalid initial state explicitly
    for begin,end in zip(breaks,breaks[1:]):
        index=0;t=begin
        while t<end:
            index+=1;target=min(begin+index*settings['dt_s'],end)
            try:
                run=integrate(states[-1],mass,target,target-t,provider,gravity_provider,t0=t,max_steps=1)
                next_state=run.state_at(-1)
                provider(target,next_state,None) # accepted-state check, not just RK stages
            except DomainStop as error:
                event=dict(reason=str(error),last_accepted_time_s=t,rejected_step_end_s=target,
                           time_resolution_s=target-t)
                return times,states,event
            times.append(target);states.append(next_state);t=target
    return times,states,event


def pulse(t,settings):
    a,b=settings['pulse_start_s'],settings['pulse_end_s']
    return settings['ruddervator_pulse_deg']*math.sin(math.pi*(t-a)/(b-a))**2 if a<t<b else 0.


def run_transient(definition):
    d=deepcopy(definition);workspace=evaluate_aircraft(d)
    settings=validate_settings(d.get('transient_case'))
    if workspace['mass_properties'] is None:raise ValueError('Complete mass inputs before transient simulation')
    if abs(workspace['load_case']['a_up_g'])>1e-12:raise ValueError('Transient initialization requires a_up_g=0 for a steady 1-g trim')
    flight=workspace['flight_condition']
    if not flight or not flight.get('trim') or not flight['trim']['feasible']:
        raise ValueError('Transient initialization requires feasible trim within the assumed flight model')
    mp=workspace['mass_properties'];mass=mass_quadrature(workspace['resolved_components']);mass.require_rigid_inertia()
    if not np.allclose(mass.inertia_CG_B_kg_m2,np.array(mp['inertia_CG'])*IN_LBF_NM,rtol=1e-10,atol=1e-12):
        raise ValueError('Mass quadrature and component inertia definitions disagree')
    if np.max(np.abs(mass.inertia_CG_B_kg_m2[[0,1],[1,2]]))>1e-10:
        raise ValueError('Longitudinal transient requires zero xy/yz inertia coupling')
    c=d['flight_condition'];trim=flight['trim'];theta=math.radians(trim['alpha_deg']);v=c['speed_ft_s']*FT_M
    if abs(trim['ruddervator_deg']+settings['ruddervator_pulse_deg'])>c.get('ruddervator_limit_deg',10.):
        raise ValueError('Pulse exceeds ruddervator travel from the trimmed control position')
    initial=RigidState(np.array([0.,0.,-settings['initial_height_agl_ft']*FT_M]),
        np.array([v*math.cos(theta),0,v*math.sin(theta)]),
        np.array([math.cos(theta/2),0,math.sin(theta/2),0]),np.zeros(3))
    def field_at(t,state):
        if state.r_CG_N_m[2]>0:raise DomainStop('Ground plane reached; rejected step was not accepted')
        velocity=state.v_CG_B_mps/FT_M;speed=float(np.linalg.norm(velocity))
        if not 30<=speed<=300:raise DomainStop('CG airspeed outside 30..300 ft/s model scope')
        if abs(velocity[1])>1e-7 or max(abs(state.omega_B_radps[[0,2]]))>1e-8:
            raise DomainStop('State left symmetric longitudinal scope')
        condition={**c,'speed_ft_s':speed}
        alpha=math.degrees(math.atan2(velocity[2],velocity[0]))
        try:field=_field(d,mp,condition,alpha,trim['ruddervator_deg']+pulse(t,settings),trim['thrust_lbf'],
                         flow_B_ft_s=velocity,omega_B_rad_s=state.omega_B_radps)
        except ValueError as error:raise DomainStop(str(error)) from error
        if field['domain_violations']:raise DomainStop('; '.join(field['domain_violations']))
        return field
    def applied(field):
        rows=field['ledger']
        return AppliedLoads(np.array([np.array(x['position_B_in'])-mp['cg_B_in'] for x in rows])*IN_M,
            np.array([x['force_B_lbf'] for x in rows])*LBF_N,
            np.array([x['free_couple_B_in_lbf'] for x in rows])*IN_LBF_NM,
            tuple(x['name'] for x in rows))
    def provider(t,state,context):return applied(field_at(t,state))
    def gravity_provider(t,position,context):return G_N
    times,states,event=propagate_bounded(initial,mass,settings,provider,gravity_provider)
    snapshots=[]
    for t,state in zip(times,states):
        field=field_at(t,state);loads=applied(field)
        derivative=rigid_derivative(state,mass,loads,G_N)
        rotation=rotation_matrix(state.q_NB)
        accel=(derivative.vdot_B_mps2+np.cross(state.omega_B_radps,state.v_CG_B_mps))/IN_M
        gravity=rotation.T@G_N/IN_M
        recovery=recover_imperial(d,workspace['resolved_components'],mp['cg_B_in'],accel,
            derivative.omegadot_B_radps2,state.omega_B_radps,gravity,field['ledger'],t)
        if not recovery['balanced']:raise ValueError('Rigid-body force/moment recovery failed; run not accepted')
        snapshots.append(dict(time_s=t,position_N_ft=(state.r_CG_N_m/FT_M).tolist(),
            velocity_B_ft_s=(state.v_CG_B_mps/FT_M).tolist(),q_NB=state.q_NB.tolist(),
            pitch_deg=math.degrees(math.asin(float(np.clip(-rotation[2,0],-1,1)))),
            angular_velocity_B_deg_s=np.degrees(state.omega_B_radps).tolist(),
            angular_acceleration_B_deg_s2=np.degrees(derivative.omegadot_B_radps2).tolist(),
            acceleration_CG_B_in_s2=accel.tolist(),gravity_B_in_s2=gravity.tolist(),
            aerodynamic=field,loads=recovery))
    encoded=json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    return dict(schema_version=1,status='completed' if event is None else 'stopped-at-scope-boundary',
        input_sha256=hashlib.sha256(encoded).hexdigest(),definition=d,settings=deepcopy(settings),
        mass_properties=mp,initial_trim=trim,event=event,snapshots=snapshots,
        review_index=max(range(len(snapshots)),key=lambda i:abs(snapshots[i]['loads']['cut_moment_B_in_lbf'][1])),
        review_selection='Largest absolute My in this run; all six load components remain concurrent',
        units='in, ft, s, lbf, in-lbf; displayed angles/rates in degrees; quaternion dimensionless',
        scope='Unvalidated rigid symmetric longitudinal model, constant atmospheric density, zero wind, open-loop tail pulse. No launch/contact, flexible response, spanwise pressure recovery or design acceptance.')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('definition',type=Path)
    parser.add_argument('--output',type=Path,help='new output JSON file; existing files are not overwritten')
    args=parser.parse_args(argv)
    try:
        if args.definition.stat().st_size>131072:raise ValueError('Aircraft definition exceeds128 KiB')
        result=run_transient(json.loads(args.definition.read_text()))
        output=json.dumps(result,indent=2,allow_nan=False)
        if args.output:
            with args.output.open('x') as file:file.write(output+'\n')
        else:print(output)
    except (ValueError,TypeError,KeyError,OSError) as error:parser.exit(2,f'transient failed: {error}\n')


if __name__=='__main__':main()
