"""Bounded conditional event accounting and concurrent aircraft case reduction."""
from collections import Counter,defaultdict
from copy import deepcopy
import numpy as np
from .aircraft_workspace import evaluate_aircraft
from .aircraft_elastic import source_history,_solve,serialize_response,digest
from .aircraft_equivalent import candidate_cases,response_histories,RESPONSES
from .uncertainty import event_statistics

DEMANDS=(*RESPONSES,'root_bending_shear')


def run_event(definition,*,young_psi=2e6):
    """Return diagnostic histories on failure; only completed cases get extrema."""
    result=dict(status='invalid-input',diagnostic=None,definition=deepcopy(definition))
    source=pilot=None;candidates=[]
    try:
        workspace=evaluate_aircraft(definition)
        result['mass_properties']=workspace['mass_properties']
        flight=workspace.get('flight_condition') or {}
        if workspace['mass_properties'] is None or not flight or 'transient_case' not in definition:
            raise ValueError('complete mass, flight condition and transient inputs required')
        result['static_stability']=(flight.get('static_stability') or {}).get('trim')
        result['initial_trim']=flight.get('trim')
        if not (flight.get('trim') or {}).get('feasible'):
            result.update(status='infeasible-trim',diagnostic='No feasible trim within the assumed model')
            return result,source,pilot,candidates
        result['status']='flight-numerical-failure'
        source=source_history(definition)
        result.update(definition=source['definition'],source_input_sha256=source['input_sha256'],
            source_history_sha256=digest(source),source_status=source['status'],event=source['event'])
        if source['status']!='completed':
            result.update(status='flight-domain-stop',diagnostic=str(source['event']))
            return result,source,pilot,candidates
        result['status']='structural-numerical-failure'
        pilot=serialize_response(source,*_solve(source,young_psi=young_psi))
        result.update(pilot_sha256=pilot['history_sha256'],structural_model_id=pilot['structural_model_id'],
            screening_metrics=pilot['screening_metrics'],screening_limits=pilot['screening_limits'])
        if pilot['scope_status']!='within-illustrative-pilot':
            result.update(status='structural-screen-failed',diagnostic='Outside declared one-way bending approximation screens')
            return result,source,pilot,candidates
        if not pilot['equation_verified']:
            result.update(status='structural-equation-failed',diagnostic='Full-mode free equilibrium failed')
            return result,source,pilot,candidates
        result['status']='static-reproduction-failed'
        candidates=candidate_cases(pilot)
        histories=response_histories(pilot);extrema={}
        for key,values in histories.items():
            low=int(np.argmin(values));high=int(np.argmax(values))
            extrema[key]=dict(min=float(values[low]),max=float(values[high]),min_index=low,max_index=high,
                min_time_s=pilot['times_s'][low],max_time_s=pilot['times_s'][high])
        result.update(status='completed',diagnostic=None,extrema=extrema,
            demands={key:float(np.max(abs(v))) if key in RESPONSES else float(np.max(v)) for key,v in histories.items()})
    except (ValueError,TypeError,KeyError,ArithmeticError,np.linalg.LinAlgError) as error:
        result['diagnostic']=str(error)
    return result,source,pilot,candidates


def paired_statistics(records):
    """One independent training realization contributes one paired-event maximum."""
    groups=defaultdict(list)
    for record in records:
        if record['partition']=='train':groups[record['realization_id']].append(record)
    observations=[];excluded=[]
    for name,rows in sorted(groups.items()):
        if len(rows)!=2 or {r['event_name'] for r in rows}!={'positive','negative'} or any(r['status']!='completed' for r in rows):
            excluded.append(dict(realization_id=name,statuses=[r['status'] for r in rows]));continue
        observations.append(dict(realization_id=name,values={k:max(r['demands'][k] for r in rows) for k in DEMANDS}))
    statistics={key:event_statistics([r['values'][key] for r in observations]) if observations else None for key in DEMANDS}
    return dict(conditioning='Both paired events completed within the illustrative model; mandatory/heldout/alternate runs excluded',
        observations=observations,excluded_realizations=excluded,statistics=statistics)


def governors(rows):
    """Each bound references its actual event, selected time and concurrent case."""
    complete=[r for r in rows if r['status']=='completed'];result={}
    if not complete:return result
    for key in DEMANDS:
        for side in (('min','max') if key in RESPONSES else ('max',)):
            # Stable ID tie-break makes reduction independent of completion order.
            ordered=sorted(complete,key=lambda r:r['id'])
            row=(min if side=='min' else max)(ordered,key=lambda r:r['extrema'][key][side])
            index=row['extrema'][key][side+'_index']
            result[key+':'+side]=dict(response=key,side=side,event_id=row['id'],
                case_id=next(c['id'] for c in row['candidates'] if c['index']==index),
                index=index,time_s=row['extrema'][key][side+'_time_s'],value=row['extrema'][key][side])
    return result


def reduce_cases(records):
    """Freeze mandatory+training bounds, then assess independent held-out runs."""
    population=[r for r in records if r['partition'] in ('mandatory','train')]
    training=governors([r for r in records if r['partition']=='train']);bounds=governors(population)
    retained={c['id'] for r in records if r['partition']=='mandatory' for c in r.get('candidates',[])}
    retained.update(v['case_id'] for v in training.values())
    checks=[]
    for row in records:
        if row['partition']!='heldout':continue
        exceeded=[]
        if row['status']=='completed' and bounds:
            for key,bound in bounds.items():
                value=row['extrema'][bound['response']][bound['side']]
                tolerance=1e-9*max(1.,abs(bound['value']))
                excess=bound['value']-value if bound['side']=='min' else value-bound['value']
                if excess>tolerance:exceeded.append(dict(criterion=key,value=value,bound=bound['value']))
        else:exceeded.append(dict(reason='Event incomplete or training bounds unavailable'))
        checks.append(dict(event_id=row['id'],covered=not exceeded,exceedances=exceeded,status=row['status']))
    return dict(training_governors=training,governors=bounds,retained_case_ids=sorted(retained),
        heldout=checks,heldout_passed=bool(checks) and all(c['covered'] for c in checks),
        roundoff_tolerance='1e-9*max(1,abs(bound)); no engineering margin or design factor',
        mandatory_event_ids=[r['id'] for r in records if r['partition']=='mandatory'],
        population_failures=[r['id'] for r in population if r['status']!='completed'])


def summary(records):
    reduction=reduce_cases(records);statistics=paired_statistics(records)
    # Numerical refinement is a separate gate applied by the archive runner.
    return dict(status_counts=dict(Counter(r['status'] for r in records)),reduction=reduction,
        conditional_statistics=statistics,
        finite_pilot_coverage_passed=not reduction['population_failures'] and reduction['heldout_passed'])
