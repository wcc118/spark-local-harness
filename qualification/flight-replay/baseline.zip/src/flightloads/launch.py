"""Ground tube launch: exit state and free flight on the unified plant (issue #217).

Scenario (imperial, degrees): tube elevation and heading, exit speed along the
tube axis (100-200 ft/s), exit height above ground, the vehicle's attitude
offsets from the tube axis (pitch, yaw) and roll, and tip-off body rates.
Wind, atmosphere/density altitude, propulsion limits and gusts come from the
plant's field_case. Fully deployed configuration; no tube-internal dynamics.

Exit state (NED, body x forward, y right, z down):
    e_tube = (cos(el) cos(hdg), cos(el) sin(hdg), -sin(el))
    v_ground_N = V_exit * e_tube
    q_NB = q321(roll, el + pitch_offset, hdg + yaw_offset)
    r_N = (0, 0, -h_exit)
Air-relative velocity follows from the plant's wind. Free flight integrates the
plant with fixed-step RK4 and stops at ground contact (CG crossing z_N = 0), at
a plant domain limit, or at the requested duration. See docs/mechanics/LAUNCH.md.
"""
from __future__ import annotations

from copy import deepcopy
import math

import numpy as np

from .aircraft_controller_plant import PlantDomainError
from .aircraft_release import attitude, quaternion_321
from .conventions import rotation_matrix, quaternion_multiply, unit_quaternion
from .state import RigidState
from .flight_conditions import flight_condition
from .station_loads import StationModel

FT_M = 0.3048
SCALARS = {  # name: (low, high, default)
    'tube_elevation_deg': (0.0, 90.0, 45.0),
    'exit_speed_ft_s': (100.0, 200.0, 150.0),
    'heading_deg': (-180.0, 180.0, 0.0),
    'exit_height_agl_ft': (0.0, 10000.0, 6.0),
    'pitch_offset_deg': (-30.0, 30.0, 0.0),
    'yaw_offset_deg': (-30.0, 30.0, 0.0),
    'roll_deg': (-180.0, 180.0, 0.0),
}
TIP_OFF_LIMIT_DEG_S = 720.0
MAX_DURATION_S, MIN_DT_S, MAX_STEPS = 30.0, 1e-4, 60000


def default_launch():
    return dict(schema_version=1, tip_off_rate_B_deg_s=[0.0, 0.0, 0.0], **{k: v[2] for k, v in SCALARS.items()})


# Additive version 2; version 1 remains the historical ground-tube contract.
PLATFORM_KINDS = ('airborne', 'ground', 'water')
PLATFORM_SCALARS = {
    'height_agl_ft': (0., 100000., 1000.),
    'north_ft': (-1e7, 1e7, 0.), 'east_ft': (-1e7, 1e7, 0.),
    **{f'ground_{axis}_ft_s': (-2000., 2000., 150. if axis == 'north' else 0.)
       for axis in ('north', 'east', 'down')},
    **{f'{prefix}_{axis}_deg': (-180., 180., 0.)
       for prefix in ('platform', 'relative') for axis in ('roll', 'pitch', 'yaw')},
    **{f'ejection_{axis}_ft_s': (-1000., 1000., 0.) for axis in ('x', 'y', 'z')},
}


def default_platform_launch(kind='airborne'):
    if kind not in PLATFORM_KINDS:
        raise ValueError('platform_kind must be airborne, ground or water')
    result = dict(schema_version=2, platform_kind=kind, ejection_frame='vehicle',
                  tip_off_rate_B_deg_s=[0., 0., 0.], **{k:v[2] for k,v in PLATFORM_SCALARS.items()})
    if kind != 'airborne':
        result.update(height_agl_ft=6., ground_north_ft_s=30.,
                      platform_pitch_deg=45., ejection_x_ft_s=150.)
    return result


def launch_sources():
    return dict(ground_tube=default_launch(), **{kind:default_platform_launch(kind) for kind in PLATFORM_KINDS})


def platform_kinematics(launch):
    """Ground velocity at the release CG, plus relative ejection; no wind here.

    Uses the same Hamilton composition as legacy carrier release. Legacy carrier
    speed is TAS; this contract intentionally accepts an explicit NED ground vector.
    """
    s = validate_launch(launch)
    if s['schema_version'] != 2:
        raise ValueError('platform kinematics requires schema_version 2')
    q_NP, q_PB = [quaternion_321(*np.radians([s[f'{p}_{a}_deg'] for a in ('roll','pitch','yaw')]))
                   for p in ('platform','relative')]
    q_NB = unit_quaternion(quaternion_multiply(q_NP, q_PB))
    inherited = np.array([s[f'ground_{a}_ft_s'] for a in ('north','east','down')])
    ejection = np.array([s[f'ejection_{a}_ft_s'] for a in ('x','y','z')])
    ejection_N = rotation_matrix(q_NB if s['ejection_frame']=='vehicle' else q_NP) @ ejection
    return dict(q_NB=q_NB, inherited_ground_N_ft_s=inherited,
                ejection_N_ft_s=ejection_N, velocity_ground_N_ft_s=inherited+ejection_N,
                position_N_ft=np.array([s['north_ft'],s['east_ft'],-s['height_agl_ft']]))


def validate_launch(launch):
    platform = type(launch) is dict and launch.get('schema_version') == 2
    expected = default_platform_launch() if platform else default_launch()
    if type(launch) is not dict or set(launch) != set(expected):
        raise ValueError('launch requires exactly the documented fields')
    if type(launch['schema_version']) is not int or launch['schema_version'] not in (1,2):
        raise ValueError('launch schema_version must be 1 or 2')
    if platform:
        if launch['platform_kind'] not in PLATFORM_KINDS:
            raise ValueError('platform_kind must be airborne, ground or water')
        if launch['ejection_frame'] not in ('vehicle','platform'):
            raise ValueError('ejection_frame must be vehicle or platform')
    for key, (low, high, _) in (PLATFORM_SCALARS if platform else SCALARS).items():
        v = launch[key]
        if type(v) not in (int, float) or not math.isfinite(v) or not low <= v <= high:
            raise ValueError(f'launch.{key} must be finite in [{low}, {high}]')
    rates = launch['tip_off_rate_B_deg_s']
    if (not isinstance(rates, list) or len(rates) != 3
            or not all(type(r) in (int, float) and math.isfinite(r) and abs(r) <= TIP_OFF_LIMIT_DEG_S for r in rates)):
        raise ValueError(f'launch.tip_off_rate_B_deg_s requires three finite rates within +/-{TIP_OFF_LIMIT_DEG_S} deg/s')
    return deepcopy(launch)


def tube_axis_N(launch):
    el, hdg = math.radians(launch['tube_elevation_deg']), math.radians(launch['heading_deg'])
    return np.array([math.cos(el)*math.cos(hdg), math.cos(el)*math.sin(hdg), -math.sin(el)])


def exit_state(launch):
    """RigidState (SI) at fully separated tube exit or platform release."""
    launch = validate_launch(launch)
    if launch['schema_version'] == 2:
        k = platform_kinematics(launch)
        return RigidState(k['position_N_ft']*FT_M,
                          rotation_matrix(k['q_NB']).T @ k['velocity_ground_N_ft_s']*FT_M,
                          k['q_NB'], np.radians(launch['tip_off_rate_B_deg_s']))
    q = quaternion_321(math.radians(launch['roll_deg']),
                       math.radians(launch['tube_elevation_deg'] + launch['pitch_offset_deg']),
                       math.radians(launch['heading_deg'] + launch['yaw_offset_deg']))
    v_N = launch['exit_speed_ft_s']*tube_axis_N(launch)
    v_B = rotation_matrix(q).T @ v_N
    return RigidState([0.0, 0.0, -launch['exit_height_agl_ft']*FT_M], v_B*FT_M, q,
                      np.radians(launch['tip_off_rate_B_deg_s']))


def _row(time_s, state, field):
    v_N = rotation_matrix(state.q_NB) @ (state.v_CG_B_mps/FT_M)
    air = np.array(field['velocity_air_B_ft_s'])
    speed = float(np.linalg.norm(air))
    ground = float(np.hypot(v_N[0], v_N[1]))
    return dict(time_s=time_s, position_N_ft=(state.r_CG_N_m/FT_M).tolist(), velocity_ground_N_ft_s=v_N.tolist(),
                height_agl_ft=float(-state.r_CG_N_m[2]/FT_M), airspeed_ft_s=speed,
                alpha_deg=math.degrees(math.atan2(air[2], air[0])) if speed > 1e-9 else None,
                beta_deg=math.degrees(math.asin(max(-1.0, min(1.0, air[1]/speed)))) if speed > 1e-9 else None,
                flight_path_deg=math.degrees(math.atan2(-v_N[2], ground)),
                omega_B_deg_s=np.degrees(state.omega_B_radps).tolist(), **attitude(state.q_NB))


def run_launch(plant, launch, controls, *, duration_s=10.0, dt_s=0.005, stations=True, states=False):
    """Fixed-control free flight from tube exit. Returns a trace with truth and station-load
    histories, the stop reason and the aero dataset identity/evidence.

    states=True adds each recorded RigidState vector (SI) to its truth row as `state_SI`,
    so a caller can re-evaluate the plant at any recorded instant (workbench station 6)."""
    launch = validate_launch(launch)
    if not (0 < duration_s <= MAX_DURATION_S) or not (MIN_DT_S <= dt_s <= 0.05):
        raise ValueError(f'duration must be in (0, {MAX_DURATION_S}] s and dt in [{MIN_DT_S}, 0.05] s')
    steps = int(math.ceil(duration_s/dt_s - 1e-9))
    if steps > MAX_STEPS:
        raise ValueError(f'launch run needs {steps} steps; limit {MAX_STEPS}')
    model = StationModel(plant) if stations else None
    state, t = exit_state(launch), 0.0
    trace = dict(schema='platform-launch-v1' if launch['schema_version']==2 else 'tube-launch-v1', launch=launch, controls=dict(controls), duration_s=duration_s, dt_s=dt_s,
                 aero_dataset=plant.aero_dataset, truth=[], station_loads=[], status=None, stop_reason=None)

    def deriv(time, vector):
        s = RigidState.from_vector(vector, normalize_quaternion=False)
        if s.r_CG_N_m[2] > 0:
            raise _Ground()
        return plant.evaluate(s, controls, time)[2].to_vector()

    def record(time, s):
        field, _, derivative = plant.evaluate(s, controls, time)
        trace['truth'].append(dict(_row(time, s, field), evidence_level=field['evidence_level'],
                                   flight_condition=flight_condition(plant,s,field,derivative)))
        if states:
            trace['truth'][-1]['state_SI'] = s.to_vector().tolist()
        trace['evidence_level'] = field['evidence_level']
        if model is not None:
            trace['station_loads'].append(dict(time_s=time, stations=model.evaluate(s, field, derivative, time)['stations']))

    try:
        record(t, state)
        for step in range(steps):
            target = min((step + 1)*dt_s, duration_s)
            h = target - t
            y = state.to_vector()
            k1 = deriv(t, y)
            k2 = deriv(t + h/2, y + h/2*k1)
            k3 = deriv(t + h/2, y + h/2*k2)
            k4 = deriv(target, y + h*k3)
            candidate = RigidState.from_vector(y + h/6*(k1 + 2*k2 + 2*k3 + k4))
            if candidate.r_CG_N_m[2] >= 0:
                trace.update(status='stopped', stop_reason=f'ground: CG reached z_N = 0 between {t:.4f} and {target:.4f} s')
                return trace
            state, t = candidate, target
            record(t, state)
    except _Ground:
        trace.update(status='stopped', stop_reason=f'ground: an RK stage crossed z_N = 0 after {t:.4f} s')
        return trace
    except PlantDomainError as error:
        trace.update(status='stopped', stop_reason=f'model-limit after {t:.4f} s: {error}')
        return trace
    trace.update(status='completed', stop_reason=None)
    return trace


class _Ground(Exception):
    pass
