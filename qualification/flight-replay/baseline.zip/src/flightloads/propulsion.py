"""Estimate propeller/motor thrust limits and shaft torque (issue #209).

The controller keeps commanding thrust in lbf; this model limits what the
propeller can deliver at the current axial airspeed and adds the shaft
reaction torque. Every parameter is an `estimate` (no measured propulsion
data exists). See docs/mechanics/PROPULSION.md (Station 5).

    T_max(V) = min( T_static * (1 - V/V_pitch),  P_shaft * eta / V )   for V > 0
    T        = min(T_commanded, T_max(V))          (never negative)
    Q        = torque_sign * k_Q * T               (couple about body +x, in-lbf)
"""
from __future__ import annotations

import math

PARAMETERS = {  # name: (low, high, default estimate, unit, basis)
    'static_thrust_lbf': (0.5, 60.0, 7.0, 'lbf', 'estimate: 8 in electric pusher, typical static thrust class'),
    'pitch_speed_ft_s': (50.0, 400.0, 210.0, 'ft/s', 'estimate: 6 in pitch at about 25,000 rpm'),
    'shaft_power_ft_lbf_s': (50.0, 5000.0, 1100.0, 'ft*lbf/s', 'estimate: about 1.5 kW shaft power'),
    'propulsive_efficiency': (0.2, 0.9, 0.6, '-', 'estimate: small fixed-pitch propeller'),
    'torque_per_thrust_in': (0.0, 2.0, 0.35, 'in', 'estimate: Q/T of a fixed-pitch 8 in propeller'),
    'torque_sign': (-1.0, 1.0, 1.0, '-', 'estimate: rotation direction unknown; flip to study'),
}


def default_propulsion():
    return dict(model='prop-map', **{k: v[2] for k, v in PARAMETERS.items()})


def validate_propulsion(value):
    if type(value) is not dict or set(value) != set(default_propulsion()):
        raise ValueError('propulsion requires exactly the documented fields')
    if value['model'] != 'prop-map':
        raise ValueError('propulsion.model must be "prop-map"')
    for key, (low, high, *_rest) in PARAMETERS.items():
        v = value[key]
        if type(v) not in (int, float) or not math.isfinite(v) or not low <= v <= high:
            raise ValueError(f'propulsion.{key} must be finite in [{low}, {high}]')
    if value['torque_sign'] not in (-1, 1, -1.0, 1.0):
        raise ValueError('propulsion.torque_sign must be +1 or -1')
    return dict(value)


def available_thrust_lbf(axial_speed_ft_s, p):
    """Maximum deliverable thrust at this axial airspeed (ft/s, body +x)."""
    v = max(float(axial_speed_ft_s), 0.0)
    linear = p['static_thrust_lbf'] * max(0.0, 1.0 - v / p['pitch_speed_ft_s'])
    if v <= 1e-9:
        return linear
    return min(linear, p['shaft_power_ft_lbf_s'] * p['propulsive_efficiency'] / v)


def delivered(commanded_thrust_lbf, axial_speed_ft_s, p):
    """(thrust_lbf, shaft_torque_in_lbf, available_lbf, saturated) for a commanded thrust."""
    available = available_thrust_lbf(axial_speed_ft_s, p)
    thrust = min(max(float(commanded_thrust_lbf), 0.0), available)
    torque = p['torque_sign'] * p['torque_per_thrust_in'] * thrust
    return thrust, torque, available, commanded_thrust_lbf > available + 1e-12


def crossover_speed_ft_s(p):
    """Speed where the power bound starts to limit: T_static*(1 - V/Vp) = P*eta/V."""
    a, b, c = p['static_thrust_lbf'] / p['pitch_speed_ft_s'], -p['static_thrust_lbf'], p['shaft_power_ft_lbf_s'] * p['propulsive_efficiency']
    disc = b*b - 4*a*c
    if disc < 0:
        return None  # power never limits below the pitch speed
    return (-b - math.sqrt(disc)) / (2*a)
