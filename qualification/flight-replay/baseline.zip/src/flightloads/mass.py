"""Point-mass properties in body axes."""

from __future__ import annotations
from dataclasses import dataclass
from typing import ClassVar
import numpy as np
from ._arrays import readonly_copy

@dataclass(frozen=True)
class MassModel:
    masses_kg: np.ndarray
    datum_locations_B_m: np.ndarray
    datum_id: str
    mass_kg: float
    cg_from_datum_B_m: np.ndarray
    rho_B_m: np.ndarray
    inertia_CG_B_kg_m2: np.ndarray
    frame: ClassVar[str] = 'B'

    def __init__(self, masses_kg: np.ndarray, datum_locations_B_m: np.ndarray, datum_id: str='body-datum') -> None:
        masses = np.asarray(masses_kg, dtype=np.float64)
        locations = np.asarray(datum_locations_B_m, dtype=np.float64)
        if masses.ndim != 1:
            raise ValueError(f'masses_kg must be 1D, got shape {masses.shape}')
        n = masses.size
        if n < 1:
            raise ValueError(f'mass count n must be >= 1, got {n}')
        if locations.shape != (n, 3):
            raise ValueError(f'datum_locations_B_m must have shape ({n}, 3), got {locations.shape}')
        if not np.all(np.isfinite(masses)):
            raise ValueError('masses_kg must be finite')
        if not np.all(np.isfinite(locations)):
            raise ValueError('datum_locations_B_m must be finite')
        if np.any(masses <= 0):
            raise ValueError('masses_kg must be strictly positive')
        if not isinstance(datum_id, str) or not datum_id:
            raise ValueError('datum_id must be a nonempty string')
        mass_kg = float(np.sum(masses))
        cg_from_datum_B_m = np.sum(masses[:, np.newaxis] * locations, axis=0) / mass_kg
        rho_B_m = locations - cg_from_datum_B_m
        inertia = np.zeros((3, 3), dtype=np.float64)
        for i in range(3):
            for j in range(3):
                if i == j:
                    transverse = [axis for axis in range(3) if axis != i]
                    inertia[i, j] = np.sum(masses * np.sum(rho_B_m[:, transverse] ** 2, axis=1))
                else:
                    inertia[i, j] = -np.sum(masses * rho_B_m[:, i] * rho_B_m[:, j])
        if not np.isfinite(mass_kg):
            raise RuntimeError('Computed mass is nonfinite')
        if not np.all(np.isfinite(cg_from_datum_B_m)):
            raise RuntimeError('Computed CG is nonfinite')
        if not np.all(np.isfinite(rho_B_m)):
            raise RuntimeError('Computed CG-relative locations are nonfinite')
        if not np.all(np.isfinite(inertia)):
            raise RuntimeError('Computed inertia is nonfinite')
        object.__setattr__(self, 'masses_kg', readonly_copy(masses))
        object.__setattr__(self, 'datum_locations_B_m', readonly_copy(locations))
        object.__setattr__(self, 'datum_id', datum_id)
        object.__setattr__(self, 'mass_kg', mass_kg)
        object.__setattr__(self, 'cg_from_datum_B_m', readonly_copy(cg_from_datum_B_m))
        object.__setattr__(self, 'rho_B_m', readonly_copy(rho_B_m))
        object.__setattr__(self, 'inertia_CG_B_kg_m2', readonly_copy(inertia))

    def inertia_about(self, point_from_datum_B_m: np.ndarray) -> np.ndarray:
        point = np.asarray(point_from_datum_B_m, dtype=np.float64)
        if point.shape != (3,):
            raise ValueError(f'point_from_datum_B_m must have shape (3,), got {point.shape}')
        if not np.all(np.isfinite(point)):
            raise ValueError('point_from_datum_B_m must be finite')
        r = point - self.cg_from_datum_B_m
        shift = -self.mass_kg * np.outer(r, r)
        for i in range(3):
            shift[i, i] = self.mass_kg * sum((r[j] ** 2 for j in range(3) if j != i))
        result = self.inertia_CG_B_kg_m2 + shift
        if not np.all(np.isfinite(result)):
            raise RuntimeError('Computed inertia about point is nonfinite')
        return readonly_copy(result)

    def require_rigid_inertia(self, max_condition: float=1000000000000.0) -> None:
        if not np.isfinite(max_condition) or max_condition < 1:
            raise ValueError(f'max_condition must be finite and >= 1, got {max_condition}')
        I = self.inertia_CG_B_kg_m2
        if not np.allclose(I, I.T, atol=1e-15):
            raise RuntimeError('Inertia is not symmetric')
        eigvals = np.linalg.eigvalsh(I)
        if np.any(eigvals <= 0):
            raise RuntimeError(f'Inertia is not SPD: min eigenvalue {eigvals.min():.3e}')
        lambda_max = eigvals.max()
        lambda_min = eigvals.min()
        condition = lambda_max / lambda_min
        if not np.isfinite(condition) or condition > max_condition:
            raise RuntimeError(f'Inertia condition number {condition:.3e} exceeds max {max_condition:.3e}')
