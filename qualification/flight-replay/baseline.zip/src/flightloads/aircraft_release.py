"""Bounded free-flight initial-state sensitivity using the separate 3-D model."""
from copy import deepcopy
import math
import hashlib
from pathlib import Path
import subprocess
import numpy as np
from .aircraft_spatial import field, symmetric_trim, MODEL_ID, LIMITATIONS
from .aircraft_workspace import evaluate_aircraft
from .aircraft_transient import (mass_quadrature, recover_imperial, propagate_bounded,
    DomainStop, IN_M, FT_M, LBF_N, IN_LBF_NM, G_N)
from .conventions import rotation_matrix
from .dynamics import rigid_derivative
from .loads import AppliedLoads
from .state import RigidState
from .aircraft_elastic import digest


def default_settings():
    return dict(duration_s=.5,dt_s=.001,height_agl_ft=1000.,phi_deg=5.,theta_offset_deg=0.,psi_deg=0.,
        beta_deg=0.,p_deg_s=10.,q_deg_s=0.,r_deg_s=0.,aileron_deg=0.,tail_differential_deg=0.,
        prop_torque_in_lbf=0.,prop_torque_source='Unknown actual torque; zero for this illustrative sensitivity')


def validate_settings(settings):
    if not isinstance(settings,dict) or set(settings)!=set(default_settings()):
        raise ValueError('Release settings require exactly the documented fields')
    from .aircraft_input_limits import RELEASE_BOUNDS, RELEASE_MAX_INTERVALS
    bounds=RELEASE_BOUNDS
    for key,(lo,hi) in bounds.items():
        value=settings[key]
        if type(value) not in (int,float) or not math.isfinite(value) or not lo<=value<=hi:
            raise ValueError(f'{key} must be a finite number in [{lo},{hi}]')
    if settings['duration_s']/settings['dt_s']>RELEASE_MAX_INTERVALS:raise ValueError('Release limited to4000 steps')
    source=settings['prop_torque_source']
    if not isinstance(source,str) or not source.strip() or len(source)>1000:raise ValueError('Declare torque source in1..1000 characters')
    return deepcopy(settings)


def quaternion_321(phi,theta,psi):
    """Radians, active body-to-NED intrinsic yaw/pitch/roll (321)."""
    cr,cp,cy=np.cos(np.array([phi,theta,psi])/2);sr,sp,sy=np.sin(np.array([phi,theta,psi])/2)
    return np.array([cr*cp*cy+sr*sp*sy,sr*cp*cy-cr*sp*sy,cr*sp*cy+sr*cp*sy,cr*cp*sy-sr*sp*cy])


def attitude(q):
    R=rotation_matrix(q);theta=math.asin(float(np.clip(-R[2,0],-1,1)))
    singular=abs(math.cos(theta))<1e-6
    return dict(phi_deg=None if singular else math.degrees(math.atan2(R[2,1],R[2,2])),
        theta_deg=math.degrees(theta),psi_deg=None if singular else math.degrees(math.atan2(R[1,0],R[0,0])),
        euler_singular=singular)


def initial_state(definition,trim,settings):
    a=math.radians(trim['alpha_deg']);b=math.radians(settings['beta_deg'])
    q=quaternion_321(math.radians(settings['phi_deg']),a+math.radians(settings['theta_offset_deg']),math.radians(settings['psi_deg']))
    speed=definition['flight_condition']['speed_ft_s']*FT_M
    return RigidState([0.,0.,-settings['height_agl_ft']*FT_M],
        speed*np.array([math.cos(b)*math.cos(a),math.sin(b),math.cos(b)*math.sin(a)]),q,
        np.radians([settings[k] for k in ('p_deg_s','q_deg_s','r_deg_s')]))


def applied_loads(result,mp):
    rows=result['ledger']
    return AppliedLoads((np.array([r['position_B_in'] for r in rows])-mp['cg_B_in'])*IN_M,
        np.array([r['force_B_lbf'] for r in rows])*LBF_N,
        np.array([r['free_couple_B_in_lbf'] for r in rows])*IN_LBF_NM,tuple(r['name'] for r in rows))


def code_provenance():
    package=Path(__file__).parent;root=package.parent.parent
    try:
        commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
        dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip())
    except (OSError,subprocess.CalledProcessError):commit='unavailable';dirty=None
    return dict(commit=commit,dirty=dirty,source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in package.glob('*.py')})


def run_release(definition,settings=None):
    d=deepcopy(definition);s=validate_settings(default_settings() if settings is None else settings)
    workspace=evaluate_aircraft(d);trim=symmetric_trim(d)
    if not trim['feasible']:raise ValueError('No feasible trim for the selected four-panel model')
    mp=trim['mass_properties'];mass=mass_quadrature(workspace['resolved_components']);mass.require_rigid_inertia()
    if not np.allclose(mass.inertia_CG_B_kg_m2,np.array(mp['inertia_CG'])*IN_LBF_NM,rtol=1e-10,atol=1e-12):
        raise ValueError('Mass quadrature and full component inertia disagree')
    initial=initial_state(d,trim,s)
    def field_at(t,state):
        if state.r_CG_N_m[2]>=0:raise DomainStop('Ground plane reached')
        v=state.v_CG_B_mps/FT_M;speed=float(np.linalg.norm(v))
        if not 30<=speed<=300:raise DomainStop('CG speed outside30..300ft/s')
        beta=math.degrees(math.asin(float(np.clip(v[1]/speed,-1,1))))
        if abs(beta)>10+1e-10:raise DomainStop('CG sideslip outside assumed +/-10deg model scope')
        try:
            result=field(d,mp,v,state.omega_B_radps,common_tail_deg=trim['common_tail_deg'],
                differential_tail_deg=s['tail_differential_deg'],aileron_deg=s['aileron_deg'],
                thrust_lbf=trim['thrust_lbf'],prop_torque_in_lbf=s['prop_torque_in_lbf'])
        except ValueError as error:raise DomainStop(str(error)) from error
        if result['domain_violations']:raise DomainStop('; '.join(result['domain_violations']))
        return result
    def provider(t,state,context):return applied_loads(field_at(t,state),mp)
    integration_settings=dict(duration_s=s['duration_s'],dt_s=s['dt_s'],pulse_start_s=0.,pulse_end_s=s['duration_s'])
    times,states,event=propagate_bounded(initial,mass,integration_settings,provider,lambda t,r,c:G_N)
    snapshots=[]
    for time,state in zip(times,states):
        result=field_at(time,state);derivative=rigid_derivative(state,mass,applied_loads(result,mp),G_N)
        R=rotation_matrix(state.q_NB);v=state.v_CG_B_mps/FT_M;speed=float(np.linalg.norm(v))
        acceleration=(derivative.vdot_B_mps2+np.cross(state.omega_B_radps,state.v_CG_B_mps))/IN_M
        gravity=R.T@G_N/IN_M
        recovery=recover_imperial(d,workspace['resolved_components'],mp['cg_B_in'],acceleration,
            derivative.omegadot_B_radps2,state.omega_B_radps,gravity,result['ledger'],time)
        if not recovery['balanced']:raise ValueError('Concurrent distributed six-load recovery failed')
        snapshots.append(dict(time_s=time,position_N_ft=(state.r_CG_N_m/FT_M).tolist(),velocity_B_ft_s=v.tolist(),
            q_NB=state.q_NB.tolist(),**attitude(state.q_NB),speed_ft_s=speed,
            alpha_deg=math.degrees(math.atan2(v[2],v[0])),beta_deg=math.degrees(math.asin(float(np.clip(v[1]/speed,-1,1)))),
            angular_velocity_B_deg_s=np.degrees(state.omega_B_radps).tolist(),
            angular_acceleration_B_deg_s2=np.degrees(derivative.omegadot_B_radps2).tolist(),
            acceleration_CG_B_in_s2=acceleration.tolist(),gravity_B_in_s2=gravity.tolist(),aerodynamic=result,loads=recovery))
    output=dict(schema='aircraft-release-v1',model_id=MODEL_ID,definition=d,settings=s,mass_properties=mp,provenance=code_provenance(),
        initial_trim=trim,input_sha256=digest(dict(definition=d,settings=s,model_id=MODEL_ID)),
        status='completed' if event is None else 'stopped-at-scope-boundary',event=event,snapshots=snapshots,
        scope=LIMITATIONS+' Rigid six-component cut recovery only; longitudinal elastic beam is not qualified for roll/torsion.',
        units='in,ft,s,lbf,in-lbf,deg,deg/s; q_NB dimensionless')
    output['history_sha256']=digest(output)
    return output
