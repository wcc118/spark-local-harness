"""Bounded, self-contained table snapshots for immutable plant input envelopes.

Compression is storage only, never a model approximation. No paths, engines or
network access are used when decoding a run's aerodynamic inputs.
"""
import base64
from copy import deepcopy
from functools import lru_cache
import hashlib
import json
import math
from types import MappingProxyType
import zlib
import numpy as np

from .aero_dataset import AXES, ComponentTable, GridAxis, TabulatedDataset, _metadata

SCHEMA = 'aero-table-snapshot-v1'
MAX_ENCODED = 2*1024**2
MAX_EXPANDED = 16*1024**2
MAX_CELLS = 100000
PANELS = {'wing-left', 'wing-right', 'tail-left', 'tail-right'}


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def freeze_dataset(dataset, definition):
    """Bind an explicitly selected table to geometry, without changing its evidence."""
    if math.prod(len(a.values) for a in dataset.axes) > MAX_CELLS or len(dataset.components) > 5:
        raise ValueError('aero snapshot grid/component budget exceeded')
    payload = dict(metadata=_metadata(dataset), geometry=deepcopy(definition['geometry']),
        tables=[dict(component=t.component, coefficients=np.asarray(t.coefficients).tolist(),
                     rate_derivatives=None if t.rate_derivatives is None else np.asarray(t.rate_derivatives).tolist())
                for t in dataset.components])
    raw = _json(payload).encode()
    if len(raw) > MAX_EXPANDED:
        raise ValueError('aero snapshot exceeds expanded storage budget')
    encoded = base64.b64encode(zlib.compress(raw)).decode('ascii')
    snapshot = dict(schema=SCHEMA, dataset_digest=dataset.digest,
                    payload_sha256=hashlib.sha256(raw).hexdigest(), payload_zlib_base64=encoded)
    snapshot_provider(snapshot, definition)
    return snapshot


def _reject_constant(value):
    raise ValueError('nonfinite JSON constant in aero snapshot: '+value)


@lru_cache(maxsize=4)
def _decode(encoded):
    if not isinstance(encoded, str) or not 0 < len(encoded) <= MAX_ENCODED:
        raise ValueError('aero snapshot encoded storage budget exceeded')
    try:
        compressed = base64.b64decode(encoded, validate=True)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(compressed, MAX_EXPANDED+1)
        if len(raw) > MAX_EXPANDED or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
            raise ValueError('aero snapshot is oversized, incomplete or has trailing data')
        payload = json.loads(raw, parse_constant=_reject_constant)
        if type(payload) is not dict or set(payload) != {'metadata', 'geometry', 'tables'}:
            raise ValueError('invalid aero snapshot payload fields')
        if type(payload['geometry']) is not dict:
            raise ValueError('aero snapshot geometry must be an object')
        meta, tables = payload['metadata'], payload['tables']
        axes = meta['axes']
        if len(axes) != len(AXES) or [a['name'] for a in axes] != list(AXES):
            raise ValueError('invalid aero snapshot axes')
        if not 0 < math.prod(len(a['values']) for a in axes) <= MAX_CELLS:
            raise ValueError('aero snapshot grid budget exceeded')
        if not isinstance(tables, list) or not 1 <= len(tables) <= 5 or len(meta['components']) != len(tables):
            raise ValueError('aero snapshot requires bounded component tables')
        components = []
        for declaration, data in zip(meta['components'], tables):
            if set(data) != {'component', 'coefficients', 'rate_derivatives'} or data['component'] != declaration['component']:
                raise ValueError('aero snapshot component mismatch')
            coefficients = np.asarray(data['coefficients'], dtype=float)
            rates = None if data['rate_derivatives'] is None else np.asarray(data['rate_derivatives'], dtype=float)
            if (rates is not None) != declaration['has_rate_derivatives']:
                raise ValueError('aero snapshot rate declaration mismatch')
            coefficients.flags.writeable = False
            if rates is not None:
                rates.flags.writeable = False
            components.append(ComponentTable(data['component'], tuple(declaration['reference_point_B_in']),
                                             coefficients, rates, declaration['source']))
        dataset = TabulatedDataset(meta['dataset_id'], meta['evidence_level'], MappingProxyType(dict(meta['source'])),
            meta['reference_area_in2'], meta['reference_span_in'], meta['reference_chord_in'],
            tuple(GridAxis(a['name'], tuple(a['values']), a['singleton_tolerance']) for a in axes), tuple(components),
            meta.get('validation_reference'), meta.get('notes', ''))
        if _metadata(dataset) != meta or dataset.digest != meta['digest']:
            raise ValueError('aero snapshot dataset digest/metadata mismatch')
        names = {t.component for t in components}
        if not PANELS <= names or names - PANELS - {'body'}:
            raise ValueError('plant table must identify both wing and both tail components (optional body)')
        if any(t.rate_derivatives is not None for t in components) and 'velocity_reference_point_B_in_json' not in dataset.source:
            raise ValueError('plant rate tables require an explicit velocity reference point')
        # Estimate geometry is available in its provenance; other tables are an
        # explicit user binding, not proof of agreement with the CFD geometry.
        if 'estimate_snapshot_json' in dataset.source:
            original = json.loads(dataset.source['estimate_snapshot_json'])['definition']['geometry']
            if original != payload['geometry']:
                raise ValueError('estimate dataset geometry differs from bound plant geometry')
        return dataset, payload['geometry'], hashlib.sha256(raw).hexdigest()
    except (KeyError, TypeError, IndexError, OverflowError, RecursionError, zlib.error) as error:
        raise ValueError('invalid aero snapshot: '+str(error)) from error


def snapshot_provider(snapshot, definition=None):
    if type(snapshot) is not dict or set(snapshot) != {'schema', 'dataset_digest', 'payload_sha256', 'payload_zlib_base64'} or snapshot['schema'] != SCHEMA:
        raise ValueError('invalid aero snapshot envelope')
    encoded = snapshot['payload_zlib_base64']
    if not isinstance(encoded, str):
        raise ValueError('aero snapshot payload must be encoded text')
    dataset, geometry, payload_hash = _decode(encoded)
    if snapshot['dataset_digest'] != dataset.digest or snapshot['payload_sha256'] != payload_hash:
        raise ValueError('aero snapshot digest mismatch')
    if definition is not None and definition['geometry'] != geometry:
        raise ValueError('aero table is bound to different geometry; explicitly apply or regenerate a matching dataset')
    return dataset
