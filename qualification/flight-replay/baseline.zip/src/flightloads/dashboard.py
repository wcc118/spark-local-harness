"""Local browser dashboard for the verified generic benchmark."""
import argparse
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
import json
from pathlib import Path
import re
import threading
from urllib.parse import urlsplit
import uuid
import zipfile
from .benchmark import (FILES, MAX_BYTES, export_benchmark, load_benchmark, payload, plain)
from .benchmark_core import BenchmarkConfig, run_benchmark

MAX_RUNS, MAX_STEPS = 16, 2000
ARTIFACTS = ('manifest.json', *FILES)
UUID_PATTERN = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'


class RunCatalog:
    """Bounded persistent catalog; clients receive copies, not mutable records."""
    def __init__(self, root):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self._runs={};self._unavailable=[]
        self._lock=threading.RLock();self._execution=threading.Lock()
        for directory in sorted(self.root.iterdir()):
            if not directory.is_dir() and not directory.is_symlink():
                continue
            try:
                if directory.is_symlink():raise ValueError('symlink run directories are not supported')
                if len(self._runs)>=MAX_RUNS:raise ValueError('loaded-run capacity reached')
                if (directory/'manifest.json').is_symlink():raise ValueError('symlink manifest is not supported')
                manifest,data=load_benchmark(directory/'manifest.json',max_steps=MAX_STEPS)
                self._register(directory,manifest,data)
            except (ValueError,TypeError,KeyError,OSError,RuntimeError,zipfile.BadZipFile) as error:
                self._unavailable.append(dict(name=directory.name,error=str(error)))

    def _register(self,directory,manifest,data):
        identifier=manifest['run_id']
        if not isinstance(identifier,str):raise ValueError('saved run ID must be a UUID string')
        if str(uuid.UUID(identifier))!=identifier or identifier in self._runs:
            raise ValueError('invalid or duplicate saved run ID')
        digest=hashlib.sha256((directory/'manifest.json').read_bytes()).hexdigest()
        with self._lock:
            self._runs[identifier]=(directory,manifest,data,digest)
        return identifier

    def listing(self):
        with self._lock:
            return plain(dict(runs=[{k:m[k] for k in ('run_id','created_utc','configuration','status')}
                                     for _,m,_,_ in self._runs.values()],unavailable=self._unavailable,
                              limits=dict(max_runs=MAX_RUNS,max_steps=MAX_STEPS)))

    def snapshot(self,identifier):
        with self._lock:
            _,manifest,data,_=self._runs[identifier]
            return plain(dict(manifest=manifest,data=data))

    def run(self,configuration):
        config=BenchmarkConfig.from_dict(configuration)
        if config.dt_s*MAX_STEPS<config.duration_s:
            raise ValueError(f'dashboard limit is {MAX_STEPS} steps; use the CLI for larger cases')
        if not self._execution.acquire(blocking=False):
            raise RuntimeError('another run is in progress')
        try:
            with self._lock:
                if len(self._runs)>=MAX_RUNS:raise RuntimeError('loaded-run capacity reached; use a fresh results directory')
            result=run_benchmark(config)
            directory=self.root/str(uuid.uuid4())
            manifest=export_benchmark(result,directory)
            return self._register(directory,manifest,payload(result))
        finally:
            self._execution.release()

    def artifact(self,identifier,name):
        if name not in ARTIFACTS:raise KeyError(name)
        with self._lock:
            directory,manifest,_,manifest_digest=self._runs[identifier]
        path=directory/name
        if directory.is_symlink() or path.is_symlink() or path.stat().st_size>MAX_BYTES:
            raise ValueError('artifact path or size is invalid')
        data=path.read_bytes()
        expected=manifest_digest if name=='manifest.json' else manifest['artifacts'][name]['sha256']
        if hashlib.sha256(data).hexdigest()!=expected:
            raise ValueError('artifact changed since loading; reopen and verify the saved run')
        return data


def make_server(catalog,port=8765,*,envelope=None,structural_review=None,aircraft_ensemble=None,carrier_study_root=None,controller_bench_root=None,control_experiment_root=None,workbench_root=None):
    transient_lock=threading.Lock()
    from .aircraft_carrier_study_catalog import CarrierStudyCatalog
    study_root=carrier_study_root if carrier_study_root is not None else catalog.root.parent/(catalog.root.name+'-carrier-studies')
    resolved_study_root=Path(study_root).resolve()
    if resolved_study_root.is_relative_to(catalog.root) or catalog.root.is_relative_to(resolved_study_root):
        raise ValueError('Carrier study and benchmark directories must be separate, without nesting')
    from .aircraft_controller_catalog import ControllerCatalog
    from .aircraft_controller_http import ControllerAPI, PREFIX as CONTROLLER_PREFIX
    controller_root=controller_bench_root if controller_bench_root is not None else catalog.root.parent/(catalog.root.name+'-controller-bench')
    resolved_controller_root=Path(controller_root).resolve()
    for other in (catalog.root,resolved_study_root):
        if resolved_controller_root.is_relative_to(other) or other.is_relative_to(resolved_controller_root):
            raise ValueError('Controller, carrier study and benchmark directories must be separate, without nesting')
    studies=CarrierStudyCatalog(study_root,transient_lock)
    controllers=ControllerCatalog(controller_root,transient_lock)
    controller_api=ControllerAPI(controllers)
    from .aircraft_control_experiment_catalog import ExperimentCatalog
    from .aircraft_control_experiment_http import ExperimentAPI, PREFIX as EXPERIMENT_PREFIX
    experiment_root=Path(control_experiment_root) if control_experiment_root is not None else Path(controller_root).with_name(Path(controller_root).name+'-experiments')
    try:
        resolved_experiment_root=experiment_root.resolve()
        for other in (catalog.root,resolved_study_root,resolved_controller_root):
            if resolved_experiment_root.is_relative_to(other) or other.is_relative_to(resolved_experiment_root):
                raise ValueError('Control study directories must be separate, without nesting')
        experiments=ExperimentCatalog(experiment_root,transient_lock)
    except BaseException:
        controllers.close();raise
    experiment_api=ExperimentAPI(experiments,controllers,controller_api.downloads)
    from .workbench_http import WorkbenchAPI, WorkbenchStore, PREFIX as WORKBENCH_PREFIX
    workbench_path=Path(workbench_root) if workbench_root is not None else catalog.root.parent/(catalog.root.name+'-workbench')
    try:
        resolved_workbench=workbench_path.resolve()
        for other in (catalog.root,resolved_study_root,resolved_controller_root,resolved_experiment_root):
            if resolved_workbench.is_relative_to(other) or other.is_relative_to(resolved_workbench):
                raise ValueError('Workbench directory must be separate from the other study directories, without nesting')
        workbench_api=WorkbenchAPI(WorkbenchStore(workbench_path), controllers)
    except BaseException:
        experiments.close();controllers.close();raise
    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup();self.connection.settimeout(10)

        def log_message(self,*args):
            pass

        def reply(self,status,data,content_type='application/json',filename=None,csp=None,*,stream=False):
            if not isinstance(data,bytes):data=json.dumps(data,allow_nan=False).encode()
            self.send_response(status);self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',csp or "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'")
            if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
            if stream:
                try:
                    self.end_headers()
                    view=memoryview(data)
                    for offset in range(0,len(view),64*1024):self.wfile.write(view[offset:offset+64*1024])
                except OSError:self.close_connection=True  # headers already sent; never append a second response
            else:
                self.end_headers();self.wfile.write(data)

        def allowed(self):
            host=self.headers.get('Host','')
            valid={f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
            origin=self.headers.get('Origin')
            if host not in valid or (origin is not None and origin!='http://'+host):
                self.reply(403,{'error':'local host and same origin required'});return False
            return True

        def do_GET(self):
            if not self.allowed():return
            path=urlsplit(self.path)
            projection_csv = re.fullmatch(WORKBENCH_PREFIX+'/studies/('+UUID_PATTERN+r')/envelopes\.csv',path.path)
            if path.fragment or (path.query and projection_csv is None):
                self.reply(404,{'error':'unknown route'});return
            if path.path.startswith(EXPERIMENT_PREFIX):
                experiment_api.get(self,path.path);return
            if path.path.startswith(CONTROLLER_PREFIX):
                controller_api.get(self,path.path);return
            if path.path.startswith(WORKBENCH_PREFIX+'/'):
                workbench_api.get(self,path.path);return
            try:
                if path.path=='/api/aircraft/carrier-studies':
                    self.reply(200,studies.listing())
                elif match:=re.fullmatch('/api/aircraft/carrier-studies/('+UUID_PATTERN+')',path.path):
                    self.reply(200,studies.snapshot(match[1]))
                elif match:=re.fullmatch('/api/aircraft/carrier-studies/('+UUID_PATTERN+')/samples/([a-z0-9-]{1,60})',path.path):
                    detail=studies.sample(match[1],match[2])
                    detail['runnable_inputs_json']=json.dumps(detail['planned']['inputs'],sort_keys=True,separators=(',',':'),allow_nan=False)
                    self.reply(200,detail)
                elif match:=re.fullmatch('/api/aircraft/carrier-studies/('+UUID_PATTERN+')/artifacts/([A-Za-z0-9_.-]{1,120})',path.path):
                    self.reply(200,studies.artifact(match[1],match[2]),'application/json',match[2])
                elif match:=re.fullmatch('/api/aircraft/carrier-studies/('+UUID_PATTERN+')/download',path.path):
                    self.reply(200,studies.bundle(match[1]),'application/zip','carrier-study-'+match[1]+'.zip')
                elif path.path=='/api/aircraft-ensemble/availability':
                    self.reply(200,{'url':'/aircraft-ensemble' if aircraft_ensemble else None})
                elif path.path in ('/aircraft-ensemble','/aircraft-ensemble.js'):
                    name='aircraft-ensemble.html' if path.path=='/aircraft-ensemble' else 'aircraft-ensemble.js'
                    kind='text/html; charset=utf-8' if name.endswith('.html') else 'text/javascript; charset=utf-8'
                    self.reply(200,files('flightloads').joinpath('static',name).read_bytes(),kind)
                elif path.path=='/api/aircraft-ensemble':
                    if aircraft_ensemble is None:raise KeyError('no aircraft ensemble loaded')
                    self.reply(200,aircraft_ensemble.overview())
                elif match:=re.fullmatch('/api/aircraft-ensemble/(cases|events)/([A-Za-z0-9-]{1,100})',path.path):
                    if aircraft_ensemble is None:raise KeyError('no aircraft ensemble loaded')
                    method=aircraft_ensemble.case_detail if match[1]=='cases' else aircraft_ensemble.event_detail
                    self.reply(200,method(match[2]))
                elif match:=re.fullmatch('/api/aircraft-ensemble/artifacts/([A-Za-z0-9_.-]{1,120})',path.path):
                    if aircraft_ensemble is None:raise KeyError('no aircraft ensemble loaded')
                    name=match[1]
                    self.reply(200,aircraft_ensemble.artifact(name),'application/gzip' if name.endswith('.gz') else 'application/json',name)
                elif path.path=='/api/structural-review':
                    self.reply(200,{'url':'/structural-review/' if structural_review else None})
                elif path.path.startswith('/structural-review/'):
                    if structural_review is None:raise KeyError('no structural review loaded')
                    name=path.path[len('/structural-review/'):] or 'index.html'
                    data,kind=structural_review.artifact(name)
                    self.reply(200,data,kind,csp=structural_review.csp)
                elif path.path in ('/dashboard-ux.css','/dashboard-ux.js'):
                    kind='text/css; charset=utf-8' if path.path.endswith('.css') else 'text/javascript; charset=utf-8'
                    self.reply(200,files('flightloads').joinpath('static',path.path[1:]).read_bytes(),kind)
                elif path.path in ('/reference','/dashboard.js'):
                    name='dashboard.html' if path.path=='/reference' else 'dashboard.js'
                    kind='text/html; charset=utf-8' if name.endswith('.html') else 'text/javascript; charset=utf-8'
                    self.reply(200,files('flightloads').joinpath('static',name).read_bytes(),kind)
                elif path.path in ('/envelope','/envelope.js'):
                    name='envelope.html' if path.path=='/envelope' else 'envelope.js'
                    kind='text/html; charset=utf-8' if name.endswith('.html') else 'text/javascript; charset=utf-8'
                    self.reply(200,files('flightloads').joinpath('static',name).read_bytes(),kind)
                elif path.path in ('/workbench','/bench','/workbench.js','/workbench-plot.js','/workbench-mc-model.js','/workbench-mc-editor.js','/workbench-launch-editor.js','/workbench-envelope-model.js','/workbench-replay-data.js','/workbench-replay.js','/recorded-replay.js','/workbench.css'):
                    name='workbench.html' if path.path in ('/workbench','/bench') else path.path[1:]
                    kind={'html':'text/html','js':'text/javascript','css':'text/css'}[name.rsplit('.',1)[1]]+'; charset=utf-8'
                    self.reply(200,files('flightloads').joinpath('static',name).read_bytes(),kind)
                elif path.path=='/aircraft-guide':
                    self.reply(200,files('flightloads').joinpath('static','aircraft-guide.html').read_bytes(),'text/html; charset=utf-8')
                elif path.path in ('/','/aircraft','/aircraft.js','/aircraft-flight.js','/aircraft-transient.js','/aircraft-release.js','/aircraft-release-pose.js','/aircraft-cg-study.js','/aircraft-dynamic.js','/aircraft-carrier-release.js','/aircraft-carrier-trajectory.js','/aircraft-carrier-study-plots.js','/aircraft-carrier-study.js','/aircraft-controller-bench.js', '/aircraft-control-experiments.js', '/aircraft-controller-replay.js', '/aircraft-controller-replay-data.js', '/aircraft-controller-learning.js', '/aircraft-controller-learning-data.js', '/aircraft-controller-comparison-data.js', '/aircraft-controller-comparison-plot.js', '/aircraft-controller-comparison.js'):
                    name='aircraft.html' if path.path in ('/','/aircraft') else path.path[1:]
                    kind='text/html; charset=utf-8' if name.endswith('.html') else 'text/javascript; charset=utf-8'
                    self.reply(200,files('flightloads').joinpath('static',name).read_bytes(),kind)
                elif path.path=='/api/aircraft/input-limits':
                    from .aircraft_input_limits import input_limits
                    self.reply(200,input_limits())
                elif path.path=='/api/aircraft/carrier-trajectory-inputs':
                    from .aircraft_carrier_trajectory import trajectory_metadata
                    self.reply(200,trajectory_metadata())
                elif path.path=='/api/aircraft/carrier-release-inputs':
                    from .aircraft_carrier_release import scenario_metadata
                    self.reply(200,scenario_metadata())
                elif path.path=='/api/aircraft/release-default':
                    from .aircraft_release import default_settings
                    self.reply(200,default_settings())
                elif path.path=='/api/aircraft/default':
                    from .aircraft_workspace import default_definition
                    self.reply(200,default_definition())
                elif path.path=='/api/aircraft/example':
                    from .aircraft_workspace import example_definition
                    self.reply(200,example_definition())
                elif path.path=='/api/aircraft/stable-example':
                    from .aircraft_workspace import stable_example_definition
                    self.reply(200,stable_example_definition())
                elif path.path=='/api/envelope':
                    if envelope is None:
                        self.reply(404,{'error':'No envelope loaded. Restart with --envelope DIRECTORY.'});return
                    self.reply(200,envelope.snapshot())
                elif match:=re.fullmatch('/api/envelope/cases/([A-Za-z0-9-]{1,80})',path.path):
                    if envelope is None:raise KeyError('no envelope loaded')
                    self.reply(200,envelope.case_detail(match[1]))
                elif match:=re.fullmatch('/api/envelope/artifacts/([A-Za-z0-9_.]+)',path.path):
                    if envelope is None:raise KeyError('no envelope loaded')
                    self.reply(200,envelope.artifact(match[1]),'application/octet-stream',match[1])
                elif path.path=='/api/runs':self.reply(200,catalog.listing())
                elif match:=re.fullmatch('/api/runs/('+UUID_PATTERN+')',path.path):
                    self.reply(200,catalog.snapshot(match[1]))
                elif match:=re.fullmatch('/artifacts/('+UUID_PATTERN+')/([A-Za-z0-9_.]+)',path.path):
                    self.reply(200,catalog.artifact(match[1],match[2]),'application/octet-stream',match[2])
                else:self.reply(404,{'error':'unknown route'})
            except (KeyError,FileNotFoundError):self.reply(404,{'error':'run or artifact not found'})
            except (ValueError,RuntimeError) as error:self.reply(409,{'error':str(error)})
            except OSError:self.reply(500,{'error':'local storage could not be read'})

        def do_POST(self):
            if not self.allowed():return
            if self.path.startswith(EXPERIMENT_PREFIX):
                experiment_api.post(self,self.path);return
            if self.path.startswith(CONTROLLER_PREFIX):
                controller_api.post(self,self.path);return
            if self.path.startswith(WORKBENCH_PREFIX+'/'):
                workbench_api.post(self,self.path);return
            cancel_match=re.fullmatch('/api/aircraft/carrier-studies/('+UUID_PATTERN+')/cancel',self.path)
            delete_match=re.fullmatch('/api/aircraft/carrier-studies/('+UUID_PATTERN+')/delete',self.path)
            if not cancel_match and not delete_match and self.path not in ('/api/aircraft/carrier-study-default','/api/aircraft/carrier-studies','/api/runs','/api/aircraft/evaluate','/api/aircraft/transient','/api/aircraft/release','/api/aircraft/cg-study','/api/aircraft/longitudinal-analysis','/api/aircraft/carrier-release-preview','/api/aircraft/carrier-trajectory'):self.reply(404,{'error':'unknown route'});return
            if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':
                self.reply(415,{'error':'application/json required'});return
            try:
                length=int(self.headers.get('Content-Length','0'))
                limit=131072 if self.path.startswith('/api/aircraft/') else 4096
                if self.headers.get('Transfer-Encoding') or not 0<length<=limit:
                    self.reply(413,{'error':f'JSON payload must be between 1 and {limit} bytes'});return
                configuration=json.loads(self.rfile.read(length))
                if delete_match:
                    if not isinstance(configuration,dict) or set(configuration)!={'confirm_id'}:
                        raise ValueError('Deletion requires exactly confirm_id for the selected study')
                    try:result=studies.delete(delete_match[1],configuration['confirm_id'])
                    except KeyError:self.reply(404,{'error':'study not found'});return
                    except OSError:self.reply(500,{'error':'Archive deletion failed; some files may have been removed. The catalog entry was retained for retry.'});return
                    self.reply(200,result)
                elif cancel_match:
                    if configuration!={}:raise ValueError('Cancellation body must be an empty object')
                    try:result=studies.cancel(cancel_match[1])
                    except KeyError:self.reply(404,{'error':'study not found'});return
                    self.reply(202,result)
                elif self.path=='/api/aircraft/carrier-studies':
                    self.reply(202,studies.start(configuration))
                elif self.path=='/api/aircraft/carrier-study-default':
                    if not isinstance(configuration,dict) or set(configuration)!={'definition','scenario','case'}:
                        raise ValueError('Study defaults require exactly definition, scenario and case')
                    from .aircraft_carrier_study import demonstration_spec,target_metadata,MAX_CASES,MAX_INTERVALS,MAX_FIELD_WORK
                    self.reply(200,dict(spec=demonstration_spec(configuration),targets=target_metadata(configuration),
                        limits=dict(max_cases=MAX_CASES,max_intervals=MAX_INTERVALS,max_field_work=MAX_FIELD_WORK)))
                elif self.path=='/api/aircraft/evaluate':
                    from .aircraft_workspace import evaluate_aircraft
                    self.reply(200,evaluate_aircraft(configuration))
                elif self.path=='/api/aircraft/carrier-trajectory':
                    if not isinstance(configuration,dict) or set(configuration)!={'definition','scenario','case'}:
                        raise ValueError('Carrier trajectory requires exactly definition, scenario and case')
                    if not transient_lock.acquire(blocking=False):
                        self.reply(409,{'error':'An aircraft analysis is already running'});return
                    try:
                        from .aircraft_carrier_trajectory import run_release
                        self.reply(200,run_release(**configuration))
                    finally:transient_lock.release()
                elif self.path=='/api/aircraft/carrier-release-preview':
                    if not isinstance(configuration,dict) or set(configuration)!={'definition','scenario'}:
                        raise ValueError('Carrier release preview requires definition and scenario')
                    from .aircraft_carrier_release import preview_release
                    self.reply(200,preview_release(configuration['definition'],configuration['scenario']))
                elif self.path=='/api/aircraft/longitudinal-analysis':
                    if not transient_lock.acquire(blocking=False):
                        self.reply(409,{'error':'An aircraft analysis is already running'});return
                    try:
                        from .aircraft_dynamic_analysis import run_dynamic_analysis
                        self.reply(200,run_dynamic_analysis(configuration))
                    finally:transient_lock.release()
                elif self.path=='/api/aircraft/cg-study':
                    if not isinstance(configuration,dict) or set(configuration)!={'definition','settings'}:
                        raise ValueError('CG study request requires definition and settings')
                    if not transient_lock.acquire(blocking=False):
                        self.reply(409,{'error':'An aircraft analysis is already running'});return
                    try:
                        from .aircraft_cg_study import run_cg_study
                        self.reply(200,run_cg_study(configuration['definition'],configuration['settings']))
                    finally:transient_lock.release()
                elif self.path in ('/api/aircraft/transient','/api/aircraft/release'):
                    if not transient_lock.acquire(blocking=False):
                        self.reply(409,{'error':'An aircraft transient is already running'});return
                    try:
                        if self.path=='/api/aircraft/release':
                            if not isinstance(configuration,dict) or set(configuration)!={'definition','settings'}:
                                raise ValueError('Release request requires definition and settings')
                            from .aircraft_release import run_release
                            from .aircraft_lateral import LateralModel
                            output=run_release(configuration['definition'],configuration['settings'])
                            from numpy.linalg import LinAlgError
                            try:
                                output['local_lateral_dynamics']=LateralModel(configuration['definition']).linearization()
                            except (ValueError,ArithmeticError,LinAlgError) as error:
                                output['local_lateral_dynamics']=dict(passed=False,classification='unavailable',
                                    eigenvalues_per_s=[],diagnostic=str(error),
                                    scope='Local linearization unavailable; accepted release history retained independently.')
                            output['scope']+=' Thrust and propulsive roll torque are held fixed; rotor relative spin, gyroscopic and propeller-slipstream effects are omitted.'
                            from .aircraft_elastic import digest
                            output.pop('history_sha256')
                            output['history_sha256']=digest(output)
                            self.reply(200,output)
                        else:
                            from .aircraft_transient import run_transient
                            self.reply(200,run_transient(configuration))
                    finally:transient_lock.release()
                else:self.reply(201,{'run_id':catalog.run(configuration)})
            except (ValueError,TypeError,KeyError,UnicodeError) as error:self.reply(400,{'error':str(error)})
            except RuntimeError as error:self.reply(409,{'error':str(error)})
            except OSError:self.reply(500,{'error':'local execution or export failed'})

        def do_PUT(self):
            if self.path.startswith(CONTROLLER_PREFIX) and not self.allowed():return
            self.reply(405,{'error':'method not allowed'})
        do_DELETE=do_PATCH=do_OPTIONS=do_PUT

    class DashboardServer(ThreadingHTTPServer):
        def server_close(self):
            workbench_api.studies.close()
            experiments.close()
            controllers.close()
            super().server_close()
    try:server=DashboardServer(('127.0.0.1',port),Handler)
    except BaseException:
        experiments.close();controllers.close();raise
    server.carrier_studies=studies
    server.controller_bench=controllers
    server.experiments=experiments
    server.controller_api=controller_api
    server.workbench_api=workbench_api
    return server


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',required=True,help='managed directory of saved benchmark runs')
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--envelope',type=Path,help='saved envelope archive to replay and review')
    parser.add_argument('--structural-review',type=Path,help='saved structural study with generated index.html')
    parser.add_argument('--aircraft-ensemble',type=Path,help='completed aircraft sensitivity ensemble archive')
    parser.add_argument('--carrier-studies',type=Path,help='managed carrier study directory; defaults to a sibling of --results')
    parser.add_argument('--controller-bench',type=Path,help='managed controller bench directory; defaults to a sibling of --results')
    parser.add_argument('--workbench',type=Path,help='saved glass-box workbench runs; defaults to a sibling of --results')
    args=parser.parse_args(argv)
    if not 0<=args.port<=65535:parser.error('port must be between 0 and 65535')
    try:
        envelope=None
        if args.envelope is not None:
            from .envelope_archive import EnvelopeCatalog
            print('Replaying envelope evidence before serving',flush=True)
            envelope=EnvelopeCatalog(args.envelope)
        review=None
        if args.structural_review is not None:
            from .saved_review import SavedStructuralReview
            review=SavedStructuralReview(args.structural_review)
        ensemble=None
        if args.aircraft_ensemble is not None:
            from .aircraft_ensemble_catalog import AircraftEnsembleCatalog
            ensemble=AircraftEnsembleCatalog(args.aircraft_ensemble)
        server=make_server(RunCatalog(args.results),args.port,envelope=envelope,structural_review=review,aircraft_ensemble=ensemble,carrier_study_root=args.carrier_studies,controller_bench_root=args.controller_bench,workbench_root=args.workbench)
    except (OSError,ValueError,RuntimeError) as error:parser.exit(2,f'dashboard startup failed: {error}\n')
    print(f'Flight-loads dashboard: http://127.0.0.1:{server.server_port}',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()


if __name__=='__main__':
    main()
