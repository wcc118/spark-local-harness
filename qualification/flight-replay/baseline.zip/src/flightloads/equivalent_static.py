"""Concurrent, same-model equivalent-static cases for the linear beam reference."""
from dataclasses import dataclass
import hashlib
import json
from numbers import Real
import re
from types import MappingProxyType
import numpy as np
from ._arrays import readonly_copy
from .beam import BeamHistory


# Absolute SI tolerances plus a common relative tolerance, always by physical field.
RTOL = 1e-8
UNITS = MappingProxyType(dict(displacement='m', slope='rad', cut_force='N', cut_moment='N m',
             stress_positive_z='Pa', stress_negative_z='Pa', root_force='N', root_moment='N m'))
ATOL = MappingProxyType({'m': 1e-12, 'rad': 1e-12, 'N': 1e-10, 'N m': 1e-10, 'Pa': 1e-4,
                        'dimensionless': 1e-10, 'sqrt(kg) m/s': 1e-10, 'sqrt(kg) m/s2': 1e-9})


def identifier(value):
    if not isinstance(value, str) or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,79}', value) is None:
        raise ValueError('identifier must be 1..80 ASCII letters, digits, dots, underscores or hyphens')
    return value


def check_pair(actual, expected, unit):
    actual, expected = np.asarray(actual), np.asarray(expected)
    error = float(np.max(abs(actual-expected)))
    limit = ATOL[unit] + RTOL*float(np.max(abs(expected)))
    return error, limit, unit


def require_close(actual, expected, unit, name):
    error, limit, _ = check_pair(actual, expected, unit)
    if not np.isfinite(error) or error > limit:
        raise ValueError(f'inconsistent history {name}: error {error} > {limit} {unit}')


@dataclass(frozen=True)
class Response:
    name: str
    quantity: str
    station_m: float | None = None
    side: str = 'right'

    def __post_init__(self):
        identifier(self.name)
        if self.quantity not in UNITS or self.side not in ('left', 'right'):
            raise ValueError('unsupported response quantity or element side')
        if self.quantity.startswith('root_'):
            if self.station_m is not None:
                raise ValueError('root reactions have no recovery station')
        elif isinstance(self.station_m, bool) or not isinstance(self.station_m, Real) or not np.isfinite(self.station_m):
            raise ValueError('a finite recovery station is required')

    @property
    def unit(self):
        return UNITS[self.quantity]

    def values(self, model, displacement, root_reaction):
        """One sample or a batch; root reactions are physical [Fz, My]."""
        if self.quantity.startswith('root_'):
            return np.asarray(root_reaction)[..., 0 if self.quantity == 'root_force' else 1]
        order = dict(displacement=0, slope=1, cut_force=3, cut_moment=2,
                     stress_positive_z=2, stress_negative_z=2)[self.quantity]
        row = model.shape(self.station_m, order=order, side=self.side)[2:]
        scale = 1.
        if self.quantity.startswith('cut_'):
            scale = model.EI_Nm2
        elif self.quantity.startswith('stress_'):
            scale = model.config['young_Pa']*model.config['thickness_m']/2
            if self.quantity == 'stress_positive_z':
                scale = -scale
        return np.asarray(displacement) @ row * scale


@dataclass(frozen=True)
class Interaction:
    """Explicit sum of squared normalized responses; no capacity/failure claim."""
    name: str
    responses: tuple[str, ...]
    scales: tuple[float, ...]

    def __post_init__(self):
        identifier(self.name)
        names, scales = tuple(self.responses), tuple(self.scales)
        if not names or len(names) != len(scales) or len(set(names)) != len(names):
            raise ValueError('interaction requires unique response names and matching scales')
        for name in names:
            identifier(name)
        if any(isinstance(x, bool) or not isinstance(x, Real) or not np.isfinite(x) or x <= 0 for x in scales):
            raise ValueError('interaction scales must be finite positive real values in response units')
        object.__setattr__(self, 'responses', names)
        object.__setattr__(self, 'scales', tuple(float(x) for x in scales))

    def values(self, histories):
        if any(name not in histories for name in self.responses):
            raise ValueError('interaction references an undeclared response')
        values = sum((np.asarray(histories[name])/scale)**2 for name, scale in zip(self.responses, self.scales))
        if not np.all(np.isfinite(values)):
            raise ValueError('nonfinite interaction response')
        return values


def reference_responses(model):
    return (Response('tip_w', 'displacement', model.nodes_m[-1]),
            Response('root_cut_Fz', 'cut_force', 0.), Response('root_cut_My', 'cut_moment', 0.),
            Response('root_stress', 'stress_positive_z', 0.),
            Response('mid_stress', 'stress_positive_z', model.nodes_m[-1]/2),
            Response('root_support_Fz', 'root_force'), Response('root_support_My', 'root_moment'))


def reference_interaction():
    return Interaction('root_bending_shear', ('root_cut_My', 'root_cut_Fz'), (.001, .001))


def select_extrema(responses, interactions=()):
    """Select first occurrence of each signed extremum and interaction maximum."""
    if not responses:
        raise ValueError('declare at least one response')
    lengths = set()
    for name, values in responses.items():
        identifier(name)
        values = np.asarray(values)
        if values.ndim != 1 or not len(values) or not np.all(np.isfinite(values)):
            raise ValueError('response histories must be finite nonempty vectors')
        lengths.add(len(values))
    if len(lengths) != 1:
        raise ValueError('response histories must share the time grid')
    selected = {}
    def add(index, reason):
        selected.setdefault(int(index), []).append(reason)
    for name, values in responses.items():
        add(np.argmin(values), name+':min')
        add(np.argmax(values), name+':max')
    names = set()
    for interaction in interactions:
        if not isinstance(interaction, Interaction) or interaction.name in names or interaction.name in responses:
            raise ValueError('interaction names must be unique and distinct from response names')
        names.add(interaction.name)
        add(np.argmax(interaction.values(responses)), interaction.name+':max')
    return tuple((index, tuple(reasons)) for index, reasons in sorted(selected.items()))


def validate_history(history):
    """Check schema and algebraic consistency, not physical validity or convergence."""
    if not isinstance(history, BeamHistory):
        raise ValueError('expected a BeamHistory')
    b = history.model; a = history.arrays; t = history.times_s
    b.residual_flexibility(history.retained_modes)  # validates retained count
    if type(history.residual_correction) is not bool:
        raise ValueError('invalid residual correction flag')
    dt = history.requested_dt_s
    if isinstance(dt, bool) or not isinstance(dt, Real) or not np.isfinite(dt) or dt <= 0:
        raise ValueError('invalid requested time step')
    if t.ndim != 1 or len(t) < 2 or not np.all(np.isfinite(t)) or t[0] != 0 or np.any(np.diff(t) <= 0):
        raise ValueError('invalid time grid')
    if not np.allclose(t[:-1], np.arange(len(t)-1)*dt, rtol=1e-12, atol=1e-14) or t[-1]-t[-2] > dt*(1+1e-12):
        raise ValueError('time grid disagrees with requested step')
    n, nf, nm, ns = len(t), len(b.mass_free), history.retained_modes, len(b.nodes_m)
    shapes = {k:(n,nm) for k in ('modal_q','modal_qdot','modal_qddot')}
    shapes.update({k:(n,nf) for k in ('displacement_free','velocity_free','acceleration_free',
                                    'effective_free','dynamic_residual_free','equivalent_free_load')})
    shapes.update(applied_full=(n,nf+2), base_accel=(n,2), root_reaction_z_N=(n,), root_reaction_y_Nm=(n,))
    shapes.update({k:(n,ns) for k in ('section_force_on_retained_z_N','section_moment_on_retained_y_Nm',
                                    'stress_positive_z_Pa','stress_negative_z_Pa')})
    if set(a) != set(shapes):
        raise ValueError('missing or unexpected beam history fields')
    for name, shape in shapes.items():
        if a[name].shape != shape or not np.all(np.isfinite(a[name])):
            raise ValueError('invalid history field '+name)
    u, v, acc = (a[k] for k in ('displacement_free','velocity_free','acceleration_free'))
    full_u = np.pad(u, ((0,0),(2,0)))
    full_acc = np.pad(acc, ((0,0),(2,0))) + a['base_accel'] @ b.rigid_map.T
    residual = full_acc @ b.mass_full.T + v @ b.damping_free.T @ b.elastic_extractor + full_u @ b.stiffness_full.T-a['applied_full']
    expected_eff = (a['applied_full']-a['base_accel'] @ b.rigid_map.T @ b.mass_full.T)[:,2:]
    for key, expected in (('effective_free',expected_eff), ('dynamic_residual_free',residual[:,2:]),
                          ('equivalent_free_load',u @ b.stiffness_free.T)):
        for offset, unit in ((0,'N'),(1,'N m')):
            require_close(a[key][:,offset::2], expected[:,offset::2], unit, key)
    require_close(a['root_reaction_z_N'], residual[:,0], 'N', 'root force')
    require_close(a['root_reaction_y_Nm'], -residual[:,1], 'N m', 'root moment')
    for quantity, key in (('cut_force','section_force_on_retained_z_N'),('cut_moment','section_moment_on_retained_y_Nm'),
                          ('stress_positive_z','stress_positive_z_Pa'),('stress_negative_z','stress_negative_z_Pa')):
        expected = np.column_stack([Response('check',quantity,x).values(b,u,None) for x in b.nodes_m])
        require_close(a[key], expected, UNITS[quantity], key)
    phi = b.modes[:,:nm]; H = b.residual_flexibility(nm) if history.residual_correction else np.zeros((nf,nf))
    expected_u = a['modal_q'] @ phi.T + a['effective_free'] @ H.T
    for offset, unit in ((0,'m'),(1,'rad')):
        require_close(u[:,offset::2],expected_u[:,offset::2],unit,'modal reconstruction')
    for key, physical, unit in (('modal_qdot',v,'sqrt(kg) m/s'),('modal_qddot',acc,'sqrt(kg) m/s2')):
        require_close(a[key],physical @ b.mass_free @ phi,unit,key)
    omega=b.omega_radps[:nm]
    expected_qddot=a['effective_free'] @ phi-2*b.config['damping_ratio']*omega*a['modal_qdot']-omega**2*a['modal_q']
    require_close(a['modal_qddot'],expected_qddot,'sqrt(kg) m/s2','modal equation')
    descriptor = dict(schema='beam-history-v1',model_id=b.model_id,retained_modes=int(nm),
                      residual_correction=history.residual_correction,dt_s=float(dt))
    digest = hashlib.sha256(json.dumps(descriptor,sort_keys=True).encode())
    for name, value in sorted(dict(times_s=t,**a).items()):
        digest.update(json.dumps([name,list(value.shape)]).encode())
        digest.update(np.asarray(value,dtype='<f8').tobytes())
    return digest.hexdigest()


@dataclass(frozen=True)
class EquivalentCase:
    model_id: str
    run_id: str
    source_digest: str
    index: int
    time_s: float
    reasons: tuple[str,...]
    components: object
    source_displacement: np.ndarray
    source_root_reaction: np.ndarray
    static_displacement: np.ndarray
    static_root_reaction: np.ndarray
    checks: object

    def __post_init__(self):
        for name in ('source_displacement','source_root_reaction','static_displacement','static_root_reaction'):
            object.__setattr__(self,name,readonly_copy(getattr(self,name)))
        object.__setattr__(self,'components',MappingProxyType({k:readonly_copy(v) for k,v in self.components.items()}))
        object.__setattr__(self,'checks',MappingProxyType(dict(self.checks)))
        object.__setattr__(self,'reasons',tuple(self.reasons))

    @property
    def verified(self):
        return all(np.isfinite(error) and error <= limit for error,limit,_ in self.checks.values())


def replay_case(case, model):
    if case.model_id != model.model_id:
        raise ValueError('case invalid for this model: regenerate after model changes')
    p = case.components['equivalent_full']
    u = model.static_displacement(p[2:])
    r = (model.stiffness_full @ np.r_[0.,0.,u]-p)[:2] * [1.,-1.]
    return u, readonly_copy(r)


@dataclass(frozen=True)
class EquivalentStudy:
    history: BeamHistory
    run_id: str
    source_digest: str
    responses: tuple[Response,...]
    interactions: tuple[Interaction,...]
    response_histories: object
    interaction_histories: object
    cases: tuple[EquivalentCase,...]

    def __post_init__(self):
        for name in ('response_histories','interaction_histories'):
            object.__setattr__(self,name,MappingProxyType({k:readonly_copy(v) for k,v in getattr(self,name).items()}))

    @property
    def verified(self):
        return bool(self.cases) and all(case.verified for case in self.cases)


def extract_cases(history, *, run_id, responses=None, interactions=()):
    identifier(run_id); digest = validate_history(history)
    b, a = history.model, history.arrays
    definitions = tuple(reference_responses(b) if responses is None else responses)
    if not definitions or any(not isinstance(x,Response) for x in definitions) or len({x.name for x in definitions}) != len(definitions):
        raise ValueError('declare unique response definitions')
    interactions = tuple(interactions)
    root = np.column_stack([a['root_reaction_z_N'],a['root_reaction_y_Nm']])
    values = {x.name:x.values(b,a['displacement_free'],root) for x in definitions}
    selected = select_extrema(values,interactions)
    interaction_values = {x.name:x.values(values) for x in interactions}
    cases = []
    for index,reasons in selected:
        u,v,acc = (a[k][index] for k in ('displacement_free','velocity_free','acceleration_free'))
        absolute = np.r_[0.,0.,acc]+b.rigid_map @ a['base_accel'][index]
        parts = dict(applied_full=a['applied_full'][index],negative_inertia_full=-b.mass_full @ absolute,
                     negative_damping_full=-b.elastic_extractor.T @ b.damping_free @ v,
                     residual_correction_full=np.r_[0.,0.,a['dynamic_residual_free'][index]])
        p = sum(parts.values()); parts['equivalent_full'] = p
        us = b.static_displacement(p[2:])
        rg = (b.stiffness_full @ np.r_[0.,0.,us]-p)[:2]; rs = rg * [1.,-1.]
        checks = dict(displacement=check_pair(us[::2],u[::2],'m'),rotation=check_pair(us[1::2],u[1::2],'rad'),
                      root_force=check_pair(rs[0],root[index,0],'N'),root_moment=check_pair(rs[1],root[index,1],'N m'))
        recovered = b.recover(us,b.nodes_m)
        for field,key,unit in (('shear_on_retained_z_N','section_force_on_retained_z_N','N'),
                               ('moment_on_retained_y_Nm','section_moment_on_retained_y_Nm','N m'),
                               ('stress_positive_z_Pa','stress_positive_z_Pa','Pa'),('stress_negative_z_Pa','stress_negative_z_Pa','Pa')):
            checks[field] = check_pair(recovered[field],a[key][index],unit)
        static_values = {x.name:x.values(b,us,rs) for x in definitions}
        for x in definitions:
            checks['response.'+x.name] = check_pair(static_values[x.name],values[x.name][index],x.unit)
        for x in interactions:
            checks['interaction.'+x.name] = check_pair(x.values(static_values),interaction_values[x.name][index],'dimensionless')
        balance = b.rigid_map.T @ (p+np.r_[rg,np.zeros(len(u))])
        checks['rigid_force'] = check_pair(balance[0],0.,'N')
        checks['rigid_moment'] = check_pair(balance[1],0.,'N m')
        cases.append(EquivalentCase(b.model_id,run_id,digest,index,float(history.times_s[index]),reasons,parts,u,root[index],us,rs,checks))
    return EquivalentStudy(history,run_id,digest,definitions,interactions,values,interaction_values,tuple(cases))
