"""Fully deployed plant shared by trim and sampled control; no control law here."""
from copy import deepcopy
import math
import numpy as np
from .aircraft_controller_contract import make_run_inputs, _number, _object, _json_values
from .aircraft_full_angle_field import default_controls
from .plant_aero import PlantAero
from .atmosphere import environment as isa_environment
from .propulsion import delivered
from .gusts import DiscreteGust, DrydenTurbulence, WindField
from .aircraft_transient import mass_quadrature, recover_imperial, IN_M, FT_M, LBF_N, IN_LBF_NM, G_N
from .aircraft_workspace import evaluate_aircraft
from .aircraft_release import quaternion_321
from .conventions import rotation_matrix
from .dynamics import rigid_derivative
from .loads import AppliedLoads
from .state import RigidState


class PlantDomainError(ValueError):
    """A force evaluation left the field's declared model domain."""


class ControllerPlant:
    def __init__(self, inputs):
        if type(inputs) is not dict or not {'definition','bench','field_case'} <= inputs.keys():
            raise ValueError('inputs requires a complete controller input envelope')
        _json_values(inputs, 'inputs')
        rebuilt = make_run_inputs(inputs['definition'],inputs['bench'],inputs['field_case'])
        if inputs != rebuilt:
            raise ValueError('inputs envelope/digest mismatch; reconstruct with make_run_inputs')
        self._inputs = rebuilt
        d = deepcopy(rebuilt['definition'])
        for key in ('flight_condition','transient_case','load_case'):
            d.pop(key,None)
        workspace = evaluate_aircraft(d)
        self._mp, self._components = workspace['mass_properties'], workspace['resolved_components']
        if self._mp is None:
            raise ValueError('Plant requires complete component mass inputs')
        try:
            self._mass = mass_quadrature(self._components)
            self._mass.require_rigid_inertia()
        except (ValueError, RuntimeError) as error:
            raise ValueError('Plant requires positive-definite usable inertia: '+str(error)) from error
        mp = self._mp
        if not (np.allclose(self._mass.cg_from_datum_B_m,np.array(mp['cg_B_in'])*IN_M,rtol=1e-10,atol=1e-12)
            and np.allclose(self._mass.inertia_CG_B_kg_m2,np.array(mp['inertia_CG'])*IN_LBF_NM,rtol=1e-10,atol=1e-12)
            and math.isclose(self._mass.mass_kg,mp['weight_lbf']*LBF_N/G_N[2],rel_tol=1e-12)):
            raise ValueError('Mass quadrature and workspace mass/CG/inertia disagree')
        self._wind = np.array(rebuilt['field_case']['wind_N_ft_s'],dtype=float)
        case = rebuilt['field_case']
        if 'aero_dataset' in case:
            from .aero_snapshot import snapshot_provider
            g = rebuilt['definition']['geometry']
            self._aero = PlantAero(snapshot_provider(case['aero_dataset'], rebuilt['definition']),
                                   [-g['prop_station_in'], 0., g['prop_z_in']])
        else:
            self._aero = PlantAero.strip_model(rebuilt['definition'], parameters=case['parameters'],
                settings=case['discretization'], installation=case['installation'])
        self._shaft_torque = default_controls()['prop_torque_in_lbf']
        self._atmosphere = case.get('atmosphere')
        self._propulsion = case.get('propulsion')
        self._wind_field = self._build_wind_field(case.get('gusts'))

    @property
    def inputs(self):
        return deepcopy(self._inputs)

    @property
    def mass_properties(self):
        return deepcopy(self._mp)

    @property
    def mass(self):
        return self._mass

    @property
    def propulsion(self):
        """Propeller-map parameters when field_case.propulsion is present (#209), else None."""
        return None if self._propulsion is None else dict(self._propulsion)

    @property
    def aero_dataset(self):
        """Identity of the aero dataset driving this plant (id, digest, evidence level)."""
        return dict(self._aero.identity)

    def initial_state(self, alpha_deg, roll_deg):
        _number(alpha_deg,-30,30,'alpha_deg')
        _number(roll_deg,-45,45,'roll_deg')
        target = self._inputs['bench']['target']
        alpha, roll = math.radians(alpha_deg), math.radians(roll_deg)
        speed = target['airspeed_ft_s']
        A, B = speed*math.cos(alpha), speed*math.cos(roll)*math.sin(alpha)
        C = math.hypot(A,B)
        if abs(self._wind[2]) > C:
            raise ValueError('Vertical wind exceeds the level-flight airspeed projection')
        pitch = math.atan2(B,A) + math.asin(self._wind[2]/C)
        if abs(pitch) > math.radians(60):
            raise ValueError('pitch exceeds the +/-60 degree trim branch')
        q = quaternion_321(roll,pitch,math.radians(target['heading_deg']))
        air = np.array([speed*math.cos(alpha),0.,speed*math.sin(alpha)])
        ground = air + rotation_matrix(q).T @ self._wind
        return RigidState([0.,0.,-target['height_agl_ft']*FT_M],ground*FT_M,q,[0.,0.,0.])

    def _build_wind_field(self, gusts):
        """Steady wind plus optional gusts (#208); None when only steady wind applies."""
        if gusts is None:
            return None
        target, timing = self._inputs['bench']['target'], self._inputs['bench']['timing']
        heading = math.radians(target['heading_deg'])
        axis = [math.cos(heading), math.sin(heading), 0.0]
        discrete = turbulence = None
        if gusts['discrete'] is not None:
            g = gusts['discrete']
            discrete = DiscreteGust(g['amplitude_ft_s'], g['gradient_length_ft'], g['direction_N'], axis,
                                    [0.0, 0.0, -target['height_agl_ft']], g['onset_distance_ft'])
        if gusts['turbulence'] is not None:
            t = gusts['turbulence']
            turbulence = DrydenTurbulence(t['sigma_ft_s'], t['scale_length_ft'], target['airspeed_ft_s'],
                                          t['sample_period_s'], timing['duration_s'], t['seed'], axis)
        return WindField(self._wind, discrete, turbulence)

    def wind_N_ft_s(self, state, time_s=None):
        """Ground-referenced wind at the CG: steady, plus gusts when field_case.gusts is present.

        time_s=None means the steady wind only (trim and equilibrium searches); simulation
        passes its stage times so gusts and turbulence apply.
        """
        if self._wind_field is None or time_s is None:
            return self._wind
        return self._wind_field.velocity_N(time_s, state.r_CG_N_m/FT_M)

    def environment_at(self, state):
        """Uniform field_case environment, or ISA at field elevation + height above ground (#207)."""
        if self._atmosphere is None:
            return self._inputs['field_case']['environment']
        height_ft = -float(state.r_CG_N_m[2])/FT_M
        return isa_environment(self._atmosphere['field_elevation_ft'] + height_ft,
                               self._atmosphere['temperature_offset_R'])

    def evaluate(self, state, controls, time_s=None):
        keys = ('left_tail_deg','right_tail_deg','aileron_deg','thrust_lbf')
        _object(controls,keys,'controls')
        bench = self._inputs['bench']
        for key,name in zip(keys[:3],('left_tail','right_tail','aileron')):
            limits = bench['actuators'][name]
            _number(controls[key],limits['min_deg'],limits['max_deg'],'controls.'+key)
        _number(controls['thrust_lbf'],bench['target']['trim_thrust_min_lbf'],
            bench['target']['trim_thrust_max_lbf'],'controls.thrust_lbf')
        air = state.v_CG_B_mps/FT_M - rotation_matrix(state.q_NB).T @ self.wind_N_ft_s(state, time_s)
        thrust, torque, propulsion = controls['thrust_lbf'], self._shaft_torque, None
        if self._propulsion is not None:
            thrust, torque, available, saturated = delivered(controls['thrust_lbf'], float(air[0]), self._propulsion)
            propulsion = dict(commanded_thrust_lbf=controls['thrust_lbf'], delivered_thrust_lbf=thrust,
                available_thrust_lbf=available, shaft_torque_in_lbf=torque, saturated=saturated)
        field = self._aero.evaluate(air,state.omega_B_radps,self._mp['cg_B_in'],
            left_tail_deg=controls['left_tail_deg'],right_tail_deg=controls['right_tail_deg'],
            aileron_deg=controls['aileron_deg'],thrust_lbf=thrust,
            shaft_torque_in_lbf=torque,environment=self.environment_at(state))
        if propulsion is not None:
            field['propulsion'] = propulsion
        if not field['within_assumed_domain']:
            raise PlantDomainError('; '.join(field['domain_violations']))
        rows = field['ledger']
        applied = AppliedLoads(np.array([np.array(r['position_B_in'])-self._mp['cg_B_in'] for r in rows])*IN_M,
            np.array([r['force_B_lbf'] for r in rows])*LBF_N,
            np.array([r['free_couple_B_in_lbf'] for r in rows])*IN_LBF_NM,tuple(r['name'] for r in rows))
        return field, applied, rigid_derivative(state,self._mass,applied,G_N)

    def recover(self, state, field, derivative, time_s=0, cut=None):
        """Balanced concurrent recovery; `cut` ({station_in, retain}) overrides the definition's cut (#213)."""
        _number(time_s,0,float('inf'),'time_s')
        acceleration = derivative.vdot_B_mps2 + np.cross(state.omega_B_radps,state.v_CG_B_mps)
        definition = self._inputs['definition'] if cut is None else dict(self._inputs['definition'], cut=dict(cut))
        result = recover_imperial(definition,self._components,self._mp['cg_B_in'],
            acceleration/IN_M,derivative.omegadot_B_radps2,state.omega_B_radps,
            rotation_matrix(state.q_NB).T@G_N/IN_M,self._recovery_ledger(field['ledger'],definition),time_s)
        if self.aero_dataset.get('load_resolution') == 'component-resultant':
            result.update(load_resolution='component-resultant',
                          cut_interpretation='Lumped-resultant numerical diagnostic only; distributed plane-cut loads are unresolved and excluded from station envelopes.')
        return result

    def _recovery_ledger(self, ledger, definition=None):
        d = self._inputs['definition'] if definition is None else definition; cut = d['cut']['station_in']
        ds = d['geometry']['fuselage_length_in']/self._inputs['field_case']['discretization']['body_strips']
        rows = []
        for source in ledger:
            station = -source['position_B_in'][0]; lo,hi = station-ds/2,station+ds/2
            if source['kind']=='body-crossflow' and lo < cut < hi:
                for a,b,label in ((lo,cut,'fore'),(cut,hi,'aft')):
                    row = deepcopy(source)
                    row.update(name=source['name']+' '+label+' cut-bin portion',
                        position_B_in=[-(a+b)/2,0.,0.],
                        force_B_lbf=(np.array(source['force_B_lbf'])*(b-a)/ds).tolist())
                    rows.append(row)
            else:
                rows.append(source)
        return rows
