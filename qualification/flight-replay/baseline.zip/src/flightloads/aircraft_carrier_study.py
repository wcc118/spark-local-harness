"""Reproducible linked-uniform carrier studies; no aircraft failure probabilities."""
from copy import deepcopy
import hashlib
import math
from pathlib import Path
import re
import numpy as np
from .aircraft_elastic import digest
from .aircraft_carrier_release import validate_scenario, scenario_metadata
from .aircraft_carrier_trajectory import run_release, _case, _Context
from .aircraft_full_angle_field import FullAngleField, default_controls, field_metadata
from .aircraft_workspace import validate_definition
from .aircraft_input_limits import POSITION_BOUNDS, WEIGHT_BOUNDS, _unit

SCHEMA='carrier-study-v1'
SAMPLER='sha256-cohort-index-variable-top53-v1'
MAX_CASES=96
# Budget expanded based on DGX Spark measurements: supports 14-case 2s/0.005s study (5600 intervals)
MAX_INTERVALS=16000
MAX_FIELD_WORK=8000000
COHORTS=('mandatory','monte-carlo','heldout')
TERMINAL=('completed','stopped','initial-rejected','initialization-failed','execution-failed')
LIMITATIONS=[
    'Uniform bounds and links are declared analyst assumptions, not measured distributions or solver-validity bounds.',
    'Different named latent variables are independent pseudorandom draws. Shared variables impose perfect affine rank links; reverse gives the opposite direction. General copulas and partial correlation matrices are not supported.',
    'Mandatory cases and held-out draws are separate cohorts; never pool them into Monte Carlo sample counts. Held-out cases are not calibration data.',
    'Computational completion is not physical capture, stability, strength or flight safety. No physical failure probability is estimated.',
    'Stopped-run maxima cover accepted samples only. Full requested-horizon maxima are unknown; any continuation retaining those samples has maxima at least as large.',
    'Complete-only empirical metrics are conditional on computational completion. Confidence intervals cover sampling error of completion frequency under declared IID inputs, not numerical error or model validation.',
    'Convergence intervals are pointwise, not simultaneous bands or an adaptive stopping guarantee. Numerical timestep/grid refinement is separate.',
]


def _object(value,keys,label):
    if not isinstance(value,dict) or set(value)!=set(keys):raise ValueError(label+' requires exactly '+', '.join(keys))


def _text(value,label,maximum=1000):
    if not isinstance(value,str) or not value.strip() or len(value)>maximum:raise ValueError(label+' must be nonblank text within '+str(maximum)+' characters')


def _integer(value,lo,hi,label):
    if type(value) is not int or not lo<=value<=hi:raise ValueError(f'{label} must be an integer in [{lo},{hi}]')


def _identifier(value,label):
    if not isinstance(value,str) or not re.fullmatch('[a-z][a-z0-9-]{0,39}',value):raise ValueError(label+' requires a lowercase identifier (1–40 characters)')


def _input_structure(inputs):
    _object(inputs,('definition','scenario','case'),'Study input envelope')
    validate_definition(inputs['definition']);validate_scenario(inputs['scenario']);c=_case(inputs['case'])
    # Validate model shape/bounds separately from sampled held-control combinations and usable inertia.
    FullAngleField(inputs['definition'],parameters=c['parameters'],environment=c['environment'],
        settings=c['discretization'],controls=dict(default_controls(),**c['installation']))


def target_metadata(base):
    """Allowlisted physical targets, resolved by component ID, never array index or aircraft CG."""
    _input_structure(base);m=field_metadata();rows=[]
    def add(target,lo,hi,value,label):
        rows.append(dict(target=target,minimum=lo,maximum=hi,value=value,label=label,unit=_unit(target['field'])))
    for key,field in scenario_metadata()['fields'].items():
        lo,hi=field['min'],field['max']
        if key in m['groups']['controls']:
            bound=m['groups']['controls'][key];lo=max(lo,bound['min']);hi=min(hi,bound['max'])
        add(dict(group='scenario',field=key),lo,hi,base['scenario'][key],field['label'])
    for group,fields in [('parameters',m['parameters']['fields']),('environment',m['groups']['environment'])]:
        for key,field in fields.items():add(dict(group=group,field=key),field['min'],field['max'],base['case'][group][key],key)
    for component in base['definition']['components']:
        add(dict(group='component',id=component['id'],field='weight_lbf'),*WEIGHT_BOUNDS,component['weight_lbf'],component['name']+' weight')
        geometric=component.get('cg_source','manual')=='geometry'
        for key in (('forward_station_in','left_y_in','top_z_in') if geometric else ('station_in','y_in','z_in')):
            source=component.get('placement',{}) if geometric else component
            add(dict(group='placement' if geometric else 'component',id=component['id'],field=key),*POSITION_BOUNDS,source.get(key),component['name']+' '+key)
    return rows


def _set_target(inputs,target,value):
    group=target['group'];key=target['field']
    if group=='scenario':inputs['scenario'][key]=value
    elif group in ('parameters','environment'):inputs['case'][group][key]=value
    else:
        component=next(c for c in inputs['definition']['components'] if c['id']==target['id'])
        (component['placement'] if group=='placement' else component)[key]=value


def validate_spec(spec):
    _object(spec,('schema_version','name','source','base','seed','monte_carlo_count','heldout_count','variables','mandatory'),'Study')
    _integer(spec['schema_version'],1,1,'schema_version');_text(spec['name'],'name',200);_text(spec['source'],'source')
    _integer(spec['seed'],0,2**32-1,'seed');_integer(spec['monte_carlo_count'],1,64,'monte_carlo_count');_integer(spec['heldout_count'],1,32,'heldout_count')
    _input_structure(spec['base']);_Context(**spec['base'])
    targets={digest(row['target']):row for row in target_metadata(spec['base'])}
    if not isinstance(spec['variables'],list) or not 1<=len(spec['variables'])<=16:raise ValueError('Require 1–16 named uniform variables')
    identifiers=set();used=set()
    for variable in spec['variables']:
        _object(variable,('id','source','distribution','bindings'),'Variable');_identifier(variable['id'],'variable id');_text(variable['source'],'variable source')
        if variable['id'] in identifiers:raise ValueError('Duplicate variable id')
        identifiers.add(variable['id'])
        if variable['distribution']!='uniform':raise ValueError('Only explicitly linked uniform variables are supported')
        if not isinstance(variable['bindings'],list) or not 1<=len(variable['bindings'])<=128:raise ValueError('Require 1–128 bindings per variable')
        for binding in variable['bindings']:
            _object(binding,('target','lower','upper','reverse'),'Binding');key=digest(binding['target'])
            if key not in targets or key in used:raise ValueError('Unknown, inactive or duplicate physical target')
            used.add(key);meta=targets[key]
            if type(binding['reverse']) is not bool:raise ValueError('reverse must be boolean')
            lo,hi=binding['lower'],binding['upper']
            if any(type(v) not in (int,float) or not math.isfinite(v) for v in (lo,hi)) or not meta['minimum']<=lo<hi<=meta['maximum']:
                raise ValueError('Binding bounds must increase within target numerical input bounds')
    mandatory=spec['mandatory']
    if not isinstance(mandatory,list) or not 1<=len(mandatory)<=8:raise ValueError('Require 1–8 deterministic mandatory cases')
    identifiers=set();costs=[(spec['base'],spec['monte_carlo_count']+spec['heldout_count'])]
    for item in mandatory:
        _object(item,('id','label','source','inputs'),'Mandatory case');_identifier(item['id'],'mandatory id');_text(item['label'],'mandatory label',200);_text(item['source'],'mandatory source')
        if item['id'] in identifiers:raise ValueError('Duplicate mandatory id')
        identifiers.add(item['id']);_input_structure(item['inputs']);costs.append((item['inputs'],1))
    intervals=work=0
    for inputs,count in costs:
        c=inputs['case'];steps=math.ceil(c['integration']['duration_s']/c['integration']['dt_s']);d=c['discretization']
        elements=2*d['wing_strips']+2*d['tail_strips']+d['body_strips']+8
        intervals+=count*steps;work+=count*(5*steps+3)*elements
    if sum(n for _,n in costs)>MAX_CASES or intervals>MAX_INTERVALS or work>MAX_FIELD_WORK:
        raise ValueError(f'Study budget exceeds limits: requested {sum(n for _,n in costs)} cases, {intervals} intervals, {work} field-element evaluations; allowed {MAX_CASES}, {MAX_INTERVALS}, {MAX_FIELD_WORK}, respectively')
    return deepcopy(spec)


def demonstration_spec(base):
    """Explicit invented study; never an inferred uncertainty calibration."""
    _input_structure(base);_Context(**base);base=deepcopy(base)
    def variable(identifier,bindings):return dict(id=identifier,distribution='uniform',source='Invented demonstration bounds; not measured launch or manufacturing uncertainty',bindings=bindings)
    def binding(group,field,lo,hi,**extra):return dict(target=dict(group=group,field=field,**extra),lower=lo,upper=hi,reverse=False)
    variables=[]
    for field,span,bounds in [('carrier_tas_kts',10,(0,1000)),('relative_yaw_deg',10,(-180,180))]:
        v=base['scenario'][field];variables.append(variable(field.replace('_','-'),[binding('scenario',field,max(bounds[0],v-span),min(bounds[1],v+span))]))
    weights=[binding('component','weight_lbf',max(WEIGHT_BOUNDS[0],c['weight_lbf']*.95),min(WEIGHT_BOUNDS[1],c['weight_lbf']*1.05),id=c['id']) for c in base['definition']['components']]
    variables.append(variable('linked-weight-scale',weights))
    reference=deepcopy(base);reference['case']['environment'].update(density_slug_ft3=0.,source='Manufactured vacuum reference, not weather')
    for key in ('thrust_lbf','prop_torque_in_lbf','p_deg_s','q_deg_s','r_deg_s'):reference['scenario'][key]=0.
    spec=dict(schema_version=1,name='Illustrative carrier uncertainty study',source='Explicit invented sensitivity example; edit sources and bounds before interpreting',base=base,seed=2026,
        monte_carlo_count=8,heldout_count=4,variables=variables,mandatory=[
            dict(id='nominal',label='Nominal input case',source='Deterministic copy of loaded inputs; not a random draw',inputs=deepcopy(base)),
            dict(id='vacuum-reference',label='Manufactured vacuum reference',source='Zero density, thrust, torque and initial rates; independent ballistic reference',inputs=reference)])
    return validate_spec(spec)


def uniform_draw(seed,cohort,index,variable_id):
    """53-bit [0,1) lattice, keyed independently of iteration order and ambient RNG."""
    raw=bytes.fromhex(digest([SCHEMA,seed,cohort,index,variable_id]))
    return (int.from_bytes(raw[:8],'big')>>11)/2**53


def make_plan(spec):
    spec=validate_spec(spec);rows=[]
    def row(identifier,cohort,index,label,source,inputs,draws):
        return dict(id=identifier,cohort=cohort,index=index,label=label,source=source,inputs=deepcopy(inputs),input_sha256=digest(inputs),draws=draws,status='not-started')
    for i,item in enumerate(spec['mandatory']):rows.append(row('mandatory-'+item['id'],'mandatory',i,item['label'],item['source'],item['inputs'],{}))
    for cohort,count in [('monte-carlo',spec['monte_carlo_count']),('heldout',spec['heldout_count'])]:
        for i in range(count):
            inputs=deepcopy(spec['base']);draws={}
            for variable in spec['variables']:
                u=uniform_draw(spec['seed'],cohort,i,variable['id']);values=[]
                for b in variable['bindings']:
                    v=b['lower']+(b['upper']-b['lower'])*(1-u if b['reverse'] else u)
                    _set_target(inputs,b['target'],v);values.append(dict(target=deepcopy(b['target']),value=v))
                draws[variable['id']]=dict(u=u,source=variable['source'],values=values)
            rows.append(row(f'{cohort}-{i:04d}',cohort,i,f'{cohort} draw {i}',spec['source'],inputs,draws))
    return dict(schema=SCHEMA,spec=spec,spec_sha256=digest(spec),sampler=SAMPLER,
        implementation_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),samples=rows,limitations=list(LIMITATIONS))


def event_metrics(report):
    frames=report['snapshots'];out={}
    getters={}
    for kind,unit in [('force','lbf'),('moment','in_lbf')]:
        for i,axis in enumerate('xyz'):
            getters[f'peak_abs_cut_{kind}_{axis}_{unit}']=lambda f,i=i,kind=kind,unit=unit:abs(f['loads'][f'cut_{kind}_B_{unit}'][i])
    for i,axis in enumerate('pqr'):getters[f'peak_abs_{axis}_deg_s']=lambda f,i=i:abs(f['angular_velocity_B_deg_s'][i])
    for angle in ('alpha','beta'):getters[f'peak_abs_{angle}_deg']=lambda f,angle=angle:None if f[angle+'_deg'] is None else abs(f[angle+'_deg'])
    origin=frames[0]['position_N_ft'] if frames else [0.,0.,0.]
    getters['max_height_loss_ft']=lambda f:max(0.,f['position_N_ft'][2]-origin[2])
    getters['max_horizontal_displacement_ft']=lambda f:math.hypot(f['position_N_ft'][0]-origin[0],f['position_N_ft'][1]-origin[1])
    for key,getter in getters.items():
        pairs=[(getter(f),f['time_s']) for f in frames];pairs=[p for p in pairs if p[0] is not None]
        peak=max(pairs,key=lambda p:p[0]) if pairs else None
        out[key]=None if peak is None else dict(value=peak[0],time_s=peak[1])
    return dict(values=out,scope='full-requested-horizon' if report['status']=='completed' else 'accepted-prefix-only',
        full_horizon_known=report['status']=='completed',requested_duration_s=report['requested_duration_s'],accepted_duration_s=report['accepted_duration_s'])


def execute_sample(sample):
    """One immutable planned input -> retained result/error; invalid draws are never replaced."""
    if sample.get('input_sha256')!=digest(sample.get('inputs')):raise ValueError('Planned sample input checksum mismatch')
    out=deepcopy(sample);out.update(report=None,metrics=None,event=None,error=None,cloud=[])
    try:
        report=run_release(**out['inputs'])
    except (ValueError,np.linalg.LinAlgError) as error:
        out.update(status='initialization-failed',error=str(error));return out
    except Exception as error:
        out.update(status='execution-failed',error=type(error).__name__+': '+str(error));return out
    try:
        out.update(status=report['status'],report=report,event=report['event'],metrics=event_metrics(report),
            cloud=[dict(time_s=f['time_s'],position_N_ft=f['position_N_ft']) for f in report['snapshots']])
    except Exception as error:
        out.update(status='execution-failed',error='Report processing: '+type(error).__name__+': '+str(error))
    return out


def binomial_interval(successes,n,confidence=.95):
    """Exact equal-tailed Clopper-Pearson, finite binomial CDF inversion (NIST)."""
    _integer(n,0,MAX_CASES,'n');_integer(successes,0,n,'successes')
    if type(confidence) not in (int,float) or not 0<confidence<1:raise ValueError('Confidence must lie strictly between zero and one')
    if n==0:return None
    alpha=1-confidence
    def root(k,target):
        lo,hi=0.,1.
        for _ in range(80):
            p=(lo+hi)/2
            cdf=math.fsum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k+1))
            if cdf>target:lo=p
            else:hi=p
        return (lo+hi)/2
    return [0. if successes==0 else root(successes-1,1-alpha/2),1. if successes==n else root(successes,alpha/2)]


def _statistics(rows):
    counts={status:sum(r['status']==status for r in rows) for status in ('not-started','running',*TERMINAL)}
    if sum(counts.values())!=len(rows):raise ValueError('Unknown sample execution state')
    n=len(rows);usable=n>0 and not any(counts[k] for k in ('not-started','running','execution-failed'))
    complete=[r for r in rows if r['status']=='completed'];metrics={}
    for r in complete:
        for key,value in r['metrics']['values'].items():
            if value is not None:metrics.setdefault(key,[]).append(value['value'])
    quantiles={key:dict(n=len(v),mean=float(np.mean(v)),p05=float(np.quantile(v,.05)),p50=float(np.quantile(v,.5)),p95=float(np.quantile(v,.95))) for key,v in metrics.items()}
    reasons={}
    for r in rows:
        reason=(r.get('event') or {}).get('kind') or (r['status'] if r['status']!='completed' else None)
        if reason:reasons[reason]=reasons.get(reason,0)+1
    return dict(requested=n,attempted=n-counts['not-started'],counts=counts,reasons=reasons,
        completion_fraction=len(complete)/n if usable else None,completion_interval_95=binomial_interval(len(complete),n) if usable else None,
        sampling_complete=usable,complete_only_metrics=quantiles,conditioning='Empirical metrics conditional on completed requested duration; per-metric n excludes undefined angles. No quantile confidence claim.')


def summarize(samples):
    if len({r['id'] for r in samples})!=len(samples) or any(r['cohort'] not in COHORTS for r in samples):
        raise ValueError('Duplicate sample identity or unknown cohort')
    for cohort in COHORTS:
        indices=sorted(r['index'] for r in samples if r['cohort']==cohort)
        if indices!=list(range(len(indices))):raise ValueError('Each cohort requires unique contiguous planned indices')
    result={}
    for cohort in COHORTS:
        rows=sorted([r for r in samples if r['cohort']==cohort],key=lambda r:r['index']);summary=_statistics(rows);summary['convergence']=[]
        if cohort=='mandatory':summary.update(completion_fraction=None,completion_interval_95=None,sampling_complete=None)
        else:
            for n,row in enumerate(rows,1):
                if row['status'] not in TERMINAL or row['status']=='execution-failed':break
                point=_statistics(rows[:n]);summary['convergence'].append(dict(n=n,completion_fraction=point['completion_fraction'],completion_interval_95=point['completion_interval_95'],complete_only_metrics=point['complete_only_metrics']))
        result[cohort]=summary
    return dict(cohorts=result,total_requested=len(samples),limitations=list(LIMITATIONS),confidence_method='Exact equal-tailed Clopper-Pearson 95%; computational completion only; independent cohort draws; pointwise intervals')
