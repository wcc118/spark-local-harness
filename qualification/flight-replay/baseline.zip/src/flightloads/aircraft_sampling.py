"""Versioned, assumed physical-component sensitivity inputs; no calibrated probability."""
from copy import deepcopy
import itertools
from numbers import Integral,Real
import numpy as np
from .aircraft_workspace import stable_example_definition
from .aircraft_elastic import digest

SPEC=dict(schema='aircraft-physical-sampling-v1',
    latents=dict(U='Uniform[-1,1]',V='Uniform[-1,1]',W='Uniform[-1,1]',independent=True),
    transform=dict(battery_weight_lbf='6*(1+0.05*U)',payload_weight_lbf='5*(1+0.05*(0.6*U+0.8*V)/1.4)',
        battery_station_in='3+0.25*W',payload_station_in=0.,battery_payload_correlation=.6,
        payload_marginal='bounded convolution, not uniform'),
    condition=dict(speed_ft_s=200.,height_ft=1000.,duration_s=.2,pulse_window_s=[.03,.07],
        paired_pulses_deg=[.25,-.25],nominal_zero_pulse=True,trim='each realization before imposing pulse'),
    structural=dict(wing_weight_lbf=3.,young_psi=2e6,damping_ratio=.02,elements=32,modes=64,
        rigid_dt_s=.00025,elastic_dt_s=.0005),
    provenance='Assumed sensitivity distributions; physical-versus-knowledge uncertainty split unknown. No calibrated probability claim.',
    fixed='Other stable-example components and geometry; illustrative aerodynamic coefficients remain fixed and unvalidated.')
SPEC_ID=digest(SPEC)


def realize(latents):
    if not isinstance(latents,(list,tuple,np.ndarray)) or len(latents)!=3:raise ValueError('three latents required')
    for value in latents:
        if isinstance(value,(bool,np.bool_)) or not isinstance(value,Real) or not np.isfinite(value) or not -1<=value<=1:
            raise ValueError('latents must be finite real values in [-1,1]')
    u,v,w=map(float,latents);definition=deepcopy(stable_example_definition())
    components={c['id']:c for c in definition['components']}
    components['battery']['weight_lbf']=6*(1+.05*u)
    components['battery']['station_in']=3+.25*w
    components['payload']['weight_lbf']=5*(1+.05*(.6*u+.8*v)/1.4)
    return definition


def sample(seed,index,partition='train'):
    for value,maximum,name in ((seed,2**64-1,'seed'),(index,2**30-1,'index')):
        if isinstance(value,(bool,np.bool_)) or not isinstance(value,Integral) or not 0<=value<=maximum:
            raise ValueError('invalid '+name)
    if partition not in ('train','heldout'):raise ValueError('invalid partition')
    seed,index=int(seed),int(index)
    sequence=np.random.SeedSequence(seed,spawn_key=(0 if partition=='train' else 1,index))
    values=np.random.Generator(np.random.PCG64(sequence)).uniform(-1,1,3)
    result=dict(schema='aircraft-physical-sample-v1',spec_identity=SPEC_ID,partition=partition,
        seed=seed,index=index,latents=dict(zip(('U','V','W'),map(float,values))),definition=realize(values))
    result['input_id']=digest(result)
    return result


def mandatory():
    values=[(0.,0.,0.),*itertools.product((-1.,1.),repeat=3)]
    return [dict(name='nominal' if i==0 else f'corner-{i}',
        latents=dict(zip(('U','V','W'),v)),definition=realize(v)) for i,v in enumerate(values)]
