"""Synthetic conditional event ensembles; probabilities describe the assumed model."""
from dataclasses import dataclass
import hashlib
import json
import math
from numbers import Integral, Real
from types import MappingProxyType
import numpy as np
from ._arrays import readonly_copy
from .beam import BeamModel, BeamHistory, Excitation, integrate_modal, smooth_pulse, vector
from .equivalent_static import validate_history, reference_responses, reference_interaction

EVENT_UNITS=MappingProxyType(dict(tip_abs_w='m',root_stress_max='Pa',root_stress_negative_max='Pa',root_bending_shear='dimensionless'))


def integer(value,name,low,high):
    if isinstance(value,bool) or not isinstance(value,Integral) or not low<=value<=high:
        raise ValueError(f'{name} must be integer {low}..{high}')
    return int(value)


def probability(value,name):
    if isinstance(value,bool) or not isinstance(value,Real) or not np.isfinite(value) or not 0<value<1:
        raise ValueError(f'{name} must be a finite probability strictly between zero and one')
    return float(value)


@dataclass(frozen=True,init=False)
class SamplingSpec:
    family: str
    location: np.ndarray
    scale: np.ndarray
    correlation: np.ndarray
    transform: np.ndarray

    def __init__(self,*,family='normal',location=(1.,1.,1.),scale=(.1,.1,.1),correlation=None):
        if family not in ('normal','uniform'):raise ValueError('supported families are normal and independent uniform')
        loc=vector(location,3,'location');width=vector(scale,3,'scale')
        if np.any(width<=0):raise ValueError('scales must be positive')
        corr=np.eye(3) if correlation is None else np.asarray(correlation,dtype=float)
        if corr.shape!=(3,3) or not np.all(np.isfinite(corr)) or not np.allclose(corr,corr.T,rtol=0,atol=1e-14) or not np.allclose(np.diag(corr),1.,rtol=0,atol=1e-14):
            raise ValueError('correlation must be finite symmetric 3x3 with unit diagonal')
        if np.any(abs(corr)>1):raise ValueError('correlation outside [-1,1]')
        if family=='uniform' and not np.array_equal(corr,np.eye(3)):
            raise ValueError('only independent uniforms are supported; no implicit copula')
        corr=(corr+corr.T)/2
        try:transform=np.linalg.cholesky(corr)
        except np.linalg.LinAlgError as exc:raise ValueError('correlation must be positive definite') from exc
        if np.linalg.cond(corr)>1e12:raise ValueError('correlation is numerically ill-conditioned')
        for name,value in dict(location=loc,scale=width,correlation=corr,transform=transform).items():
            object.__setattr__(self,name,readonly_copy(value))
        object.__setattr__(self,'family',family)

    def metadata(self):
        return dict(family=self.family,location=self.location.tolist(),scale=self.scale.tolist(),
            scale_meaning='standard deviation' if self.family=='normal' else 'uniform half-width',
            correlation=self.correlation.tolist(),input_order=['tip','mid','base'],units='dimensionless amplitude multipliers',
            provenance='synthetic assumptions, not vehicle uncertainty evidence')

    def sample(self,master_seed,index):
        seed=integer(master_seed,'master_seed',0,2**64-1);index=integer(index,'index',0,2**32-1)
        sequence=np.random.SeedSequence(seed,spawn_key=(index,))
        words=tuple(int(x) for x in sequence.generate_state(4))
        rng=np.random.Generator(np.random.PCG64(sequence))
        z=self.transform @ rng.standard_normal(3) if self.family=='normal' else rng.uniform(-1.,1.,3)
        return vector(self.location+self.scale*z,3,'sampled amplitudes'),words


def order_confidences(n,coverage):
    """Confidence at ranks 1..n; exact for continuous IID populations, conservative with atoms."""
    n=integer(n,'sample count',1,10000);p=probability(coverage,'coverage')
    # Start at the binomial mode: outward recurrences avoid factorial overflow/underflow.
    mode=min(n,int((n+1)*p));weights=[0.]*(n+1);weights[mode]=1.
    for i in range(mode,n):weights[i+1]=weights[i]*(n-i)/(i+1)*p/(1-p)
    for i in range(mode,0,-1):weights[i-1]=weights[i]*i/(n-i+1)*(1-p)/p
    total=math.fsum(weights)
    result=np.cumsum(np.asarray(weights)/total)[:-1]
    # Exact maximum-rank identity also keeps the important upper tail well resolved.
    result=np.minimum(result,-math.expm1(n*math.log(p)))
    result[-1]=-math.expm1(n*math.log(p))
    return readonly_copy(result)


def event_statistics(values,*,coverage=.95,confidence=.95,threshold=None):
    values=np.asarray(values,dtype=float)
    if values.ndim!=1 or not 1<=len(values)<=10000 or not np.all(np.isfinite(values)):
        raise ValueError('event statistics require a finite nonempty vector of independent event observations')
    p=probability(coverage,'coverage');c=probability(confidence,'confidence')
    if threshold is not None and (isinstance(threshold,bool) or not isinstance(threshold,Real) or not np.isfinite(threshold)):
        raise ValueError('threshold must be finite real')
    ordered=np.sort(values);bounds=order_confidences(len(values),p);ranks=np.flatnonzero(bounds>=c)
    rank=int(ranks[0]+1) if len(ranks) else None
    return dict(sample_count=len(values),coverage=p,requested_confidence=c,
        empirical_quantile=float(ordered[math.ceil(p*len(values))-1]),quantile_method='inverted empirical CDF',
        tolerance_status='available' if rank is not None else 'insufficient_sample_size',
        tolerance_rank=rank,tolerance_upper=float(ordered[rank-1]) if rank is not None else None,
        achieved_confidence=float(bounds[rank-1]) if rank is not None else None,
        confidence_at_sample_max=float(bounds[-1]),threshold=None if threshold is None else float(threshold),
        exceedances=None if threshold is None else int(np.count_nonzero(values>threshold)),
        exceedance_fraction=None if threshold is None else float(np.mean(values>threshold)))


def scaled_forcing(model,t,amplitudes):
    amp=vector(amplitudes,3,'amplitudes')
    tip=smooth_pulse(t,duration=.5);mid=smooth_pulse(t,start=.15,duration=.65);base=smooth_pulse(t,duration=.8)
    ft=model.point_load(model.nodes_m[-1],force_N=.001)*amp[0]
    fm=model.point_load(model.nodes_m[-1]/2,force_N=-.0006)*amp[1]
    f=[ft*tip[k]+fm*mid[k] for k in range(3)]
    return Excitation(model,f[0],applied_rate_full=f[1],applied_accel_full=f[2],
        base_accel=(.02*amp[2]*base[0],0.),base_jerk=(.02*amp[2]*base[1],0.),base_snap=(.02*amp[2]*base[2],0.))


@dataclass(frozen=True)
class ResponseBasis:
    histories: tuple[BeamHistory,...]
    digests: tuple[str,...]
    basis_id: str

    @property
    def model(self):return self.histories[0].model

    def reconstruct(self,amplitudes):
        amp=vector(amplitudes,3,'amplitudes');first=self.histories[0]
        arrays={k:amp[0]*self.histories[0].arrays[k]+amp[1]*self.histories[1].arrays[k]+amp[2]*self.histories[2].arrays[k] for k in first.arrays}
        return BeamHistory(first.model,first.retained_modes,first.residual_correction,first.requested_dt_s,first.times_s,arrays)


def make_basis(*,damping_ratio=.02,dt_s=.001,t_final_s=4.,retained_modes=4):
    model=BeamModel(damping_ratio=damping_ratio);histories=[]
    for amp in np.eye(3):
        histories.append(integrate_modal(model,lambda t:scaled_forcing(model,t,amp),dt_s=dt_s,
            t_final_s=t_final_s,retained_modes=retained_modes,residual_correction=True))
    return checked_basis(histories)


def checked_basis(histories):
    """Validate saved/reloaded basis histories before reconstruction; hashes are recomputed."""
    histories=tuple(histories)
    if len(histories)!=3:raise ValueError('a tip/mid/base basis needs exactly three histories')
    digests=tuple(validate_history(h) for h in histories);first=histories[0]
    for h in histories[1:]:
        if h.model.model_id!=first.model.model_id or h.retained_modes!=first.retained_modes or h.residual_correction!=first.residual_correction or h.requested_dt_s!=first.requested_dt_s or not np.array_equal(h.times_s,first.times_s):
            raise ValueError('basis models, integration settings and grids must agree')
    pulses=np.array([[smooth_pulse(t,duration=.5)[0],smooth_pulse(t,start=.15,duration=.65)[0],
                      smooth_pulse(t,duration=.8)[0]] for t in first.times_s])
    model=first.model
    fields=(model.point_load(model.nodes_m[-1],force_N=.001),
            model.point_load(model.nodes_m[-1]/2,force_N=-.0006),np.zeros(len(model.mass_full)))
    for j,h in enumerate(histories):
        expected=pulses[:,j,None]*fields[j]
        base=np.zeros((len(h.times_s),2))
        if j==2:base[:,0]=.02*pulses[:,2]
        if not np.allclose(h.arrays['applied_full'],expected,rtol=1e-12,atol=1e-14) or not np.allclose(h.arrays['base_accel'],base,rtol=1e-12,atol=1e-14):
            raise ValueError('basis forcing does not match its tip/mid/base identity')
        q,v,a=(h.arrays[k] for k in ('modal_q','modal_qdot','modal_qddot'))
        if np.any(q[0]!=0) or np.any(v[0]!=0):raise ValueError('reference bases require zero initial modal state')
        step=np.diff(h.times_s)[:,None]
        if not np.allclose(q[1:],q[:-1]+step*v[:-1]+step**2/4*(a[:-1]+a[1:]),rtol=1e-9,atol=1e-12) or not np.allclose(v[1:],v[:-1]+step/2*(a[:-1]+a[1:]),rtol=1e-9,atol=1e-12):
            raise ValueError('basis history violates Newmark kinematics')
    identity=hashlib.sha256(json.dumps(dict(schema='linear-amplitude-basis-v1',digests=digests,
        combination='a0*tip+a1*mid+a2*base, left associative for every history field')).encode()).hexdigest()
    return ResponseBasis(histories,digests,identity)


def event_histories(history):
    root=np.column_stack([history.arrays['root_reaction_z_N'],history.arrays['root_reaction_y_Nm']])
    values={r.name:r.values(history.model,history.arrays['displacement_free'],root) for r in reference_responses(history.model)}
    return MappingProxyType({k:readonly_copy(v) for k,v in dict(tip_abs_w=abs(values['tip_w']),
        root_stress_max=values['root_stress'],root_stress_negative_max=-values['root_stress'],
        root_bending_shear=reference_interaction().values(values)).items()})


@dataclass(frozen=True)
class Trial:
    index: int
    seed_words: tuple[int,...]
    amplitudes: np.ndarray | None
    status: str
    diagnostic: str | None
    history_digest: str | None
    maxima: object
    peak_indices: object
    peak_times_s: object

    def __post_init__(self):
        object.__setattr__(self,'seed_words',tuple(self.seed_words))
        if self.amplitudes is not None:object.__setattr__(self,'amplitudes',readonly_copy(self.amplitudes))
        for name in ('maxima','peak_indices','peak_times_s'):
            object.__setattr__(self,name,MappingProxyType(dict(getattr(self,name))))

    def metadata(self):
        return dict(index=self.index,seed_words=list(self.seed_words),amplitudes=None if self.amplitudes is None else self.amplitudes.tolist(),
            status=self.status,diagnostic=self.diagnostic,history_digest=self.history_digest,
            maxima=dict(self.maxima),peak_indices=dict(self.peak_indices),peak_times_s=dict(self.peak_times_s))


@dataclass(frozen=True)
class Ensemble:
    basis: ResponseBasis
    sampling: SamplingSpec
    master_seed: int
    trials: tuple[Trial,...]

    def __post_init__(self):object.__setattr__(self,'trials',tuple(self.trials))

    @property
    def complete(self):return bool(self.trials) and all(t.status=='completed' for t in self.trials)

    def statistics(self,*,coverage=.95,confidence=.95,thresholds=None,prefix=None):
        count=len(self.trials) if prefix is None else integer(prefix,'prefix',1,len(self.trials))
        trials=self.trials[:count]
        if any(t.status!='completed' for t in trials):return None
        # Prefixes are the original requested sequence, never a filtered success subset.
        thresholds={} if thresholds is None else thresholds
        if set(thresholds)-set(EVENT_UNITS):raise ValueError('unknown event threshold')
        return {name:event_statistics([t.maxima[name] for t in trials],coverage=coverage,confidence=confidence,
            threshold=thresholds.get(name)) for name in EVENT_UNITS}

    def replay(self,index):
        index=integer(index,'trial index',0,len(self.trials)-1);trial=self.trials[index]
        if trial.status!='completed':raise ValueError('cannot replay a failed trial as a completed event')
        amp,words=self.sampling.sample(self.master_seed,index)
        if words!=trial.seed_words or not np.array_equal(amp,trial.amplitudes):raise ValueError('sample identity mismatch')
        history=self.basis.reconstruct(amp)
        if validate_history(history)!=trial.history_digest:raise ValueError('reconstructed history digest mismatch')
        for name,values in event_histories(history).items():
            i=int(np.argmax(values))
            if trial.index!=index or trial.peak_indices.get(name)!=i or trial.peak_times_s.get(name)!=float(history.times_s[i]) or trial.maxima.get(name)!=float(values[i]):
                raise ValueError('recorded event maximum does not match reconstructed history')
        return history


def run_ensemble(basis,sampling,*,master_seed=20260907,count=64):
    count=integer(count,'trial count',1,10000);seed=integer(master_seed,'master_seed',0,2**64-1)
    if not isinstance(basis,ResponseBasis) or not isinstance(sampling,SamplingSpec):raise ValueError('expected checked basis and sampling specification')
    verified=checked_basis(basis.histories)
    if verified.basis_id!=basis.basis_id or verified.digests!=basis.digests:raise ValueError('basis identity mismatch')
    trials=[];first=basis.histories[0]
    for index in range(count):
        amp=None;words=();digest=None;maxima={};indices={};times={};diagnostic=None
        try:
            with np.errstate(over='raise',invalid='raise',divide='raise'):
                amp,words=sampling.sample(seed,index)
                history=basis.reconstruct(amp)
                digest=validate_history(history)
                if history.model.model_id!=basis.model.model_id or not np.array_equal(history.times_s,first.times_s) or history.retained_modes!=first.retained_modes or history.residual_correction!=first.residual_correction or history.requested_dt_s!=first.requested_dt_s:
                    raise ValueError('trial returned a different model or time/modal configuration')
                for name,values in event_histories(history).items():
                    i=int(np.argmax(values));maxima[name]=float(values[i]);indices[name]=i;times[name]=float(history.times_s[i])
                status='completed'
        except (ValueError,RuntimeError,ArithmeticError,np.linalg.LinAlgError) as exc:
            status='invalid' if isinstance(exc,ValueError) else 'failed';diagnostic=f'{type(exc).__name__}: {exc}'
            digest=None;maxima={};indices={};times={}
        trials.append(Trial(index,words,amp,status,diagnostic,digest,maxima,indices,times))
    return Ensemble(basis,sampling,seed,tuple(trials))


def reference_study(*,count=64,master_seed=20260907):
    spec=SamplingSpec(correlation=((1.,.4,0.),(.4,1.,0.),(0.,0.,1.)))
    return tuple(run_ensemble(make_basis(damping_ratio=z),spec,count=count,master_seed=master_seed) for z in (.01,.02,.04))
