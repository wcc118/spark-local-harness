"""Archive one reproduced aircraft case with its complete verified source files."""
import argparse
import gzip
import hashlib
import json
import subprocess
from pathlib import Path
from .aircraft_elastic import digest
from .aircraft_equivalent import extract_case,replay_case

MAX_BYTES=64*1024*1024
NAMES=('study.json','pilot.json.gz','rigid-source.json.gz')


def read_json(raw):
    return json.loads(raw,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite JSON')))


def source_files(directory):
    root=Path(directory).resolve();raw={}
    for name in NAMES:
        path=root/name
        if path.is_symlink() or path.stat().st_size>MAX_BYTES:
            raise ValueError('source artifact path or size invalid')
        raw[name]=path.read_bytes()
    study=read_json(raw['study.json'])
    if study.get('schema')!='aircraft-wing-study-v1' or study.get('verification_passed') is not True:
        raise ValueError('source study is not numerically qualified')
    if study.get('artifacts')!={'pilot':'pilot.json.gz','rigid_source':'rigid-source.json.gz'}:
        raise ValueError('unexpected source artifact mapping')
    objects={}
    for name in NAMES[1:]:
        if hashlib.sha256(raw[name]).hexdigest()!=study['provenance']['artifact_sha256'][name]:
            raise ValueError('source artifact hash mismatch')
        # Stream through a bounded decompressor rather than gzip.decompress.
        import io
        with gzip.GzipFile(fileobj=io.BytesIO(raw[name])) as stream:
            decoded=stream.read(MAX_BYTES+1)
        if len(decoded)>MAX_BYTES:raise ValueError('expanded source exceeds size bound')
        objects[name]=read_json(decoded)
    pilot=objects['pilot.json.gz'];rigid=objects['rigid-source.json.gz']
    if pilot['source_history_sha256']!=digest(rigid):raise ValueError('rigid source identity mismatch')
    if pilot['source_input_sha256']!=digest(pilot['definition']):raise ValueError('aircraft input identity mismatch')
    if study['pilot_summary']['history_sha256']!=pilot['history_sha256']:
        raise ValueError('study/pilot identity mismatch')
    indices=pilot['inputs']['source_indices']
    if len(indices)!=len(pilot['concurrent_rigid_snapshots']):raise ValueError('source index count mismatch')
    for index,snapshot in zip(indices,pilot['concurrent_rigid_snapshots']):
        if type(index) is not int or not 0<=index<len(rigid['snapshots']):raise ValueError('invalid rigid source index')
        if snapshot!=rigid['snapshots'][index]:raise ValueError('concurrent source snapshot mismatch')
    return raw,study,pilot


def save_case(source_directory,output_directory):
    raw,study,pilot=source_files(source_directory)
    case=extract_case(pilot)
    package=Path(__file__).parent;root=package.parent.parent
    try:
        commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
        dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip())
    except (subprocess.CalledProcessError,FileNotFoundError):commit='unavailable';dirty=None
    code={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in package.glob('*.py')}
    record=dict(schema='aircraft-equivalent-static-archive-v1',case=case,
        producer_provenance=dict(commit=commit,dirty=dirty,source_sha256=code),
        source_provenance=study['provenance'],
        source_artifact_sha256={name:hashlib.sha256(data).hexdigest() for name,data in raw.items()})
    record['archive_sha256']=digest(record)
    output=Path(output_directory);output.mkdir(parents=True,exist_ok=False)
    for name,data in raw.items():(output/name).write_bytes(data)
    (output/'equivalent-static.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    return record


def replay_archive(directory):
    raw,study,pilot=source_files(directory)
    path=Path(directory)/'equivalent-static.json'
    if path.is_symlink() or path.stat().st_size>MAX_BYTES:raise ValueError('case path or size invalid')
    record=read_json(path.read_bytes());payload=dict(record);identity=payload.pop('archive_sha256')
    if record.get('schema')!='aircraft-equivalent-static-archive-v1' or digest(payload)!=identity:
        raise ValueError('equivalent archive identity mismatch')
    expected={name:hashlib.sha256(data).hexdigest() for name,data in raw.items()}
    if record['source_artifact_sha256']!=expected or record['source_provenance']!=study['provenance']:
        raise ValueError('equivalent source provenance mismatch')
    replay_case(record['case'],pilot)
    return record


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path,help='saved structural study directory')
    parser.add_argument('--output',type=Path,help='new equivalent-static archive directory')
    args=parser.parse_args(argv)
    try:
        record=save_case(args.source,args.output) if args.output else replay_archive(args.source)
        print('Equivalent-static archive verified: '+record['archive_sha256'])
    except (ValueError,TypeError,KeyError,OSError) as error:parser.exit(2,f'archive failed: {error}\n')


if __name__=='__main__':main()
