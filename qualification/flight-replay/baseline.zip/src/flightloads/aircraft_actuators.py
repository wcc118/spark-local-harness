"""Per-surface delayed targets and pure continuous rate-limited segments."""
from dataclasses import dataclass
import math
import numpy as np
from .aircraft_controller import _setup, _vector, SURFACES, CONTROL_KEYS
from .aircraft_controller_contract import _number


@dataclass(frozen=True)
class ActuatorSegment:
    _tick: int
    _dt: float
    _start: tuple
    _target: tuple
    _rates: tuple
    _requested: tuple | None
    _travel: tuple
    _pending: tuple

    def at(self, elapsed_s):
        _number(elapsed_s,0,self._dt,'elapsed_s')
        return [float(target if abs(target-start)<=rate*elapsed_s else
                      start+math.copysign(rate*elapsed_s,target-start))
                for start,target,rate in zip(self._start,self._target,self._rates)]

    def as_dict(self):
        end = self.at(self._dt)
        return dict(tick=self._tick,time_s=self._tick*self._dt,duration_s=self._dt,
            start_deg=list(self._start),target_deg=list(self._target),end_deg=end,
            rate_deg_s=list(self._rates),requested_surface_deg=None if self._requested is None else list(self._requested),
            travel_limited=list(self._travel),rate_limited=[a!=b for a,b in zip(end,self._target)],
            pending_commands=list(self._pending))


class ActuatorBank:
    def __init__(self, bench, trim_controls):
        self._bench, controls, self._low, self._high = _setup(bench,trim_controls)
        self._trim = [float(controls[k]) for k in CONTROL_KEYS[:3]]
        self._dt = self._bench['timing']['plant_dt_s']
        self._rates = tuple(float(self._bench['actuators'][n]['rate_deg_s']) for n in SURFACES)
        self._delays = [round(self._bench['actuators'][n]['delay_s']/self._dt) for n in SURFACES]
        self.reset()

    def reset(self):
        self._next_tick = 0
        self._actual, self._target = self._trim.copy(), self._trim.copy()
        self._queues = [[],[],[]]

    def snapshot(self):
        return dict(next_tick=self._next_tick,next_actual_deg=self._actual.copy(),target_deg=self._target.copy(),
            queued_commands=[[[tick,value] for tick,value in queue] for queue in self._queues])

    def plan_interval(self, tick, command=None):
        if type(tick) is not int or tick != self._next_tick:
            raise ValueError('Expected actuator plant tick '+str(self._next_tick))
        requested = None if command is None else _vector(command,3,'command')
        limited = None if requested is None else np.clip(requested,self._low,self._high)
        # All caller validation precedes queue/state mutation.
        if limited is not None:
            for i,value in enumerate(limited): self._queues[i].append((tick+self._delays[i],float(value)))
        for i,queue in enumerate(self._queues):
            while queue and queue[0][0]<=tick: self._target[i] = queue.pop(0)[1]
        segment = ActuatorSegment(tick,float(self._dt),tuple(self._actual),tuple(self._target),self._rates,
            None if requested is None else tuple(requested.tolist()),
            (False,False,False) if requested is None else tuple((limited!=requested).tolist()),
            tuple(len(q) for q in self._queues))
        self._actual, self._next_tick = segment.at(self._dt), tick+1
        return segment
