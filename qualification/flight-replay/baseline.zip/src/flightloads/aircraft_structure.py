"""Illustrative moving-root wing bending; imperial boundary, SI beam reference.

eta points outward on the right wing; w points body +z. Relative slope is
rotation about +x, so the reference beam's physical My becomes -Mx here.
See docs/mechanics/AIRCRAFT_STRUCTURE.md before interpreting nominal stresses.
"""
from dataclasses import dataclass
import hashlib
import json
from numbers import Real, Integral
import numpy as np
from .beam import BeamModel
from .aircraft_workspace import G_IN_S2, resolve_components, validate_definition

IN_M = .0254
LBF_N = 4.4482216152605
MOMENT_NM = IN_M * LBF_N
PSI_PA = LBF_N / IN_M**2


def number(value, name, *, positive=False):
    if isinstance(value, bool) or not isinstance(value, Real) or not np.isfinite(value):
        raise ValueError(name+' must be a finite real number')
    if positive and value <= 0:
        raise ValueError(name+' must be positive')
    return float(value)


def vector(value, name):
    a = np.asarray(value)
    if (a.dtype.kind not in 'iuf' or a.shape != (3,) or not np.all(np.isfinite(a))
            or any(isinstance(x, (bool, np.bool_)) for x in np.asarray(value, dtype=object).flat)):
        raise ValueError(name+' must be a finite real three-vector')
    return np.array(a, dtype=float)


def generalized_imperial(values):
    """Alternating force lbf / slope-conjugate couple in-lbf, not one unit."""
    a = np.array(values, dtype=float, copy=True)
    a[..., ::2] /= LBF_N
    a[..., 1::2] /= MOMENT_NM
    return a.tolist()


@dataclass(frozen=True)
class WingBeam:
    length_in: float = 24.
    width_in: float = 4.
    thickness_in: float = .48
    young_psi: float = 1e6
    weight_lbf: float = 3.
    elements: int = 16
    damping_ratio: float = .02

    def __post_init__(self):
        for key in ('length_in', 'width_in', 'thickness_in', 'young_psi', 'weight_lbf'):
            object.__setattr__(self, key, number(getattr(self, key), key, positive=True))
        if isinstance(self.elements, bool) or not isinstance(self.elements, Integral) or not 1 <= self.elements <= 32:
            raise ValueError('elements must be integer 1..32')
        zeta = number(self.damping_ratio, 'damping_ratio')
        if not 0 <= zeta <= .2:
            raise ValueError('damping_ratio must lie in 0..0.2')
        object.__setattr__(self, 'damping_ratio', zeta)
        object.__setattr__(self, 'elements', int(self.elements))
        volume = self.length_in*self.width_in*self.thickness_in*IN_M**3
        mass = self.weight_lbf*LBF_N/(G_IN_S2*IN_M)
        b = BeamModel(length_m=self.length_in*IN_M, width_m=self.width_in*IN_M,
            thickness_m=self.thickness_in*IN_M, young_Pa=self.young_psi*PSI_PA,
            density_kgpm3=mass/volume, elements=self.elements, damping_ratio=zeta)
        object.__setattr__(self, 'beam', b)
        config = {k: getattr(self, k) for k in self.__dataclass_fields__}
        config['elements'] = int(config['elements'])
        digest = hashlib.sha256(json.dumps(config, sort_keys=True).encode()+b.model_id.encode()).hexdigest()
        object.__setattr__(self, 'model_id', 'imperial-wing-v1:'+digest)

    @property
    def EI_lbf_in2(self):
        return self.young_psi*self.width_in*self.thickness_in**3/12

    @property
    def mass_per_length_lbf_s2_in2(self):
        return self.weight_lbf/G_IN_S2/self.length_in

    def recover(self, displacement_free_m_rad, stations_in=None):
        b = self.beam
        stations = b.nodes_m/IN_M if stations_in is None else np.asarray(stations_in)
        if stations.dtype.kind not in 'iuf' or stations.ndim != 1:
            raise ValueError('stations_in must be a real vector')
        r = b.recover(displacement_free_m_rad, stations*IN_M)
        return dict(eta_in=stations.tolist(), w_in=(r['displacement_m']/IN_M).tolist(),
            slope_deg=np.degrees(r['slope_rad']).tolist(),
            cut_Fz_lbf=(r['shear_on_retained_z_N']/LBF_N).tolist(),
            cut_Mx_in_lbf=(-r['moment_on_retained_y_Nm']/MOMENT_NM).tolist(),
            stress_positive_z_psi=(r['stress_positive_z_Pa']/PSI_PA).tolist(),
            stress_negative_z_psi=(r['stress_negative_z_Pa']/PSI_PA).tolist())

    def uniform_case(self, aero_lbf_per_in, *, gravity_z_in_s2=G_IN_S2, root_accel_z_in_s2=0.):
        aero = number(aero_lbf_per_in, 'aero_lbf_per_in')
        gravity = number(gravity_z_in_s2, 'gravity_z_in_s2')
        accel = number(root_accel_z_in_s2, 'root_accel_z_in_s2')
        b = self.beam
        p_aero = b.uniform_load(aero*LBF_N/IN_M)
        p_gravity = b.mass_full@b.rigid_map[:, 0]*(gravity*IN_M)
        p_inertia = -b.mass_full@b.rigid_map[:, 0]*(accel*IN_M)
        applied = p_aero+p_gravity
        effective = applied+p_inertia
        u = b.static_displacement(effective[2:])
        reaction = (b.stiffness_full@np.r_[0., 0., u]-effective)[:2]
        return dict(model_id=self.model_id, nodes_in=(b.nodes_m/IN_M).tolist(),
            generalized_units='even entries lbf; odd entries in-lbf conjugate to +x slope',
            aero_full=generalized_imperial(p_aero), gravity_full=generalized_imperial(p_gravity),
            negative_rigid_inertia_full=generalized_imperial(p_inertia),
            applied_full=generalized_imperial(applied), effective_full=generalized_imperial(effective),
            root_Fz_lbf=float(reaction[0]/LBF_N), root_Mx_in_lbf=float(reaction[1]/MOMENT_NM),
            response=self.recover(u), scope='Illustrative linear wing bending; no torsion/local strength prediction')


def from_aircraft(definition, *, young_psi=1e6, elements=16, damping_ratio=.02):
    """Require the two uniform wing boxes to match the declared geometry exactly."""
    validate_definition(definition)
    g = definition['geometry']
    cs = {c['id']: c for c in resolve_components(definition)}
    panels = [cs.get('wing-'+side) for side in ('left', 'right')]
    if any(c is None for c in panels):
        raise ValueError('both wing component boxes are required')
    L = g['wing_exposed_span_in']/2
    for side, c in zip((-1, 1), panels):
        if c['model'] != 'box' or c['weight_lbf'] is None:
            raise ValueError('complete uniform wing box mass is required')
        expected = dict(length_in=g['wing_chord_in'], width_in=L,
            station_in=g['wing_le_station_in']+g['wing_chord_in']/2,
            y_in=side*(g['wing_root_spacing_in']/2+L/2), z_in=g['wing_z_in'])
        if any(c[k] is None or abs(c[k]-v)>1e-8 for k, v in expected.items()):
            raise ValueError('wing mass box must match exposed panel geometry and centroid')
    if any(abs(panels[0][k]-panels[1][k])>1e-8 for k in ('weight_lbf', 'height_in')):
        raise ValueError('wing mass and thickness must be symmetric')
    if abs(g['wing_load_y_in'])>1e-8:
        raise ValueError('wing aerodynamic source must be on centerline')
    return WingBeam(length_in=L, width_in=g['wing_chord_in'], thickness_in=panels[1]['height_in'],
        weight_lbf=panels[1]['weight_lbf'], young_psi=young_psi, elements=elements, damping_ratio=damping_ratio)


def resultant(rows, origin):
    force, moment = np.zeros(3), np.zeros(3)
    for row in rows:
        f = np.asarray(row['force_B_lbf'])
        force += f
        moment += np.cross(np.asarray(row['position_B_in'])-origin, f)+row['free_couple_B_in_lbf']
    return np.r_[force, moment]


def transfer_wing_load(source, *, panel_span_in=24., root_spacing_in=6.,
        beam_station_in=12., beam_z_in=-3., cg_B_in=(0., 0., 0.), quadrature_order=4):
    """Uniform symmetric span assumption, then chord/z transfer at the SAME y.

    Quadrature weights integrate a force density, not an inferred pressure field.
    Complete 3-D ledgers preserve omitted Fx and My, while only Fz drives bending.
    """
    L = number(panel_span_in, 'panel_span_in', positive=True)
    spacing = number(root_spacing_in, 'root_spacing_in')
    if spacing < 0:
        raise ValueError('root_spacing_in must be nonnegative')
    station = number(beam_station_in, 'beam_station_in')
    z = number(beam_z_in, 'beam_z_in')
    cg = vector(cg_B_in, 'cg_B_in')
    if isinstance(quadrature_order, bool) or not isinstance(quadrature_order, Integral) or not 2 <= quadrature_order <= 16:
        raise ValueError('quadrature_order must be integer 2..16')
    if not isinstance(source, dict) or not all(k in source for k in ('position_B_in', 'force_B_lbf', 'free_couple_B_in_lbf')):
        raise ValueError('source requires position, force and free couple')
    r, f, c = (vector(source[k], k) for k in ('position_B_in', 'force_B_lbf', 'free_couple_B_in_lbf'))
    if max(abs(r[1]), abs(f[1]), abs(c[0]), abs(c[2])) > 1e-10:
        raise ValueError('source outside symmetric longitudinal scope')
    points, weights = np.polynomial.legendre.leggauss(quadrature_order)
    aero_rows, axis_rows = [], []
    for side in (-1, 1):
        for point, weight in zip(points, weights):
            eta = L*(point+1)/2
            y = side*(spacing/2+eta)
            ra, rb = np.array([r[0], y, r[2]]), np.array([-station, y, z])
            fq, cq = f*weight/4, c*weight/4
            shifted = cq+np.cross(ra-rb, fq)
            row = dict(side='right' if side==1 else 'left', eta_in=float(eta),
                force_B_lbf=fq.tolist(), free_couple_B_in_lbf=cq.tolist(), position_B_in=ra.tolist())
            aero_rows.append(row)
            axis_rows.append({**row, 'position_B_in': rb.tolist(), 'free_couple_B_in_lbf': shifted.tolist(),
                'omitted_force_B_lbf': [float(fq[0]), float(fq[1]), 0.],
                'omitted_couple_B_in_lbf': shifted.tolist()})
    checks = {}
    for name, origin in (('nose', np.zeros(3)), ('CG', cg)):
        expected = resultant([source], origin)
        for label, rows in (('distributed_aero', aero_rows), ('beam_axis', axis_rows)):
            error = resultant(rows, origin)-expected
            checks[label+'_'+name] = error.tolist()
            if max(abs(error[:3]))>1e-8 or max(abs(error[3:]))>1e-7:
                raise ValueError('wing force/moment transfer failed')
    digest = hashlib.sha256(json.dumps(dict(source=source, axis_rows=axis_rows, cg=cg.tolist()),
        sort_keys=True, allow_nan=False).encode()).hexdigest()
    return dict(schema_version=1, source_sha256=digest, aerodynamic_rows=aero_rows, beam_axis_rows=axis_rows,
        transfer_residuals=checks, right_uniform_Fz_lbf_per_in=float(f[2]/(2*L)),
        scope='Assumed uniform span distribution; Fx and My retained but no corresponding stress response')
