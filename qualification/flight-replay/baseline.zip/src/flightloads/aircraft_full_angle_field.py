"""Located exploratory full-angle blade elements and tapered-body crossflow.

Air-relative body velocity enters this field. Ground-relative propagation and
wind subtraction are the caller's responsibility. Gravity/inertia are separate.
"""
from copy import deepcopy
import hashlib
import math
from pathlib import Path
import numpy as np
from .aircraft_workspace import validate_definition
from .aircraft_full_angle_polar import (validate_parameters, default_parameters,
    parameter_metadata, _section_polar, component_comparison)
from .aircraft_elastic import digest

MODEL_ID = 'exploratory-full-angle-blade-body-v1'
MAX_MACH = .35
MAX_REYNOLDS = 3e6
ZERO_SPEED = 1e-10
ENVIRONMENT = {'density_slug_ft3':(0.,.004,.0023769),
    'viscosity_slug_ft_s':(1e-7,1e-6,3.737e-7),'sound_speed_ft_s':(800.,1200.,1116.45)}
CONTROLS = {'wing_incidence_deg':(-30.,30.,0.),'tail_incidence_deg':(-30.,30.,0.),
    'common_tail_deg':(-90.,90.,0.),'differential_tail_deg':(-90.,90.,0.),
    'aileron_deg':(-45.,45.,0.),'thrust_lbf':(0.,100.,0.),'prop_torque_in_lbf':(-100.,100.,0.)}
SETTINGS = {'wing_strips':(1,64,8),'tail_strips':(1,64,4),'body_strips':(1,64,16),
    'aileron_effectiveness':(0.,1.,.35)}
LIMITATIONS = [
    'Exploratory quasi-steady component model; no measured complete-aircraft or NACA4412 validation, stability, capture or strength acceptance.',
    'Low/high-angle coefficients and transition are analyst assumptions with retained component-data discrepancies. No dynamic stall, wake, interference or shielding model.',
    'Uniform chord-normal-plane strip polars neglect full three-dimensional spanwise-flow coupling. Edge drag uses an assumed chord-times-thickness area per panel.',
    'Ailerons use assumed whole-chord equivalent incidence only over their actual span; no measured full-angle effectiveness or hinge/deflected-geometry model.',
    'Body is an assumed linear circular taper from forward to aft diameter, with constant side-area Cd; drag crisis, shedding and end/taper interactions are not modeled.',
    'Constant-coefficient continuation to zero Reynolds keeps vanishing loads continuous; below/above published Re coverage it is unvalidated, not a creeping-flow model.',
    'Empirical quarter-chord pitching couples may exchange rotational work. Nonpositive drag power alone is not a total-energy or aircraft-validation claim.',
    'Fixed propulsive thrust/shaft torque only; no rotor gyroscopic, propeller inflow/slipstream, contact, deployment or carrier wake forces.',
]


def _defaults(bounds):return {k:v[2] for k,v in bounds.items()}


def default_environment():
    return dict(**_defaults(ENVIRONMENT),source='Analyst sea-level example, not measured weather')


def default_controls():return _defaults(CONTROLS)


def default_settings():return _defaults(SETTINGS)


def _validate(values,bounds,name,source=False):
    expected=set(bounds)|({'source'} if source else set())
    if not isinstance(values,dict) or set(values)!=expected:raise ValueError(name+' requires exactly the documented fields')
    for key,(lo,hi,_) in bounds.items():
        v=values[key]
        if type(v) not in (int,float) or not math.isfinite(v) or not lo<=v<=hi:
            raise ValueError(f'{name}.{key} must be finite in [{lo},{hi}]')
        if key.endswith('_strips') and type(v) is not int:raise ValueError(key+' must be an integer')
    if source and (not isinstance(values['source'],str) or not values['source'].strip() or len(values['source'])>1000):
        raise ValueError('environment source requires 1..1000 nonblank characters')
    return deepcopy(values)


def _vector(value,name,bound):
    if isinstance(value,(list,tuple)) and any(isinstance(x,(bool,np.bool_)) for x in value):
        raise ValueError(name+' does not accept boolean components')
    a=np.asarray(value)
    if a.shape!=(3,) or a.dtype.kind not in 'fiu':
        raise ValueError(name+' requires three finite numeric components')
    a=np.asarray(a,dtype=float) # avoid signed integer abs overflow before magnitude checks
    if not np.all(np.isfinite(a)) or np.max(np.abs(a))>bound:
        raise ValueError(f'{name} requires three finite numeric components with magnitude <= {bound}')
    return np.asarray(a,dtype=float)


def field_metadata():
    groups={name:{k:dict(min=v[0],max=v[1],default=v[2]) for k,v in b.items()} for name,b in
        [('environment',ENVIRONMENT),('controls',CONTROLS),('settings',SETTINGS)]}
    return dict(model_id=MODEL_ID,groups=groups,parameters=parameter_metadata(),
        defaults=dict(environment=default_environment(),controls=default_controls(),settings=default_settings()),
        assumed_domain=dict(max_local_mach=MAX_MACH,reynolds_range=[0,MAX_REYNOLDS],
            basis='Analyst exploratory screening; published component coverage is reported separately, not validation'),
        limitations=list(LIMITATIONS))


class FullAngleField:
    """Prepare fixed geometry/controls once; evaluate arbitrary body airflow/rates."""
    def __init__(self,definition,parameters=None,environment=None,controls=None,settings=None):
        self._definition=deepcopy(definition);validate_definition(self._definition)
        self._parameters=validate_parameters(default_parameters() if parameters is None else parameters)
        self._environment=_validate(default_environment() if environment is None else environment,ENVIRONMENT,'environment',True)
        self._controls=_validate(default_controls() if controls is None else controls,CONTROLS,'controls')
        self._settings=_validate(default_settings() if settings is None else settings,SETTINGS,'settings')
        if max(abs(self._controls['common_tail_deg']+sign*self._controls['differential_tail_deg']) for sign in [-1,1])>90:
            raise ValueError('Each combined tail deflection must be in [-90,90] deg')
        self._elements=self._geometry()
        self._positions=np.array([r['position_B_in'] for r in self._elements])
        self._snapshot=dict(model_id=MODEL_ID,definition=self._definition,parameters=self._parameters,
            environment=self._environment,controls=self._controls,settings=self._settings)
        self._configuration_sha256=digest(self._snapshot)

    @property
    def configuration_sha256(self):return self._configuration_sha256

    @property
    def configuration(self):return deepcopy(self._snapshot)

    def _geometry(self):
        g=self._definition['geometry'];elements=[]
        for kind in ['wing','tail']:
            wing=kind=='wing';length=g['wing_exposed_span_in']/2 if wing else g['tail_panel_length_in'];chord=g[kind+'_chord_in']
            ar=2*length/chord if wing else length/chord
            if not .01<=ar<=1000:raise ValueError(kind+' aspect ratio outside [.01,1000] model representation')
            cant=0 if wing else math.radians(g['tail_down_cant_deg'])
            edges=list(np.linspace(0,length,self._settings[kind+'_strips']+1))
            if wing:edges+= [g['aileron_inboard_from_root_in'],g['aileron_inboard_from_root_in']+g['aileron_span_in']]
            edges=sorted(set(edges))
            for side in [-1,1]:
                span=np.array([0.,math.cos(cant),side*math.sin(cant)]);normal=np.cross([1.,0.,0.],span)
                for lo,hi in zip(edges,edges[1:]):
                    mid=(lo+hi)/2;control_active=wing and g['aileron_inboard_from_root_in']<=mid<=g['aileron_inboard_from_root_in']+g['aileron_span_in']
                    delta=(-side*self._controls['aileron_deg']*self._settings['aileron_effectiveness'] if control_active else 0.) if wing else self._controls['common_tail_deg']-side*self._controls['differential_tail_deg']
                    angle=math.radians(self._controls[kind+'_incidence_deg']+delta)
                    c=math.cos(angle)*np.array([1.,0.,0.])-math.sin(angle)*normal
                    n=math.sin(angle)*np.array([1.,0.,0.])+math.cos(angle)*normal
                    position=[-g[kind+'_le_station_in']-chord/4,side*(g[kind+'_root_spacing_in']/2+mid*math.cos(cant)),
                        (g['wing_z_in'] if wing else g['tail_root_z_in'])+mid*math.sin(cant)]
                    elements.append(dict(name=f'{kind} {side:+d} strip {lo:g}..{hi:g}',kind=kind,side=side,
                        position_B_in=position,chord_in=chord,area_in2=(hi-lo)*chord,aspect_ratio=ar,
                        edge_area_in2=chord**2*self._parameters[kind+'_thickness_ratio']*(hi-lo)/length,
                        chord_unit_B=c,normal_unit_B=n,span_unit_B=span,control_incidence_deg=delta,
                        control_active=bool(control_active)))
        length=g['fuselage_length_in'];ds=length/self._settings['body_strips']
        for i in range(self._settings['body_strips']):
            station=(i+.5)*ds;diameter=g['forward_diameter_in']+(g['aft_diameter_in']-g['forward_diameter_in'])*station/length
            elements.append(dict(name=f'body crossflow strip {i}',kind='body-crossflow',position_B_in=[-station,0.,0.],
                area_in2=diameter*ds,reference_length_in=diameter))
        diameter=max(g['forward_diameter_in'],g['aft_diameter_in'])
        elements.append(dict(name='body axial drag',kind='body-axial',position_B_in=[-length/2,0.,0.],
            area_in2=math.pi*diameter**2/4,reference_length_in=diameter))
        elements.append(dict(name='fixed propulsion',kind='propulsion',position_B_in=[-g['prop_station_in'],0.,g['prop_z_in']]))
        return elements

    def evaluate(self,velocity_air_B_ft_s,omega_B_rad_s,cg_B_in):
        v=_vector(velocity_air_B_ft_s,'air velocity',1e6);omega=_vector(omega_B_rad_s,'angular rate',1e4);cg=_vector(cg_B_in,'CG',1e5)
        local=v+np.cross(omega,(self._positions-cg)/12)
        rho=self._environment['density_slug_ft3'];mu=self._environment['viscosity_slug_ft_s'];sound=self._environment['sound_speed_ft_s'];p=self._parameters
        ledger=[];violations=[];coverage=[]
        for element,flow in zip(self._elements,local):
            kind=element['kind'];force=np.zeros(3);couple=np.zeros(3);drag=np.zeros(3);details={}
            speed=float(np.linalg.norm(flow));mach=speed/sound;reynolds=None;reference=None
            if kind in ['wing','tail']:
                c,n,span=(element[k] for k in ['chord_unit_B','normal_unit_B','span_unit_B'])
                vc,vn,vs=float(flow@c),float(flow@n),float(flow@span);plane=math.hypot(vc,vn)
                alpha=None if plane<=ZERO_SPEED else math.degrees(math.atan2(vn,vc))
                q=0. if alpha is None else .5*rho*plane**2;area=element['area_in2']/144;polar=None
                if alpha is not None:
                    polar=_section_polar(alpha,kind,p,element['aspect_ratio'])
                    lift=q*area*polar['cl']*(vn*c-vc*n)/plane
                    drag_plane=-q*area*polar['cd']*(vc*c+vn*n)/plane
                    force=lift+drag_plane;drag+=drag_plane
                    couple=q*area*element['chord_in']*polar['cm_quarter_chord']*span
                edge=-.5*rho*p['edge_cd']*element['edge_area_in2']/144*abs(vs)*vs*span
                force+=edge;drag+=edge
                reynolds=rho*plane*element['chord_in']/12/mu if q>0 else None
                reference=(360000,700000)
                details=dict(alpha_deg=alpha,plane_speed_ft_s=plane,span_speed_ft_s=vs,polar=polar,
                    area_in2=element['area_in2'],edge_area_in2=element['edge_area_in2'],
                    chord_unit_B=c.tolist(),normal_unit_B=n.tolist(),span_unit_B=span.tolist(),
                    control_incidence_deg=element['control_incidence_deg'],control_active=element['control_active'])
            elif kind.startswith('body-'):
                cross=kind=='body-crossflow';direction=flow*np.array([0,1,1] if cross else [1,0,0]);flow_speed=float(np.linalg.norm(direction))
                coefficient=p['body_crossflow_cd' if cross else 'body_axial_cd']
                force=-.5*rho*element['area_in2']/144*coefficient*flow_speed*direction;drag=force.copy()
                reynolds=rho*flow_speed*element['reference_length_in']/12/mu if rho>0 and flow_speed>ZERO_SPEED else None
                reference=(300000,1650000) if cross else None
                details=dict(area_in2=element['area_in2'],reference_length_in=element['reference_length_in'],coefficient=coefficient)
            else:
                force=np.array([self._controls['thrust_lbf'],0.,0.]);couple=np.array([self._controls['prop_torque_in_lbf'],0.,0.])
            if kind!='propulsion' and rho>0:
                if mach>MAX_MACH:violations.append(element['name']+f': local Mach {mach:g} exceeds assumed {MAX_MACH}')
                if reynolds is not None and reynolds>MAX_REYNOLDS:violations.append(element['name']+f': Reynolds {reynolds:g} exceeds assumed {MAX_REYNOLDS:g}')
            covered=None if reference is None or reynolds is None else reference[0]<=reynolds<=reference[1]
            if covered is False:coverage.append(element['name']+': Reynolds outside published component comparison range; coefficient continuation is unvalidated')
            moment=np.cross(np.array(element['position_B_in'])-cg,force)+couple
            ledger.append(dict(name=element['name'],kind=kind,position_B_in=list(element['position_B_in']),local_velocity_B_ft_s=flow.tolist(),
                force_B_lbf=force.tolist(),free_couple_B_in_lbf=couple.tolist(),moment_about_CG_in_lbf=moment.tolist(),
                drag_B_lbf=drag.tolist(),drag_power_lbf_ft_s=float(drag@flow),couple_power_lbf_ft_s=float(couple@omega/12),
                local_mach=mach,reynolds=reynolds,reference_Re_range=None if reference is None else list(reference),within_reference_Re_range=covered,**details))
        return dict(model_id=MODEL_ID,configuration_sha256=self._configuration_sha256,
            state_sha256=digest(dict(velocity_air_B_ft_s=v.tolist(),omega_B_rad_s=omega.tolist(),cg_B_in=cg.tolist())),cg_B_in=cg.tolist(),velocity_air_B_ft_s=v.tolist(),omega_B_rad_s=omega.tolist(),
            ledger=ledger,non_gravity_force_B_lbf=np.sum([r['force_B_lbf'] for r in ledger],axis=0).tolist(),
            moment_about_CG_B_in_lbf=np.sum([r['moment_about_CG_in_lbf'] for r in ledger],axis=0).tolist(),
            drag_power_lbf_ft_s=sum(r['drag_power_lbf_ft_s'] for r in ledger),
            empirical_couple_power_lbf_ft_s=sum(r['couple_power_lbf_ft_s'] for r in ledger if r['kind']!='propulsion'),
            within_assumed_domain=not violations,domain_violations=violations,reference_coverage_gaps=coverage,
            limitations=list(LIMITATIONS),units='ft/s, rad/s, in, in^2, lbf, in-lbf; power lbf*ft/s')

    def report(self,velocity_air_B_ft_s,omega_B_rad_s,cg_B_in):
        result=self.evaluate(velocity_air_B_ft_s,omega_B_rad_s,cg_B_in)
        root=Path(__file__).parent
        out=dict(schema='full-angle-force-evidence-v1',configuration=deepcopy(self._snapshot),
            metadata=field_metadata(),field=result,component_evidence=component_comparison(self._parameters),
            implementation_sha256={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in
                ['aircraft_full_angle_field.py','aircraft_full_angle_polar.py','aircraft_workspace.py','aircraft_input_limits.py','aircraft_elastic.py']})
        out['report_sha256']=digest(out)
        return out
