"""Local longitudinal verification of the illustrative aircraft model.

State [u,w,q,theta] uses ft/s, ft/s, rad/s, rad. This reduced planar system is
a verification model; production nonlinear runs retain quaternion propagation.
No new aerodynamic data or actual-aircraft validation is implied.
"""
from copy import deepcopy
import math
import numpy as np

from .aircraft_workspace import evaluate_aircraft, example_definition, stable_example_definition, G_IN_S2
from .aircraft_flight import _field, atmosphere, default_condition
from .aircraft_transient import default_settings, run_transient, pulse, mass_quadrature, IN_LBF_NM

STATE_NAMES = ['u_B', 'w_B', 'q_B', 'theta']
STATE_UNITS = ['ft/s', 'ft/s', 'rad/s', 'rad']
STATE_DISPLAY_UNITS = ['ft/s', 'ft/s', 'deg/s', 'deg']
DISPLAY_SCALE = np.array([1., 1., 180/math.pi, 180/math.pi])
DERIVATIVE_STEPS = np.array([.001, .001, 1e-5, 1e-5, 1e-5])
RESPONSE_TOLERANCE = np.array([.001, .001, .001, .0001])
CONVERGENCE_TOLERANCE = np.array([1e-5, 1e-4, 1e-5, 1e-5, 1e-5, 1e-4, 1e-4, 1e-4])
MODE_REAL_TOLERANCE = 1e-6


def analytic_aero_derivatives(d, mp, state, delta_deg):
    """Independent chain-rule [X,Z,My] derivatives wrt [u,w,q,delta_rad].

    Forces exclude gravity. Point velocities and dynamic pressures vary with
    u,w,q; geometry, density, thrust and installed incidence remain fixed.
    """
    u, w, q, _ = state
    g, c = d['geometry'], d['flight_condition']
    rho = c['density_override_slug_ft3']
    if rho is None:
        rho = atmosphere(c['altitude_ft'])['density_slug_ft3']
    cc = math.cos(math.radians(g['tail_down_cant_deg']))
    surfaces = []
    for station, z in [(g['wing_load_station_in'], g['wing_z_in']),
                       (g['tail_load_station_in'], g['tail_root_z_in'])]:
        rx = (-station-mp['cg_B_in'][0])/12
        rz = (z-mp['cg_B_in'][2])/12
        vx, vz = u+q*rz, w-q*rx
        dx, dz = np.array([1., 0., rz, 0.]), np.array([0., 1., -rx, 0.])
        a = math.atan2(vz, vx)
        da = (vx*dz-vz*dx)/(vx*vx+vz*vz)
        pressure = .5*rho*(vx*vx+vz*vz)/144
        dp = rho*(vx*dx+vz*dz)/144
        surfaces.append((a, da, pressure, dp, rx*12, rz*12))
    aw = surfaces[0][0]+math.radians(c['wing_incidence_deg'])
    daw = surfaces[0][1]
    at = ((surfaces[1][0]-c['downwash_gradient']*aw)*cc
          + math.radians(c['tail_incidence_deg']+delta_deg))
    dat = (surfaces[1][1]-c['downwash_gradient']*daw)*cc+np.array([0., 0., 0., 1.])
    sw = g['wing_exposed_span_in']*g['wing_chord_in']
    st = g['tail_panel_length_in']*g['tail_chord_in']
    coefficients = [
        (c['wing_cl0']+c['wing_cl_alpha_per_rad']*aw, c['wing_cl_alpha_per_rad']*daw,
         c['wing_cd0'], g['wing_exposed_span_in']**2/sw, c['wing_efficiency'], sw, 1.),
        (c['tail_cl_alpha_per_rad']*at, c['tail_cl_alpha_per_rad']*dat,
         c['tail_cd0'], g['tail_panel_length_in']**2/st, c['tail_efficiency'], 2*st, cc)]
    derivative = np.zeros((3, 4))
    for surface, coefficient in zip(surfaces, coefficients):
        a, da, pressure, dp, rx, rz = surface
        cl, dcl, cd0, ar, efficiency, area, projection = coefficient
        cd = cd0+cl*cl/(math.pi*ar*efficiency)
        dcd = 2*cl*dcl/(math.pi*ar*efficiency)
        lift, drag = pressure*area*cl*projection, pressure*area*cd
        d_lift = area*projection*(dp*cl+pressure*dcl)
        d_drag = area*(dp*cd+pressure*dcd)
        d_x = (math.sin(a)*d_lift-math.cos(a)*d_drag
               +(lift*math.cos(a)+drag*math.sin(a))*da)
        d_z = (-math.cos(a)*d_lift-math.sin(a)*d_drag
               +(lift*math.sin(a)-drag*math.cos(a))*da)
        derivative[0] += d_x
        derivative[1] += d_z
        derivative[2] += rz*d_x-rx*d_z
    derivative[2] += surfaces[0][3]*sw*g['wing_chord_in']*c['wing_cm0']
    return derivative


class LongitudinalModel:
    """One feasible steady-level trim with fixed density and propulsion."""
    def __init__(self, definition):
        self.definition = deepcopy(definition)
        self.workspace = evaluate_aircraft(self.definition)
        self.mp = self.workspace['mass_properties']
        flight = self.workspace['flight_condition']
        if self.mp is None or not flight or not (flight.get('trim') or {}).get('feasible'):
            raise ValueError('Longitudinal verification requires feasible trim and complete mass')
        if abs(self.workspace['load_case']['a_up_g']) > 1e-12:
            raise ValueError('Longitudinal verification requires steady 1-g initialization')
        self.trim = flight['trim']
        mass = mass_quadrature(self.workspace['resolved_components'])
        mass.require_rigid_inertia()
        if np.max(np.abs(mass.inertia_CG_B_kg_m2[[0, 1], [1, 2]])) > 1e-10:
            raise ValueError('Longitudinal verification requires zero xy/yz inertia coupling')
        self.inertia = self.mp['inertia_CG'][1][1]
        if not math.isclose(mass.inertia_CG_B_kg_m2[1, 1], self.inertia*IN_LBF_NM, rel_tol=1e-10):
            raise ValueError('Component inertia and quadrature disagree')
        self.g = G_IN_S2/12
        self.mass_slug = self.mp['weight_lbf']/self.g
        theta = math.radians(self.trim['alpha_deg'])
        speed = self.definition['flight_condition']['speed_ft_s']
        self.state0 = np.array([speed*math.cos(theta), speed*math.sin(theta), 0., theta])

    def field(self, state, increment_rad=0.):
        u, w, q, theta = np.asarray(state, dtype=float)
        if not np.isfinite([u, w, q, theta, increment_rad]).all():
            raise ValueError('Nonfinite longitudinal state')
        c = {**self.definition['flight_condition'], 'speed_ft_s':math.hypot(u, w)}
        field = _field(self.definition, self.mp, c, math.degrees(math.atan2(w, u)),
                       self.trim['ruddervator_deg']+math.degrees(increment_rad),
                       self.trim['thrust_lbf'], flow_B_ft_s=[u, 0, w], omega_B_rad_s=[0, q, 0])
        if field['domain_violations']:
            raise ValueError('; '.join(field['domain_violations']))
        return field

    def rhs(self, state, increment_rad=0.):
        u, w, q, theta = state
        field = self.field(state, increment_rad)
        x, _, z = field['non_gravity_force_B_lbf']
        return np.array([x/self.mass_slug-self.g*math.sin(theta)-q*w,
                         z/self.mass_slug+self.g*math.cos(theta)+q*u,
                         field['moment_about_CG_B_in_lbf'][1]/self.inertia, q])

    def analytic_jacobian(self):
        self.field(self.state0)
        u, w, q, theta = self.state0
        aero = analytic_aero_derivatives(self.definition, self.mp, self.state0,
                                        self.trim['ruddervator_deg'])
        jac = np.zeros((4, 5))
        for row, divisor in [(0, self.mass_slug), (1, self.mass_slug), (2, self.inertia)]:
            jac[row, :3] = aero[row, :3]/divisor
            jac[row, 4] = aero[row, 3]/divisor
        jac[0, 1] -= q
        jac[0, 2] -= w
        jac[0, 3] = -self.g*math.cos(theta)
        jac[1, 0] += q
        jac[1, 2] += u
        jac[1, 3] = -self.g*math.sin(theta)
        jac[3, 2] = 1.
        return jac

    def numeric_jacobian(self, step_factor=1.):
        if not math.isfinite(step_factor) or step_factor <= 0:
            raise ValueError('Derivative step factor must be positive')
        base = np.r_[self.state0, 0.]
        columns = []
        for axis, step in enumerate(DERIVATIVE_STEPS*step_factor):
            plus, minus = base.copy(), base.copy()
            plus[axis] += step
            minus[axis] -= step
            columns.append((self.rhs(plus[:4], plus[4])-self.rhs(minus[:4], minus[4]))/(2*step))
        return np.column_stack(columns)

    def linearization(self):
        analytic = self.analytic_jacobian()
        numeric = [self.numeric_jacobian(factor) for factor in (1., .5)]
        errors = [np.abs(jac-analytic) for jac in numeric]
        tolerances = [1e-8+1e-6*np.maximum(np.abs(jac), np.abs(analytic)) for jac in numeric]
        step_error = np.abs(numeric[0]-numeric[1])
        step_tolerance = 1e-8+1e-6*np.maximum(np.abs(numeric[0]), np.abs(numeric[1]))
        verified = all(np.all(error <= tol) for error,tol in zip(errors,tolerances))
        residual = self.rhs(self.state0)
        residual_tolerance = np.array([1e-5, 1e-5, 1e-5, 1e-12])
        verified = bool(verified and np.all(step_error <= step_tolerance)
                        and np.all(np.abs(residual) <= residual_tolerance))
        eigenvalues = np.linalg.eigvals(analytic[:, :4])
        real = eigenvalues.real
        tendency = ('unstable' if np.max(real) > MODE_REAL_TOLERANCE else
                    'locally-asymptotically-stable' if np.max(real) < -MODE_REAL_TOLERANCE
                    else 'near-neutral-or-indeterminate')
        modes = [dict(real_per_s=float(v.real), imag_per_s=float(v.imag),
                      period_s=None if abs(v.imag) < 1e-12 else float(2*math.pi/abs(v.imag)),
                      e_fold_time_s=None if abs(v.real) < MODE_REAL_TOLERANCE else float(1/abs(v.real)))
                 for v in eigenvalues]
        return dict(state_names=STATE_NAMES, state_units=STATE_UNITS,
                    input_name='ruddervator increment', input_unit='rad',
                    state0=self.state0.tolist(), rhs_at_trim=residual.tolist(),
                    allowed_trim_rhs=residual_tolerance.tolist(),
                    A=analytic[:, :4].tolist(), B=analytic[:, 4].tolist(),
                    numeric_jacobians=[j.tolist() for j in numeric],
                    derivative_steps=DERIVATIVE_STEPS.tolist(),
                    derivative_tolerances=[t.tolist() for t in tolerances],
                    derivative_step_tolerance=step_tolerance.tolist(),
                    derivative_tolerance_rule='Elementwise 1e-8 + 1e-6*max(abs(analytic),abs(numeric)); analogous rule for step comparison',
                    derivative_max_errors=[float(np.max(e)) for e in errors],
                    derivative_step_max_error=float(np.max(step_error)),
                    derivative_verified=verified, modes=modes if verified else [],
                    dynamic_tendency=tendency if verified else 'withheld-unverified-derivatives',
                    mode_real_tolerance_per_s=MODE_REAL_TOLERANCE,
                    static_stability=self.workspace['flight_condition']['static_stability']['trim'],
                    note='Four local longitudinal states exclude position gauge modes. Eigenvalues assess this assumed linear model; short nonlinear traces do not demonstrate slow-mode decay or actual-aircraft stability.')


def linear_history(A, B, times, settings, initial=None):
    """RK4 of dx/dt=A*dx+B*delta(t), on supplied pulse-split accepted times."""
    A, B = np.asarray(A), np.asarray(B)
    state = np.zeros(4) if initial is None else np.asarray(initial, dtype=float).copy()
    history = [state.copy()]
    def rhs(t, x):
        return A@x+B*math.radians(pulse(t, settings))
    for start, end in zip(times, times[1:]):
        if end <= start:
            raise ValueError('Linear history times must increase')
        for event in (settings['pulse_start_s'], settings['pulse_end_s']):
            if start < event < end:
                raise ValueError('Linear history must split exactly at pulse boundaries')
        h = end-start
        k1 = rhs(start, state)
        k2 = rhs(start+h/2, state+h*k1/2)
        k3 = rhs(start+h/2, state+h*k2/2)
        k4 = rhs(end, state+h*k3)
        state = state+h*(k1+2*k2+2*k3+k4)/6
        history.append(state.copy())
    return np.array(history)


def state_history(run):
    return np.array([[f['velocity_B_ft_s'][0], f['velocity_B_ft_s'][2],
                      math.radians(f['angular_velocity_B_deg_s'][1]),
                      math.radians(f['pitch_deg'])] for f in run['snapshots']])


def comparison_case(definition, amplitude_deg=.01, dt_s=.001, duration_s=.5):
    d = deepcopy(definition)
    d['transient_case'] = {**default_settings(), 'duration_s':duration_s,
                           'dt_s':dt_s, 'ruddervator_pulse_deg':amplitude_deg}
    model = LongitudinalModel(d)
    linear = model.linearization()
    run = run_transient(d)
    times = [f['time_s'] for f in run['snapshots']]
    predicted = linear_history(linear['A'], linear['B'], times, d['transient_case'])
    actual = state_history(run)-model.state0
    discrepancy = np.max(np.abs((actual-predicted)*DISPLAY_SCALE), axis=0)
    response_scale = np.array([d['flight_condition']['speed_ft_s']]*2+[1., 1.])
    scaled = float(np.max(np.abs(actual-predicted)/response_scale))
    verified = bool(run['status']=='completed' and linear['derivative_verified']
                    and np.all(discrepancy <= RESPONSE_TOLERANCE))
    return dict(definition=d, input_sha256=run['input_sha256'], status=run['status'],
                event=run['event'], initialization='independently recomputed steady 1-g trim',
                linearization=linear, time_s=times,
                nonlinear_delta=(actual*DISPLAY_SCALE).tolist(),
                linear_delta=(predicted*DISPLAY_SCALE).tolist(), display_units=STATE_DISPLAY_UNITS,
                max_abs_discrepancy=discrepancy.tolist(), allowed_discrepancy=RESPONSE_TOLERANCE.tolist(),
                amplitude_normalized_discrepancy=scaled/abs(math.radians(amplitude_deg)) if amplitude_deg else None,
                verified=verified, nonlinear_run=run)


def convergence_case(definition):
    runs = []
    for dt in (.01, .005, .0025):
        d = deepcopy(definition)
        d['transient_case'] = {**default_settings(), 'duration_s':.5,
                               'dt_s':dt, 'ruddervator_pulse_deg':.01}
        runs.append(run_transient(d))
    def rows(run):
        return {round(f['time_s'], 10):np.array([f['pitch_deg'], f['angular_velocity_B_deg_s'][1],
                *f['loads']['cut_force_B_lbf'], *f['loads']['cut_moment_B_in_lbf']])
                for f in run['snapshots']}
    grids = [rows(run) for run in runs]
    common = sorted(set(grids[0]) & set(grids[1]) & set(grids[2]))
    errors = [np.max([np.abs(grids[i][t]-grids[i+1][t]) for t in common], axis=0)
              for i in (0, 1)]
    reduced = all(errors[0][i] <= 1e-10 or errors[1][i] <= errors[0][i]/4 for i in (1, 6))
    complete = all(run['status']=='completed' for run in runs)
    return dict(dt_s=[.01, .005, .0025], common_time_s=common,
                quantities=['pitch_deg','q_deg_s','Fx_lbf','Fy_lbf','Fz_lbf','Mx_in_lbf','My_in_lbf','Mz_in_lbf'],
                coarse_medium_error=errors[0].tolist(), medium_fine_error=errors[1].tolist(),
                allowed_medium_fine_error=CONVERGENCE_TOLERANCE.tolist(),
                q_and_My_error_reduced=bool(reduced),
                verified=bool(complete and reduced and np.all(errors[1] <= CONVERGENCE_TOLERANCE)),
                statuses=[run['status'] for run in runs], events=[run['event'] for run in runs],
                input_sha256=[run['input_sha256'] for run in runs], runs=runs)


def study_definition(aft_fraction, speed_ft_s):
    """Consistent component moves, never direct CG or inertia overrides."""
    if not 0 <= aft_fraction <= 1:
        raise ValueError('Aft fraction must be in [0,1]')
    d = example_definition()
    d['name'] = f'Illustrative CG study: aft fraction {aft_fraction:g}, speed {speed_ft_s:g} ft/s'
    d['flight_condition'] = {**default_condition(), 'speed_ft_s':speed_ft_s}
    d['transient_case'] = {**default_settings(), 'duration_s':.5, 'ruddervator_pulse_deg':.01}
    for component in d['components']:
        if component['id']=='battery':
            component['station_in'] = 3+4*aft_fraction
        if component['id']=='payload':
            component['station_in'] = 6*aft_fraction
    d['assumptions'].append('Deterministic study only: battery station=3+4*f in, payload station=6*f in; weights unchanged. Each speed/layout is retrimmed, not a common-control launch disturbance.')
    return d


def run_study():
    """Declared deterministic pilot; retain all nine grid cases and failures."""
    comparisons, convergence = {}, {}
    for name, definition in [('original', example_definition()), ('stable', stable_example_definition())]:
        definition['flight_condition'] = default_condition()
        cases = [comparison_case(definition, amplitude) for amplitude in (.01, .005, .0025)]
        normalized = [case['amplitude_normalized_discrepancy'] for case in cases]
        # A nontrivial error must decrease as amplitude decreases; roundoff is reported.
        decreasing = all(b < a or max(a, b) < 1e-7 for a,b in zip(normalized, normalized[1:]))
        comparisons[name] = dict(cases=cases, amplitude_normalized_discrepancy=normalized,
                                 amplitude_trend_verified=decreasing)
        convergence[name] = convergence_case(definition)
    grid = []
    for fraction in (0., .5, 1.):
        for speed in (150., 200., 250.):
            d = study_definition(fraction, speed)
            workspace = evaluate_aircraft(d)
            trim = workspace['flight_condition']['trim']
            entry = dict(id=f'f{fraction:g}-v{speed:g}', aft_fraction=fraction, speed_ft_s=speed,
                         definition=d, mass_properties=workspace['mass_properties'], trim=trim,
                         initialization='retrim each case independently; no common-control experiment',
                         status='trim-infeasible', linearization=None, run=None, load_extrema=None)
            if trim['feasible']:
                try:
                    entry['linearization'] = LongitudinalModel(d).linearization()
                    entry['run'] = run_transient(d)
                    run = entry['run']
                    entry['status'] = run['status']
                    # Preserve concurrent vectors and source time for each scalar extreme.
                    extrema = []
                    for key in ('cut_force_B_lbf', 'cut_moment_B_in_lbf'):
                        for axis in range(3):
                            index = max(range(len(run['snapshots'])), key=lambda i:abs(run['snapshots'][i]['loads'][key][axis]))
                            frame = run['snapshots'][index]
                            extrema.append(dict(selected_quantity=key, axis=axis, snapshot_index=index,
                                time_s=frame['time_s'], force_B_lbf=frame['loads']['cut_force_B_lbf'],
                                moment_B_in_lbf=frame['loads']['cut_moment_B_in_lbf']))
                    entry['load_extrema'] = dict(scope='completed event' if run['status']=='completed' else 'accepted prefix only; not full event maximum', cases=extrema)
                except ValueError as error:
                    entry['status'] = 'verification-unavailable'
                    entry['reason'] = str(error)
            grid.append(entry)
    verified = (all(c['amplitude_trend_verified'] and all(v['verified'] for v in c['cases'])
                    for c in comparisons.values()) and all(c['verified'] for c in convergence.values())
                and all(e['status']=='trim-infeasible' or (e['status']=='completed' and
                    e['linearization'] is not None and e['linearization']['derivative_verified']) for e in grid))
    return dict(schema_version=1, verification_passed=bool(verified),
                scope='Illustrative fixed-configuration longitudinal numerical verification; not a probability envelope, actual-aircraft validation or structural sizing acceptance.',
                initialization='Every layout/speed is retrimmed independently. Common-control disturbances are a different study.',
                comparisons=comparisons, convergence=convergence, grid=grid)


def save_study(study, output):
    """New-directory artifact: readable summary plus lossless compressed runs."""
    import gzip
    import json
    from pathlib import Path
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    (output/'runs').mkdir()
    def save_run(name, run):
        filename = 'runs/'+name+'.json.gz'
        encoded = json.dumps(run, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
        (output/filename).write_bytes(gzip.compress(encoded, mtime=0))
        return filename
    summary = {key:value for key,value in study.items() if key not in ('comparisons', 'convergence', 'grid')}
    summary['comparisons'] = {}
    summary['convergence'] = {}
    summary['grid'] = []
    for name, group in study['comparisons'].items():
        cases = []
        for index, case in enumerate(group['cases']):
            row = {key:value for key,value in case.items() if key != 'nonlinear_run'}
            row['run_file'] = save_run(f'{name}-amplitude-{index}', case['nonlinear_run'])
            cases.append(row)
        summary['comparisons'][name] = {**group, 'cases':cases}
    for name, group in study['convergence'].items():
        row = {key:value for key,value in group.items() if key != 'runs'}
        row['run_files'] = [save_run(f'{name}-dt-{index}', run) for index,run in enumerate(group['runs'])]
        summary['convergence'][name] = row
    for case in study['grid']:
        row = {key:value for key,value in case.items() if key != 'run'}
        row['run_file'] = None if case['run'] is None else save_run('grid-'+case['id'], case['run'])
        summary['grid'].append(row)
    (output/'study.json').write_text(json.dumps(summary, indent=2, allow_nan=False)+'\n')
    return summary


def main(argv=None):
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args(argv)
    if args.output.exists():
        parser.error('Output directory already exists; choose a new path')
    study = run_study()
    save_study(study, args.output)
    print(f'Longitudinal study: {args.output}/study.json; verification_passed={study["verification_passed"]}')
    return 0 if study['verification_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
