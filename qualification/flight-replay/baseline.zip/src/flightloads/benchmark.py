"""Reproducible prescribed-couple benchmark: run/rerun CLI and artifact export."""
import argparse
import csv
import hashlib
import json
import platform
import subprocess
import sys
import uuid
import zipfile
from collections.abc import Mapping
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path
import numpy as np
from .benchmark_core import BenchmarkConfig, run_benchmark, BenchmarkResult
from ._arrays import readonly_copy
from .benchmark_report import render_report, render_plots

FILES = ('histories.npz', 'history.csv', 'report.html', 'plots.svg')
MAX_BYTES = 64*1024*1024
MANIFEST_KEYS = {'schema_version', 'model_id', 'run_id', 'created_utc', 'configuration',
                 'provenance', 'model', 'numerics', 'verification', 'status', 'artifacts', 'comparison'}


def plain(value):
    if isinstance(value, Mapping):
        return {k: plain(v) for k,v in value.items()}
    if isinstance(value, (tuple, list)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def code_identity():
    root = Path(__file__).resolve().parents[2]
    identity = dict(package_version=version('flight-loads'), python=platform.python_version(),
                    numpy=np.__version__, git_revision=None, git_dirty=None,
                    git_status='unavailable', input_provenance='generic analytical reference; SI inputs')
    if (root/'.git').exists():
        try:
            def git(*args):
                return subprocess.check_output(['git','-C',str(root),*args],text=True,
                                               stderr=subprocess.DEVNULL,timeout=5).strip()
            identity.update(git_revision=git('rev-parse','HEAD'),
                            git_dirty=bool(git('status','--porcelain')),git_status='available')
        except (OSError, subprocess.SubprocessError):
            pass
    return identity


def payload(result):
    return dict(times_s=result.simulation.times_s, states=result.simulation.states, **result.arrays)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()



def model_metadata(result):
    return plain(dict(
                        masses_kg=result.mass_model.masses_kg,
                        locations_CG_B_m=result.mass_model.rho_B_m,
                        inertia_CG_B_kg_m2=result.mass_model.inertia_CG_B_kg_m2,
                        applied_locations_CG_B_m=result.applied_loads.locations_CG_B_m,
                        applied_forces_non_gravity_B_N=result.applied_loads.forces_non_gravity_B_N,
                        applied_couples_B_Nm=result.applied_loads.couples_B_Nm,
                        source_ids=result.applied_loads.source_ids,
                        cut_id=result.cut.cut_id,cut_point_CG_B_m=result.cut.point_CG_B_m,
                        cut_normal_B=result.cut.normal_B,cut_on_plane_policy=result.cut.on_plane_policy,
                        cut_incidence_tolerance_m=result.cut.incidence_tolerance_m,
                        constant_data_policy='model mass/applied records apply at every saved time',
                        units='SI; array names encode units; quaternion dimensionless',
                        state_order='r_CG_N_m[3], v_CG_B_mps[3], q_NB[4], omega_B_radps[3]'))

def export_benchmark(result, output_dir, *, comparison=None):
    """Create a fresh directory. Completed-but-unverified runs retain evidence."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    data = payload(result)
    np.savez_compressed(output/FILES[0], **data)
    n = len(data['times_s'])
    columns = {'time_s': data['times_s']}
    state_names = ['r_N_x_m','r_N_y_m','r_N_z_m','v_B_x_mps','v_B_y_mps','v_B_z_mps',
                   'q_NB_s','q_NB_x','q_NB_y','q_NB_z','omega_B_x_radps','omega_B_y_radps','omega_B_z_radps']
    columns.update({name:data['states'][:,i] for i,name in enumerate(state_names)})
    for name, array in result.arrays.items():
        if array.ndim == 1:
            columns[name] = array
        else:
            for index in np.ndindex(array.shape[1:]):
                columns[name+'_'+('_'.join(map(str,index)))] = array[(slice(None),*index)]
    for name, vector in [('applied_force_B_N',result.applied_loads.forces_non_gravity_B_N[0]),
                         ('applied_couple_B_Nm',result.applied_loads.couples_B_Nm[0])]:
        for i,axis in enumerate('xyz'):
            columns[name+'_'+axis] = np.full(n,vector[i])
    with (output/FILES[1]).open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(columns)
        writer.writerows(zip(*columns.values()))
    manifest = dict(schema_version=1, model_id='prescribed-couple-v1', run_id=str(uuid.uuid4()),
                    created_utc=datetime.now(timezone.utc).isoformat(), configuration=result.config.to_dict(),
                    provenance=code_identity(), model=model_metadata(result),
                    numerics=dict(method='RK4',requested_dt_s=result.config.dt_s,
                        initial_quaternion_norm=result.simulation.initial_quaternion_norm,
                        normalization='raw stages; initial and accepted states normalized',
                        postprocessing='providers and RHS reevaluated at saved states'),
                    verification=plain(result.verification), status=dict(run='completed',
                        numerical_verification='passed' if result.numerically_verified else 'failed',
                        model_validation='not_performed',design_acceptance='not_performed'),
                    artifacts={}, comparison=comparison)
    manifest=plain(manifest)
    svg=render_plots(result)
    (output/'plots.svg').write_text(svg,encoding='utf-8')
    manifest['provenance']['matplotlib']=version('matplotlib')
    (output/FILES[2]).write_text(render_report(result,manifest,svg),encoding='utf-8')
    manifest['artifacts']={name:dict(sha256=_sha(output/name),bytes=(output/name).stat().st_size) for name in FILES}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return manifest


def _read_benchmark(manifest_path, *, max_steps=20000):
    path=Path(manifest_path)
    if path.stat().st_size > 1024*1024:
        raise ValueError('manifest too large')
    manifest=json.loads(path.read_text(encoding='utf-8'))
    if (not isinstance(manifest,dict) or set(manifest)!=MANIFEST_KEYS
            or type(manifest['schema_version']) is not int or manifest['schema_version']!=1
            or manifest['model_id']!='prescribed-couple-v1' or set(manifest['artifacts'])!=set(FILES)):
        raise ValueError('unsupported manifest schema or model')
    config=BenchmarkConfig.from_dict(manifest['configuration'])
    if config.dt_s*max_steps < config.duration_s:
        raise ValueError(f'saved case exceeds {max_steps} steps')
    for name in FILES:
        artifact=path.parent/name
        if artifact.is_symlink() or artifact.stat().st_size > MAX_BYTES:
            raise ValueError('artifact is a symlink or exceeds size limit')
        if (artifact.stat().st_size != manifest['artifacts'][name]['bytes']
                or _sha(artifact)!=manifest['artifacts'][name]['sha256']):
            raise ValueError(f'artifact hash mismatch: {name}')
    fresh=run_benchmark(config)
    if manifest['model'] != model_metadata(fresh):
        raise ValueError('saved model metadata differs from the declared reference model')
    expected=payload(fresh)
    with zipfile.ZipFile(path.parent/FILES[0]) as archive:
        info=archive.infolist()
        if (len(info)!=len(expected) or {i.filename for i in info}!={key+'.npy' for key in expected}
                or sum(i.file_size for i in info)>MAX_BYTES):
            raise ValueError('invalid or oversized numeric archive')
    differences={}
    arrays={}
    with np.load(path.parent/FILES[0],allow_pickle=False) as stored:
        for name, reference in expected.items():
            value=stored[name]
            if value.dtype!=np.float64 or value.shape!=reference.shape or not np.all(np.isfinite(value)):
                raise ValueError(f'invalid numeric history: {name}')
            arrays[name]=readonly_copy(value)
            differences[name]=dict(max_abs_error=float(np.max(np.abs(value-reference))),
                                   passed=bool(np.allclose(value,reference,atol=1e-9,rtol=1e-10)))
    return manifest,fresh,arrays,differences


def load_benchmark(manifest_path, *, max_steps=20000):
    """Reopen saved data only after integrity and reproduction checks; no writes."""
    manifest,fresh,arrays,differences=_read_benchmark(manifest_path,max_steps=max_steps)
    if not all(v['passed'] for v in differences.values()):
        raise ValueError('saved histories did not reproduce within atol=1e-9, rtol=1e-10')
    metrics=BenchmarkResult._verify_histories(arrays['states'],arrays)
    manifest['reopen_check']=dict(code=code_identity(),atol=1e-9,rtol=1e-10,
                                  max_abs_difference=max(v['max_abs_error'] for v in differences.values()))
    manifest['verification']=plain(metrics)
    manifest['status']=dict(run='completed',numerical_verification=(
        'passed' if all(m['passed'] for m in metrics.values()) else 'failed'),
        model_validation='not_performed',design_acceptance='not_performed')
    return manifest,arrays


def rerun_benchmark(manifest_path, output_dir):
    manifest,fresh,arrays,differences=_read_benchmark(manifest_path)
    comparison=dict(source_run_id=manifest['run_id'],source_provenance=manifest['provenance'],
                    atol=1e-9,rtol=1e-10,arrays=differences,
                    passed=all(v['passed'] for v in differences.values()))
    return export_benchmark(fresh,output_dir,comparison=comparison)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    run=sub.add_parser('run');run.add_argument('--output',required=True)
    for arg,default in [('duration',2.),('dt',.01),('alpha',1.),('gravity',9.81)]:
        run.add_argument('--'+arg,type=float,default=default)
    rerun=sub.add_parser('rerun');rerun.add_argument('--manifest',required=True);rerun.add_argument('--output',required=True)
    args=parser.parse_args(argv)
    try:
        if args.command=='run':
            config=BenchmarkConfig(duration_s=args.duration,dt_s=args.dt,alpha_radps2=args.alpha,g_mps2=args.gravity)
            manifest=export_benchmark(run_benchmark(config),args.output)
        else:
            manifest=rerun_benchmark(args.manifest,args.output)
    except (ValueError,TypeError,KeyError,OSError,RuntimeError,zipfile.BadZipFile) as error:
        parser.exit(2,f'benchmark error: {error}\n')
    print(json.dumps(dict(output=str(Path(args.output).resolve()),run_id=manifest['run_id'],status=manifest['status'],
                         reproduced=None if manifest['comparison'] is None else manifest['comparison']['passed'])))
    return 0 if (manifest['status']['numerical_verification']=='passed'
                 and (manifest['comparison'] is None or manifest['comparison']['passed'])) else 1


if __name__=='__main__':
    raise SystemExit(main())
